# Payment Hub — Audit Module (Production-Grade Implementation)

## Architecture Overview

This is the first module implementation for the Modern Payment Hub platform. It implements the complete tamper-proof audit subsystem designed across the [8-document design suite](../platform-architecture-reference.md).

```
┌──────────────────────────────────────────────────────────────┐
│  PAYMENT HUB MODULES (any module)                            │
│  Include: hub-audit-starter                                  │
│  @Audited AOP → Ring Buffer → AuditTransport.publish()       │
└───────────────────────┬──────────────────────────────────────┘
                        │
              ┌─────────▼─────────┐
              │ AUDIT MODULE      │
              │ SERVER             │
              │                   │
              │ AuditEventPipeline│
              │  ├─ HashChain     │
              │  ├─ BatchSigning  │
              │  ├─ MerkleTree    │
              │  ├─ QueryStore    │
              │  ├─ ArchiveStore  │
              │  └─ AnomalyDetect │
              │                   │
              │ REST + gRPC API   │
              └───────────────────┘
```

## Module Structure (17 modules, 3 tiers)

### Tier 1 — Platform Foundation
| Module | Purpose |
|--------|---------|
| `hub-common-model` | Shared domain model — events, enums, value objects |
| `hub-crypto-starter` | SHA3-256 hashing, ECDSA-P384 signing, AES-256-GCM, Merkle trees |
| `hub-pii-starter` | PII detection (Luhn), masking, log sanitization |
| `hub-observability-starter` | CorrelationContext propagation, structured logging |
| `hub-error-starter` | Standardized exception hierarchy |
| `hub-time-starter` | NTP-synchronized HubClock |
| `hub-resilience-starter` | @Resilient annotation (circuit breaker, retry, timeout) |
| `hub-idempotency-starter` | @Idempotent annotation with pluggable stores |
| `hub-secret-starter` | Vault/KMS/Secrets Manager abstraction |

### Tier 2 — Payment Hub Platform
| Module | Purpose |
|--------|---------|
| `hub-tenant-context-starter` | Multi-tenant context holder, TenantAwareRepository |
| `hub-nats-starter` | Enhanced NATS client with context propagation |
| `hub-messaging-starter` | Kafka/RabbitMQ/NATS JetStream transport abstraction |
| `hub-security-starter` | OAuth2, JWT, entity-scoped authorization |
| `hub-grpc-starter` | gRPC server/client with correlation interceptors |

### Tier 3 — Audit Domain
| Module | Purpose |
|--------|---------|
| `hub-audit-starter` | Client-side: @Audited AOP, ring buffer, event emitter |
| `audit-module-server` | Server: process, chain, sign, store, query, verify |

## Deployment Profiles

**Same binary, configuration-driven scaling (ADR-001):**

| Profile | TPS | Transport | Query Store | Signing | Cost/mo |
|---------|-----|-----------|-------------|---------|---------|
| **Large** | 5K-15K | Kafka (dedicated) | OpenSearch (dedicated) | HSM (PKCS#11) | ~$6,700 |
| **Medium** | 500-5K | Kafka (shared) | OpenSearch (shared) | HSM (shared) | ~$430 |
| **Small** | 10-500 | NATS JetStream | PostgreSQL + tsvector | Software ECDSA | ~$55 |

## Key Design Decisions

- **ADR-001**: Interface-driven pluggable architecture — 7 interfaces abstract all infrastructure
- **ADR-002**: NATS JetStream as primary for small profile — no Kafka dependency needed
- **ADR-003**: PostgreSQL as query store for small profile — tsvector FTS sufficient
- **ADR-004**: Software signing acceptable for small profile — key rotation mitigates risk
- **ADR-008**: Mandatory sync audit for critical control events (overrides, escalations)
- **ADR-019**: Cross-cutting concerns extracted into 13 shared libraries
- **ADR-020**: PII log masking non-optional in production

## Quick Start

```bash
# Build all modules
./gradlew build

# Run the audit server (small profile)
cd audit-module-server
../gradlew bootRun --args='--spring.profiles.active=small'

# Run with Docker
docker build -t audit-module-server audit-module-server/
docker run -p 8080:8080 -p 9090:9090 \
  -e SPRING_PROFILES_ACTIVE=small \
  -e AUDIT_DB_URL=jdbc:postgresql://host:5432/audit \
  audit-module-server
```

## API Endpoints

### REST (port 8080)
- `GET /api/audit/events?tenantId=MB-001` — Query audit events
- `GET /api/audit/events/count?tenantId=MB-001` — Count events
- `GET /api/audit/config/profile` — Get deployment profile
- `GET /api/audit/health/pipeline` — Pipeline health
- `GET /actuator/health` — Spring Boot health

### gRPC (port 9090)
- `AuditService.RecordEvent` — Synchronous single event recording
- `AuditService.RecordBatch` — Atomic batch recording
- `AuditService.VerifyEvent` — Integrity verification
- `AuditService.QueryEvents` — Forensic search
- `AuditService.ExportEvidence` — Evidence package generation

## Cryptographic Integrity

Every audit event passes through:
1. **Hash Chain** — SHA3-256 chain per tenant per event category
2. **Batch Signing** — ECDSA-P384 signatures (HSM or software)
3. **Merkle Tree** — 10-minute tumbling windows with signed root anchors
4. **S3 WORM** — Parquet files with Object Lock (Governance mode)

## For Future Module Developers

Include `hub-audit-starter` in your module's dependencies:

```kotlin
dependencies {
    implementation("com.paymenthub:hub-audit-starter")
}
```

Then annotate your business methods:

```java
@NatsListener(subject = "payment.validate")
@Audited(eventType = "payment.validated", captureStateChange = true)
public ValidationResponse validate(ValidationRequest req) {
    return validationService.validate(req);
}
```

The shared libraries (PII masking, correlation context, tenant isolation, etc.) activate automatically via Spring Boot auto-configuration.

## Tech Stack

- **Java 21** (LTS) with preview features
- **Spring Boot 3.4.2**
- **PostgreSQL** (primary durable store + small profile query store)
- **gRPC 1.68** (sync audit API)
- **BouncyCastle 1.80** (ECDSA-P384, SHA3-256)
- **LMAX Disruptor 4.0** (async ring buffer)
- **Micrometer** (metrics)
- **Flyway** (database migrations)
- **ArchUnit** (architecture tests)
