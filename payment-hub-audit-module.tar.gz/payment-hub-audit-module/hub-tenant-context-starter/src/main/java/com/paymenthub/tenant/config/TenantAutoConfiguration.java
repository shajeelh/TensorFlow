package com.paymenthub.tenant.config;
import org.springframework.boot.autoconfigure.AutoConfiguration;
@AutoConfiguration public class TenantAutoConfiguration {}
