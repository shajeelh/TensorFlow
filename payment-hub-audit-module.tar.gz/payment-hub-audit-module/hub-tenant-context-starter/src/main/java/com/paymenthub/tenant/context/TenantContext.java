package com.paymenthub.tenant.context;
public record TenantContext(String tenantId, String entityId, String jurisdiction) {}
