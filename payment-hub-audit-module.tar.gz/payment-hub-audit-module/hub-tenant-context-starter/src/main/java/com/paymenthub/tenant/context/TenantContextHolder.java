package com.paymenthub.tenant.context;
public final class TenantContextHolder {
    private static final InheritableThreadLocal<TenantContext> CTX = new InheritableThreadLocal<>();
    private TenantContextHolder() {}
    public static TenantContext get() { return CTX.get(); }
    public static void set(TenantContext c) { CTX.set(c); }
    public static void clear() { CTX.remove(); }
    public static String getTenantId() { TenantContext c=CTX.get(); return c!=null?c.tenantId():null; }
}
