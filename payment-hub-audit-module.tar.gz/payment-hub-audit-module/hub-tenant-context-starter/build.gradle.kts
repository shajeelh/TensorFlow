plugins {
    `java-library`
}

description = "Payment Hub — Multi-tenant context propagation and isolation"

dependencies {
    api(project(":hub-common-model"))
    api(project(":hub-observability-starter"))
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    compileOnly("org.springframework.data:spring-data-jpa")
    compileOnly("org.springframework.security:spring-security-core")
    compileOnly("org.springframework:spring-webmvc")
}
