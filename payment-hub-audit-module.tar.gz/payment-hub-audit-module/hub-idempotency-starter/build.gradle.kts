plugins {
    `java-library`
}

description = "Payment Hub — Idempotency handling with pluggable stores"

dependencies {
    api(project(":hub-common-model"))
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    compileOnly("org.springframework.data:spring-data-redis")
    compileOnly("org.springframework.boot:spring-boot-starter-jdbc")
}
