package com.paymenthub.idempotency.config;
import com.paymenthub.idempotency.store.*;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
@AutoConfiguration public class IdempotencyAutoConfiguration {
    @Bean @ConditionalOnMissingBean public IdempotencyStore idempotencyStore() { return new InMemoryIdempotencyStore(); }
}
