package com.paymenthub.idempotency.store;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
public class InMemoryIdempotencyStore implements IdempotencyStore {
    private final Map<String,E> store = new ConcurrentHashMap<>();
    @Override public Optional<Object> get(String k) { E e=store.get(k); if(e==null) return Optional.empty(); if(e.exp.isBefore(Instant.now())) { store.remove(k); return Optional.empty(); } return Optional.of(e.r); }
    @Override public void put(String k, Object r, Duration ttl) { store.put(k, new E(r, Instant.now().plus(ttl))); }
    @Override public void remove(String k) { store.remove(k); }
    private record E(Object r, Instant exp) {}
}
