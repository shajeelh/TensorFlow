package com.paymenthub.idempotency.store;
import java.time.Duration;
import java.util.Optional;
public interface IdempotencyStore { Optional<Object> get(String key); void put(String key, Object result, Duration ttl); void remove(String key); }
