plugins {
    `java-library`
}

description = "Payment Hub — Kafka/RabbitMQ/NATS JetStream transport abstraction"

dependencies {
    api(project(":hub-common-model"))
    api(project(":hub-observability-starter"))
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    compileOnly("org.springframework.kafka:spring-kafka")
    compileOnly("org.springframework.amqp:spring-rabbit")
    compileOnly("io.nats:jnats")
}
