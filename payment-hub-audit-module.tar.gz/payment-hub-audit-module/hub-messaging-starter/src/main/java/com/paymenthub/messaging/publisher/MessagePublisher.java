package com.paymenthub.messaging.publisher;
import java.util.concurrent.CompletableFuture;
public interface MessagePublisher {
    CompletableFuture<Void> publish(String topic, String key, byte[] payload);
    String transportType();
}
