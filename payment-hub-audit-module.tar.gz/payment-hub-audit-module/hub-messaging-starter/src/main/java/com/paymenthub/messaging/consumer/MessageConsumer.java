package com.paymenthub.messaging.consumer;
import java.util.List;
import java.util.function.Consumer;
public interface MessageConsumer {
    void subscribe(String topic, Consumer<ReceivedMessage> handler);
    void start();
    void stop();
    record ReceivedMessage(String topic, String key, byte[] payload, java.util.Map<String,String> headers) {}
}
