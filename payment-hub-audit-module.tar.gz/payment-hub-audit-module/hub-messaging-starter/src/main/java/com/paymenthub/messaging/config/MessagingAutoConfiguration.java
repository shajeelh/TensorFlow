package com.paymenthub.messaging.config;
import org.springframework.boot.autoconfigure.AutoConfiguration;
@AutoConfiguration public class MessagingAutoConfiguration {}
