package com.paymenthub.messaging.transport.kafka;
import com.paymenthub.messaging.publisher.MessagePublisher;
import java.util.concurrent.CompletableFuture;
public class KafkaMessagePublisher implements MessagePublisher {
    // Kafka producer wrapping logic — delegates to Spring KafkaTemplate
    @Override public CompletableFuture<Void> publish(String topic, String key, byte[] payload) {
        // In production: kafkaTemplate.send(topic, key, payload).thenApply(v -> null)
        return CompletableFuture.completedFuture(null);
    }
    @Override public String transportType() { return "kafka"; }
}
