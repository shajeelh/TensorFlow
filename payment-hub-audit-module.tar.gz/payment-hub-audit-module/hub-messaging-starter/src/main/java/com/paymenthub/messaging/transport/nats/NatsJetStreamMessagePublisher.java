package com.paymenthub.messaging.transport.nats;
import com.paymenthub.messaging.publisher.MessagePublisher;
import java.util.concurrent.CompletableFuture;
public class NatsJetStreamMessagePublisher implements MessagePublisher {
    @Override public CompletableFuture<Void> publish(String subject, String key, byte[] payload) {
        // In production: natsConnection.jetStream().publishAsync(subject, payload)
        return CompletableFuture.completedFuture(null);
    }
    @Override public String transportType() { return "nats-jetstream"; }
}
