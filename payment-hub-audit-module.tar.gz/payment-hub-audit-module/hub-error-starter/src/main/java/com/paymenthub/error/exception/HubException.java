package com.paymenthub.error.exception;
public class HubException extends RuntimeException {
    private final String errorCode; private final String severity; private final boolean retrySafe;
    public HubException(String code, String msg, String sev, boolean retry) { super(msg); this.errorCode=code; this.severity=sev; this.retrySafe=retry; }
    public HubException(String code, String msg, String sev, boolean retry, Throwable cause) { super(msg,cause); this.errorCode=code; this.severity=sev; this.retrySafe=retry; }
    public String getErrorCode() { return errorCode; } public String getSeverity() { return severity; } public boolean isRetrySafe() { return retrySafe; }
}
