package com.paymenthub.error.config;
import org.springframework.boot.autoconfigure.AutoConfiguration;
@AutoConfiguration public class ErrorAutoConfiguration {}
