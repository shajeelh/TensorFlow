plugins {
    `java-library`
}

description = "Payment Hub — Standardized error handling and exception hierarchy"

dependencies {
    api(project(":hub-common-model"))
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    compileOnly("org.springframework:spring-webmvc")
    compileOnly("io.grpc:grpc-api")
}
