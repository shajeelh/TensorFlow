package com.paymenthub.security.config;
import org.springframework.boot.autoconfigure.AutoConfiguration;
@AutoConfiguration public class SecurityAutoConfiguration {}
