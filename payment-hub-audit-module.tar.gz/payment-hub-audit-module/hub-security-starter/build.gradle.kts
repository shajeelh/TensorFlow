plugins {
    `java-library`
}

description = "Payment Hub — OAuth2, JWT, entity-scoped authorization"

dependencies {
    api(project(":hub-common-model"))
    api(project(":hub-observability-starter"))
    api(project(":hub-tenant-context-starter"))
    api("org.springframework.boot:spring-boot-starter-security")
    implementation("org.springframework.boot:spring-boot-starter-oauth2-resource-server")
    implementation("org.springframework.boot:spring-boot-autoconfigure")
}
