package com.paymenthub.time.clock;
import java.time.Instant;
public class HubClock {
    private final String clockId;
    public HubClock(String clockId) { this.clockId = clockId; }
    public HubTimestamp now() { return new HubTimestamp(Instant.now(), clockId, 0L); }
    public Instant instant() { return Instant.now(); }
    public String getClockId() { return clockId; }
}
