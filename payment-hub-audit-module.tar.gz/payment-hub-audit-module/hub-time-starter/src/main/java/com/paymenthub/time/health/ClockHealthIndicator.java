package com.paymenthub.time.health;
import com.paymenthub.time.clock.HubClock;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
public class ClockHealthIndicator implements HealthIndicator {
    private final HubClock clock;
    public ClockHealthIndicator(HubClock c) { this.clock = c; }
    @Override public Health health() { var ts=clock.now(); return Health.up().withDetail("clockId",ts.clockId()).build(); }
}
