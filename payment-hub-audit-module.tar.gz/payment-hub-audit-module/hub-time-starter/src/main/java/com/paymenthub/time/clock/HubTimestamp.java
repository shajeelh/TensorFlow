package com.paymenthub.time.clock;
import java.time.Instant;
public record HubTimestamp(Instant instant, String clockId, long driftEstimateNanos) { public String toString() { return instant.toString(); } }
