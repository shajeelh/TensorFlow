package com.paymenthub.time.config;
import com.paymenthub.time.clock.HubClock;
import com.paymenthub.time.health.ClockHealthIndicator;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
@AutoConfiguration
public class TimeAutoConfiguration {
    @Bean @ConditionalOnMissingBean public HubClock hubClock(@Value("${hub.time.clock-id:ntp-default}") String id) { return new HubClock(id); }
    @Bean @ConditionalOnMissingBean public ClockHealthIndicator clockHealth(HubClock c) { return new ClockHealthIndicator(c); }
}
