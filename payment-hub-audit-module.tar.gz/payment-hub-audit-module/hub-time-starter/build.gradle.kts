plugins {
    `java-library`
}

description = "Payment Hub — NTP-synchronized clock"

dependencies {
    api(project(":hub-common-model"))
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("org.springframework.boot:spring-boot-starter-actuator")
}
