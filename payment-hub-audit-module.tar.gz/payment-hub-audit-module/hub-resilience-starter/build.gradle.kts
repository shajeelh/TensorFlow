plugins {
    `java-library`
}

description = "Payment Hub — Circuit breaker, retry, timeout patterns"

dependencies {
    api(project(":hub-common-model"))
    api("io.github.resilience4j:resilience4j-spring-boot3")
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("io.micrometer:micrometer-core")
}
