package com.paymenthub.resilience.annotation;
import java.lang.annotation.*;
@Target(ElementType.METHOD) @Retention(RetentionPolicy.RUNTIME) @Documented
public @interface Resilient { String circuitBreaker() default "default"; String retry() default "none"; String timeout() default "normal"; }
