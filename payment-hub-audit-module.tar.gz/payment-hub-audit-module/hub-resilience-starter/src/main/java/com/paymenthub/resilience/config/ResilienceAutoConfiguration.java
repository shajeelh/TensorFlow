package com.paymenthub.resilience.config;
import org.springframework.boot.autoconfigure.AutoConfiguration;
@AutoConfiguration public class ResilienceAutoConfiguration {}
