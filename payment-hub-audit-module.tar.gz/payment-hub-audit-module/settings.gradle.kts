rootProject.name = "payment-hub-platform"

// ═══════════════════════════════════════════════════════════════
// TIER 1: Platform Foundation Libraries
// ═══════════════════════════════════════════════════════════════
include("hub-common-model")              // Shared domain model (events, enums, value objects)
include("hub-crypto-starter")            // Hashing, signing, encryption, Merkle trees
include("hub-pii-starter")               // PII detection, masking, field-level encryption
include("hub-observability-starter")     // Correlation context, structured logging, metrics
include("hub-error-starter")             // Standardized exceptions and error codes
include("hub-time-starter")              // NTP-synchronized clock
include("hub-resilience-starter")        // Circuit breaker, retry, timeout
include("hub-idempotency-starter")       // @Idempotent annotation and stores
include("hub-secret-starter")            // Vault / KMS / Secrets Manager abstraction

// ═══════════════════════════════════════════════════════════════
// TIER 2: Payment Hub Platform Libraries
// ═══════════════════════════════════════════════════════════════
include("hub-tenant-context-starter")    // Multi-tenant context holder and propagation
include("hub-nats-starter")              // Enhanced NATS client with context propagation
include("hub-messaging-starter")         // Kafka/RabbitMQ/NATS JetStream abstraction
include("hub-security-starter")          // OAuth2, JWT, entity-scoped authorization
include("hub-grpc-starter")              // gRPC server/client with interceptors

// ═══════════════════════════════════════════════════════════════
// TIER 3: Audit Domain
// ═══════════════════════════════════════════════════════════════
include("hub-audit-starter")             // Client-side: @Audited, ring buffer, emit
include("audit-module-server")           // Server: process, chain, sign, store, query

// ═══════════════════════════════════════════════════════════════
// BOM
// ═══════════════════════════════════════════════════════════════
include("hub-dependencies-bom")
