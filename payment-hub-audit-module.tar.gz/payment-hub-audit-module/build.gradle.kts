import org.gradle.api.tasks.testing.logging.TestExceptionFormat

plugins {
    java
    id("org.springframework.boot") version "3.4.2" apply false
    id("io.spring.dependency-management") version "1.1.7" apply false
    id("com.google.protobuf") version "0.9.4" apply false
}

val javaVersion = 21
val springBootVersion = "3.4.2"
val springCloudVersion = "2024.0.0"
val grpcVersion = "1.68.2"
val protobufVersion = "4.29.3"
val lmaxDisruptorVersion = "4.0.0"
val resilience4jVersion = "2.2.0"
val bouncyCastleVersion = "1.80"
val micrometerVersion = "1.14.3"
val natsClientVersion = "2.20.5"
val opensearchClientVersion = "2.18.0"
val parquetVersion = "1.15.0"
val testcontainersVersion = "1.20.4"
val junitVersion = "5.11.4"
val archunitVersion = "1.3.0"

allprojects {
    group = "com.paymenthub"
    version = "1.0.0-SNAPSHOT"

    repositories {
        mavenCentral()
    }
}

subprojects {
    apply(plugin = "java")
    apply(plugin = "io.spring.dependency-management")

    java {
        toolchain {
            languageVersion.set(JavaLanguageVersion.of(javaVersion))
        }
    }

    dependencyManagement {
        imports {
            mavenBom("org.springframework.boot:spring-boot-dependencies:$springBootVersion")
            mavenBom("org.springframework.cloud:spring-cloud-dependencies:$springCloudVersion")
            mavenBom("io.grpc:grpc-bom:$grpcVersion")
            mavenBom("io.micrometer:micrometer-bom:$micrometerVersion")
        }
        dependencies {
            // LMAX Disruptor
            dependency("com.lmax:disruptor:$lmaxDisruptorVersion")

            // Resilience4j
            dependency("io.github.resilience4j:resilience4j-spring-boot3:$resilience4jVersion")
            dependency("io.github.resilience4j:resilience4j-circuitbreaker:$resilience4jVersion")
            dependency("io.github.resilience4j:resilience4j-retry:$resilience4jVersion")

            // BouncyCastle
            dependency("org.bouncycastle:bcprov-jdk18on:$bouncyCastleVersion")
            dependency("org.bouncycastle:bcpkix-jdk18on:$bouncyCastleVersion")

            // NATS
            dependency("io.nats:jnats:$natsClientVersion")

            // OpenSearch
            dependency("org.opensearch.client:opensearch-java:$opensearchClientVersion")

            // Parquet
            dependency("org.apache.parquet:parquet-avro:$parquetVersion")

            // Protobuf
            dependency("com.google.protobuf:protobuf-java:$protobufVersion")
            dependency("com.google.protobuf:protobuf-java-util:$protobufVersion")

            // Testing
            dependency("org.testcontainers:testcontainers:$testcontainersVersion")
            dependency("org.testcontainers:postgresql:$testcontainersVersion")
            dependency("org.testcontainers:kafka:$testcontainersVersion")
            dependency("com.tngtech.archunit:archunit-junit5:$archunitVersion")
        }
    }

    dependencies {
        // Annotation processors
        annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")

        // Testing baseline
        testImplementation("org.springframework.boot:spring-boot-starter-test")
        testImplementation("org.junit.jupiter:junit-jupiter")
        testImplementation("org.assertj:assertj-core")
        testImplementation("org.mockito:mockito-core")
    }

    tasks.withType<JavaCompile> {
        options.encoding = "UTF-8"
        options.compilerArgs.addAll(listOf(
            "-parameters",           // Preserve parameter names for Spring
            "--enable-preview",      // Enable Java 21 preview features
            "-Xlint:all,-processing" // All warnings except annotation processing
        ))
    }

    tasks.withType<Test> {
        useJUnitPlatform()
        jvmArgs("--enable-preview")
        testLogging {
            events("passed", "skipped", "failed")
            exceptionFormat = TestExceptionFormat.FULL
        }
    }
}
