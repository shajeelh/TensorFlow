plugins {
    `java-library`
}

description = "Payment Hub — Enhanced NATS client with context propagation"

dependencies {
    api(project(":hub-common-model"))
    api(project(":hub-observability-starter"))
    api("io.nats:jnats")
    implementation(project(":hub-pii-starter"))
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("com.fasterxml.jackson.core:jackson-databind")
    implementation("io.micrometer:micrometer-core")
}
