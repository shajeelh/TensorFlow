plugins {
    id("org.springframework.boot")
    id("com.google.protobuf")
}

description = "Payment Hub — Audit Module Server (process, chain, sign, store, query)"

dependencies {
    implementation(project(":hub-audit-starter"))
    implementation(project(":hub-grpc-starter"))

    // Spring Boot starters
    implementation("org.springframework.boot:spring-boot-starter-web")
    implementation("org.springframework.boot:spring-boot-starter-data-jpa")
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation("org.springframework.boot:spring-boot-starter-validation")
    implementation("org.springframework.boot:spring-boot-starter-security")

    // gRPC
    implementation("io.grpc:grpc-stub")
    implementation("io.grpc:grpc-protobuf")
    implementation("io.grpc:grpc-netty-shaded")
    implementation("com.google.protobuf:protobuf-java")
    implementation("com.google.protobuf:protobuf-java-util")

    // Kafka (conditional — large/medium profiles)
    implementation("org.springframework.kafka:spring-kafka")
    implementation("org.apache.kafka:kafka-streams")

    // NATS (conditional — small profile)
    implementation("io.nats:jnats")

    // Database
    runtimeOnly("org.postgresql:postgresql")
    implementation("org.flywaydb:flyway-core")
    implementation("org.flywaydb:flyway-database-postgresql")

    // OpenSearch (conditional — large/medium profiles)
    implementation("org.opensearch.client:opensearch-java")

    // Parquet / S3 archival
    implementation("org.apache.parquet:parquet-avro")
    implementation("software.amazon.awssdk:s3:2.29.50")

    // Redis (conditional — large/medium hash chain lock)
    implementation("org.springframework.boot:spring-boot-starter-data-redis")
    implementation("org.redisson:redisson-spring-boot-starter:3.40.2")

    // BouncyCastle for software signing
    implementation("org.bouncycastle:bcprov-jdk18on")
    implementation("org.bouncycastle:bcpkix-jdk18on")

    // LMAX for ring buffer
    implementation("com.lmax:disruptor")

    // Testing
    testImplementation("org.testcontainers:testcontainers")
    testImplementation("org.testcontainers:postgresql")
    testImplementation("org.testcontainers:kafka")
    testImplementation("com.tngtech.archunit:archunit-junit5")
    testImplementation("org.springframework.security:spring-security-test")
}

protobuf {
    protoc {
        artifact = "com.google.protobuf:protoc:4.29.3"
    }
    plugins {
        create("grpc") {
            artifact = "io.grpc:protoc-gen-grpc-java:1.68.2"
        }
    }
    generateProtoTasks {
        all().forEach { task ->
            task.plugins {
                create("grpc")
            }
        }
    }
}
