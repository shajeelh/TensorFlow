package com.paymenthub.audit.server.processing.chain;

import com.paymenthub.common.enums.ActionResult;
import com.paymenthub.common.enums.ActorType;
import com.paymenthub.common.model.action.AuditAction;
import com.paymenthub.common.model.actor.AuditActor;
import com.paymenthub.common.model.event.AuditEvent;
import com.paymenthub.common.model.integrity.IntegrityInfo;
import com.paymenthub.common.model.resource.AuditResource;
import com.paymenthub.crypto.hash.HashService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests for the hash chain service — verifies chain integrity,
 * sequence monotonicity, and genesis block handling.
 */
class HashChainServiceTest {

    private HashChainService hashChainService;

    @BeforeEach
    void setUp() {
        hashChainService = new HashChainService(new HashService("SHA-256"));
    }

    @Test
    @DisplayName("First event in chain should have all-zeros previous hash (genesis)")
    void genesisBlock() {
        AuditEvent event = createTestEvent("payment.initiated");
        IntegrityInfo integrity = hashChainService.computeIntegrity(event, "MB-001:payment");

        assertThat(integrity.sequenceNumber()).isEqualTo(1);
        assertThat(integrity.previousHash()).isEqualTo(new byte[32]); // genesis
        assertThat(integrity.recordHash()).isNotNull();
        assertThat(integrity.recordHash()).hasSize(32); // SHA-256
    }

    @Test
    @DisplayName("Second event should chain to first event's hash")
    void chainContinuity() {
        String chainId = "MB-001:payment";
        AuditEvent event1 = createTestEvent("payment.initiated");
        AuditEvent event2 = createTestEvent("payment.validated");

        IntegrityInfo info1 = hashChainService.computeIntegrity(event1, chainId);
        IntegrityInfo info2 = hashChainService.computeIntegrity(event2, chainId);

        assertThat(info2.previousHash()).isEqualTo(info1.recordHash());
        assertThat(info2.sequenceNumber()).isEqualTo(2);
    }

    @Test
    @DisplayName("Sequence numbers should be monotonically increasing")
    void monotonicSequence() {
        String chainId = "MB-001:payment";
        for (int i = 0; i < 100; i++) {
            AuditEvent event = createTestEvent("payment.step" + i);
            IntegrityInfo info = hashChainService.computeIntegrity(event, chainId);
            assertThat(info.sequenceNumber()).isEqualTo(i + 1);
        }
    }

    @Test
    @DisplayName("Different chains should be independent")
    void chainIsolation() {
        AuditEvent event1 = createTestEvent("payment.initiated");
        AuditEvent event2 = createTestEvent("admin.config_change");

        IntegrityInfo info1 = hashChainService.computeIntegrity(event1, "MB-001:payment");
        IntegrityInfo info2 = hashChainService.computeIntegrity(event2, "MB-001:admin");

        // Both should be sequence 1 (independent chains)
        assertThat(info1.sequenceNumber()).isEqualTo(1);
        assertThat(info2.sequenceNumber()).isEqualTo(1);

        // Both should have genesis previous hash
        assertThat(info1.previousHash()).isEqualTo(new byte[32]);
        assertThat(info2.previousHash()).isEqualTo(new byte[32]);
    }

    @Test
    @DisplayName("Same event content should produce same hash")
    void deterministicHashing() {
        AuditEvent event = createTestEvent("payment.initiated");

        // Two separate chains, same event — same content hash
        IntegrityInfo info1 = hashChainService.computeIntegrity(event, "chain-a");
        IntegrityInfo info2 = hashChainService.computeIntegrity(event, "chain-b");

        assertThat(info1.recordHash()).isEqualTo(info2.recordHash());
    }

    @Test
    @DisplayName("Chain recovery should restore state correctly")
    void chainRecovery() {
        String chainId = "MB-001:payment";

        // Build 3 events
        AuditEvent e1 = createTestEvent("payment.initiated");
        AuditEvent e2 = createTestEvent("payment.validated");
        AuditEvent e3 = createTestEvent("payment.executed");

        IntegrityInfo i1 = hashChainService.computeIntegrity(e1, chainId);
        IntegrityInfo i2 = hashChainService.computeIntegrity(e2, chainId);

        // Simulate restart — initialize chain from last known state
        HashChainService recovered = new HashChainService(new HashService("SHA-256"));
        recovered.initializeChain(chainId, i2.recordHash(), i2.sequenceNumber());

        IntegrityInfo i3 = recovered.computeIntegrity(e3, chainId);

        assertThat(i3.sequenceNumber()).isEqualTo(3);
        assertThat(i3.previousHash()).isEqualTo(i2.recordHash());
    }

    private AuditEvent createTestEvent(String eventType) {
        return AuditEvent.builder()
            .eventId(UUID.randomUUID())
            .eventType(eventType)
            .correlationId(UUID.randomUUID())
            .timestamp(Instant.now())
            .actor(AuditActor.builder()
                .type(ActorType.USER)
                .identity("test@example.com")
                .build())
            .resource(AuditResource.builder()
                .type("payment")
                .id("PAY-" + UUID.randomUUID().toString().substring(0, 8))
                .tenantId("MB-001")
                .entityId("MAIN_BANK")
                .build())
            .action(AuditAction.builder()
                .operation("TEST")
                .result(ActionResult.SUCCESS)
                .build())
            .build();
    }
}
