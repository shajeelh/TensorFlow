package com.paymenthub.audit.server;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.core.importer.ImportOption;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;

/**
 * Architecture tests enforcing the dependency rules from the design:
 * - Tier 1 libraries have no upward dependencies
 * - Processing layer doesn't depend on REST/gRPC layer
 * - Store implementations don't depend on each other
 */
class ArchitectureTest {

    private static JavaClasses classes;

    @BeforeAll
    static void importClasses() {
        classes = new ClassFileImporter()
            .withImportOption(ImportOption.Predefined.DO_NOT_INCLUDE_TESTS)
            .importPackages("com.paymenthub");
    }

    @Test
    @DisplayName("Processing layer should not depend on REST controllers")
    void processingDoesNotDependOnRest() {
        noClasses()
            .that().resideInAPackage("..processing..")
            .should().dependOnClassesThat().resideInAPackage("..rest..")
            .check(classes);
    }

    @Test
    @DisplayName("Processing layer should not depend on gRPC layer")
    void processingDoesNotDependOnGrpc() {
        noClasses()
            .that().resideInAPackage("..processing..")
            .should().dependOnClassesThat().resideInAPackage("..grpc..")
            .check(classes);
    }

    @Test
    @DisplayName("Store implementations should not depend on each other")
    void storeIsolation() {
        noClasses()
            .that().resideInAPackage("..store.postgres..")
            .should().dependOnClassesThat().resideInAPackage("..store.opensearch..")
            .check(classes);
    }

    @Test
    @DisplayName("Common model should not depend on Spring")
    void commonModelNoSpring() {
        noClasses()
            .that().resideInAPackage("..common.model..")
            .should().dependOnClassesThat().resideInAPackage("org.springframework..")
            .check(classes);
    }
}
