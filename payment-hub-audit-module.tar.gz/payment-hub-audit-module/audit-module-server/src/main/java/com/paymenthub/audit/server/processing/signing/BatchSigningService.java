package com.paymenthub.audit.server.processing.signing;

import com.paymenthub.common.model.integrity.SignedBatch;
import com.paymenthub.crypto.signature.AuditSigner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.ArrayList;
import java.util.List;

/**
 * Accumulates record hashes and signs them in batches.
 * Batch size is profile-dependent: Large=500, Medium=200, Small=50.
 */
public class BatchSigningService {

    private static final Logger log = LoggerFactory.getLogger(BatchSigningService.class);

    private final AuditSigner signer;
    private final int batchSize;
    private final List<byte[]> pendingHashes = new ArrayList<>();
    private final List<SignedBatch> completedBatches = new ArrayList<>();

    public BatchSigningService(AuditSigner signer, int batchSize) {
        this.signer = signer;
        this.batchSize = batchSize;
    }

    /**
     * Add a record hash to the pending batch. Returns a SignedBatch if the batch is full.
     */
    public synchronized SignedBatch addAndSignIfReady(byte[] recordHash) {
        pendingHashes.add(recordHash);
        if (pendingHashes.size() >= batchSize) {
            return flushBatch();
        }
        return null;
    }

    /**
     * Force-flush the current batch (e.g., on timer or shutdown).
     */
    public synchronized SignedBatch flushBatch() {
        if (pendingHashes.isEmpty()) return null;
        List<byte[]> toSign = new ArrayList<>(pendingHashes);
        pendingHashes.clear();

        SignedBatch batch = signer.sign(toSign);
        completedBatches.add(batch);
        log.info("Signed batch {} with {} records using {} mode",
            batch.batchId(), toSign.size(), signer.signingMode());
        return batch;
    }

    public int getPendingCount() { return pendingHashes.size(); }
    public String getSigningMode() { return signer.signingMode(); }
}
