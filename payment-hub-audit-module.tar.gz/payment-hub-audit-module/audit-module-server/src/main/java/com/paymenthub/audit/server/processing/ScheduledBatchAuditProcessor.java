package com.paymenthub.audit.server.processing;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.paymenthub.common.model.event.AuditEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * Small profile stream processor (ADR-002).
 * Polls NATS JetStream every 1 second, processes events in batches of 100.
 * Replaces Kafka Streams for small deployments.
 */
public class ScheduledBatchAuditProcessor implements AuditStreamProcessor {

    private static final Logger log = LoggerFactory.getLogger(ScheduledBatchAuditProcessor.class);

    private final AuditEventPipeline pipeline;
    private final ObjectMapper objectMapper;
    private volatile boolean running = false;
    private long eventsProcessed = 0;

    public ScheduledBatchAuditProcessor(AuditEventPipeline pipeline, ObjectMapper objectMapper) {
        this.pipeline = pipeline;
        this.objectMapper = objectMapper;
    }

    @Override
    public void start() { running = true; log.info("ScheduledBatchAuditProcessor started"); }

    @Override
    public void stop() { running = false; log.info("ScheduledBatchAuditProcessor stopped"); }

    @Override
    public ProcessorHealth health() {
        return new ProcessorHealth(running, eventsProcessed, System.currentTimeMillis(), 0);
    }

    @Scheduled(fixedDelayString = "${audit.stream-processor.scheduled-batch.poll-interval-ms:1000}")
    public void poll() {
        if (!running) return;
        // In production: pull batch from NATS JetStream subscription
        // For each message: deserialize → pipeline.process(event) → ack
    }
}
