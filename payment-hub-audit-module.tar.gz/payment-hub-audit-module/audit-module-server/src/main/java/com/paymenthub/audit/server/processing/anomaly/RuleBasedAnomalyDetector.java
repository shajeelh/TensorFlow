package com.paymenthub.audit.server.processing.anomaly;

import com.paymenthub.common.model.event.AuditEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Rule-based anomaly detector — mandatory across all profiles.
 * Implements the 6 core alert rules from v3 Section 7.1.
 */
public class RuleBasedAnomalyDetector implements AnomalyDetector {

    private final Map<String, AtomicInteger> failedAuthCounts = new ConcurrentHashMap<>();

    @Override
    public List<AnomalyAlert> evaluate(AuditEvent event) {
        List<AnomalyAlert> alerts = new ArrayList<>();

        // Rule 1: Audit config change (P2)
        if ("admin.audit_config_change".equals(event.eventType())) {
            alerts.add(new AnomalyAlert("AUDIT_CONFIG_CHANGE", "P2",
                "Audit configuration changed by " + (event.actor() != null ? event.actor().identity() : "unknown"),
                event.eventId().toString()));
        }

        // Rule 2: Excessive failed auth from same IP (P2)
        if (event.eventType() != null && event.eventType().startsWith("auth.failed")) {
            String ip = event.actor() != null ? event.actor().sourceIp() : "unknown";
            AtomicInteger count = failedAuthCounts.computeIfAbsent(ip, k -> new AtomicInteger(0));
            if (count.incrementAndGet() > 10) {
                alerts.add(new AnomalyAlert("EXCESSIVE_FAILED_AUTH", "P2",
                    "More than 10 failed auth attempts from " + ip,
                    event.eventId().toString()));
            }
        }

        // Rule 3: Privilege escalation (P1)
        if ("authz.privilege_escalation".equals(event.eventType())) {
            alerts.add(new AnomalyAlert("PRIVILEGE_ESCALATION", "P1",
                "Privilege escalation by " + (event.actor() != null ? event.actor().identity() : "unknown"),
                event.eventId().toString()));
        }

        return alerts;
    }
}
