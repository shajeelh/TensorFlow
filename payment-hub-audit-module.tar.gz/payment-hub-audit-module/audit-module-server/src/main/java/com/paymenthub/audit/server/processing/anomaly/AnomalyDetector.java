package com.paymenthub.audit.server.processing.anomaly;

import com.paymenthub.common.model.event.AuditEvent;
import java.util.List;

public interface AnomalyDetector {
    List<AnomalyAlert> evaluate(AuditEvent event);
    record AnomalyAlert(String ruleId, String severity, String message, String eventId) {}
}
