package com.paymenthub.audit.server.processing.chain;

import com.paymenthub.common.model.event.AuditEvent;
import com.paymenthub.common.model.integrity.IntegrityInfo;
import com.paymenthub.common.util.JsonCanonicalizer;
import com.paymenthub.crypto.hash.HashService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Core hash chain service — maintains per-chain state and computes integrity info.
 * Chain ID = tenantId + ":" + eventCategory (one chain per entity per category).
 *
 * <p>Thread-safe: uses synchronized per-chain to prevent concurrent hash chain corruption.
 * In large/medium profiles, Redis distributed lock replaces JVM synchronization (ADR-011).</p>
 */
public class HashChainService {

    private static final Logger log = LoggerFactory.getLogger(HashChainService.class);

    private final HashService hashService;
    private final Map<String, ChainState> chains = new ConcurrentHashMap<>();

    public HashChainService(HashService hashService) {
        this.hashService = hashService;
    }

    /**
     * Compute integrity info for an event and advance the chain.
     * This is the core hash chain operation — must be called in order per chain.
     */
    public IntegrityInfo computeIntegrity(AuditEvent event, String chainId) {
        ChainState state = chains.computeIfAbsent(chainId, k -> new ChainState());

        synchronized (state) {
            // Compute record hash from canonical JSON of the event (excluding integrity block)
            byte[] recordHash = hashService.canonicalHash(new HashableEvent(
                event.eventId(), event.eventType(), event.timestamp(),
                event.actor(), event.resource(), event.action(), event.stateChange()
            ));

            // Get previous hash (genesis = all zeros)
            byte[] previousHash = state.lastHash != null ?
                state.lastHash : new byte[32]; // SHA3-256 = 32 bytes

            // Advance chain
            state.lastHash = recordHash;
            long sequence = state.sequence.incrementAndGet();

            log.trace("Chain {} advanced to seq={}", chainId, sequence);

            return IntegrityInfo.builder()
                .recordHash(recordHash)
                .previousHash(previousHash)
                .sequenceNumber(sequence)
                .build();
        }
    }

    /**
     * Verify a single link in the chain.
     */
    public boolean verifyLink(byte[] recordHash, byte[] previousHash, byte[] expectedChainHash) {
        byte[] computed = hashService.chainHash(previousHash, recordHash);
        return java.util.Arrays.equals(computed, expectedChainHash);
    }

    /**
     * Initialize chain state from persistent store (recovery after restart).
     */
    public void initializeChain(String chainId, byte[] lastHash, long lastSequence) {
        ChainState state = new ChainState();
        state.lastHash = lastHash;
        state.sequence.set(lastSequence);
        chains.put(chainId, state);
    }

    private static class ChainState {
        volatile byte[] lastHash;
        final AtomicLong sequence = new AtomicLong(0);
    }

    // Record used for hashing — excludes integrity block to avoid circular dependency
    private record HashableEvent(Object eventId, String eventType, Object timestamp,
        Object actor, Object resource, Object action, Object stateChange) {}
}
