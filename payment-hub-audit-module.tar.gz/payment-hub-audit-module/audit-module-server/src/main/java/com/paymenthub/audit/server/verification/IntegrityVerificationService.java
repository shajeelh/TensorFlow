package com.paymenthub.audit.server.verification;

import com.paymenthub.audit.server.processing.chain.HashChainService;
import com.paymenthub.crypto.merkle.MerkleTreeBuilder;
import com.paymenthub.crypto.signature.AuditSigner;
import com.paymenthub.common.model.integrity.SignedBatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Map;

/**
 * Scheduled integrity verification — runs every 60s.
 * Verifies hash chain continuity, batch signatures, and Merkle anchors.
 * Fires P1 alerts on any integrity violation (Section 7.1).
 */
public class IntegrityVerificationService {

    private static final Logger log = LoggerFactory.getLogger(IntegrityVerificationService.class);

    private final JdbcTemplate jdbc;
    private final HashChainService hashChainService;
    private final AuditSigner signer;
    private final MerkleTreeBuilder merkleTreeBuilder;

    public IntegrityVerificationService(JdbcTemplate jdbc, HashChainService hashChainService,
                                         AuditSigner signer, MerkleTreeBuilder merkleTreeBuilder) {
        this.jdbc = jdbc;
        this.hashChainService = hashChainService;
        this.signer = signer;
        this.merkleTreeBuilder = merkleTreeBuilder;
    }

    /**
     * Verify hash chain integrity for all chains.
     * Returns true if all chains are intact.
     */
    public boolean verifyAllChains() {
        List<Map<String, Object>> rows = jdbc.queryForList(
            "SELECT record_hash, previous_hash, sequence_number, tenant_id, event_type " +
            "FROM audit_events ORDER BY tenant_id, sequence_number ASC LIMIT 10000");

        if (rows.isEmpty()) return true;

        byte[] expectedPrev = new byte[32]; // genesis
        String currentChain = null;
        boolean valid = true;

        for (Map<String, Object> row : rows) {
            String chainId = row.get("tenant_id") + ":" +
                ((String) row.get("event_type")).split("\\.")[0];

            if (!chainId.equals(currentChain)) {
                currentChain = chainId;
                expectedPrev = new byte[32]; // reset for new chain
            }

            byte[] recordHash = (byte[]) row.get("record_hash");
            byte[] prevHash = (byte[]) row.get("previous_hash");

            if (recordHash != null && prevHash != null) {
                if (!java.util.Arrays.equals(prevHash, expectedPrev)) {
                    log.error("HASH CHAIN BREAK detected in chain {} at seq {}",
                        chainId, row.get("sequence_number"));
                    valid = false;
                }
                expectedPrev = recordHash;
            }
        }

        if (valid) log.info("Hash chain verification passed for all chains");
        return valid;
    }

    /**
     * Verify a specific batch signature.
     */
    public boolean verifyBatchSignature(long batchId) {
        Map<String, Object> batch = jdbc.queryForMap(
            "SELECT batch_digest, signature, signing_key_id, signing_mode, record_count " +
            "FROM signature_batches WHERE id = ?", batchId);

        SignedBatch signedBatch = new SignedBatch(
            batchId, List.of(), (byte[]) batch.get("batch_digest"),
            (byte[]) batch.get("signature"),
            (String) batch.get("signing_key_id"),
            (String) batch.get("signing_mode"));

        return signer.verify(signedBatch);
    }
}
