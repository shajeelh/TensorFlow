package com.paymenthub.audit.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Payment Hub — Audit Module Server.
 *
 * <p>Receives audit events from all payment hub modules via Kafka/NATS/RabbitMQ,
 * processes them through the integrity pipeline (hash chaining → batch signing → Merkle trees),
 * and stores them in the configured query store (OpenSearch/PostgreSQL) and archive (S3 WORM).</p>
 *
 * <p>Profile-driven: the same binary deploys across Large, Medium, and Small profiles.
 * Infrastructure selection is handled by Spring conditional auto-configuration.</p>
 *
 * @see com.paymenthub.audit.server.config.AuditServerProperties
 */
@SpringBootApplication(scanBasePackages = "com.paymenthub")
@EnableScheduling
public class AuditModuleServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuditModuleServerApplication.class, args);
    }
}
