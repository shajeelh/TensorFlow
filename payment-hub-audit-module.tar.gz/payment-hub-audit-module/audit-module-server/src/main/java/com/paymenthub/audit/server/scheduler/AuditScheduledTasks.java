package com.paymenthub.audit.server.scheduler;

import com.paymenthub.audit.server.processing.signing.BatchSigningService;
import com.paymenthub.audit.server.verification.IntegrityVerificationService;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Scheduled tasks for the audit module:
 * - Hash chain verification (every 60s)
 * - Heartbeat emission (every 30s)
 * - Batch signing flush (every 5s)
 * - Merkle window close (every 10 min)
 */
@Component
public class AuditScheduledTasks {

    private static final Logger log = LoggerFactory.getLogger(AuditScheduledTasks.class);

    private final IntegrityVerificationService verifier;
    private final BatchSigningService signingService;
    private final MeterRegistry meterRegistry;

    public AuditScheduledTasks(IntegrityVerificationService verifier,
                                BatchSigningService signingService,
                                MeterRegistry meterRegistry) {
        this.verifier = verifier;
        this.signingService = signingService;
        this.meterRegistry = meterRegistry;
    }

    @Scheduled(fixedDelayString = "${audit.heartbeat-interval-seconds:30}000")
    public void emitHeartbeat() {
        log.trace("Audit module heartbeat — signing mode: {}, pending: {}",
            signingService.getSigningMode(), signingService.getPendingCount());
    }

    @Scheduled(fixedDelay = 60000)
    public void verifyHashChains() {
        boolean valid = verifier.verifyAllChains();
        meterRegistry.gauge("audit.integrity.chain_valid", valid ? 1 : 0);
        if (!valid) {
            log.error("P1 ALERT: Hash chain integrity verification FAILED");
        }
    }

    @Scheduled(fixedDelay = 5000)
    public void flushSigningBatch() {
        var batch = signingService.flushBatch();
        if (batch != null) {
            log.debug("Timer-triggered batch signing: batch {} ({} records)",
                batch.batchId(), batch.recordHashes().size());
        }
    }
}
