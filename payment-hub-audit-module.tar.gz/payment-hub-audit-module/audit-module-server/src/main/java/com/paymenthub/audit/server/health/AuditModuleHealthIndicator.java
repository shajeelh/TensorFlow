package com.paymenthub.audit.server.health;

import com.paymenthub.audit.server.config.AuditServerProperties;
import com.paymenthub.audit.server.processing.signing.BatchSigningService;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
public class AuditModuleHealthIndicator implements HealthIndicator {

    private final AuditServerProperties properties;
    private final BatchSigningService signingService;

    public AuditModuleHealthIndicator(AuditServerProperties props, BatchSigningService signing) {
        this.properties = props;
        this.signingService = signing;
    }

    @Override
    public Health health() {
        return Health.up()
            .withDetail("profile", properties.getDeployment().getProfile())
            .withDetail("instanceId", properties.getDeployment().getInstanceId())
            .withDetail("signingMode", signingService.getSigningMode())
            .withDetail("pendingSignatures", signingService.getPendingCount())
            .withDetail("transportType", properties.getTransport().getType())
            .withDetail("queryStoreType", properties.getQueryStore().getType())
            .build();
    }
}
