package com.paymenthub.audit.server.query;

import com.paymenthub.common.model.event.AuditEvent;
import com.paymenthub.common.model.query.AuditQuery;
import java.util.List;

/**
 * Profile-transparent query store.
 * Large/Medium: OpenSearch, Small: PostgreSQL with tsvector FTS.
 */
public interface AuditQueryStore {
    List<AuditEvent> query(AuditQuery query);
    long count(AuditQuery query);
    void index(AuditEvent event);
    void indexBatch(List<AuditEvent> events);
}
