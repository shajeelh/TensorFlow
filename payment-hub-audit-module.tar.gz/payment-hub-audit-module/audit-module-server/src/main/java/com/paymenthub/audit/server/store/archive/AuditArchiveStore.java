package com.paymenthub.audit.server.store.archive;

import com.paymenthub.common.model.event.AuditEvent;
import java.util.List;

/**
 * S3 WORM archive store — identical across all profiles.
 * Writes Parquet files with Object Lock (Governance mode).
 */
public interface AuditArchiveStore {
    void archive(List<AuditEvent> events, String entityId);
}
