package com.paymenthub.audit.server.processing;

import com.paymenthub.audit.server.processing.anomaly.AnomalyDetector;
import com.paymenthub.audit.server.processing.chain.HashChainService;
import com.paymenthub.audit.server.processing.signing.BatchSigningService;
import com.paymenthub.audit.server.query.AuditQueryStore;
import com.paymenthub.common.model.event.AuditEvent;
import com.paymenthub.common.model.integrity.IntegrityInfo;
import com.paymenthub.common.model.integrity.SignedBatch;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Central event processing pipeline — the heart of the audit module server.
 * Every event flows through: validate → hash chain → store → sign → anomaly detect.
 */
public class AuditEventPipeline {

    private static final Logger log = LoggerFactory.getLogger(AuditEventPipeline.class);

    private final HashChainService hashChainService;
    private final BatchSigningService signingService;
    private final AuditQueryStore queryStore;
    private final AnomalyDetector anomalyDetector;
    private final Counter eventsProcessed;
    private final Timer processingTimer;

    public AuditEventPipeline(HashChainService hashChainService,
                               BatchSigningService signingService,
                               AuditQueryStore queryStore,
                               AnomalyDetector anomalyDetector,
                               MeterRegistry meterRegistry) {
        this.hashChainService = hashChainService;
        this.signingService = signingService;
        this.queryStore = queryStore;
        this.anomalyDetector = anomalyDetector;
        this.eventsProcessed = Counter.builder("audit.events.processed")
            .description("Total audit events processed")
            .register(meterRegistry);
        this.processingTimer = Timer.builder("audit.event.processing.duration")
            .description("Time to process a single audit event")
            .register(meterRegistry);
    }

    /**
     * Process a single audit event through the full integrity pipeline.
     */
    public AuditEvent process(AuditEvent event) {
        return processingTimer.record(() -> {
            // 1. Resolve chain ID: tenantId:category
            String chainId = resolveChainId(event);

            // 2. Compute hash chain integrity
            IntegrityInfo integrity = hashChainService.computeIntegrity(event, chainId);

            // 3. Create enriched event with integrity info
            AuditEvent enriched = AuditEvent.builder()
                .eventId(event.eventId())
                .eventType(event.eventType())
                .eventVersion(event.eventVersion())
                .correlationId(event.correlationId())
                .causationId(event.causationId())
                .timestamp(event.timestamp())
                .actor(event.actor())
                .resource(event.resource())
                .action(event.action())
                .stateChange(event.stateChange())
                .context(event.context())
                .deployment(event.deployment())
                .integrity(integrity)
                .idempotencyKey(event.idempotencyKey())
                .build();

            // 4. Persist to query store (PostgreSQL/OpenSearch)
            queryStore.index(enriched);

            // 5. Add to signing batch
            if (integrity.recordHash() != null) {
                SignedBatch batch = signingService.addAndSignIfReady(integrity.recordHash());
                if (batch != null) {
                    log.info("Batch {} signed with {} records", batch.batchId(), batch.recordHashes().size());
                }
            }

            // 6. Anomaly detection
            var alerts = anomalyDetector.evaluate(enriched);
            if (!alerts.isEmpty()) {
                log.warn("Anomaly detected for event {}: {}", event.eventId(),
                    alerts.stream().map(AnomalyDetector.AnomalyAlert::message).toList());
            }

            eventsProcessed.increment();
            return enriched;
        });
    }

    private String resolveChainId(AuditEvent event) {
        String tenantId = event.resource() != null ? event.resource().tenantId() : "UNKNOWN";
        String category = event.eventType().contains(".") ?
            event.eventType().substring(0, event.eventType().indexOf('.')) : "business";
        return tenantId + ":" + category;
    }
}
