package com.paymenthub.audit.server.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.paymenthub.audit.server.processing.AuditEventPipeline;
import com.paymenthub.audit.server.processing.ScheduledBatchAuditProcessor;
import com.paymenthub.audit.server.processing.anomaly.AnomalyDetector;
import com.paymenthub.audit.server.processing.anomaly.RuleBasedAnomalyDetector;
import com.paymenthub.audit.server.processing.chain.HashChainService;
import com.paymenthub.audit.server.processing.signing.BatchSigningService;
import com.paymenthub.audit.server.query.AuditQueryStore;
import com.paymenthub.audit.server.store.postgres.PostgresAuditStore;
import com.paymenthub.crypto.hash.HashService;
import com.paymenthub.crypto.signature.AuditSigner;
import com.paymenthub.crypto.signature.SoftwareAuditSigner;
import io.micrometer.core.instrument.MeterRegistry;
import org.bouncycastle.jce.ECNamedCurveTable;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECParameterSpec;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;

import java.security.*;

@AutoConfiguration
@EnableConfigurationProperties(AuditServerProperties.class)
public class AuditServerAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public HashChainService hashChainService(HashService hashService) {
        return new HashChainService(hashService);
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(name = "audit.signing.mode", havingValue = "software", matchIfMissing = true)
    public AuditSigner softwareAuditSigner(HashService hashService) throws Exception {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
        ECParameterSpec ecSpec = ECNamedCurveTable.getParameterSpec("P-384");
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC", BouncyCastleProvider.PROVIDER_NAME);
        kpg.initialize(ecSpec, new SecureRandom());
        KeyPair kp = kpg.generateKeyPair();
        String keyId = "sw-" + System.currentTimeMillis();
        return new SoftwareAuditSigner(kp.getPrivate(), kp.getPublic(), keyId, hashService);
    }

    @Bean
    @ConditionalOnMissingBean
    public BatchSigningService batchSigningService(AuditSigner signer, AuditServerProperties props) {
        return new BatchSigningService(signer, props.getSigning().getBatchSize());
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(name = "audit.query-store.type", havingValue = "postgresql", matchIfMissing = true)
    public AuditQueryStore postgresAuditStore(JdbcTemplate jdbc, ObjectMapper om) {
        return new PostgresAuditStore(jdbc, om);
    }

    @Bean
    @ConditionalOnMissingBean
    public AnomalyDetector anomalyDetector() {
        return new RuleBasedAnomalyDetector();
    }

    @Bean
    @ConditionalOnMissingBean
    public AuditEventPipeline auditEventPipeline(HashChainService chain, BatchSigningService signing,
                                                   AuditQueryStore store, AnomalyDetector anomaly,
                                                   MeterRegistry registry) {
        return new AuditEventPipeline(chain, signing, store, anomaly, registry);
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(name = "audit.stream-processor.type", havingValue = "scheduled-batch", matchIfMissing = true)
    public ScheduledBatchAuditProcessor scheduledBatchProcessor(AuditEventPipeline pipeline, ObjectMapper om) {
        var proc = new ScheduledBatchAuditProcessor(pipeline, om);
        proc.start();
        return proc;
    }
}

// Additional beans added via append — in production these would be in the main class
