package com.paymenthub.audit.server.processing.merkle;

import com.paymenthub.common.model.integrity.MerkleProof;
import com.paymenthub.common.model.integrity.MerkleRoot;

public interface MerkleAnchorStore {
    void persistRoot(MerkleRoot root);
    MerkleRoot getRoot(String windowId);
    MerkleProof generateProof(String recordHash, String windowId);
}
