package com.paymenthub.audit.server.store.postgres;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.paymenthub.audit.server.query.AuditQueryStore;
import com.paymenthub.common.model.event.AuditEvent;
import com.paymenthub.common.model.query.AuditQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * PostgreSQL-backed audit store for Small profile (ADR-003).
 * Append-only table with tsvector FTS. Also serves as primary durable store
 * for all profiles (sync audit persist-before-ack).
 */
public class PostgresAuditStore implements AuditQueryStore {

    private static final Logger log = LoggerFactory.getLogger(PostgresAuditStore.class);

    private final JdbcTemplate jdbc;
    private final ObjectMapper objectMapper;

    public PostgresAuditStore(JdbcTemplate jdbc, ObjectMapper objectMapper) {
        this.jdbc = jdbc;
        this.objectMapper = objectMapper;
    }

    @Override
    public void index(AuditEvent event) {
        try {
            jdbc.update("""
                INSERT INTO audit_events (event_id, event_type, tenant_id, entity_id,
                    timestamp_utc, actor_identity, correlation_id, resource_id,
                    record_hash, previous_hash, payload)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?::jsonb)
                ON CONFLICT (event_id) DO NOTHING
                """,
                event.eventId(),
                event.eventType(),
                event.resource() != null ? event.resource().tenantId() : null,
                event.resource() != null ? event.resource().entityId() : null,
                Timestamp.from(event.timestamp()),
                event.actor() != null ? event.actor().identity() : null,
                event.correlationId(),
                event.resource() != null ? event.resource().id() : null,
                event.integrity() != null ? event.integrity().recordHash() : null,
                event.integrity() != null ? event.integrity().previousHash() : null,
                objectMapper.writeValueAsString(event)
            );
        } catch (Exception e) {
            log.error("Failed to persist audit event {}", event.eventId(), e);
            throw new RuntimeException("Audit persistence failed", e);
        }
    }

    @Override
    public void indexBatch(List<AuditEvent> events) {
        events.forEach(this::index);
    }

    @Override
    public List<AuditEvent> query(AuditQuery query) {
        var sql = new StringBuilder("SELECT payload FROM audit_events WHERE 1=1");
        var params = new ArrayList<Object>();

        if (query.tenantId() != null) { sql.append(" AND tenant_id = ?"); params.add(query.tenantId()); }
        if (query.correlationId() != null) { sql.append(" AND correlation_id = ?::uuid"); params.add(query.correlationId()); }
        if (query.resourceId() != null) { sql.append(" AND resource_id = ?"); params.add(query.resourceId()); }
        if (query.actorIdentity() != null) { sql.append(" AND actor_identity = ?"); params.add(query.actorIdentity()); }
        if (query.eventType() != null) { sql.append(" AND event_type = ?"); params.add(query.eventType()); }
        if (query.timeFrom() != null) { sql.append(" AND timestamp_utc >= ?"); params.add(Timestamp.from(query.timeFrom())); }
        if (query.timeTo() != null) { sql.append(" AND timestamp_utc <= ?"); params.add(Timestamp.from(query.timeTo())); }
        if (query.fullTextQuery() != null) { sql.append(" AND search_vector @@ plainto_tsquery(?)"); params.add(query.fullTextQuery()); }

        sql.append(" ORDER BY timestamp_utc DESC LIMIT ?");
        params.add(query.pageSize() > 0 ? query.pageSize() : 50);

        return jdbc.query(sql.toString(), params.toArray(), (rs, rowNum) -> {
            try { return objectMapper.readValue(rs.getString("payload"), AuditEvent.class); }
            catch (Exception e) { throw new RuntimeException("Failed to deserialize audit event", e); }
        });
    }

    @Override
    public long count(AuditQuery query) {
        var sql = new StringBuilder("SELECT COUNT(*) FROM audit_events WHERE 1=1");
        var params = new ArrayList<Object>();
        if (query.tenantId() != null) { sql.append(" AND tenant_id = ?"); params.add(query.tenantId()); }
        if (query.eventType() != null) { sql.append(" AND event_type = ?"); params.add(query.eventType()); }
        return jdbc.queryForObject(sql.toString(), Long.class, params.toArray());
    }
}
