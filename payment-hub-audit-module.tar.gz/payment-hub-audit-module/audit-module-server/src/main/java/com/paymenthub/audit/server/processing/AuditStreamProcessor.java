package com.paymenthub.audit.server.processing;

/**
 * Profile-specific stream processor.
 * Large/Medium: KafkaStreamsAuditProcessor
 * Small: ScheduledBatchAuditProcessor (NATS JetStream pull)
 */
public interface AuditStreamProcessor {
    void start();
    void stop();
    ProcessorHealth health();
    record ProcessorHealth(boolean running, long eventsProcessed, long lastProcessedTimestamp, long lagEvents) {}
}
