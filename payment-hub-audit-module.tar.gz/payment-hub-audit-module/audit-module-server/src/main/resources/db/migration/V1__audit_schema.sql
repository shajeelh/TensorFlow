-- ═══════════════════════════════════════════════════════════════
-- V1__audit_schema.sql
-- Payment Hub Audit Module — PostgreSQL Schema
-- Append-only, immutable, partition-ready audit events table
-- ═══════════════════════════════════════════════════════════════

-- 1. Core audit events table (partitioned by month)
CREATE TABLE audit_events (
    id              BIGSERIAL,
    event_id        UUID            NOT NULL,
    event_type      VARCHAR(100)    NOT NULL,
    tenant_id       VARCHAR(50)     NOT NULL,
    entity_id       VARCHAR(50)     NOT NULL,
    timestamp_utc   TIMESTAMPTZ     NOT NULL,
    actor_identity  VARCHAR(255)    NOT NULL,
    correlation_id  UUID            NOT NULL,
    causation_id    UUID,
    resource_id     VARCHAR(255),
    record_hash     BYTEA,
    previous_hash   BYTEA,
    sequence_number BIGINT,
    signature_batch_id BIGINT,
    payload         JSONB           NOT NULL,
    search_vector   TSVECTOR GENERATED ALWAYS AS (
        to_tsvector('english',
            coalesce(event_type, '') || ' ' ||
            coalesce(actor_identity, '') || ' ' ||
            coalesce(resource_id, '') || ' ' ||
            coalesce(payload->>'eventType', '')
        )
    ) STORED,
    created_at      TIMESTAMPTZ     DEFAULT NOW(),

    PRIMARY KEY (id, timestamp_utc),
    CONSTRAINT uq_audit_event_id UNIQUE (event_id, timestamp_utc)
) PARTITION BY RANGE (timestamp_utc);

-- 2. Create initial monthly partitions (current + next 3 months)
DO $$
DECLARE
    start_date DATE := date_trunc('month', CURRENT_DATE);
    end_date DATE;
    partition_name TEXT;
BEGIN
    FOR i IN 0..3 LOOP
        end_date := start_date + interval '1 month';
        partition_name := 'audit_events_' || to_char(start_date, 'YYYY_MM');
        EXECUTE format(
            'CREATE TABLE IF NOT EXISTS %I PARTITION OF audit_events FOR VALUES FROM (%L) TO (%L)',
            partition_name, start_date, end_date
        );
        start_date := end_date;
    END LOOP;
END $$;

-- 3. Performance indexes
CREATE INDEX idx_audit_correlation ON audit_events (correlation_id);
CREATE INDEX idx_audit_resource ON audit_events (resource_id, timestamp_utc);
CREATE INDEX idx_audit_actor ON audit_events (actor_identity, timestamp_utc);
CREATE INDEX idx_audit_type_time ON audit_events (event_type, timestamp_utc);
CREATE INDEX idx_audit_tenant ON audit_events (tenant_id, timestamp_utc);
CREATE INDEX idx_audit_search ON audit_events USING GIN (search_vector);

-- 4. Append-only enforcement trigger
CREATE OR REPLACE FUNCTION prevent_audit_mutation()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'UPDATE' THEN
        RAISE EXCEPTION 'Audit records are immutable. UPDATE denied on event_id=%', OLD.event_id;
    ELSIF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'Audit records are immutable. DELETE denied on event_id=%', OLD.event_id;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER audit_immutable
    BEFORE UPDATE OR DELETE ON audit_events
    FOR EACH ROW EXECUTE FUNCTION prevent_audit_mutation();

-- 5. Signature batches table
CREATE TABLE signature_batches (
    id              BIGSERIAL       PRIMARY KEY,
    batch_digest    BYTEA           NOT NULL,
    signature       BYTEA           NOT NULL,
    signing_key_id  VARCHAR(100)    NOT NULL,
    signing_mode    VARCHAR(20)     NOT NULL,
    record_count    INT             NOT NULL,
    created_at      TIMESTAMPTZ     DEFAULT NOW()
);

-- 6. Merkle anchor table
CREATE TABLE merkle_anchors (
    id              BIGSERIAL       PRIMARY KEY,
    window_id       VARCHAR(100)    NOT NULL UNIQUE,
    root_hash       BYTEA           NOT NULL,
    signature       BYTEA           NOT NULL,
    signing_key_id  VARCHAR(100)    NOT NULL,
    event_count     INT             NOT NULL,
    window_start    TIMESTAMPTZ     NOT NULL,
    window_end      TIMESTAMPTZ     NOT NULL,
    entity_id       VARCHAR(50)     NOT NULL,
    tenant_id       VARCHAR(50)     NOT NULL,
    created_at      TIMESTAMPTZ     DEFAULT NOW()
);

CREATE INDEX idx_merkle_entity ON merkle_anchors (entity_id, window_start);
CREATE INDEX idx_merkle_window ON merkle_anchors (window_start, window_end);

-- 7. Hash chain state table (recovery after restart)
CREATE TABLE hash_chain_state (
    chain_id        VARCHAR(200)    PRIMARY KEY,
    last_hash       BYTEA           NOT NULL,
    last_sequence   BIGINT          NOT NULL,
    updated_at      TIMESTAMPTZ     DEFAULT NOW()
);

-- 8. Heartbeat tracking table
CREATE TABLE heartbeat_tracking (
    module_id       VARCHAR(200)    NOT NULL,
    entity_id       VARCHAR(50)     NOT NULL,
    last_seen       TIMESTAMPTZ     NOT NULL,
    sequence_number BIGINT          NOT NULL DEFAULT 0,
    PRIMARY KEY (module_id, entity_id)
);

-- 9. Row-level security for tenant isolation
ALTER TABLE audit_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation ON audit_events
    USING (tenant_id = current_setting('app.current_tenant_id', true));

-- 10. Revoke direct mutation permissions
-- (Applied after creating the audit_app_user role)
-- REVOKE UPDATE, DELETE ON audit_events FROM audit_app_user;
-- GRANT INSERT, SELECT ON audit_events TO audit_app_user;
