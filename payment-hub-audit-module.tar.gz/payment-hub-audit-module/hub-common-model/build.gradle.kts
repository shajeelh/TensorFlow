plugins {
    `java-library`
}

description = "Payment Hub — Common Domain Model (events, enums, value objects)"

dependencies {
    api("com.fasterxml.jackson.core:jackson-annotations")
    api("com.fasterxml.jackson.core:jackson-databind")
    api("jakarta.validation:jakarta.validation-api")
    compileOnly("org.springframework.boot:spring-boot-autoconfigure")
}
