package com.paymenthub.common.exception;

public class HashChainBrokenException extends RuntimeException {
    private final String chainId;
    private final long sequenceNumber;

    public HashChainBrokenException(String chainId, long sequenceNumber) {
        super("Hash chain broken at chain=" + chainId + ", seq=" + sequenceNumber);
        this.chainId = chainId;
        this.sequenceNumber = sequenceNumber;
    }

    public String getChainId() { return chainId; }
    public long getSequenceNumber() { return sequenceNumber; }
}
