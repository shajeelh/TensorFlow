package com.paymenthub.common.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record EventContext(
    String module,
    String moduleVersion,
    String environment,
    String region,
    String cluster,
    String pod,
    String deploymentId,
    String natsSubject,
    Map<String, String> metadata
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String module, moduleVersion, environment, region, cluster, pod, deploymentId, natsSubject;
        private Map<String, String> metadata;

        public Builder module(String m) { this.module = m; return this; }
        public Builder moduleVersion(String v) { this.moduleVersion = v; return this; }
        public Builder environment(String e) { this.environment = e; return this; }
        public Builder region(String r) { this.region = r; return this; }
        public Builder cluster(String c) { this.cluster = c; return this; }
        public Builder pod(String p) { this.pod = p; return this; }
        public Builder deploymentId(String d) { this.deploymentId = d; return this; }
        public Builder natsSubject(String n) { this.natsSubject = n; return this; }
        public Builder metadata(Map<String, String> m) { this.metadata = m; return this; }

        public EventContext build() {
            return new EventContext(module, moduleVersion, environment, region, cluster, pod, deploymentId, natsSubject, metadata);
        }
    }
}
