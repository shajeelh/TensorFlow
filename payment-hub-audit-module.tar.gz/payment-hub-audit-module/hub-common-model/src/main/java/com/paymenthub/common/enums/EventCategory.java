package com.paymenthub.common.enums;

public enum EventCategory { BUSINESS, SECURITY, TECHNICAL, CONFIGURATION, DATA_ACCESS, ADMINISTRATIVE, CDC }
