package com.paymenthub.common.enums;

public enum ReceiptStatus { CONFIRMED, CONFIRMED_SIGNED, FAILED, DUPLICATE }
