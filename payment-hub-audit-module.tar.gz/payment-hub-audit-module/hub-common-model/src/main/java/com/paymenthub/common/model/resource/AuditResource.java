package com.paymenthub.common.model.resource;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paymenthub.common.enums.DataClassification;
import jakarta.validation.constraints.NotBlank;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record AuditResource(
    @NotBlank String type,
    @NotBlank String id,
    @NotBlank String tenantId,
    @NotBlank String entityId,
    String entityJurisdiction,
    String instanceId,
    DataClassification classification
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String type, id, tenantId, entityId, entityJurisdiction, instanceId;
        private DataClassification classification = DataClassification.NORMAL;

        public Builder type(String type) { this.type = type; return this; }
        public Builder id(String id) { this.id = id; return this; }
        public Builder tenantId(String tenantId) { this.tenantId = tenantId; return this; }
        public Builder entityId(String entityId) { this.entityId = entityId; return this; }
        public Builder entityJurisdiction(String j) { this.entityJurisdiction = j; return this; }
        public Builder instanceId(String i) { this.instanceId = i; return this; }
        public Builder classification(DataClassification c) { this.classification = c; return this; }

        public AuditResource build() {
            return new AuditResource(type, id, tenantId, entityId, entityJurisdiction, instanceId, classification);
        }
    }
}
