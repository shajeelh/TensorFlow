package com.paymenthub.common.model.pii;

/**
 * Represents a Tier 2 PII field after encryption.
 * The pseudo_id enables querying without decryption (ADR-018).
 */
public record EncryptedField(
    String encrypted,
    String keyId,
    String pseudoId,
    String cleartextHint
) {}
