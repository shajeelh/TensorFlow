package com.paymenthub.common.enums;

public enum AuditMode { AUTO, SYNC, ASYNC }
