package com.paymenthub.common.model.event;

import com.paymenthub.common.enums.DeploymentProfile;
import com.paymenthub.common.enums.SigningMode;

public record DeploymentInfo(
    String instanceId,
    DeploymentProfile profile,
    String region,
    String cluster,
    String auditModuleVersion,
    SigningMode signingMode,
    String storageMode
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String instanceId, region, cluster, auditModuleVersion, storageMode;
        private DeploymentProfile profile;
        private SigningMode signingMode;

        public Builder instanceId(String i) { this.instanceId = i; return this; }
        public Builder profile(DeploymentProfile p) { this.profile = p; return this; }
        public Builder region(String r) { this.region = r; return this; }
        public Builder cluster(String c) { this.cluster = c; return this; }
        public Builder auditModuleVersion(String v) { this.auditModuleVersion = v; return this; }
        public Builder signingMode(SigningMode s) { this.signingMode = s; return this; }
        public Builder storageMode(String s) { this.storageMode = s; return this; }

        public DeploymentInfo build() {
            return new DeploymentInfo(instanceId, profile, region, cluster, auditModuleVersion, signingMode, storageMode);
        }
    }
}
