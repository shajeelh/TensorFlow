package com.paymenthub.common.enums;

public enum TransportType { KAFKA, NATS_JETSTREAM, RABBITMQ_STREAM, RABBITMQ_QUORUM }
