package com.paymenthub.common.model.event;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Before/after state for audited operations.
 * The PII sanitizer processes these fields before they enter the audit pipeline.
 */
public record StateChange(JsonNode before, JsonNode after) {
    public static StateChange of(Object before, Object after) {
        // Actual conversion handled by AuditEventBuilder using ObjectMapper
        return new StateChange(null, null);
    }
}
