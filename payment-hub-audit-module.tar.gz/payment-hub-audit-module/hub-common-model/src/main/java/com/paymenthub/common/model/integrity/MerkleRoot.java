package com.paymenthub.common.model.integrity;

import java.time.Instant;

public record MerkleRoot(
    String windowId,
    byte[] rootHash,
    byte[] signature,
    String signingKeyId,
    int eventCount,
    Instant windowStart,
    Instant windowEnd,
    String entityId,
    String tenantId
) {}
