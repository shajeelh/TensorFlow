package com.paymenthub.common.model.integrity;

public record SignatureInfo(
    byte[] signature,
    String signingKeyId,
    String signingMode,
    boolean batchSigned,
    Long batchId
) {}
