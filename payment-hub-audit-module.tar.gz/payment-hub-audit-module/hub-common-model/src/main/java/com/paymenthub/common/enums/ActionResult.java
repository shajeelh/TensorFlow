package com.paymenthub.common.enums;

public enum ActionResult { SUCCESS, FAILURE, PARTIAL }
