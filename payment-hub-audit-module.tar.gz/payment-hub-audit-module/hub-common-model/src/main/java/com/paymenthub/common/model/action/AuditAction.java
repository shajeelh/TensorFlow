package com.paymenthub.common.model.action;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paymenthub.common.enums.ActionResult;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record AuditAction(
    @NotBlank String operation,
    @NotNull ActionResult result,
    String reasonCode,
    Long durationUs
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String operation, reasonCode;
        private ActionResult result = ActionResult.SUCCESS;
        private Long durationUs;

        public Builder operation(String op) { this.operation = op; return this; }
        public Builder result(ActionResult r) { this.result = r; return this; }
        public Builder reasonCode(String code) { this.reasonCode = code; return this; }
        public Builder durationUs(Long d) { this.durationUs = d; return this; }

        public AuditAction build() { return new AuditAction(operation, result, reasonCode, durationUs); }
    }
}
