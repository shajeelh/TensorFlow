package com.paymenthub.common.model.receipt;

import com.paymenthub.common.enums.ReceiptStatus;
import java.time.Instant;
import java.util.UUID;

/**
 * Proof that an audit event was durably recorded.
 * Returned synchronously to the caller for SYNC mode events.
 */
public record AuditReceipt(
    UUID eventId,
    byte[] recordHash,
    byte[] previousHash,
    long sequenceNumber,
    Instant recordedAt,
    String clockId,
    PersistenceConfirmation persistence,
    ReceiptStatus status
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private UUID eventId;
        private byte[] recordHash, previousHash;
        private long sequenceNumber;
        private Instant recordedAt;
        private String clockId;
        private PersistenceConfirmation persistence;
        private ReceiptStatus status;

        public Builder eventId(UUID id) { this.eventId = id; return this; }
        public Builder recordHash(byte[] h) { this.recordHash = h; return this; }
        public Builder previousHash(byte[] h) { this.previousHash = h; return this; }
        public Builder sequenceNumber(long s) { this.sequenceNumber = s; return this; }
        public Builder recordedAt(Instant t) { this.recordedAt = t; return this; }
        public Builder clockId(String c) { this.clockId = c; return this; }
        public Builder persistence(PersistenceConfirmation p) { this.persistence = p; return this; }
        public Builder status(ReceiptStatus s) { this.status = s; return this; }

        public AuditReceipt build() {
            return new AuditReceipt(eventId, recordHash, previousHash, sequenceNumber, recordedAt, clockId, persistence, status);
        }
    }
}
