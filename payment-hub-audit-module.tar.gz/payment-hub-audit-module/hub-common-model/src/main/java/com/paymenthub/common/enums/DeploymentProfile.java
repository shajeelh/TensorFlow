package com.paymenthub.common.enums;

public enum DeploymentProfile { LARGE, MEDIUM, SMALL }
