package com.paymenthub.common.model.integrity;

import java.util.List;

public record MerkleProof(
    byte[] leafHash,
    List<MerkleProofNode> path,
    byte[] rootHash,
    byte[] rootSignature,
    String merkleWindowId
) {}
