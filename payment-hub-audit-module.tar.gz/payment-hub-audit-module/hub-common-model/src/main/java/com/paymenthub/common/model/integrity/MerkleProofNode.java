package com.paymenthub.common.model.integrity;

public record MerkleProofNode(byte[] hash, Position position) {
    public enum Position { LEFT, RIGHT }
}
