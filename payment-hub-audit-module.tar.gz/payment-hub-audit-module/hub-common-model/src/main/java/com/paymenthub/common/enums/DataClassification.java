package com.paymenthub.common.enums;

public enum DataClassification { PROHIBITED, PCI, PII, NORMAL, CONFIDENTIAL }
