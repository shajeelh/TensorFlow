package com.paymenthub.common.model.actor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paymenthub.common.enums.ActorType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record AuditActor(
    @NotNull ActorType type,
    @NotBlank String identity,
    String authMethod,
    String sessionId,
    String sourceIp,
    String geoLocation,
    String deviceFingerprint
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private ActorType type;
        private String identity;
        private String authMethod;
        private String sessionId;
        private String sourceIp;
        private String geoLocation;
        private String deviceFingerprint;

        public Builder type(ActorType type) { this.type = type; return this; }
        public Builder identity(String identity) { this.identity = identity; return this; }
        public Builder authMethod(String authMethod) { this.authMethod = authMethod; return this; }
        public Builder sessionId(String sessionId) { this.sessionId = sessionId; return this; }
        public Builder sourceIp(String sourceIp) { this.sourceIp = sourceIp; return this; }
        public Builder geoLocation(String geoLocation) { this.geoLocation = geoLocation; return this; }
        public Builder deviceFingerprint(String deviceFingerprint) { this.deviceFingerprint = deviceFingerprint; return this; }

        public AuditActor build() {
            return new AuditActor(type, identity, authMethod, sessionId, sourceIp, geoLocation, deviceFingerprint);
        }
    }
}
