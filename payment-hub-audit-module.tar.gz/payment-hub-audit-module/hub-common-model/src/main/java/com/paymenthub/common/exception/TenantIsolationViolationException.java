package com.paymenthub.common.exception;

public class TenantIsolationViolationException extends SecurityException {
    public TenantIsolationViolationException(String requestedTenant, String authorizedTenant) {
        super("Tenant isolation violation: requested=" + requestedTenant + ", authorized=" + authorizedTenant);
    }
}
