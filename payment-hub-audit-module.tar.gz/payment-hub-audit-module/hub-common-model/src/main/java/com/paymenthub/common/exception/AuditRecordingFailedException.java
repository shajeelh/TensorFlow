package com.paymenthub.common.exception;

/**
 * Thrown when synchronous audit recording fails.
 * The business operation MUST NOT proceed when this is thrown.
 */
public class AuditRecordingFailedException extends RuntimeException {
    private final String eventType;
    private final String correlationId;

    public AuditRecordingFailedException(String message) {
        super(message);
        this.eventType = null;
        this.correlationId = null;
    }

    public AuditRecordingFailedException(String message, String eventType, String correlationId) {
        super(message + " [eventType=" + eventType + ", correlationId=" + correlationId + "]");
        this.eventType = eventType;
        this.correlationId = correlationId;
    }

    public AuditRecordingFailedException(String message, Throwable cause) {
        super(message, cause);
        this.eventType = null;
        this.correlationId = null;
    }

    public String getEventType() { return eventType; }
    public String getCorrelationId() { return correlationId; }
}
