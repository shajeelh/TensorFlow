package com.paymenthub.common.model.pii;

/**
 * Represents a Tier 1 PCI field after tokenization.
 * Only the vault token and last-4 are stored.
 */
public record TokenizedField(
    String token,
    String last4
) {}
