package com.paymenthub.common.model.integrity;

import java.util.List;

public record SignedBatch(
    long batchId,
    List<byte[]> recordHashes,
    byte[] batchDigest,
    byte[] signature,
    String signingKeyId,
    String signingMode
) {}
