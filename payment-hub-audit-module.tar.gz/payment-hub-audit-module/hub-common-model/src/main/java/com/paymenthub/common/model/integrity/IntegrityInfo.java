package com.paymenthub.common.model.integrity;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Cryptographic integrity metadata for an audit record.
 * Populated by the audit processing pipeline (hash chaining, signing, Merkle tree).
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record IntegrityInfo(
    byte[] recordHash,
    byte[] previousHash,
    long sequenceNumber,
    byte[] piiHash,
    byte[] combinedHash,
    SignatureInfo signature,
    String merkleWindowId
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private byte[] recordHash, previousHash, piiHash, combinedHash;
        private long sequenceNumber;
        private SignatureInfo signature;
        private String merkleWindowId;

        public Builder recordHash(byte[] h) { this.recordHash = h; return this; }
        public Builder previousHash(byte[] h) { this.previousHash = h; return this; }
        public Builder sequenceNumber(long s) { this.sequenceNumber = s; return this; }
        public Builder piiHash(byte[] h) { this.piiHash = h; return this; }
        public Builder combinedHash(byte[] h) { this.combinedHash = h; return this; }
        public Builder signature(SignatureInfo s) { this.signature = s; return this; }
        public Builder merkleWindowId(String id) { this.merkleWindowId = id; return this; }

        public IntegrityInfo build() {
            return new IntegrityInfo(recordHash, previousHash, sequenceNumber, piiHash, combinedHash, signature, merkleWindowId);
        }
    }
}
