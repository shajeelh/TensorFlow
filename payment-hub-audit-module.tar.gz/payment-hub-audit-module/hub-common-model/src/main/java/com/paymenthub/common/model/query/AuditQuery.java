package com.paymenthub.common.model.query;

import java.time.Instant;

/**
 * Profile-transparent query model used by AuditQueryStore (OpenSearch or PostgreSQL).
 */
public record AuditQuery(
    String correlationId,
    String resourceId,
    String actorIdentity,
    String eventType,
    String tenantId,
    Instant timeFrom,
    Instant timeTo,
    String fullTextQuery,
    int pageSize,
    String pageToken
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String correlationId, resourceId, actorIdentity, eventType, tenantId, fullTextQuery, pageToken;
        private Instant timeFrom, timeTo;
        private int pageSize = 50;

        public Builder correlationId(String id) { this.correlationId = id; return this; }
        public Builder resourceId(String id) { this.resourceId = id; return this; }
        public Builder actorIdentity(String id) { this.actorIdentity = id; return this; }
        public Builder eventType(String type) { this.eventType = type; return this; }
        public Builder tenantId(String id) { this.tenantId = id; return this; }
        public Builder timeFrom(Instant t) { this.timeFrom = t; return this; }
        public Builder timeTo(Instant t) { this.timeTo = t; return this; }
        public Builder fullTextQuery(String q) { this.fullTextQuery = q; return this; }
        public Builder pageSize(int s) { this.pageSize = s; return this; }
        public Builder pageToken(String token) { this.pageToken = token; return this; }

        public AuditQuery build() {
            return new AuditQuery(correlationId, resourceId, actorIdentity, eventType, tenantId, timeFrom, timeTo, fullTextQuery, pageSize, pageToken);
        }
    }
}
