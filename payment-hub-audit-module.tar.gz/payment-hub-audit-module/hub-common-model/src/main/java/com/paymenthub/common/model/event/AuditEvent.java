package com.paymenthub.common.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paymenthub.common.model.action.AuditAction;
import com.paymenthub.common.model.actor.AuditActor;
import com.paymenthub.common.model.integrity.IntegrityInfo;
import com.paymenthub.common.model.resource.AuditResource;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.Instant;
import java.util.UUID;

/**
 * Canonical audit event — the fundamental data structure of the audit module.
 * Immutable once constructed. PII fields are encrypted/tokenized before this
 * object reaches the transport layer.
 *
 * @see com.paymenthub.common.model.integrity.IntegrityInfo
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record AuditEvent(
    UUID eventId,
    @NotBlank String eventType,
    String eventVersion,
    @NotNull UUID correlationId,
    UUID causationId,
    @NotNull Instant timestamp,
    @Valid @NotNull AuditActor actor,
    @Valid @NotNull AuditResource resource,
    @Valid @NotNull AuditAction action,
    StateChange stateChange,
    EventContext context,
    DeploymentInfo deployment,
    IntegrityInfo integrity,
    String idempotencyKey
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private UUID eventId;
        private String eventType, eventVersion = "2.1", idempotencyKey;
        private UUID correlationId, causationId;
        private Instant timestamp;
        private AuditActor actor;
        private AuditResource resource;
        private AuditAction action;
        private StateChange stateChange;
        private EventContext context;
        private DeploymentInfo deployment;
        private IntegrityInfo integrity;

        public Builder eventId(UUID id) { this.eventId = id; return this; }
        public Builder eventType(String type) { this.eventType = type; return this; }
        public Builder eventVersion(String v) { this.eventVersion = v; return this; }
        public Builder correlationId(UUID id) { this.correlationId = id; return this; }
        public Builder causationId(UUID id) { this.causationId = id; return this; }
        public Builder timestamp(Instant ts) { this.timestamp = ts; return this; }
        public Builder actor(AuditActor actor) { this.actor = actor; return this; }
        public Builder resource(AuditResource resource) { this.resource = resource; return this; }
        public Builder action(AuditAction action) { this.action = action; return this; }
        public Builder stateChange(StateChange sc) { this.stateChange = sc; return this; }
        public Builder context(EventContext ctx) { this.context = ctx; return this; }
        public Builder deployment(DeploymentInfo di) { this.deployment = di; return this; }
        public Builder integrity(IntegrityInfo ii) { this.integrity = ii; return this; }
        public Builder idempotencyKey(String key) { this.idempotencyKey = key; return this; }

        public AuditEvent build() {
            if (eventId == null) eventId = UUID.randomUUID();
            if (timestamp == null) timestamp = Instant.now();
            return new AuditEvent(eventId, eventType, eventVersion, correlationId, causationId,
                timestamp, actor, resource, action, stateChange, context, deployment, integrity, idempotencyKey);
        }
    }
}
