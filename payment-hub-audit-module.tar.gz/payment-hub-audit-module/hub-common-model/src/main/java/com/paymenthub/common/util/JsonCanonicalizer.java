package com.paymenthub.common.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.util.Iterator;
import java.util.TreeMap;

/**
 * RFC 8785 (JCS) compliant JSON canonicalization for deterministic hashing.
 * All hash computations in the audit module use this to ensure
 * the same logical event always produces the same hash.
 */
public final class JsonCanonicalizer {

    private static final ObjectMapper MAPPER = new ObjectMapper()
        .registerModule(new JavaTimeModule())
        .configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true)
        .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

    private JsonCanonicalizer() {}

    public static String canonicalize(Object obj) {
        try {
            JsonNode node = MAPPER.valueToTree(obj);
            JsonNode sorted = sortNode(node);
            return MAPPER.writeValueAsString(sorted);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Failed to canonicalize JSON", e);
        }
    }

    public static byte[] canonicalizeToBytes(Object obj) {
        return canonicalize(obj).getBytes(java.nio.charset.StandardCharsets.UTF_8);
    }

    private static JsonNode sortNode(JsonNode node) {
        if (node.isObject()) {
            ObjectNode sorted = MAPPER.createObjectNode();
            TreeMap<String, JsonNode> fields = new TreeMap<>();
            Iterator<java.util.Map.Entry<String, JsonNode>> it = node.fields();
            while (it.hasNext()) {
                var entry = it.next();
                fields.put(entry.getKey(), sortNode(entry.getValue()));
            }
            fields.forEach(sorted::set);
            return sorted;
        } else if (node.isArray()) {
            var array = MAPPER.createArrayNode();
            node.forEach(element -> array.add(sortNode(element)));
            return array;
        }
        return node;
    }
}
