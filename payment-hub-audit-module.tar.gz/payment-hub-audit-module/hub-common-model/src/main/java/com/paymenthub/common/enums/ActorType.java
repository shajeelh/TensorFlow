package com.paymenthub.common.enums;

public enum ActorType { USER, SERVICE, SYSTEM, SCHEDULER }
