package com.paymenthub.common.model.receipt;

public record PersistenceConfirmation(
    String storeType,
    String storeReference,
    boolean replicated,
    int replicaCount
) {}
