plugins {
    `java-library`
}

description = "Payment Hub — gRPC server/client with interceptors"

dependencies {
    api(project(":hub-common-model"))
    api(project(":hub-observability-starter"))
    api("io.grpc:grpc-stub")
    api("io.grpc:grpc-protobuf")
    api("io.grpc:grpc-netty-shaded")
    implementation(project(":hub-pii-starter"))
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("io.micrometer:micrometer-core")
    compileOnly("com.google.protobuf:protobuf-java")
}
