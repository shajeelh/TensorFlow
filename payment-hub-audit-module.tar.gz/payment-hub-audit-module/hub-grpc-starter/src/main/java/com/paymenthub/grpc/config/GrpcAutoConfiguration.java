package com.paymenthub.grpc.config;
import org.springframework.boot.autoconfigure.AutoConfiguration;
@AutoConfiguration public class GrpcAutoConfiguration {}
