#!/bin/bash
set -e
cd /home/claude/payment-hub-audit-module
BASE="src/main/java/com/paymenthub"

# ═══════════════════════════════════════════════════════════════
# HUB-COMMON-MODEL: Domain model shared across ALL modules
# ═══════════════════════════════════════════════════════════════
CM="hub-common-model/$BASE/common"

# --- Enums ---
cat > $CM/enums/AuditMode.java << 'EOF'
package com.paymenthub.common.enums;

public enum AuditMode { AUTO, SYNC, ASYNC }
EOF

cat > $CM/enums/ActorType.java << 'EOF'
package com.paymenthub.common.enums;

public enum ActorType { USER, SERVICE, SYSTEM, SCHEDULER }
EOF

cat > $CM/enums/ActionResult.java << 'EOF'
package com.paymenthub.common.enums;

public enum ActionResult { SUCCESS, FAILURE, PARTIAL }
EOF

cat > $CM/enums/DataClassification.java << 'EOF'
package com.paymenthub.common.enums;

public enum DataClassification { PROHIBITED, PCI, PII, NORMAL, CONFIDENTIAL }
EOF

cat > $CM/enums/ReceiptStatus.java << 'EOF'
package com.paymenthub.common.enums;

public enum ReceiptStatus { CONFIRMED, CONFIRMED_SIGNED, FAILED, DUPLICATE }
EOF

cat > $CM/enums/DeploymentProfile.java << 'EOF'
package com.paymenthub.common.enums;

public enum DeploymentProfile { LARGE, MEDIUM, SMALL }
EOF

cat > $CM/enums/SigningMode.java << 'EOF'
package com.paymenthub.common.enums;

public enum SigningMode { HSM, SOFTWARE, REMOTE_HSM }
EOF

cat > $CM/enums/TransportType.java << 'EOF'
package com.paymenthub.common.enums;

public enum TransportType { KAFKA, NATS_JETSTREAM, RABBITMQ_STREAM, RABBITMQ_QUORUM }
EOF

cat > $CM/enums/EventCategory.java << 'EOF'
package com.paymenthub.common.enums;

public enum EventCategory { BUSINESS, SECURITY, TECHNICAL, CONFIGURATION, DATA_ACCESS, ADMINISTRATIVE, CDC }
EOF

# --- Model: Actor ---
cat > $CM/model/actor/AuditActor.java << 'EOF'
package com.paymenthub.common.model.actor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paymenthub.common.enums.ActorType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record AuditActor(
    @NotNull ActorType type,
    @NotBlank String identity,
    String authMethod,
    String sessionId,
    String sourceIp,
    String geoLocation,
    String deviceFingerprint
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private ActorType type;
        private String identity;
        private String authMethod;
        private String sessionId;
        private String sourceIp;
        private String geoLocation;
        private String deviceFingerprint;

        public Builder type(ActorType type) { this.type = type; return this; }
        public Builder identity(String identity) { this.identity = identity; return this; }
        public Builder authMethod(String authMethod) { this.authMethod = authMethod; return this; }
        public Builder sessionId(String sessionId) { this.sessionId = sessionId; return this; }
        public Builder sourceIp(String sourceIp) { this.sourceIp = sourceIp; return this; }
        public Builder geoLocation(String geoLocation) { this.geoLocation = geoLocation; return this; }
        public Builder deviceFingerprint(String deviceFingerprint) { this.deviceFingerprint = deviceFingerprint; return this; }

        public AuditActor build() {
            return new AuditActor(type, identity, authMethod, sessionId, sourceIp, geoLocation, deviceFingerprint);
        }
    }
}
EOF

# --- Model: Resource ---
cat > $CM/model/resource/AuditResource.java << 'EOF'
package com.paymenthub.common.model.resource;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paymenthub.common.enums.DataClassification;
import jakarta.validation.constraints.NotBlank;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record AuditResource(
    @NotBlank String type,
    @NotBlank String id,
    @NotBlank String tenantId,
    @NotBlank String entityId,
    String entityJurisdiction,
    String instanceId,
    DataClassification classification
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String type, id, tenantId, entityId, entityJurisdiction, instanceId;
        private DataClassification classification = DataClassification.NORMAL;

        public Builder type(String type) { this.type = type; return this; }
        public Builder id(String id) { this.id = id; return this; }
        public Builder tenantId(String tenantId) { this.tenantId = tenantId; return this; }
        public Builder entityId(String entityId) { this.entityId = entityId; return this; }
        public Builder entityJurisdiction(String j) { this.entityJurisdiction = j; return this; }
        public Builder instanceId(String i) { this.instanceId = i; return this; }
        public Builder classification(DataClassification c) { this.classification = c; return this; }

        public AuditResource build() {
            return new AuditResource(type, id, tenantId, entityId, entityJurisdiction, instanceId, classification);
        }
    }
}
EOF

# --- Model: Action ---
cat > $CM/model/action/AuditAction.java << 'EOF'
package com.paymenthub.common.model.action;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paymenthub.common.enums.ActionResult;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record AuditAction(
    @NotBlank String operation,
    @NotNull ActionResult result,
    String reasonCode,
    Long durationUs
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String operation, reasonCode;
        private ActionResult result = ActionResult.SUCCESS;
        private Long durationUs;

        public Builder operation(String op) { this.operation = op; return this; }
        public Builder result(ActionResult r) { this.result = r; return this; }
        public Builder reasonCode(String code) { this.reasonCode = code; return this; }
        public Builder durationUs(Long d) { this.durationUs = d; return this; }

        public AuditAction build() { return new AuditAction(operation, result, reasonCode, durationUs); }
    }
}
EOF

# --- Model: StateChange ---
cat > $CM/model/event/StateChange.java << 'EOF'
package com.paymenthub.common.model.event;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Before/after state for audited operations.
 * The PII sanitizer processes these fields before they enter the audit pipeline.
 */
public record StateChange(JsonNode before, JsonNode after) {
    public static StateChange of(Object before, Object after) {
        // Actual conversion handled by AuditEventBuilder using ObjectMapper
        return new StateChange(null, null);
    }
}
EOF

# --- Model: EventContext ---
cat > $CM/model/event/EventContext.java << 'EOF'
package com.paymenthub.common.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record EventContext(
    String module,
    String moduleVersion,
    String environment,
    String region,
    String cluster,
    String pod,
    String deploymentId,
    String natsSubject,
    Map<String, String> metadata
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String module, moduleVersion, environment, region, cluster, pod, deploymentId, natsSubject;
        private Map<String, String> metadata;

        public Builder module(String m) { this.module = m; return this; }
        public Builder moduleVersion(String v) { this.moduleVersion = v; return this; }
        public Builder environment(String e) { this.environment = e; return this; }
        public Builder region(String r) { this.region = r; return this; }
        public Builder cluster(String c) { this.cluster = c; return this; }
        public Builder pod(String p) { this.pod = p; return this; }
        public Builder deploymentId(String d) { this.deploymentId = d; return this; }
        public Builder natsSubject(String n) { this.natsSubject = n; return this; }
        public Builder metadata(Map<String, String> m) { this.metadata = m; return this; }

        public EventContext build() {
            return new EventContext(module, moduleVersion, environment, region, cluster, pod, deploymentId, natsSubject, metadata);
        }
    }
}
EOF

# --- Model: DeploymentInfo ---
cat > $CM/model/event/DeploymentInfo.java << 'EOF'
package com.paymenthub.common.model.event;

import com.paymenthub.common.enums.DeploymentProfile;
import com.paymenthub.common.enums.SigningMode;

public record DeploymentInfo(
    String instanceId,
    DeploymentProfile profile,
    String region,
    String cluster,
    String auditModuleVersion,
    SigningMode signingMode,
    String storageMode
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String instanceId, region, cluster, auditModuleVersion, storageMode;
        private DeploymentProfile profile;
        private SigningMode signingMode;

        public Builder instanceId(String i) { this.instanceId = i; return this; }
        public Builder profile(DeploymentProfile p) { this.profile = p; return this; }
        public Builder region(String r) { this.region = r; return this; }
        public Builder cluster(String c) { this.cluster = c; return this; }
        public Builder auditModuleVersion(String v) { this.auditModuleVersion = v; return this; }
        public Builder signingMode(SigningMode s) { this.signingMode = s; return this; }
        public Builder storageMode(String s) { this.storageMode = s; return this; }

        public DeploymentInfo build() {
            return new DeploymentInfo(instanceId, profile, region, cluster, auditModuleVersion, signingMode, storageMode);
        }
    }
}
EOF

# --- Model: AuditEvent (the canonical event) ---
cat > $CM/model/event/AuditEvent.java << 'EOF'
package com.paymenthub.common.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paymenthub.common.model.action.AuditAction;
import com.paymenthub.common.model.actor.AuditActor;
import com.paymenthub.common.model.integrity.IntegrityInfo;
import com.paymenthub.common.model.resource.AuditResource;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.Instant;
import java.util.UUID;

/**
 * Canonical audit event — the fundamental data structure of the audit module.
 * Immutable once constructed. PII fields are encrypted/tokenized before this
 * object reaches the transport layer.
 *
 * @see com.paymenthub.common.model.integrity.IntegrityInfo
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record AuditEvent(
    UUID eventId,
    @NotBlank String eventType,
    String eventVersion,
    @NotNull UUID correlationId,
    UUID causationId,
    @NotNull Instant timestamp,
    @Valid @NotNull AuditActor actor,
    @Valid @NotNull AuditResource resource,
    @Valid @NotNull AuditAction action,
    StateChange stateChange,
    EventContext context,
    DeploymentInfo deployment,
    IntegrityInfo integrity,
    String idempotencyKey
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private UUID eventId;
        private String eventType, eventVersion = "2.1", idempotencyKey;
        private UUID correlationId, causationId;
        private Instant timestamp;
        private AuditActor actor;
        private AuditResource resource;
        private AuditAction action;
        private StateChange stateChange;
        private EventContext context;
        private DeploymentInfo deployment;
        private IntegrityInfo integrity;

        public Builder eventId(UUID id) { this.eventId = id; return this; }
        public Builder eventType(String type) { this.eventType = type; return this; }
        public Builder eventVersion(String v) { this.eventVersion = v; return this; }
        public Builder correlationId(UUID id) { this.correlationId = id; return this; }
        public Builder causationId(UUID id) { this.causationId = id; return this; }
        public Builder timestamp(Instant ts) { this.timestamp = ts; return this; }
        public Builder actor(AuditActor actor) { this.actor = actor; return this; }
        public Builder resource(AuditResource resource) { this.resource = resource; return this; }
        public Builder action(AuditAction action) { this.action = action; return this; }
        public Builder stateChange(StateChange sc) { this.stateChange = sc; return this; }
        public Builder context(EventContext ctx) { this.context = ctx; return this; }
        public Builder deployment(DeploymentInfo di) { this.deployment = di; return this; }
        public Builder integrity(IntegrityInfo ii) { this.integrity = ii; return this; }
        public Builder idempotencyKey(String key) { this.idempotencyKey = key; return this; }

        public AuditEvent build() {
            if (eventId == null) eventId = UUID.randomUUID();
            if (timestamp == null) timestamp = Instant.now();
            return new AuditEvent(eventId, eventType, eventVersion, correlationId, causationId,
                timestamp, actor, resource, action, stateChange, context, deployment, integrity, idempotencyKey);
        }
    }
}
EOF

# --- Model: IntegrityInfo ---
cat > $CM/model/integrity/IntegrityInfo.java << 'EOF'
package com.paymenthub.common.model.integrity;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Cryptographic integrity metadata for an audit record.
 * Populated by the audit processing pipeline (hash chaining, signing, Merkle tree).
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record IntegrityInfo(
    byte[] recordHash,
    byte[] previousHash,
    long sequenceNumber,
    byte[] piiHash,
    byte[] combinedHash,
    SignatureInfo signature,
    String merkleWindowId
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private byte[] recordHash, previousHash, piiHash, combinedHash;
        private long sequenceNumber;
        private SignatureInfo signature;
        private String merkleWindowId;

        public Builder recordHash(byte[] h) { this.recordHash = h; return this; }
        public Builder previousHash(byte[] h) { this.previousHash = h; return this; }
        public Builder sequenceNumber(long s) { this.sequenceNumber = s; return this; }
        public Builder piiHash(byte[] h) { this.piiHash = h; return this; }
        public Builder combinedHash(byte[] h) { this.combinedHash = h; return this; }
        public Builder signature(SignatureInfo s) { this.signature = s; return this; }
        public Builder merkleWindowId(String id) { this.merkleWindowId = id; return this; }

        public IntegrityInfo build() {
            return new IntegrityInfo(recordHash, previousHash, sequenceNumber, piiHash, combinedHash, signature, merkleWindowId);
        }
    }
}
EOF

cat > $CM/model/integrity/SignatureInfo.java << 'EOF'
package com.paymenthub.common.model.integrity;

public record SignatureInfo(
    byte[] signature,
    String signingKeyId,
    String signingMode,
    boolean batchSigned,
    Long batchId
) {}
EOF

cat > $CM/model/integrity/MerkleRoot.java << 'EOF'
package com.paymenthub.common.model.integrity;

import java.time.Instant;

public record MerkleRoot(
    String windowId,
    byte[] rootHash,
    byte[] signature,
    String signingKeyId,
    int eventCount,
    Instant windowStart,
    Instant windowEnd,
    String entityId,
    String tenantId
) {}
EOF

cat > $CM/model/integrity/MerkleProof.java << 'EOF'
package com.paymenthub.common.model.integrity;

import java.util.List;

public record MerkleProof(
    byte[] leafHash,
    List<MerkleProofNode> path,
    byte[] rootHash,
    byte[] rootSignature,
    String merkleWindowId
) {}
EOF

cat > $CM/model/integrity/MerkleProofNode.java << 'EOF'
package com.paymenthub.common.model.integrity;

public record MerkleProofNode(byte[] hash, Position position) {
    public enum Position { LEFT, RIGHT }
}
EOF

cat > $CM/model/integrity/SignedBatch.java << 'EOF'
package com.paymenthub.common.model.integrity;

import java.util.List;

public record SignedBatch(
    long batchId,
    List<byte[]> recordHashes,
    byte[] batchDigest,
    byte[] signature,
    String signingKeyId,
    String signingMode
) {}
EOF

# --- Model: AuditReceipt ---
cat > $CM/model/receipt/AuditReceipt.java << 'EOF'
package com.paymenthub.common.model.receipt;

import com.paymenthub.common.enums.ReceiptStatus;
import java.time.Instant;
import java.util.UUID;

/**
 * Proof that an audit event was durably recorded.
 * Returned synchronously to the caller for SYNC mode events.
 */
public record AuditReceipt(
    UUID eventId,
    byte[] recordHash,
    byte[] previousHash,
    long sequenceNumber,
    Instant recordedAt,
    String clockId,
    PersistenceConfirmation persistence,
    ReceiptStatus status
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private UUID eventId;
        private byte[] recordHash, previousHash;
        private long sequenceNumber;
        private Instant recordedAt;
        private String clockId;
        private PersistenceConfirmation persistence;
        private ReceiptStatus status;

        public Builder eventId(UUID id) { this.eventId = id; return this; }
        public Builder recordHash(byte[] h) { this.recordHash = h; return this; }
        public Builder previousHash(byte[] h) { this.previousHash = h; return this; }
        public Builder sequenceNumber(long s) { this.sequenceNumber = s; return this; }
        public Builder recordedAt(Instant t) { this.recordedAt = t; return this; }
        public Builder clockId(String c) { this.clockId = c; return this; }
        public Builder persistence(PersistenceConfirmation p) { this.persistence = p; return this; }
        public Builder status(ReceiptStatus s) { this.status = s; return this; }

        public AuditReceipt build() {
            return new AuditReceipt(eventId, recordHash, previousHash, sequenceNumber, recordedAt, clockId, persistence, status);
        }
    }
}
EOF

cat > $CM/model/receipt/PersistenceConfirmation.java << 'EOF'
package com.paymenthub.common.model.receipt;

public record PersistenceConfirmation(
    String storeType,
    String storeReference,
    boolean replicated,
    int replicaCount
) {}
EOF

# --- Model: PII ---
cat > $CM/model/pii/EncryptedField.java << 'EOF'
package com.paymenthub.common.model.pii;

/**
 * Represents a Tier 2 PII field after encryption.
 * The pseudo_id enables querying without decryption (ADR-018).
 */
public record EncryptedField(
    String encrypted,
    String keyId,
    String pseudoId,
    String cleartextHint
) {}
EOF

cat > $CM/model/pii/TokenizedField.java << 'EOF'
package com.paymenthub.common.model.pii;

/**
 * Represents a Tier 1 PCI field after tokenization.
 * Only the vault token and last-4 are stored.
 */
public record TokenizedField(
    String token,
    String last4
) {}
EOF

# --- Model: Query ---
mkdir -p $CM/model/query
cat > $CM/model/query/AuditQuery.java << 'EOF'
package com.paymenthub.common.model.query;

import java.time.Instant;

/**
 * Profile-transparent query model used by AuditQueryStore (OpenSearch or PostgreSQL).
 */
public record AuditQuery(
    String correlationId,
    String resourceId,
    String actorIdentity,
    String eventType,
    String tenantId,
    Instant timeFrom,
    Instant timeTo,
    String fullTextQuery,
    int pageSize,
    String pageToken
) {
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String correlationId, resourceId, actorIdentity, eventType, tenantId, fullTextQuery, pageToken;
        private Instant timeFrom, timeTo;
        private int pageSize = 50;

        public Builder correlationId(String id) { this.correlationId = id; return this; }
        public Builder resourceId(String id) { this.resourceId = id; return this; }
        public Builder actorIdentity(String id) { this.actorIdentity = id; return this; }
        public Builder eventType(String type) { this.eventType = type; return this; }
        public Builder tenantId(String id) { this.tenantId = id; return this; }
        public Builder timeFrom(Instant t) { this.timeFrom = t; return this; }
        public Builder timeTo(Instant t) { this.timeTo = t; return this; }
        public Builder fullTextQuery(String q) { this.fullTextQuery = q; return this; }
        public Builder pageSize(int s) { this.pageSize = s; return this; }
        public Builder pageToken(String token) { this.pageToken = token; return this; }

        public AuditQuery build() {
            return new AuditQuery(correlationId, resourceId, actorIdentity, eventType, tenantId, timeFrom, timeTo, fullTextQuery, pageSize, pageToken);
        }
    }
}
EOF

# --- Exceptions ---
cat > $CM/exception/AuditRecordingFailedException.java << 'EOF'
package com.paymenthub.common.exception;

/**
 * Thrown when synchronous audit recording fails.
 * The business operation MUST NOT proceed when this is thrown.
 */
public class AuditRecordingFailedException extends RuntimeException {
    private final String eventType;
    private final String correlationId;

    public AuditRecordingFailedException(String message) {
        super(message);
        this.eventType = null;
        this.correlationId = null;
    }

    public AuditRecordingFailedException(String message, String eventType, String correlationId) {
        super(message + " [eventType=" + eventType + ", correlationId=" + correlationId + "]");
        this.eventType = eventType;
        this.correlationId = correlationId;
    }

    public AuditRecordingFailedException(String message, Throwable cause) {
        super(message, cause);
        this.eventType = null;
        this.correlationId = null;
    }

    public String getEventType() { return eventType; }
    public String getCorrelationId() { return correlationId; }
}
EOF

cat > $CM/exception/HashChainBrokenException.java << 'EOF'
package com.paymenthub.common.exception;

public class HashChainBrokenException extends RuntimeException {
    private final String chainId;
    private final long sequenceNumber;

    public HashChainBrokenException(String chainId, long sequenceNumber) {
        super("Hash chain broken at chain=" + chainId + ", seq=" + sequenceNumber);
        this.chainId = chainId;
        this.sequenceNumber = sequenceNumber;
    }

    public String getChainId() { return chainId; }
    public long getSequenceNumber() { return sequenceNumber; }
}
EOF

cat > $CM/exception/TenantIsolationViolationException.java << 'EOF'
package com.paymenthub.common.exception;

public class TenantIsolationViolationException extends SecurityException {
    public TenantIsolationViolationException(String requestedTenant, String authorizedTenant) {
        super("Tenant isolation violation: requested=" + requestedTenant + ", authorized=" + authorizedTenant);
    }
}
EOF

# --- Util ---
cat > $CM/util/JsonCanonicalizer.java << 'EOF'
package com.paymenthub.common.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.util.Iterator;
import java.util.TreeMap;

/**
 * RFC 8785 (JCS) compliant JSON canonicalization for deterministic hashing.
 * All hash computations in the audit module use this to ensure
 * the same logical event always produces the same hash.
 */
public final class JsonCanonicalizer {

    private static final ObjectMapper MAPPER = new ObjectMapper()
        .registerModule(new JavaTimeModule())
        .configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true)
        .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

    private JsonCanonicalizer() {}

    public static String canonicalize(Object obj) {
        try {
            JsonNode node = MAPPER.valueToTree(obj);
            JsonNode sorted = sortNode(node);
            return MAPPER.writeValueAsString(sorted);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Failed to canonicalize JSON", e);
        }
    }

    public static byte[] canonicalizeToBytes(Object obj) {
        return canonicalize(obj).getBytes(java.nio.charset.StandardCharsets.UTF_8);
    }

    private static JsonNode sortNode(JsonNode node) {
        if (node.isObject()) {
            ObjectNode sorted = MAPPER.createObjectNode();
            TreeMap<String, JsonNode> fields = new TreeMap<>();
            Iterator<java.util.Map.Entry<String, JsonNode>> it = node.fields();
            while (it.hasNext()) {
                var entry = it.next();
                fields.put(entry.getKey(), sortNode(entry.getValue()));
            }
            fields.forEach(sorted::set);
            return sorted;
        } else if (node.isArray()) {
            var array = MAPPER.createArrayNode();
            node.forEach(element -> array.add(sortNode(element)));
            return array;
        }
        return node;
    }
}
EOF

cat > $CM/util/HexUtils.java << 'EOF'
package com.paymenthub.common.util;

public final class HexUtils {
    private static final char[] HEX_CHARS = "0123456789abcdef".toCharArray();

    private HexUtils() {}

    public static String toHex(byte[] bytes) {
        if (bytes == null) return null;
        char[] hex = new char[bytes.length * 2];
        for (int i = 0; i < bytes.length; i++) {
            int v = bytes[i] & 0xFF;
            hex[i * 2] = HEX_CHARS[v >>> 4];
            hex[i * 2 + 1] = HEX_CHARS[v & 0x0F];
        }
        return new String(hex);
    }

    public static byte[] fromHex(String hex) {
        if (hex == null) return null;
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }
}
EOF

echo "✅ hub-common-model complete"
