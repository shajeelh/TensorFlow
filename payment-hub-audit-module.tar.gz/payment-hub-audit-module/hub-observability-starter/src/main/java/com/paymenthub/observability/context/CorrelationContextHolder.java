package com.paymenthub.observability.context;
public final class CorrelationContextHolder {
    private static final InheritableThreadLocal<CorrelationContext> CTX = new InheritableThreadLocal<>();
    private CorrelationContextHolder() {}
    public static CorrelationContext get() { CorrelationContext c = CTX.get(); if (c==null) { c=CorrelationContext.create(); CTX.set(c); } return c; }
    public static void set(CorrelationContext c) { CTX.set(c); }
    public static void clear() { CTX.remove(); }
}
