package com.paymenthub.observability.config;
import org.springframework.boot.autoconfigure.AutoConfiguration;
@AutoConfiguration
public class ObservabilityAutoConfiguration {}
