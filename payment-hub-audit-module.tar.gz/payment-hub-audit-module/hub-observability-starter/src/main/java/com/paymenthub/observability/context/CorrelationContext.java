package com.paymenthub.observability.context;
import java.time.Instant;
import java.util.UUID;
public record CorrelationContext(String correlationId, String traceId, String spanId, String causationId,
    String tenantId, String entityId, String actorIdentity, String actorType, String sourceModule, Instant requestTimestamp) {
    public static CorrelationContext create() { return new CorrelationContext(UUID.randomUUID().toString(), UUID.randomUUID().toString(), null,null,null,null,null,null,null,null); }
    public CorrelationContext withTenant(String tid, String eid) { return new CorrelationContext(correlationId,traceId,spanId,causationId,tid,eid,actorIdentity,actorType,sourceModule,requestTimestamp); }
    public CorrelationContext withActor(String identity, String type) { return new CorrelationContext(correlationId,traceId,spanId,causationId,tenantId,entityId,identity,type,sourceModule,requestTimestamp); }
}
