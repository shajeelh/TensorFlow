plugins {
    `java-library`
}

description = "Payment Hub — Correlation context, structured logging, metrics, tracing"

dependencies {
    api(project(":hub-common-model"))
    implementation(project(":hub-pii-starter"))
    api("io.micrometer:micrometer-core")
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    compileOnly("io.nats:jnats")
    compileOnly("org.springframework.kafka:spring-kafka")
    compileOnly("io.grpc:grpc-api")
    compileOnly("org.springframework:spring-webmvc")
}
