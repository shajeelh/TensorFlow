plugins {
    `java-platform`
}

description = "Payment Hub — Bill of Materials (version alignment for all modules)"

javaPlatform {
    allowDependencies()
}

dependencies {
    api(platform("org.springframework.boot:spring-boot-dependencies:3.4.2"))

    constraints {
        api(project(":hub-common-model"))
        api(project(":hub-crypto-starter"))
        api(project(":hub-pii-starter"))
        api(project(":hub-observability-starter"))
        api(project(":hub-error-starter"))
        api(project(":hub-time-starter"))
        api(project(":hub-resilience-starter"))
        api(project(":hub-idempotency-starter"))
        api(project(":hub-secret-starter"))
        api(project(":hub-tenant-context-starter"))
        api(project(":hub-nats-starter"))
        api(project(":hub-messaging-starter"))
        api(project(":hub-security-starter"))
        api(project(":hub-grpc-starter"))
        api(project(":hub-audit-starter"))
    }
}
