plugins {
    `java-library`
}

description = "Payment Hub — Cryptographic utilities (hashing, signing, encryption, Merkle trees)"

dependencies {
    api(project(":hub-common-model"))
    api("org.bouncycastle:bcprov-jdk18on")
    api("org.bouncycastle:bcpkix-jdk18on")
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("com.fasterxml.jackson.core:jackson-databind")
    compileOnly("org.springframework.boot:spring-boot-starter")
}
