package com.paymenthub.crypto.encryption;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import java.util.Base64;

public class EncryptionService {
    private static final String ALG = "AES/GCM/NoPadding";
    private static final int TAG = 128, IV = 12;
    private static final SecureRandom RNG = new SecureRandom();
    public record EncryptedPayload(byte[] iv, byte[] ciphertext) {
        public String toBase64() { byte[] c = new byte[iv.length+ciphertext.length]; System.arraycopy(iv,0,c,0,iv.length); System.arraycopy(ciphertext,0,c,iv.length,ciphertext.length); return Base64.getEncoder().encodeToString(c); }
    }
    public EncryptedPayload encrypt(byte[] pt, byte[] key) {
        try { byte[] iv = new byte[IV]; RNG.nextBytes(iv); Cipher c = Cipher.getInstance(ALG); c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key,"AES"), new GCMParameterSpec(TAG,iv)); return new EncryptedPayload(iv, c.doFinal(pt)); }
        catch (Exception e) { throw new RuntimeException("Encrypt failed", e); }
    }
    public byte[] decrypt(EncryptedPayload p, byte[] key) {
        try { Cipher c = Cipher.getInstance(ALG); c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key,"AES"), new GCMParameterSpec(TAG,p.iv())); return c.doFinal(p.ciphertext()); }
        catch (Exception e) { throw new RuntimeException("Decrypt failed", e); }
    }
    public byte[] generateKey() { try { KeyGenerator kg = KeyGenerator.getInstance("AES"); kg.init(256,RNG); return kg.generateKey().getEncoded(); } catch (Exception e) { throw new RuntimeException(e); } }
}
