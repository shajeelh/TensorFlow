package com.paymenthub.crypto.config;
import com.paymenthub.crypto.encryption.EncryptionService;
import com.paymenthub.crypto.hash.HashService;
import com.paymenthub.crypto.merkle.MerkleTreeBuilder;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
@AutoConfiguration
public class CryptoAutoConfiguration {
    @Bean @ConditionalOnMissingBean public HashService hashService(@Value("${hub.crypto.hash-algorithm:SHA3-256}") String alg) { return new HashService(alg); }
    @Bean @ConditionalOnMissingBean public EncryptionService encryptionService() { return new EncryptionService(); }
    @Bean @ConditionalOnMissingBean public MerkleTreeBuilder merkleTreeBuilder(HashService hs) { return new MerkleTreeBuilder(hs); }
}
