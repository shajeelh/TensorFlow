package com.paymenthub.crypto.signature;
import com.paymenthub.common.model.integrity.SignedBatch;
import com.paymenthub.crypto.hash.HashService;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import java.security.*;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class SoftwareAuditSigner implements AuditSigner {
    private final PrivateKey signingKey;
    private final PublicKey verifyKey;
    private final String keyId;
    private final HashService hashService;
    private final AtomicLong counter = new AtomicLong(0);

    public SoftwareAuditSigner(PrivateKey sk, PublicKey vk, String keyId, HashService hs) {
        this.signingKey = sk; this.verifyKey = vk; this.keyId = keyId; this.hashService = hs;
    }
    @Override public SignedBatch sign(List<byte[]> hashes) {
        try {
            byte[] digest = hashService.hash(concat(hashes));
            Signature s = Signature.getInstance("SHA384withECDSA", BouncyCastleProvider.PROVIDER_NAME);
            s.initSign(signingKey); s.update(digest);
            return new SignedBatch(counter.incrementAndGet(), hashes, digest, s.sign(), keyId, "software");
        } catch (Exception e) { throw new RuntimeException("Sign failed", e); }
    }
    @Override public boolean verify(SignedBatch batch) {
        try {
            Signature s = Signature.getInstance("SHA384withECDSA", BouncyCastleProvider.PROVIDER_NAME);
            s.initVerify(verifyKey); s.update(batch.batchDigest());
            return s.verify(batch.signature());
        } catch (Exception e) { return false; }
    }
    @Override public String signingMode() { return "software"; }
    @Override public String currentKeyId() { return keyId; }
    private byte[] concat(List<byte[]> hs) {
        int len = hs.stream().mapToInt(h -> h.length).sum(); byte[] r = new byte[len]; int o = 0;
        for (byte[] h : hs) { System.arraycopy(h, 0, r, o, h.length); o += h.length; } return r;
    }
}
