package com.paymenthub.crypto.signature;
import com.paymenthub.common.model.integrity.SignedBatch;
import java.util.List;
public interface AuditSigner {
    SignedBatch sign(List<byte[]> recordHashes);
    boolean verify(SignedBatch batch);
    String signingMode();
    String currentKeyId();
}
