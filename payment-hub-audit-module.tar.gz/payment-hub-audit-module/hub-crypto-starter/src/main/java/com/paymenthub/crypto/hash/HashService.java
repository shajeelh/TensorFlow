package com.paymenthub.crypto.hash;

import com.paymenthub.common.util.JsonCanonicalizer;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.MessageDigest;
import java.security.Security;

public class HashService {
    private final String defaultAlgorithm;
    static { if (Security.getProvider("BC") == null) Security.addProvider(new BouncyCastleProvider()); }
    public HashService(String defaultAlgorithm) { this.defaultAlgorithm = defaultAlgorithm; }
    public byte[] hash(byte[] input) { return hash(input, defaultAlgorithm); }
    public byte[] hash(byte[] input, String algorithm) {
        try { return MessageDigest.getInstance(algorithm).digest(input); }
        catch (Exception e) { throw new RuntimeException("Hash failed: " + algorithm, e); }
    }
    public byte[] hmac(byte[] input, byte[] key) {
        try { Mac m = Mac.getInstance("HmacSHA256"); m.init(new SecretKeySpec(key, "HmacSHA256")); return m.doFinal(input); }
        catch (Exception e) { throw new RuntimeException("HMAC failed", e); }
    }
    public byte[] canonicalHash(Object obj) { return hash(JsonCanonicalizer.canonicalizeToBytes(obj)); }
    public byte[] chainHash(byte[] prev, byte[] rec) {
        byte[] c = new byte[prev.length + rec.length];
        System.arraycopy(prev, 0, c, 0, prev.length);
        System.arraycopy(rec, 0, c, prev.length, rec.length);
        return hash(c);
    }
    public String getDefaultAlgorithm() { return defaultAlgorithm; }
}
