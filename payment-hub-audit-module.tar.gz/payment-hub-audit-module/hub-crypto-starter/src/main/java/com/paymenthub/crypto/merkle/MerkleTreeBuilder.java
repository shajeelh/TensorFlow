package com.paymenthub.crypto.merkle;
import com.paymenthub.common.model.integrity.MerkleProof;
import com.paymenthub.common.model.integrity.MerkleProofNode;
import com.paymenthub.crypto.hash.HashService;
import java.util.ArrayList;
import java.util.List;

public class MerkleTreeBuilder {
    private final HashService hashService;
    public MerkleTreeBuilder(HashService hs) { this.hashService = hs; }
    public byte[] computeRoot(List<byte[]> leaves) {
        if (leaves.isEmpty()) return hashService.hash(new byte[0]);
        if (leaves.size() == 1) return leaves.getFirst();
        var level = new ArrayList<>(leaves);
        while (Integer.bitCount(level.size()) != 1) level.add(level.getLast());
        while (level.size() > 1) {
            var next = new ArrayList<byte[]>();
            for (int i = 0; i < level.size(); i += 2) {
                byte[] c = new byte[level.get(i).length + level.get(i+1).length];
                System.arraycopy(level.get(i),0,c,0,level.get(i).length);
                System.arraycopy(level.get(i+1),0,c,level.get(i).length,level.get(i+1).length);
                next.add(hashService.hash(c));
            }
            level = next;
        }
        return level.getFirst();
    }
    public boolean verifyProof(MerkleProof proof) {
        byte[] cur = proof.leafHash();
        for (MerkleProofNode n : proof.path()) {
            byte[] c; if (n.position() == MerkleProofNode.Position.LEFT) {
                c = new byte[n.hash().length+cur.length]; System.arraycopy(n.hash(),0,c,0,n.hash().length); System.arraycopy(cur,0,c,n.hash().length,cur.length);
            } else { c = new byte[cur.length+n.hash().length]; System.arraycopy(cur,0,c,0,cur.length); System.arraycopy(n.hash(),0,c,cur.length,n.hash().length); }
            cur = hashService.hash(c);
        }
        return java.util.Arrays.equals(cur, proof.rootHash());
    }
}
