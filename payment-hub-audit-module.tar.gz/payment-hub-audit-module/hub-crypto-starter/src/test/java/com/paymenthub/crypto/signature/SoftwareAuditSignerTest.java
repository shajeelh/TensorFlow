package com.paymenthub.crypto.signature;

import com.paymenthub.common.model.integrity.SignedBatch;
import com.paymenthub.crypto.hash.HashService;
import org.bouncycastle.jce.ECNamedCurveTable;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECParameterSpec;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.security.*;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class SoftwareAuditSignerTest {

    private SoftwareAuditSigner signer;
    private HashService hashService;

    @BeforeAll
    static void setupProvider() {
        if (Security.getProvider("BC") == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }

    @BeforeEach
    void setUp() throws Exception {
        hashService = new HashService("SHA-256");
        ECParameterSpec ecSpec = ECNamedCurveTable.getParameterSpec("P-384");
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC", "BC");
        kpg.initialize(ecSpec, new SecureRandom());
        KeyPair kp = kpg.generateKeyPair();
        signer = new SoftwareAuditSigner(kp.getPrivate(), kp.getPublic(), "test-key-1", hashService);
    }

    @Test
    @DisplayName("Sign and verify a batch of record hashes")
    void signAndVerify() {
        List<byte[]> hashes = List.of(
            hashService.hash("event-1".getBytes()),
            hashService.hash("event-2".getBytes()),
            hashService.hash("event-3".getBytes())
        );

        SignedBatch batch = signer.sign(hashes);

        assertThat(batch.batchId()).isGreaterThan(0);
        assertThat(batch.signature()).isNotEmpty();
        assertThat(batch.signingKeyId()).isEqualTo("test-key-1");
        assertThat(batch.signingMode()).isEqualTo("software");

        assertThat(signer.verify(batch)).isTrue();
    }

    @Test
    @DisplayName("Tampered batch should fail verification")
    void tamperedBatchFailsVerification() {
        List<byte[]> hashes = List.of(
            hashService.hash("event-1".getBytes()),
            hashService.hash("event-2".getBytes())
        );

        SignedBatch batch = signer.sign(hashes);

        // Tamper with the digest
        byte[] tamperedDigest = batch.batchDigest().clone();
        tamperedDigest[0] ^= 0xFF;
        SignedBatch tampered = new SignedBatch(
            batch.batchId(), batch.recordHashes(), tamperedDigest,
            batch.signature(), batch.signingKeyId(), batch.signingMode());

        assertThat(signer.verify(tampered)).isFalse();
    }

    @Test
    @DisplayName("Batch IDs should be monotonically increasing")
    void monotonicBatchIds() {
        List<byte[]> hashes = List.of(hashService.hash("event".getBytes()));

        SignedBatch b1 = signer.sign(hashes);
        SignedBatch b2 = signer.sign(hashes);
        SignedBatch b3 = signer.sign(hashes);

        assertThat(b2.batchId()).isGreaterThan(b1.batchId());
        assertThat(b3.batchId()).isGreaterThan(b2.batchId());
    }
}
