package com.paymenthub.pii.config;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paymenthub.pii.log.PiiMaskingLogEncoder;
import com.paymenthub.pii.masker.PiiMasker;
import com.paymenthub.pii.sanitizer.PiiJsonSanitizer;
import com.paymenthub.pii.scanner.PiiScanner;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import java.util.List;

@AutoConfiguration
@EnableConfigurationProperties(PiiAutoConfiguration.PiiProperties.class)
public class PiiAutoConfiguration {
    @Bean @ConditionalOnMissingBean public PiiScanner piiScanner(PiiProperties p) { return new PiiScanner(p.getTier0Patterns(), p.isLuhnValidation()); }
    @Bean @ConditionalOnMissingBean public PiiMasker piiMasker() { return new PiiMasker(); }
    @Bean @ConditionalOnMissingBean public PiiMaskingLogEncoder piiMaskingLogEncoder(PiiScanner s, PiiMasker m) { return new PiiMaskingLogEncoder(s, m); }
    @Bean @ConditionalOnMissingBean public PiiJsonSanitizer piiJsonSanitizer(PiiScanner s, PiiMasker m, ObjectMapper om) { return new PiiJsonSanitizer(s, m, om); }

    @ConfigurationProperties(prefix = "hub.pii")
    public static class PiiProperties {
        private List<String> tier0Patterns = List.of("\\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})\\b");
        private boolean luhnValidation = true;
        public List<String> getTier0Patterns() { return tier0Patterns; }
        public void setTier0Patterns(List<String> p) { this.tier0Patterns = p; }
        public boolean isLuhnValidation() { return luhnValidation; }
        public void setLuhnValidation(boolean v) { this.luhnValidation = v; }
    }
}
