package com.paymenthub.pii.scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PiiScanner {
    public record PiiDetection(String value, int tier, int start, int end) {}
    private final List<Pattern> tier0Patterns;
    private final boolean luhnValidation;
    public PiiScanner(List<String> patterns, boolean luhnValidation) {
        this.tier0Patterns = patterns.stream().map(Pattern::compile).toList();
        this.luhnValidation = luhnValidation;
    }
    public List<PiiDetection> scan(String input) {
        if (input == null || input.isEmpty()) return List.of();
        List<PiiDetection> detections = new ArrayList<>();
        for (Pattern p : tier0Patterns) {
            Matcher m = p.matcher(input);
            while (m.find()) { String match = m.group(); if (!luhnValidation || passesLuhn(match)) detections.add(new PiiDetection(match, 0, m.start(), m.end())); }
        }
        return detections;
    }
    public String scanAndRedact(String input) {
        if (input == null) return null; String r = input;
        for (PiiDetection d : scan(input)) r = r.replace(d.value(), "[REDACTED:PCI:PAN_DETECTED]");
        return r;
    }
    private boolean passesLuhn(String num) {
        String d = num.replaceAll("\\D",""); if (d.length()<13||d.length()>19) return false;
        int s = 0; boolean alt = false;
        for (int i = d.length()-1; i >= 0; i--) { int n = d.charAt(i)-'0'; if (alt) { n*=2; if (n>9) n-=9; } s+=n; alt=!alt; }
        return s % 10 == 0;
    }
}
