package com.paymenthub.pii.sanitizer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.paymenthub.pii.masker.PiiMasker;
import com.paymenthub.pii.scanner.PiiScanner;
import java.util.Iterator;
import java.util.Map;
public class PiiJsonSanitizer {
    private final PiiScanner scanner; private final PiiMasker masker; private final ObjectMapper om;
    public PiiJsonSanitizer(PiiScanner s, PiiMasker m, ObjectMapper om) { this.scanner=s; this.masker=m; this.om=om; }
    public JsonNode sanitize(JsonNode node) {
        if (node==null) return null;
        if (node.isTextual()) { String v=node.asText(); String r=scanner.scanAndRedact(v); return r.equals(v)?node:new TextNode(r); }
        if (node.isObject()) { ObjectNode sn=om.createObjectNode(); Iterator<Map.Entry<String,JsonNode>> f=node.fields(); while(f.hasNext()) { var e=f.next(); sn.set(e.getKey(),sanitize(e.getValue())); } return sn; }
        if (node.isArray()) { var a=om.createArrayNode(); node.forEach(e->a.add(sanitize(e))); return a; }
        return node;
    }
}
