package com.paymenthub.pii.masker;
import java.util.regex.Pattern;
public class PiiMasker {
    private static final Pattern EMAIL = Pattern.compile("[\\w.+-]+@[\\w.-]+\\.[a-zA-Z]{2,}");
    private static final Pattern IBAN = Pattern.compile("[A-Z]{2}\\d{2}[A-Z0-9]{4,30}");
    public String maskEmail(String e) {
        if (e==null||!e.contains("@")) return e;
        String[] p = e.split("@"); String l = p[0]; String[] d = p[1].split("\\.");
        return l.charAt(0)+"***"+(l.length()>1?String.valueOf(l.charAt(l.length()-1)):"")+"@"+d[0].charAt(0)+"***."+d[d.length-1];
    }
    public String maskIban(String i) { return i==null||i.length()<4?i:"****"+i.substring(i.length()-4); }
    public String maskIp(String ip) { if (ip==null||!ip.contains(".")) return ip; String[] o=ip.split("\\."); return o.length==4?o[0]+"."+o[1]+"."+o[2]+".0/24":ip; }
    public String maskAll(String input) {
        if (input==null) return null; String r = input;
        var em = EMAIL.matcher(r); while (em.find()) r = r.replace(em.group(), maskEmail(em.group()));
        var im = IBAN.matcher(r); while (im.find()) { String m = im.group(); if (m.length()>10) r = r.replace(m, maskIban(m)); }
        return r;
    }
}
