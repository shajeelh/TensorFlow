package com.paymenthub.pii.log;
import com.paymenthub.pii.masker.PiiMasker;
import com.paymenthub.pii.scanner.PiiScanner;
public class PiiMaskingLogEncoder {
    private final PiiScanner scanner;
    private final PiiMasker masker;
    public PiiMaskingLogEncoder(PiiScanner s, PiiMasker m) { this.scanner=s; this.masker=m; }
    public String mask(String msg) { if (msg==null||msg.isEmpty()) return msg; return masker.maskAll(scanner.scanAndRedact(msg)); }
}
