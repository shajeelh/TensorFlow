plugins {
    `java-library`
}

description = "Payment Hub — PII detection, masking, field-level encryption, log masking"

dependencies {
    api(project(":hub-common-model"))
    api(project(":hub-crypto-starter"))
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("com.fasterxml.jackson.core:jackson-databind")
    implementation("org.yaml:snakeyaml")
    compileOnly("ch.qos.logback:logback-classic")
    compileOnly("net.logstash.logback:logstash-logback-encoder:8.0")
    compileOnly("org.springframework.boot:spring-boot-starter")
}
