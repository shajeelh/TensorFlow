package com.paymenthub.secret.kms;
public interface KeyManagementService { byte[] encrypt(byte[] data, String keyId); byte[] decrypt(byte[] data, String keyId); byte[] generateDataKey(String keyId); }
