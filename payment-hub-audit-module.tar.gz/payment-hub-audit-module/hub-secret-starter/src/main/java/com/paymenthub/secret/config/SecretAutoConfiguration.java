package com.paymenthub.secret.config;
import org.springframework.boot.autoconfigure.AutoConfiguration;
@AutoConfiguration public class SecretAutoConfiguration {}
