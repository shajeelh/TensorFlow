package com.paymenthub.secret.provider;
public interface SecretProvider { String getSecret(String name); byte[] getSecretBytes(String name); }
