plugins {
    `java-library`
}

description = "Payment Hub — Secret and key management abstraction"

dependencies {
    api(project(":hub-common-model"))
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    compileOnly("org.springframework.cloud:spring-cloud-starter-vault-config")
}
