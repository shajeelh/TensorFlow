package com.paymenthub.audit.starter.health;

import com.paymenthub.audit.starter.emitter.AuditEventEmitter;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

public class AuditHealthIndicator implements HealthIndicator {
    private final AuditEventEmitter emitter;
    public AuditHealthIndicator(AuditEventEmitter emitter) { this.emitter = emitter; }
    @Override public Health health() {
        return emitter != null ? Health.up().withDetail("emitter", "active").build() : Health.down().build();
    }
}
