package com.paymenthub.audit.starter.annotation;

import com.paymenthub.common.enums.AuditMode;
import java.lang.annotation.*;

/**
 * Marks a method as requiring audit capture. Applied to all business operations
 * across all payment hub modules.
 *
 * <p>The AOP aspect intercepts annotated methods, captures before/after state,
 * builds an {@link com.paymenthub.common.model.event.AuditEvent}, sanitizes PII
 * (via hub-pii-starter), and emits the event via the configured transport.</p>
 *
 * <h3>Modes:</h3>
 * <ul>
 *   <li>{@link AuditMode#AUTO} (default) — sync or async determined by config per entity/event-type</li>
 *   <li>{@link AuditMode#SYNC} — blocks until AuditReceipt confirms durability. Business operation
 *       MUST NOT proceed if audit fails.</li>
 *   <li>{@link AuditMode#ASYNC} — fire-and-forget via LMAX ring buffer. Sub-microsecond overhead.</li>
 * </ul>
 *
 * <h3>Usage:</h3>
 * <pre>{@code
 * @NatsListener(subject = "payment.validate")
 * @Audited(eventType = "payment.validated", captureStateChange = true)
 * public ValidationResponse validate(ValidationRequest req) {
 *     return validationService.validate(req);
 * }
 * }</pre>
 *
 * @see com.paymenthub.audit.starter.aop.AuditedAspect
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Audited {

    /**
     * Dot-notation event type. Examples: "payment.initiated", "admin.manual_override".
     */
    String eventType();

    /**
     * Audit capture mode. AUTO resolves to sync/async based on entity configuration.
     */
    AuditMode mode() default AuditMode.AUTO;

    /**
     * Whether to capture before/after state of the operation.
     * The first method parameter is treated as "before" state; return value is "after" state.
     */
    boolean captureStateChange() default false;

    /**
     * Deadline in milliseconds for SYNC mode. If the audit module cannot confirm
     * persistence within this duration, the business operation MUST fail.
     */
    long syncDeadlineMs() default 5000;

    /**
     * Whether to throw AuditRecordingFailedException on audit failure (SYNC mode only).
     * Default true — the business operation fails if audit recording fails.
     */
    boolean failOnAuditFailure() default true;

    /**
     * Resource type for the audit event. If empty, inferred from the class name.
     */
    String resourceType() default "";

    /**
     * SpEL expression to extract the resource ID from method parameters.
     */
    String resourceIdExpression() default "";

    /**
     * Event version. Default "2.1" per canonical schema.
     */
    String eventVersion() default "2.1";
}
