package com.paymenthub.audit.starter.aop;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paymenthub.audit.starter.annotation.Audited;
import com.paymenthub.audit.starter.emitter.AuditEventEmitter;
import com.paymenthub.common.enums.ActionResult;
import com.paymenthub.common.enums.AuditMode;
import com.paymenthub.common.exception.AuditRecordingFailedException;
import com.paymenthub.common.model.action.AuditAction;
import com.paymenthub.common.model.actor.AuditActor;
import com.paymenthub.common.model.event.AuditEvent;
import com.paymenthub.common.model.event.EventContext;
import com.paymenthub.common.model.event.StateChange;
import com.paymenthub.common.model.receipt.AuditReceipt;
import com.paymenthub.common.model.resource.AuditResource;
import com.paymenthub.common.enums.ActorType;
import com.paymenthub.common.enums.ReceiptStatus;
import com.paymenthub.observability.context.CorrelationContext;
import com.paymenthub.observability.context.CorrelationContextHolder;
import com.paymenthub.pii.sanitizer.PiiJsonSanitizer;
import com.paymenthub.tenant.context.TenantContextHolder;
import com.paymenthub.time.clock.HubClock;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

/**
 * AOP aspect that intercepts all {@link Audited} methods across the payment hub.
 * This is the universal audit capture mechanism — every module gets audit
 * coverage by including hub-audit-starter.
 *
 * <p>Flow:</p>
 * <ol>
 *   <li>Capture "before" state from method parameters</li>
 *   <li>Execute the business method</li>
 *   <li>Capture "after" state from return value</li>
 *   <li>Build AuditEvent from context (correlation, tenant, actor)</li>
 *   <li>Sanitize PII fields (Tier 0 redact, Tier 1 tokenize, Tier 2 encrypt)</li>
 *   <li>Emit via ring buffer (ASYNC) or sync client (SYNC)</li>
 * </ol>
 */
@Aspect
public class AuditedAspect {

    private static final Logger log = LoggerFactory.getLogger(AuditedAspect.class);

    private final AuditEventEmitter emitter;
    private final HubClock clock;
    private final PiiJsonSanitizer piiSanitizer;
    private final ObjectMapper objectMapper;
    private final AuditStarterProperties properties;

    public AuditedAspect(AuditEventEmitter emitter, HubClock clock,
                          PiiJsonSanitizer piiSanitizer, ObjectMapper objectMapper,
                          AuditStarterProperties properties) {
        this.emitter = emitter;
        this.clock = clock;
        this.piiSanitizer = piiSanitizer;
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    @Around("@annotation(audited)")
    public Object aroundAudited(ProceedingJoinPoint joinPoint, Audited audited) throws Throwable {

        long startNanos = System.nanoTime();
        CorrelationContext ctx = CorrelationContextHolder.get();

        // 1. Capture "before" state (first parameter)
        JsonNode beforeState = null;
        if (audited.captureStateChange() && joinPoint.getArgs().length > 0) {
            try {
                beforeState = objectMapper.valueToTree(joinPoint.getArgs()[0]);
                beforeState = piiSanitizer.sanitize(beforeState);
            } catch (Exception e) {
                log.warn("Failed to capture before state for {}", audited.eventType(), e);
            }
        }

        // 2. Determine audit mode
        AuditMode effectiveMode = resolveMode(audited, ctx.tenantId());

        // 3. For SYNC mode: build event and record BEFORE executing business logic
        if (effectiveMode == AuditMode.SYNC) {
            return handleSyncAudit(joinPoint, audited, ctx, beforeState, startNanos);
        }

        // 4. For ASYNC mode: execute business logic first, then emit
        return handleAsyncAudit(joinPoint, audited, ctx, beforeState, startNanos);
    }

    private Object handleSyncAudit(ProceedingJoinPoint joinPoint, Audited audited,
                                     CorrelationContext ctx, JsonNode beforeState,
                                     long startNanos) throws Throwable {
        // Build event BEFORE executing business operation
        AuditEvent event = buildEvent(audited, ctx, beforeState, null, ActionResult.SUCCESS,
            System.nanoTime() - startNanos);

        // Record synchronously — blocks until confirmed durable
        try {
            AuditReceipt receipt = emitter.emitSync(event);
            if (receipt.status() == ReceiptStatus.FAILED && audited.failOnAuditFailure()) {
                throw new AuditRecordingFailedException(
                    "Sync audit recording failed for " + audited.eventType(),
                    audited.eventType(), ctx.correlationId());
            }
        } catch (AuditRecordingFailedException e) {
            throw e; // Re-throw — business operation MUST NOT proceed
        } catch (Exception e) {
            if (audited.failOnAuditFailure()) {
                throw new AuditRecordingFailedException(
                    "Sync audit failed: " + e.getMessage(), e);
            }
            log.error("Sync audit failed but failOnAuditFailure=false for {}", audited.eventType(), e);
        }

        // Now execute the business operation
        return joinPoint.proceed();
    }

    private Object handleAsyncAudit(ProceedingJoinPoint joinPoint, Audited audited,
                                      CorrelationContext ctx, JsonNode beforeState,
                                      long startNanos) throws Throwable {
        Object result = null;
        ActionResult actionResult = ActionResult.SUCCESS;

        try {
            result = joinPoint.proceed();
        } catch (Throwable t) {
            actionResult = ActionResult.FAILURE;
            throw t;
        } finally {
            long durationNanos = System.nanoTime() - startNanos;

            // Capture "after" state from return value
            JsonNode afterState = null;
            if (audited.captureStateChange() && result != null) {
                try {
                    afterState = objectMapper.valueToTree(result);
                    afterState = piiSanitizer.sanitize(afterState);
                } catch (Exception e) {
                    log.warn("Failed to capture after state for {}", audited.eventType(), e);
                }
            }

            AuditEvent event = buildEvent(audited, ctx, beforeState, afterState,
                actionResult, durationNanos);

            // Emit asynchronously via ring buffer
            try {
                emitter.emitAsync(event);
            } catch (Exception e) {
                log.error("Async audit emit failed for {} — event may be lost",
                    audited.eventType(), e);
            }
        }

        return result;
    }

    private AuditEvent buildEvent(Audited audited, CorrelationContext ctx,
                                    JsonNode beforeState, JsonNode afterState,
                                    ActionResult result, long durationNanos) {

        var tenantCtx = TenantContextHolder.get();
        String tenantId = tenantCtx != null ? tenantCtx.tenantId() : ctx.tenantId();
        String entityId = tenantCtx != null ? tenantCtx.entityId() : ctx.entityId();

        return AuditEvent.builder()
            .eventId(UUID.randomUUID())
            .eventType(audited.eventType())
            .eventVersion(audited.eventVersion())
            .correlationId(UUID.fromString(ctx.correlationId()))
            .causationId(ctx.causationId() != null ? UUID.fromString(ctx.causationId()) : null)
            .timestamp(clock.instant())
            .actor(AuditActor.builder()
                .type(resolveActorType(ctx.actorType()))
                .identity(ctx.actorIdentity() != null ? ctx.actorIdentity() : "system")
                .build())
            .resource(AuditResource.builder()
                .type(audited.resourceType().isEmpty() ? "unknown" : audited.resourceType())
                .id("") // Resolved from expression in full implementation
                .tenantId(tenantId != null ? tenantId : "UNKNOWN")
                .entityId(entityId != null ? entityId : "UNKNOWN")
                .build())
            .action(AuditAction.builder()
                .operation(audited.eventType().contains(".") ?
                    audited.eventType().substring(audited.eventType().lastIndexOf('.') + 1).toUpperCase() :
                    audited.eventType().toUpperCase())
                .result(result)
                .durationUs(durationNanos / 1000)
                .build())
            .stateChange(audited.captureStateChange() ?
                new StateChange(beforeState, afterState) : null)
            .context(EventContext.builder()
                .module(ctx.sourceModule())
                .build())
            .idempotencyKey(UUID.randomUUID().toString())
            .build();
    }

    private AuditMode resolveMode(Audited audited, String tenantId) {
        if (audited.mode() != AuditMode.AUTO) return audited.mode();
        // Check if this event type is in the mandatory-sync list
        if (properties.getSyncEvents().getMandatory().contains(audited.eventType())) {
            return AuditMode.SYNC;
        }
        return AuditMode.ASYNC;
    }

    private ActorType resolveActorType(String type) {
        if (type == null) return ActorType.SYSTEM;
        return switch (type.toUpperCase()) {
            case "USER" -> ActorType.USER;
            case "SERVICE" -> ActorType.SERVICE;
            case "SCHEDULER" -> ActorType.SCHEDULER;
            default -> ActorType.SYSTEM;
        };
    }

    /**
     * Configuration properties for audit starter.
     */
    public static class AuditStarterProperties {
        private SyncEventsConfig syncEvents = new SyncEventsConfig();
        public SyncEventsConfig getSyncEvents() { return syncEvents; }
        public void setSyncEvents(SyncEventsConfig c) { this.syncEvents = c; }

        public static class SyncEventsConfig {
            private java.util.List<String> mandatory = java.util.List.of(
                "admin.manual_override", "admin.audit_config_change",
                "admin.legal_hold_placed", "admin.legal_hold_removed",
                "authz.privilege_escalation", "crypto.key_generated",
                "crypto.key_destroyed", "data.masking_bypass"
            );
            public java.util.List<String> getMandatory() { return mandatory; }
            public void setMandatory(java.util.List<String> m) { this.mandatory = m; }
        }
    }
}
