package com.paymenthub.audit.starter.emitter;

import com.paymenthub.common.model.event.AuditEvent;
import com.paymenthub.common.model.receipt.AuditReceipt;

/**
 * Primary interface for emitting audit events.
 * Supports both async (ring buffer → transport) and sync (gRPC/REST → receipt) modes.
 */
public interface AuditEventEmitter {

    /**
     * Emit asynchronously via LMAX ring buffer → transport.
     * Sub-microsecond overhead. Fire-and-forget from caller's perspective.
     */
    void emitAsync(AuditEvent event);

    /**
     * Emit synchronously — blocks until AuditReceipt confirms durability.
     * Used for critical control events (ADR-008).
     */
    AuditReceipt emitSync(AuditEvent event);
}
