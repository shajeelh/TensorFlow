package com.paymenthub.audit.starter.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.paymenthub.audit.starter.aop.AuditedAspect;
import com.paymenthub.audit.starter.emitter.AuditEventEmitter;
import com.paymenthub.audit.starter.emitter.DefaultAuditEventEmitter;
import com.paymenthub.audit.starter.health.AuditHealthIndicator;
import com.paymenthub.messaging.publisher.MessagePublisher;
import com.paymenthub.pii.sanitizer.PiiJsonSanitizer;
import com.paymenthub.time.clock.HubClock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@AutoConfiguration
@EnableAspectJAutoProxy
@EnableConfigurationProperties
public class AuditStarterAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public AuditEventEmitter auditEventEmitter(
            MessagePublisher messagePublisher,
            ObjectMapper objectMapper,
            @Value("${audit.topic-prefix:audit}") String topicPrefix) {
        return new DefaultAuditEventEmitter(messagePublisher, objectMapper, topicPrefix);
    }

    @Bean
    @ConditionalOnMissingBean
    @ConfigurationProperties(prefix = "audit")
    public AuditedAspect.AuditStarterProperties auditStarterProperties() {
        return new AuditedAspect.AuditStarterProperties();
    }

    @Bean
    public AuditedAspect auditedAspect(
            AuditEventEmitter emitter,
            HubClock clock,
            PiiJsonSanitizer piiSanitizer,
            ObjectMapper objectMapper,
            AuditedAspect.AuditStarterProperties properties) {
        return new AuditedAspect(emitter, clock, piiSanitizer, objectMapper, properties);
    }

    @Bean
    @ConditionalOnMissingBean
    public AuditHealthIndicator auditHealthIndicator(AuditEventEmitter emitter) {
        return new AuditHealthIndicator(emitter);
    }
}
