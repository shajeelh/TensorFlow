package com.paymenthub.audit.starter.emitter;

import com.paymenthub.common.model.event.AuditEvent;
import java.util.concurrent.CompletableFuture;

/**
 * Transport interface for audit events.
 * Implementations: Kafka, NATS JetStream, RabbitMQ (ADR-001, ADR-012).
 */
public interface AuditTransport {
    CompletableFuture<Void> publish(AuditEvent event);
    String transportType();
}
