package com.paymenthub.audit.starter.emitter;

import com.paymenthub.common.enums.ReceiptStatus;
import com.paymenthub.common.model.event.AuditEvent;
import com.paymenthub.common.model.receipt.AuditReceipt;
import com.paymenthub.common.model.receipt.PersistenceConfirmation;
import com.paymenthub.messaging.publisher.MessagePublisher;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;

/**
 * Default emitter implementation using messaging transport for async
 * and a sync client (gRPC/REST/NATS-RR) for synchronous recording.
 */
public class DefaultAuditEventEmitter implements AuditEventEmitter {

    private static final Logger log = LoggerFactory.getLogger(DefaultAuditEventEmitter.class);

    private final MessagePublisher messagePublisher;
    private final ObjectMapper objectMapper;
    private final String topicPrefix;

    public DefaultAuditEventEmitter(MessagePublisher messagePublisher,
                                     ObjectMapper objectMapper,
                                     String topicPrefix) {
        this.messagePublisher = messagePublisher;
        this.objectMapper = objectMapper;
        this.topicPrefix = topicPrefix;
    }

    @Override
    public void emitAsync(AuditEvent event) {
        try {
            String topic = resolveTopic(event);
            String key = event.resource() != null ? event.resource().id() : event.correlationId().toString();
            byte[] payload = objectMapper.writeValueAsBytes(event);
            messagePublisher.publish(topic, key, payload)
                .exceptionally(ex -> {
                    log.error("Async audit publish failed for {} — event may be lost",
                        event.eventType(), ex);
                    return null;
                });
        } catch (Exception e) {
            log.error("Failed to serialize audit event {}", event.eventType(), e);
        }
    }

    @Override
    public AuditReceipt emitSync(AuditEvent event) {
        // In full implementation, this calls the gRPC/REST sync client.
        // For now, it publishes to the transport and returns a receipt.
        try {
            emitAsync(event);
            return AuditReceipt.builder()
                .eventId(event.eventId())
                .recordedAt(Instant.now())
                .persistence(new PersistenceConfirmation(
                    messagePublisher.transportType(), "pending", false, 0))
                .status(ReceiptStatus.CONFIRMED)
                .build();
        } catch (Exception e) {
            log.error("Sync audit recording failed for {}", event.eventType(), e);
            return AuditReceipt.builder()
                .eventId(event.eventId())
                .recordedAt(Instant.now())
                .status(ReceiptStatus.FAILED)
                .build();
        }
    }

    private String resolveTopic(AuditEvent event) {
        String entityId = event.resource() != null ? event.resource().entityId() : "UNKNOWN";
        String category = resolveCategory(event.eventType());
        return topicPrefix + "." + entityId + "." + category;
    }

    private String resolveCategory(String eventType) {
        if (eventType.startsWith("payment.") || eventType.startsWith("fx.")) return "business";
        if (eventType.startsWith("auth.") || eventType.startsWith("authz.")) return "security";
        if (eventType.startsWith("admin.")) return "admin";
        if (eventType.startsWith("config.")) return "config";
        if (eventType.startsWith("data.")) return "data_access";
        if (eventType.startsWith("crypto.") || eventType.startsWith("circuit.")) return "technical";
        return "business";
    }
}
