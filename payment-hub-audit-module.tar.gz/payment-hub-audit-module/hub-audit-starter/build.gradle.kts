plugins {
    `java-library`
}

description = "Payment Hub — Client-side audit starter (@Audited, ring buffer, emit)"

dependencies {
    // Tier 1 transitive
    api(project(":hub-common-model"))
    api(project(":hub-pii-starter"))
    api(project(":hub-crypto-starter"))
    api(project(":hub-observability-starter"))
    api(project(":hub-error-starter"))
    api(project(":hub-time-starter"))
    api(project(":hub-resilience-starter"))
    api(project(":hub-idempotency-starter"))
    api(project(":hub-secret-starter"))

    // Tier 2 transitive
    api(project(":hub-tenant-context-starter"))
    api(project(":hub-nats-starter"))
    api(project(":hub-messaging-starter"))
    api(project(":hub-security-starter"))

    // Direct dependencies
    implementation("com.lmax:disruptor")
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("org.springframework.boot:spring-boot-starter-aop")
    implementation("org.springframework.boot:spring-boot-starter-actuator")

    // Optional gRPC for sync client
    compileOnly(project(":hub-grpc-starter"))
    compileOnly("io.grpc:grpc-stub")
}
