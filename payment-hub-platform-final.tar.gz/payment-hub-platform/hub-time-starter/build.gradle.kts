plugins { `java-library` }
description = "Payment Hub — Monotonic Clock, NTP Sync, Clock Health"
dependencies {
    api(project(":hub-common-model"))
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("org.springframework.boot:spring-boot-actuator")
    implementation("org.slf4j:slf4j-api")
    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
