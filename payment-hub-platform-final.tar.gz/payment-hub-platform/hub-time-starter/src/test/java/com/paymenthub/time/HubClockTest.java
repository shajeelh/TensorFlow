package com.paymenthub.time;

import com.paymenthub.time.clock.HubClock;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.*;

import static org.assertj.core.api.Assertions.*;

class HubClockTest {

    @Test
    @DisplayName("Timestamps are monotonically increasing")
    void monotonic() {
        var clock = new HubClock("test");
        Instant prev = Instant.EPOCH;
        for (int i = 0; i < 10_000; i++) {
            Instant now = clock.instant();
            assertThat(now).isAfterOrEqualTo(prev);
            prev = now;
        }
    }

    @Test
    @DisplayName("Clock detects backward jump")
    void backwardJump() {
        // Create a clock that jumps backward
        Instant start = Instant.parse("2025-06-01T12:00:00Z");
        var jumping = new JumpingClock(start);
        var hubClock = new HubClock("test", jumping);

        Instant t1 = hubClock.instant();
        jumping.jumpBackward(Duration.ofSeconds(5));
        Instant t2 = hubClock.instant();

        // t2 should NOT go backward despite system clock going backward
        assertThat(t2).isAfterOrEqualTo(t1);
        assertThat(hubClock.monotonicViolationCount()).isGreaterThan(0);
    }

    @Test
    @DisplayName("Health check passes with small drift")
    void healthySmallDrift() {
        var clock = new HubClock("test");
        clock.instant();
        assertThat(clock.isHealthy(Duration.ofMillis(100))).isTrue();
    }

    @Test
    @DisplayName("Health check fails with large drift")
    void unhealthyLargeDrift() {
        Instant start = Instant.parse("2025-06-01T12:00:00Z");
        var jumping = new JumpingClock(start);
        var hubClock = new HubClock("test", jumping);

        hubClock.instant();
        jumping.jumpBackward(Duration.ofSeconds(2));
        hubClock.instant();

        assertThat(hubClock.isHealthy(Duration.ofMillis(100))).isFalse();
        assertThat(hubClock.maxObservedDrift().toMillis()).isGreaterThanOrEqualTo(2000);
    }

    @Test
    @DisplayName("Clock ID is preserved")
    void clockId() {
        var clock = new HubClock("audit-server-1");
        assertThat(clock.clockId()).isEqualTo("audit-server-1");
    }

    // ── Helper: clock that can jump backward ──
    private static class JumpingClock extends Clock {
        private Instant current;
        JumpingClock(Instant start) { this.current = start; }
        void jumpBackward(Duration amount) { current = current.minus(amount); }
        @Override public ZoneId getZone() { return ZoneId.of("UTC"); }
        @Override public Clock withZone(ZoneId zone) { return this; }
        @Override public Instant instant() {
            current = current.plusNanos(1_000_000); // advance 1ms per call
            return current;
        }
    }
}
