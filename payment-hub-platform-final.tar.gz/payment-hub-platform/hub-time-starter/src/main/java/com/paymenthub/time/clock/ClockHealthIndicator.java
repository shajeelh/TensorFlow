package com.paymenthub.time.clock;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

import java.time.Duration;

/**
 * Spring Boot Actuator health indicator for the HubClock.
 *
 * <p>Reports UP when the maximum observed clock drift is below
 * the configured threshold. Reports DOWN if significant drift is
 * detected, indicating NTP issues.</p>
 */
public class ClockHealthIndicator implements HealthIndicator {

    private final HubClock clock;
    private final Duration maxAllowedDrift;

    public ClockHealthIndicator(HubClock clock, Duration maxAllowedDrift) {
        this.clock = clock;
        this.maxAllowedDrift = maxAllowedDrift;
    }

    @Override
    public Health health() {
        Health.Builder builder = clock.isHealthy(maxAllowedDrift)
            ? Health.up()
            : Health.down();

        return builder
            .withDetail("clockId", clock.clockId())
            .withDetail("monotonicViolations", clock.monotonicViolationCount())
            .withDetail("maxObservedDrift", clock.maxObservedDrift().toString())
            .withDetail("maxAllowedDrift", maxAllowedDrift.toString())
            .build();
    }
}
