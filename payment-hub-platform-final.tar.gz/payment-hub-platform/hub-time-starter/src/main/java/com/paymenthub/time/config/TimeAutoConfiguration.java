package com.paymenthub.time.config;

import com.paymenthub.time.clock.ClockHealthIndicator;
import com.paymenthub.time.clock.HubClock;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

import java.time.Duration;

@AutoConfiguration
@EnableConfigurationProperties(TimeAutoConfiguration.TimeProperties.class)
public class TimeAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public HubClock hubClock(TimeProperties props) {
        return new HubClock(props.getClockId());
    }

    @Bean
    @ConditionalOnMissingBean
    public ClockHealthIndicator clockHealthIndicator(HubClock clock, TimeProperties props) {
        return new ClockHealthIndicator(clock, Duration.ofMillis(props.getMaxDriftMs()));
    }

    @ConfigurationProperties(prefix = "hub.time")
    public static class TimeProperties {
        private String clockId = "hub-" + ProcessHandle.current().pid();
        private long maxDriftMs = 100;
        public String getClockId() { return clockId; }
        public void setClockId(String v) { this.clockId = v; }
        public long getMaxDriftMs() { return maxDriftMs; }
        public void setMaxDriftMs(long v) { this.maxDriftMs = v; }
    }
}
