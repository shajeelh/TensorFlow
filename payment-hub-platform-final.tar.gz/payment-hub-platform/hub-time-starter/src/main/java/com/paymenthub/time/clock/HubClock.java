package com.paymenthub.time.clock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Audit-grade monotonic clock for the payment hub platform.
 *
 * <h3>Monotonicity Guarantee</h3>
 * <p>Every call to {@link #instant()} returns a timestamp that is
 * strictly greater than or equal to the previous call's timestamp.
 * If the system clock goes backward (NTP correction, leap second,
 * VM migration), HubClock holds at the last-known value until the
 * system clock catches up.</p>
 *
 * <h3>Clock ID</h3>
 * <p>Each HubClock instance has a unique {@code clockId} (derived from
 * hostname + instance). This is recorded in every audit event to
 * enable forensic clock analysis across a distributed cluster.</p>
 *
 * <h3>NTP Drift Detection</h3>
 * <p>Tracks the maximum observed drift between the system clock and
 * the monotonic floor. If drift exceeds a configurable threshold
 * (default: 100ms), a health check failure is reported.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Thread-safe via atomic operations. No locks are held during
 * timestamp generation.</p>
 */
public class HubClock {

    private static final Logger log = LoggerFactory.getLogger(HubClock.class);

    private final String clockId;
    private final Clock systemClock;
    private final AtomicReference<Instant> lastTimestamp;
    private final AtomicLong monotonicViolationCount;
    private final AtomicReference<Duration> maxObservedDrift;

    /**
     * Create a HubClock with the given identifier.
     *
     * @param clockId unique clock identifier (e.g., "audit-server-pod-1")
     */
    public HubClock(String clockId) {
        this(clockId, Clock.systemUTC());
    }

    /**
     * Create a HubClock with a specific underlying system clock (for testing).
     */
    public HubClock(String clockId, Clock systemClock) {
        this.clockId = clockId;
        this.systemClock = systemClock;
        this.lastTimestamp = new AtomicReference<>(Instant.EPOCH);
        this.monotonicViolationCount = new AtomicLong(0);
        this.maxObservedDrift = new AtomicReference<>(Duration.ZERO);
    }

    /**
     * Get the current monotonic timestamp.
     *
     * <p>Guaranteed to never go backward. If the system clock reports
     * a time earlier than the last returned timestamp, the previous
     * timestamp is returned instead.</p>
     *
     * @return monotonically non-decreasing UTC timestamp
     */
    public Instant instant() {
        Instant now = systemClock.instant();
        return lastTimestamp.updateAndGet(last -> {
            if (now.isAfter(last)) {
                return now;
            } else {
                // Clock went backward — hold at last value
                Duration drift = Duration.between(now, last);
                monotonicViolationCount.incrementAndGet();
                maxObservedDrift.updateAndGet(max ->
                    drift.compareTo(max) > 0 ? drift : max);
                if (drift.toMillis() > 100) {
                    log.warn("Clock backward drift detected: {}ms, clockId={}",
                        drift.toMillis(), clockId);
                }
                return last;
            }
        });
    }

    /**
     * Get the current time in epoch milliseconds (monotonic).
     */
    public long epochMillis() {
        return instant().toEpochMilli();
    }

    /**
     * Get the unique clock identifier.
     */
    public String clockId() { return clockId; }

    /**
     * Get the number of times the system clock went backward.
     */
    public long monotonicViolationCount() {
        return monotonicViolationCount.get();
    }

    /**
     * Get the maximum observed backward drift.
     */
    public Duration maxObservedDrift() {
        return maxObservedDrift.get();
    }

    /**
     * Check if the clock is healthy (drift below threshold).
     *
     * @param maxAllowedDrift maximum allowed drift before unhealthy
     */
    public boolean isHealthy(Duration maxAllowedDrift) {
        return maxObservedDrift.get().compareTo(maxAllowedDrift) <= 0;
    }

    @Override
    public String toString() {
        return "HubClock{id='%s', violations=%d, maxDrift=%s}"
            .formatted(clockId, monotonicViolationCount.get(), maxObservedDrift.get());
    }
}
