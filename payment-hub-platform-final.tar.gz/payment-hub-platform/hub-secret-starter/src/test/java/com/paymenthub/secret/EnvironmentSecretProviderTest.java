package com.paymenthub.secret;

import com.paymenthub.secret.provider.EnvironmentSecretProvider;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

class EnvironmentSecretProviderTest {

    private final EnvironmentSecretProvider provider = new EnvironmentSecretProvider();

    @Test
    @DisplayName("Path to env var conversion")
    void pathConversion() {
        assertThat(EnvironmentSecretProvider.pathToEnvVar("hub/audit/signing-key"))
            .isEqualTo("HUB_AUDIT_SIGNING_KEY");
        assertThat(EnvironmentSecretProvider.pathToEnvVar("hub.pii.encryption-key"))
            .isEqualTo("HUB_PII_ENCRYPTION_KEY");
    }

    @Test
    @DisplayName("Missing secret returns empty")
    void missing() {
        assertThat(provider.getSecret("nonexistent/secret/path")).isEmpty();
    }

    @Test
    @DisplayName("secretExists returns false for missing")
    void notExists() {
        assertThat(provider.secretExists("nonexistent")).isFalse();
    }

    @Test
    @DisplayName("Provider type is 'environment'")
    void providerType() {
        assertThat(provider.providerType()).isEqualTo("environment");
    }

    @Test
    @DisplayName("getSecretOrThrow throws for missing secret")
    void throwOnMissing() {
        assertThatThrownBy(() -> provider.getSecretOrThrow("missing"))
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("missing");
    }

    @Test
    @DisplayName("System property fallback works")
    void systemPropertyFallback() {
        System.setProperty("test/secret", "test-value");
        try {
            assertThat(provider.getSecret("test/secret")).hasValue("test-value");
        } finally {
            System.clearProperty("test/secret");
        }
    }
}
