package com.paymenthub.secret.provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Optional;

/**
 * Secret provider that reads from environment variables.
 *
 * <p><strong>Development/testing only.</strong> In production, use
 * VaultSecretProvider or a cloud-native KMS.</p>
 *
 * <p>Secret paths are converted to environment variable names:
 * {@code hub/audit/signing-key} → {@code HUB_AUDIT_SIGNING_KEY}</p>
 */
public class EnvironmentSecretProvider implements SecretProvider {

    private static final Logger log = LoggerFactory.getLogger(EnvironmentSecretProvider.class);

    public EnvironmentSecretProvider() {
        log.warn("Using EnvironmentSecretProvider — NOT for production use");
    }

    @Override
    public Optional<String> getSecret(String path) {
        String envName = pathToEnvVar(path);
        String value = System.getenv(envName);
        if (value == null) {
            // Try system property as fallback
            value = System.getProperty(path);
        }
        return Optional.ofNullable(value);
    }

    @Override
    public Optional<byte[]> getSecretBytes(String path) {
        return getSecret(path).map(s -> {
            try {
                return Base64.getDecoder().decode(s);
            } catch (IllegalArgumentException e) {
                return s.getBytes(StandardCharsets.UTF_8);
            }
        });
    }

    @Override
    public boolean secretExists(String path) {
        return getSecret(path).isPresent();
    }

    @Override
    public String providerType() { return "environment"; }

    /**
     * Convert a path to an environment variable name.
     * {@code hub/audit/signing-key} → {@code HUB_AUDIT_SIGNING_KEY}
     */
    static String pathToEnvVar(String path) {
        return path.toUpperCase()
            .replace('/', '_')
            .replace('.', '_')
            .replace('-', '_');
    }
}
