package com.paymenthub.secret.provider;

import java.util.Optional;

/**
 * Abstraction for secret retrieval across different backends.
 *
 * <p>Implementations:</p>
 * <ul>
 *   <li>{@link EnvironmentSecretProvider} — environment variables (dev/test)</li>
 *   <li>{@code VaultSecretProvider} — HashiCorp Vault (production)</li>
 *   <li>{@code AwsSecretProvider} — AWS Secrets Manager (cloud)</li>
 *   <li>{@code AzureSecretProvider} — Azure Key Vault (cloud)</li>
 * </ul>
 *
 * <p>Secrets are referenced by path: {@code hub/audit/signing-key},
 * {@code hub/pii/encryption-key}, etc.</p>
 */
public interface SecretProvider {

    /**
     * Retrieve a secret by path.
     *
     * @param path secret path (e.g., "hub/audit/signing-key")
     * @return the secret value, or empty if not found
     */
    Optional<String> getSecret(String path);

    /**
     * Retrieve a secret, throwing if not found.
     */
    default String getSecretOrThrow(String path) {
        return getSecret(path).orElseThrow(() ->
            new IllegalStateException("Secret not found: " + path));
    }

    /**
     * Retrieve a secret as raw bytes (for encryption keys).
     */
    Optional<byte[]> getSecretBytes(String path);

    /**
     * Check if a secret exists without retrieving its value.
     */
    boolean secretExists(String path);

    /**
     * Get the provider type identifier.
     */
    String providerType();
}
