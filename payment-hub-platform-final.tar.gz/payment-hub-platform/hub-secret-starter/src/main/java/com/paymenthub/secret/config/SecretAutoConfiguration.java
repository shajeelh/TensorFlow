package com.paymenthub.secret.config;

import com.paymenthub.secret.provider.EnvironmentSecretProvider;
import com.paymenthub.secret.provider.SecretProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
public class SecretAutoConfiguration {
    @Bean
    @ConditionalOnMissingBean
    public SecretProvider secretProvider() {
        return new EnvironmentSecretProvider();
    }
}
