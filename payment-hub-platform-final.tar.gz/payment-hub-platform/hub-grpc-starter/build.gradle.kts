plugins { `java-library` }
description = "Payment Hub — gRPC Server/Client Interceptors (Tenant, Security, Observability, Error Mapping)"
dependencies {
    api(project(":hub-common-model"))
    implementation(project(":hub-observability-starter"))
    implementation(project(":hub-tenant-context-starter"))
    implementation(project(":hub-security-starter"))
    implementation(project(":hub-error-starter"))

    compileOnly("io.grpc:grpc-api")
    compileOnly("io.grpc:grpc-stub")
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("org.springframework.boot:spring-boot-actuator")
    implementation("org.slf4j:slf4j-api")

    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
