package com.paymenthub.grpc.interceptor;

import com.paymenthub.grpc.context.GrpcMetadataKeys;
import com.paymenthub.grpc.health.GrpcHealthService;
import io.grpc.Metadata;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

class GrpcInterceptorTest {

    @Nested
    @DisplayName("GrpcMetadataKeys")
    class MetadataKeys {

        @Test
        @DisplayName("All keys are properly defined")
        void keysDefinedCorrectly() {
            assertThat(GrpcMetadataKeys.TENANT_ID.name()).isEqualTo("x-tenant-id");
            assertThat(GrpcMetadataKeys.ENTITY_ID.name()).isEqualTo("x-entity-id");
            assertThat(GrpcMetadataKeys.CORRELATION_ID.name()).isEqualTo("x-correlation-id");
            assertThat(GrpcMetadataKeys.ACTOR_IDENTITY.name()).isEqualTo("x-actor-identity");
            assertThat(GrpcMetadataKeys.ERROR_CODE.name()).isEqualTo("x-error-code");
        }

        @Test
        @DisplayName("Metadata round-trip preserves values")
        void metadataRoundTrip() {
            Metadata headers = new Metadata();
            headers.put(GrpcMetadataKeys.TENANT_ID, "MB-001");
            headers.put(GrpcMetadataKeys.CORRELATION_ID, "corr-123");
            headers.put(GrpcMetadataKeys.ERROR_RETRY_SAFE, "true");

            assertThat(headers.get(GrpcMetadataKeys.TENANT_ID)).isEqualTo("MB-001");
            assertThat(headers.get(GrpcMetadataKeys.CORRELATION_ID)).isEqualTo("corr-123");
            assertThat(headers.get(GrpcMetadataKeys.ERROR_RETRY_SAFE)).isEqualTo("true");
        }
    }

    @Nested
    @DisplayName("GrpcHealthService")
    class HealthServiceTests {

        @Test
        @DisplayName("Check returns UNKNOWN for unregistered service")
        void unknownService() {
            var service = new GrpcHealthService();
            assertThat(service.check("nonexistent")).isEqualTo(GrpcHealthService.ServingStatus.UNKNOWN);
        }

        @Test
        @DisplayName("Healthy check returns SERVING")
        void healthyService() {
            var service = new GrpcHealthService();
            service.registerCheck("audit", () -> true);
            assertThat(service.check("audit")).isEqualTo(GrpcHealthService.ServingStatus.SERVING);
        }

        @Test
        @DisplayName("Unhealthy check returns NOT_SERVING")
        void unhealthyService() {
            var service = new GrpcHealthService();
            service.registerCheck("nats", () -> false);
            assertThat(service.check("nats")).isEqualTo(GrpcHealthService.ServingStatus.NOT_SERVING);
        }

        @Test
        @DisplayName("Exception in check returns NOT_SERVING")
        void checkException() {
            var service = new GrpcHealthService();
            service.registerCheck("broken", () -> { throw new RuntimeException("boom"); });
            assertThat(service.check("broken")).isEqualTo(GrpcHealthService.ServingStatus.NOT_SERVING);
        }

        @Test
        @DisplayName("checkAll returns SERVING when all healthy")
        void allHealthy() {
            var service = new GrpcHealthService();
            service.registerCheck("a", () -> true);
            service.registerCheck("b", () -> true);
            assertThat(service.checkAll()).isEqualTo(GrpcHealthService.ServingStatus.SERVING);
        }

        @Test
        @DisplayName("checkAll returns NOT_SERVING when any unhealthy")
        void anyUnhealthy() {
            var service = new GrpcHealthService();
            service.registerCheck("a", () -> true);
            service.registerCheck("b", () -> false);
            assertThat(service.checkAll()).isEqualTo(GrpcHealthService.ServingStatus.NOT_SERVING);
        }

        @Test
        @DisplayName("Empty checks returns SERVING")
        void emptyChecks() {
            assertThat(new GrpcHealthService().checkAll()).isEqualTo(GrpcHealthService.ServingStatus.SERVING);
        }
    }

    @Nested
    @DisplayName("Interceptor instantiation")
    class Instantiation {

        @Test
        @DisplayName("TenantServerInterceptor creates with default (required=true)")
        void serverDefault() {
            assertThatCode(TenantServerInterceptor::new).doesNotThrowAnyException();
        }

        @Test
        @DisplayName("TenantClientInterceptor creates with module name")
        void clientCreate() {
            assertThatCode(() -> new TenantClientInterceptor("audit-module"))
                .doesNotThrowAnyException();
        }

        @Test
        @DisplayName("ErrorMappingServerInterceptor creates")
        void errorMapping() {
            assertThatCode(ErrorMappingServerInterceptor::new).doesNotThrowAnyException();
        }
    }
}
