package com.paymenthub.grpc.interceptor;

import com.paymenthub.grpc.context.GrpcMetadataKeys;
import com.paymenthub.observability.context.CorrelationContextHolder;
import com.paymenthub.tenant.context.TenantContextHolder;
import io.grpc.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Client-side gRPC interceptor that propagates tenant and correlation
 * context from thread-local holders to outgoing call metadata.
 *
 * <h3>Propagated Metadata</h3>
 * <ul>
 *   <li>{@code x-tenant-id} — from TenantContextHolder</li>
 *   <li>{@code x-entity-id} — from TenantContextHolder</li>
 *   <li>{@code x-correlation-id} — from CorrelationContextHolder</li>
 *   <li>{@code x-source-module} — configured module name</li>
 *   <li>{@code x-actor-identity} — from CorrelationContextHolder</li>
 * </ul>
 *
 * <h3>Usage</h3>
 * <pre>{@code
 * ManagedChannel channel = ManagedChannelBuilder.forTarget("audit-server:9090")
 *     .intercept(new TenantClientInterceptor("payment-orchestration"))
 *     .build();
 * }</pre>
 */
public class TenantClientInterceptor implements ClientInterceptor {

    private static final Logger log = LoggerFactory.getLogger(TenantClientInterceptor.class);

    private final String sourceModule;

    public TenantClientInterceptor(String sourceModule) {
        this.sourceModule = sourceModule;
    }

    @Override
    public <ReqT, RespT> ClientCall<ReqT, RespT> interceptCall(
            MethodDescriptor<ReqT, RespT> method,
            CallOptions callOptions,
            Channel next) {

        return new ForwardingClientCall.SimpleForwardingClientCall<>(
                next.newCall(method, callOptions)) {

            @Override
            public void start(Listener<RespT> responseListener, Metadata headers) {
                // Propagate tenant context
                String tenantId = TenantContextHolder.getTenantId();
                if (tenantId != null) {
                    headers.put(GrpcMetadataKeys.TENANT_ID, tenantId);
                }
                String entityId = TenantContextHolder.getEntityId();
                if (entityId != null) {
                    headers.put(GrpcMetadataKeys.ENTITY_ID, entityId);
                }

                // Propagate correlation context
                String correlationId = CorrelationContextHolder.getCorrelationId();
                if (correlationId != null) {
                    headers.put(GrpcMetadataKeys.CORRELATION_ID, correlationId);
                }

                String actorIdentity = CorrelationContextHolder.getActorIdentity();
                if (actorIdentity != null) {
                    headers.put(GrpcMetadataKeys.ACTOR_IDENTITY, actorIdentity);
                }

                // Set source module
                if (sourceModule != null) {
                    headers.put(GrpcMetadataKeys.SOURCE_MODULE, sourceModule);
                }

                log.trace("gRPC client propagated: tenant={}, correlation={}, method={}",
                    tenantId, correlationId, method.getFullMethodName());

                super.start(responseListener, headers);
            }
        };
    }
}
