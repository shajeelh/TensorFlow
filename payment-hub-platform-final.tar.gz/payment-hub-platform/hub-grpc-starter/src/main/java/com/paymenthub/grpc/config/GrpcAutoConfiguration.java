package com.paymenthub.grpc.config;

import com.paymenthub.grpc.health.GrpcHealthService;
import com.paymenthub.grpc.interceptor.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
public class GrpcAutoConfiguration {
    private static final Logger log = LoggerFactory.getLogger(GrpcAutoConfiguration.class);

    @Bean @ConditionalOnMissingBean
    public TenantServerInterceptor tenantServerInterceptor() { return new TenantServerInterceptor(); }

    @Bean @ConditionalOnMissingBean
    public TenantClientInterceptor tenantClientInterceptor(
            @Value("${hub.observability.module-name:unknown}") String moduleName) {
        return new TenantClientInterceptor(moduleName);
    }

    @Bean @ConditionalOnMissingBean
    public ErrorMappingServerInterceptor errorMappingServerInterceptor() {
        return new ErrorMappingServerInterceptor();
    }

    @Bean @ConditionalOnMissingBean
    public GrpcHealthService grpcHealthService() {
        log.info("gRPC health service configured");
        return new GrpcHealthService();
    }
}
