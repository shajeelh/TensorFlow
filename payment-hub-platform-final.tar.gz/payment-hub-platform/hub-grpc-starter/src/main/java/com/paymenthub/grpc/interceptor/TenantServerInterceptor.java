package com.paymenthub.grpc.interceptor;

import com.paymenthub.grpc.context.GrpcMetadataKeys;
import com.paymenthub.tenant.context.TenantContext;
import com.paymenthub.tenant.context.TenantContextHolder;
import io.grpc.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Server-side gRPC interceptor that extracts tenant context from
 * incoming call metadata and sets it on {@link TenantContextHolder}.
 *
 * <h3>Processing</h3>
 * <ol>
 *   <li>Extract {@code x-tenant-id} and {@code x-entity-id} from metadata</li>
 *   <li>If tenant ID present: create {@link TenantContext} and set on holder</li>
 *   <li>If tenant ID missing and required: reject with UNAUTHENTICATED status</li>
 *   <li>Invoke the handler (actual RPC method)</li>
 *   <li>Clear tenant context in onComplete/onCancel</li>
 * </ol>
 *
 * <h3>Interceptor Order</h3>
 * <p>This interceptor should run BEFORE permission-checking interceptors
 * because they need the tenant context to evaluate tenant-scoped permissions.</p>
 */
public class TenantServerInterceptor implements ServerInterceptor {

    private static final Logger log = LoggerFactory.getLogger(TenantServerInterceptor.class);

    private final boolean tenantRequired;

    public TenantServerInterceptor(boolean tenantRequired) {
        this.tenantRequired = tenantRequired;
    }

    public TenantServerInterceptor() {
        this(true);
    }

    @Override
    public <ReqT, RespT> ServerCall.Listener<ReqT> interceptCall(
            ServerCall<ReqT, RespT> call,
            Metadata headers,
            ServerCallHandler<ReqT, RespT> next) {

        String tenantId = headers.get(GrpcMetadataKeys.TENANT_ID);
        String entityId = headers.get(GrpcMetadataKeys.ENTITY_ID);
        String method = call.getMethodDescriptor().getFullMethodName();

        if (tenantId == null || tenantId.isBlank()) {
            if (tenantRequired) {
                log.warn("gRPC call without tenant context: method={}", method);
                call.close(Status.UNAUTHENTICATED
                    .withDescription("Tenant context required. Set x-tenant-id metadata."),
                    new Metadata());
                return new ServerCall.Listener<>() {};
            }
            return next.startCall(call, headers);
        }

        // Hydrate tenant context
        TenantContext ctx = TenantContext.of(tenantId.trim(),
            entityId != null ? entityId.trim() : tenantId.trim());
        TenantContextHolder.set(ctx);

        log.trace("gRPC tenant context set: tenant={}, entity={}, method={}",
            tenantId, entityId, method);

        // Wrap listener to clear context on completion
        ServerCall.Listener<ReqT> listener = next.startCall(call, headers);
        return new ForwardingServerCallListener.SimpleForwardingServerCallListener<>(listener) {
            @Override
            public void onComplete() {
                try {
                    super.onComplete();
                } finally {
                    TenantContextHolder.clear();
                }
            }

            @Override
            public void onCancel() {
                try {
                    super.onCancel();
                } finally {
                    TenantContextHolder.clear();
                }
            }
        };
    }
}
