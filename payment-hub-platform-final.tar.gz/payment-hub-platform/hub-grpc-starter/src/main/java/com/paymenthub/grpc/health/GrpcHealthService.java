package com.paymenthub.grpc.health;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BooleanSupplier;

/**
 * gRPC health service following the gRPC Health Checking Protocol.
 *
 * <p>Tracks health status of individual services within the gRPC server.
 * Used by Kubernetes gRPC health probes and load balancers.</p>
 *
 * <p>Health checks are registered by modules:</p>
 * <pre>{@code
 * grpcHealthService.registerCheck("AuditService", () -> auditStore.isHealthy());
 * grpcHealthService.registerCheck("NATS", () -> natsManager.isConnected());
 * }</pre>
 */
public class GrpcHealthService {

    private static final Logger log = LoggerFactory.getLogger(GrpcHealthService.class);

    public enum ServingStatus { SERVING, NOT_SERVING, UNKNOWN }

    private final Map<String, BooleanSupplier> healthChecks = new ConcurrentHashMap<>();

    /**
     * Register a health check for a named service.
     */
    public void registerCheck(String serviceName, BooleanSupplier check) {
        healthChecks.put(serviceName, check);
        log.debug("Registered gRPC health check: {}", serviceName);
    }

    /**
     * Check health of a specific service.
     */
    public ServingStatus check(String serviceName) {
        BooleanSupplier check = healthChecks.get(serviceName);
        if (check == null) return ServingStatus.UNKNOWN;
        try {
            return check.getAsBoolean() ? ServingStatus.SERVING : ServingStatus.NOT_SERVING;
        } catch (Exception e) {
            log.warn("Health check failed for '{}': {}", serviceName, e.getMessage());
            return ServingStatus.NOT_SERVING;
        }
    }

    /**
     * Check overall health (all services must be SERVING).
     */
    public ServingStatus checkAll() {
        if (healthChecks.isEmpty()) return ServingStatus.SERVING;
        for (Map.Entry<String, BooleanSupplier> entry : healthChecks.entrySet()) {
            if (check(entry.getKey()) != ServingStatus.SERVING) {
                return ServingStatus.NOT_SERVING;
            }
        }
        return ServingStatus.SERVING;
    }

    public int registeredCheckCount() { return healthChecks.size(); }
}
