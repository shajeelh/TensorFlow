package com.paymenthub.grpc.context;

import io.grpc.Metadata;

/**
 * Standard gRPC metadata keys for context propagation.
 *
 * <p>All inter-module gRPC calls carry these metadata keys. They are
 * set by client interceptors and read by server interceptors to
 * hydrate {@code TenantContextHolder}, {@code SecurityContextHolder},
 * and {@code CorrelationContextHolder}.</p>
 *
 * <h3>Key Naming</h3>
 * <p>gRPC metadata keys are case-insensitive. We use lowercase with
 * hyphens to match HTTP header conventions. Binary keys use the
 * {@code -bin} suffix per gRPC specification.</p>
 */
public final class GrpcMetadataKeys {

    private GrpcMetadataKeys() {}

    // ── Tenant Context ───────────────────────────────────────
    public static final Metadata.Key<String> TENANT_ID =
        Metadata.Key.of("x-tenant-id", Metadata.ASCII_STRING_MARSHALLER);

    public static final Metadata.Key<String> ENTITY_ID =
        Metadata.Key.of("x-entity-id", Metadata.ASCII_STRING_MARSHALLER);

    // ── Correlation Context ──────────────────────────────────
    public static final Metadata.Key<String> CORRELATION_ID =
        Metadata.Key.of("x-correlation-id", Metadata.ASCII_STRING_MARSHALLER);

    public static final Metadata.Key<String> CAUSATION_ID =
        Metadata.Key.of("x-causation-id", Metadata.ASCII_STRING_MARSHALLER);

    public static final Metadata.Key<String> TRACE_ID =
        Metadata.Key.of("x-trace-id", Metadata.ASCII_STRING_MARSHALLER);

    public static final Metadata.Key<String> SPAN_ID =
        Metadata.Key.of("x-span-id", Metadata.ASCII_STRING_MARSHALLER);

    // ── Security Context ─────────────────────────────────────
    public static final Metadata.Key<String> ACTOR_IDENTITY =
        Metadata.Key.of("x-actor-identity", Metadata.ASCII_STRING_MARSHALLER);

    public static final Metadata.Key<String> ACTOR_TYPE =
        Metadata.Key.of("x-actor-type", Metadata.ASCII_STRING_MARSHALLER);

    public static final Metadata.Key<String> AUTH_METHOD =
        Metadata.Key.of("x-auth-method", Metadata.ASCII_STRING_MARSHALLER);

    // ── Source ────────────────────────────────────────────────
    public static final Metadata.Key<String> SOURCE_MODULE =
        Metadata.Key.of("x-source-module", Metadata.ASCII_STRING_MARSHALLER);

    // ── Error Details ────────────────────────────────────────
    public static final Metadata.Key<String> ERROR_CODE =
        Metadata.Key.of("x-error-code", Metadata.ASCII_STRING_MARSHALLER);

    public static final Metadata.Key<String> ERROR_RETRY_SAFE =
        Metadata.Key.of("x-error-retry-safe", Metadata.ASCII_STRING_MARSHALLER);
}
