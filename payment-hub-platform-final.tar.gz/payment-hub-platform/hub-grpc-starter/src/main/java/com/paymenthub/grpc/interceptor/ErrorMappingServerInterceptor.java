package com.paymenthub.grpc.interceptor;

import com.paymenthub.common.exception.HubException;
import com.paymenthub.error.codes.ErrorCode;
import com.paymenthub.grpc.context.GrpcMetadataKeys;
import com.paymenthub.security.rbac.PermissionEvaluator;
import io.grpc.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Server-side interceptor that catches exceptions from RPC handlers
 * and maps them to appropriate gRPC status codes with error metadata.
 *
 * <h3>Exception Mapping</h3>
 * <ul>
 *   <li>{@link HubException} → mapped by severity (BUSINESS→INVALID_ARGUMENT,
 *       SECURITY→PERMISSION_DENIED, TECHNICAL→INTERNAL)</li>
 *   <li>{@link com.paymenthub.common.exception.TenantIsolationViolationException}
 *       → PERMISSION_DENIED</li>
 *   <li>{@link PermissionEvaluator.AccessDeniedException}
 *       → PERMISSION_DENIED</li>
 *   <li>{@link IllegalArgumentException} → INVALID_ARGUMENT</li>
 *   <li>{@link IllegalStateException} → FAILED_PRECONDITION</li>
 *   <li>All others → INTERNAL</li>
 * </ul>
 *
 * <h3>Error Metadata</h3>
 * <p>On error, the following metadata is sent in trailers:</p>
 * <ul>
 *   <li>{@code x-error-code} — the hub error code (e.g., "AUDIT-0001")</li>
 *   <li>{@code x-error-retry-safe} — "true" if the client should retry</li>
 * </ul>
 */
public class ErrorMappingServerInterceptor implements ServerInterceptor {

    private static final Logger log = LoggerFactory.getLogger(ErrorMappingServerInterceptor.class);

    @Override
    public <ReqT, RespT> ServerCall.Listener<ReqT> interceptCall(
            ServerCall<ReqT, RespT> call,
            Metadata headers,
            ServerCallHandler<ReqT, RespT> next) {

        ServerCall.Listener<ReqT> listener = next.startCall(
            new ExceptionHandlingServerCall<>(call), headers);

        return new ForwardingServerCallListener.SimpleForwardingServerCallListener<>(listener) {
            @Override
            public void onHalfClose() {
                try {
                    super.onHalfClose();
                } catch (Exception e) {
                    handleException(call, e);
                }
            }

            @Override
            public void onMessage(ReqT message) {
                try {
                    super.onMessage(message);
                } catch (Exception e) {
                    handleException(call, e);
                }
            }
        };
    }

    private <ReqT, RespT> void handleException(ServerCall<ReqT, RespT> call, Exception e) {
        String method = call.getMethodDescriptor().getFullMethodName();
        Status status;
        Metadata trailers = new Metadata();

        if (e instanceof HubException hubEx) {
            status = mapHubException(hubEx);
            trailers.put(GrpcMetadataKeys.ERROR_CODE, hubEx.getErrorCode());
            trailers.put(GrpcMetadataKeys.ERROR_RETRY_SAFE, String.valueOf(hubEx.isRetryable()));
            log.warn("gRPC error: method={}, code={}, severity={}, message={}",
                method, hubEx.getErrorCode(), hubEx.getSeverity(), hubEx.getMessage());

        } else if (e instanceof PermissionEvaluator.AccessDeniedException ade) {
            status = Status.PERMISSION_DENIED.withDescription(ade.getMessage());
            trailers.put(GrpcMetadataKeys.ERROR_CODE, ErrorCode.AUTH_FORBIDDEN.code());
            trailers.put(GrpcMetadataKeys.ERROR_RETRY_SAFE, "false");
            log.warn("gRPC access denied: method={}, permission={}",
                method, ade.getRequiredPermission());

        } else if (e instanceof IllegalArgumentException) {
            status = Status.INVALID_ARGUMENT.withDescription(e.getMessage());
            trailers.put(GrpcMetadataKeys.ERROR_RETRY_SAFE, "false");

        } else if (e instanceof IllegalStateException) {
            status = Status.FAILED_PRECONDITION.withDescription(e.getMessage());
            trailers.put(GrpcMetadataKeys.ERROR_RETRY_SAFE, "false");

        } else {
            status = Status.INTERNAL.withDescription("Internal error");
            trailers.put(GrpcMetadataKeys.ERROR_CODE, ErrorCode.SYS_INTERNAL_ERROR.code());
            trailers.put(GrpcMetadataKeys.ERROR_RETRY_SAFE, "true");
            log.error("Unhandled gRPC error: method={}", method, e);
        }

        call.close(status, trailers);
    }

    private Status mapHubException(HubException e) {
        return switch (e.getSeverity()) {
            case BUSINESS -> Status.INVALID_ARGUMENT.withDescription(e.getMessage());
            case SECURITY -> Status.PERMISSION_DENIED.withDescription(e.getMessage());
            case TECHNICAL -> e.isRetryable()
                ? Status.UNAVAILABLE.withDescription(e.getMessage())
                : Status.INTERNAL.withDescription(e.getMessage());
        };
    }

    /**
     * Wraps the ServerCall to catch exceptions in close/sendMessage.
     */
    private static class ExceptionHandlingServerCall<ReqT, RespT>
            extends ForwardingServerCall.SimpleForwardingServerCall<ReqT, RespT> {

        ExceptionHandlingServerCall(ServerCall<ReqT, RespT> delegate) {
            super(delegate);
        }
    }
}
