plugins { `java-library` }
description = "Payment Hub — NATS JetStream Transport (Connection, Publisher, Subscriber, Stream Management)"
dependencies {
    api(project(":hub-common-model"))
    api(project(":hub-messaging-starter"))
    implementation(project(":hub-observability-starter"))
    implementation(project(":hub-tenant-context-starter"))

    api("io.nats:jnats")
    implementation("com.fasterxml.jackson.core:jackson-databind")
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("org.springframework.boot:spring-boot-actuator")
    implementation("org.slf4j:slf4j-api")

    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
