package com.paymenthub.nats.connection;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Duration;

import static org.assertj.core.api.Assertions.*;

class NatsConnectionManagerTest {

    @Test
    @DisplayName("Initial state is DISCONNECTED")
    void initialState() {
        var mgr = new NatsConnectionManager("nats://localhost:4222", "test",
            Duration.ofSeconds(5), Duration.ofSeconds(2), 3);

        assertThat(mgr.getState()).isEqualTo(NatsConnectionManager.State.DISCONNECTED);
        assertThat(mgr.isConnected()).isFalse();
        assertThat(mgr.getReconnectCount()).isZero();
        assertThat(mgr.getConnectedUrl()).isNull();
    }

    @Test
    @DisplayName("getConnection throws when not connected")
    void getConnectionThrows() {
        var mgr = new NatsConnectionManager("nats://localhost:4222", "test",
            Duration.ofSeconds(5), Duration.ofSeconds(2), 3);

        assertThatThrownBy(mgr::getConnection)
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("Not connected");
    }

    @Test
    @DisplayName("toString contains state info")
    void toStringInfo() {
        var mgr = new NatsConnectionManager("nats://localhost:4222", "test",
            Duration.ofSeconds(5), Duration.ofSeconds(2), 3);

        assertThat(mgr.toString()).contains("DISCONNECTED");
        assertThat(mgr.toString()).contains("nats://localhost:4222");
    }

    @Test
    @DisplayName("Close on disconnected manager is safe")
    void closeWhenDisconnected() {
        var mgr = new NatsConnectionManager("nats://localhost:4222", "test",
            Duration.ofSeconds(5), Duration.ofSeconds(2), 3);

        assertThatCode(mgr::close).doesNotThrowAnyException();
        assertThat(mgr.getState()).isEqualTo(NatsConnectionManager.State.DISCONNECTED);
    }
}
