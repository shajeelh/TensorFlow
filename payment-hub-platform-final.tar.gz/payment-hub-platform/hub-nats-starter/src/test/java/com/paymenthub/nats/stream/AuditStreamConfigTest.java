package com.paymenthub.nats.stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

class AuditStreamConfigTest {

    @Test
    @DisplayName("Development config uses single replica")
    void developmentConfig() {
        var config = AuditStreamConfig.development();
        assertThat(config).isNotNull();
    }

    @Test
    @DisplayName("Production config uses 3 replicas")
    void productionConfig() {
        var config = AuditStreamConfig.production();
        assertThat(config).isNotNull();
    }

    @Test
    @DisplayName("Stream names are constants")
    void streamNames() {
        assertThat(AuditStreamConfig.STREAM_AUDIT_EVENTS).isEqualTo("AUDIT_EVENTS");
        assertThat(AuditStreamConfig.STREAM_AUDIT_RECEIPTS).isEqualTo("AUDIT_RECEIPTS");
        assertThat(AuditStreamConfig.STREAM_AUDIT_ALERTS).isEqualTo("AUDIT_ALERTS");
    }

    @Test
    @DisplayName("Consumer names are constants")
    void consumerNames() {
        assertThat(AuditStreamConfig.CONSUMER_AUDIT_PROCESSOR).isEqualTo("audit-processor");
    }

    @Test
    @DisplayName("Subject patterns match expected format")
    void subjectPatterns() {
        assertThat(AuditStreamConfig.SUBJECT_AUDIT_ALL).isEqualTo("hub.audit.>");
        assertThat(AuditStreamConfig.SUBJECT_RECEIPTS).isEqualTo("hub.audit.receipt.>");
        assertThat(AuditStreamConfig.SUBJECT_ALERTS).isEqualTo("hub.audit.alert.>");
    }
}
