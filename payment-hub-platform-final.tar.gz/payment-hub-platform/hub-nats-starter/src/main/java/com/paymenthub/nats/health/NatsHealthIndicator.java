package com.paymenthub.nats.health;

import com.paymenthub.nats.connection.NatsConnectionManager;
import com.paymenthub.nats.subscriber.NatsJetStreamSubscriber;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

/**
 * Spring Boot Actuator health indicator for NATS infrastructure.
 *
 * <p>Reports:</p>
 * <ul>
 *   <li>Connection state and connected server URL</li>
 *   <li>Reconnection count (indicates network instability)</li>
 *   <li>Subscriber status (running, processed count, error count)</li>
 * </ul>
 */
public class NatsHealthIndicator implements HealthIndicator {

    private final NatsConnectionManager connectionManager;
    private final NatsJetStreamSubscriber subscriber;

    public NatsHealthIndicator(NatsConnectionManager connectionManager,
                                NatsJetStreamSubscriber subscriber) {
        this.connectionManager = connectionManager;
        this.subscriber = subscriber;
    }

    /**
     * Create without subscriber (publisher-only modules).
     */
    public NatsHealthIndicator(NatsConnectionManager connectionManager) {
        this(connectionManager, null);
    }

    @Override
    public Health health() {
        Health.Builder builder;

        if (connectionManager.isConnected()) {
            builder = Health.up();
        } else {
            builder = Health.down().withDetail("reason", "NATS disconnected");
        }

        builder.withDetail("state", connectionManager.getState().name())
            .withDetail("connectedUrl", connectionManager.getConnectedUrl())
            .withDetail("reconnectCount", connectionManager.getReconnectCount());

        if (subscriber != null) {
            builder.withDetail("subscriberRunning", subscriber.isRunning())
                .withDetail("processedCount", subscriber.getProcessedCount())
                .withDetail("errorCount", subscriber.getErrorCount())
                .withDetail("lastProcessedAt", subscriber.getLastProcessedAt());
        }

        return builder.build();
    }
}
