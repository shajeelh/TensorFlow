package com.paymenthub.nats.publisher;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.paymenthub.messaging.envelope.MessageEnvelope;
import com.paymenthub.messaging.publisher.MessagePublisher;
import com.paymenthub.nats.connection.NatsConnectionManager;
import io.nats.client.*;
import io.nats.client.api.PublishAck;
import io.nats.client.impl.Headers;
import io.nats.client.impl.NatsMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

/**
 * NATS JetStream implementation of {@link MessagePublisher}.
 *
 * <h3>Publish Flow</h3>
 * <ol>
 *   <li>Serialize {@link MessageEnvelope} to JSON</li>
 *   <li>Build NATS message with subject + headers (tenant, correlation, type)</li>
 *   <li>Publish via JetStream {@code publishAsync} for non-blocking IO</li>
 *   <li>Return CompletableFuture that completes on JetStream ack
 *       (message durably persisted to stream)</li>
 * </ol>
 *
 * <h3>Headers</h3>
 * <p>In addition to the JSON body, key fields are duplicated as NATS
 * headers for server-side subject filtering without deserialization:</p>
 * <ul>
 *   <li>{@code X-Tenant-Id} — for tenant-scoped stream filtering</li>
 *   <li>{@code X-Message-Type} — for type-based consumer filtering</li>
 *   <li>{@code X-Correlation-Id} — for distributed tracing</li>
 *   <li>{@code Nats-Msg-Id} — for server-side deduplication</li>
 * </ul>
 *
 * <h3>Deduplication</h3>
 * <p>The message ID is set as {@code Nats-Msg-Id} header, enabling
 * JetStream's built-in deduplication within the stream's duplicate
 * window (default: 2 minutes).</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Thread-safe. NATS JetStream publish is thread-safe. The ObjectMapper
 * is shared but thread-safe for serialization.</p>
 */
public class NatsJetStreamPublisher implements MessagePublisher {

    private static final Logger log = LoggerFactory.getLogger(NatsJetStreamPublisher.class);

    private final NatsConnectionManager connectionManager;
    private final ObjectMapper objectMapper;

    public NatsJetStreamPublisher(NatsConnectionManager connectionManager) {
        this(connectionManager, createObjectMapper());
    }

    public NatsJetStreamPublisher(NatsConnectionManager connectionManager, ObjectMapper objectMapper) {
        this.connectionManager = Objects.requireNonNull(connectionManager);
        this.objectMapper = Objects.requireNonNull(objectMapper);
    }

    @Override
    public <T> CompletableFuture<PublishResult> publish(MessageEnvelope<T> envelope) {
        return publish(envelope.subject(), envelope);
    }

    @Override
    public <T> CompletableFuture<PublishResult> publish(String subject, MessageEnvelope<T> envelope) {
        Objects.requireNonNull(subject, "Subject required");
        Objects.requireNonNull(envelope, "Envelope required");

        try {
            byte[] payload = objectMapper.writeValueAsBytes(envelope);
            Headers headers = buildHeaders(envelope);

            Message natsMsg = NatsMessage.builder()
                .subject(subject)
                .headers(headers)
                .data(payload)
                .build();

            JetStream js = connectionManager.getConnection().jetStream();
            CompletableFuture<PublishAck> ackFuture = js.publishAsync(natsMsg);

            return ackFuture.thenApply(ack -> {
                log.debug("Published to '{}': seq={}, stream={}, msgId={}",
                    subject, ack.getSeqno(), ack.getStream(), envelope.messageId());
                return PublishResult.success(envelope.messageId(), subject, ack.getSeqno());
            }).exceptionally(ex -> {
                log.error("Publish failed to '{}': msgId={}, error={}",
                    subject, envelope.messageId(), ex.getMessage());
                return PublishResult.failure(envelope.messageId(), subject);
            });

        } catch (JsonProcessingException e) {
            log.error("Failed to serialize envelope: {}", e.getMessage());
            return CompletableFuture.completedFuture(
                PublishResult.failure(envelope.messageId(), subject));
        } catch (IOException e) {
            log.error("JetStream unavailable: {}", e.getMessage());
            return CompletableFuture.failedFuture(e);
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T, R> CompletableFuture<MessageEnvelope<R>> request(MessageEnvelope<T> envelope,
                                                                   Duration timeout) {
        Objects.requireNonNull(envelope, "Envelope required");
        Objects.requireNonNull(timeout, "Timeout required");

        try {
            byte[] payload = objectMapper.writeValueAsBytes(envelope);
            Connection conn = connectionManager.getConnection();

            // Use NATS core request-reply (not JetStream) for low-latency sync path
            return conn.requestWithTimeout(envelope.subject(), payload, timeout)
                .thenApply(reply -> {
                    try {
                        return objectMapper.readValue(reply.getData(),
                            objectMapper.getTypeFactory().constructParametricType(
                                MessageEnvelope.class, Object.class));
                    } catch (IOException e) {
                        throw new RuntimeException("Failed to deserialize reply", e);
                    }
                });

        } catch (JsonProcessingException e) {
            return CompletableFuture.failedFuture(e);
        }
    }

    @Override
    public String transportType() { return "nats_jetstream"; }

    @Override
    public boolean isHealthy() { return connectionManager.isConnected(); }

    // ── Internal ─────────────────────────────────────────────

    private <T> Headers buildHeaders(MessageEnvelope<T> envelope) {
        Headers headers = new Headers();

        // Nats-Msg-Id enables server-side deduplication
        if (envelope.messageId() != null) {
            headers.add("Nats-Msg-Id", envelope.messageId());
        }

        // Propagate key fields as headers for server-side filtering
        if (envelope.tenantId() != null) {
            headers.add("X-Tenant-Id", envelope.tenantId());
        }
        if (envelope.entityId() != null) {
            headers.add("X-Entity-Id", envelope.entityId());
        }
        if (envelope.correlationId() != null) {
            headers.add("X-Correlation-Id", envelope.correlationId());
        }
        if (envelope.type() != null) {
            headers.add("X-Message-Type", envelope.type());
        }
        if (envelope.source() != null) {
            headers.add("X-Source-Module", envelope.source());
        }

        // Custom envelope headers
        envelope.headers().forEach(headers::add);

        return headers;
    }

    private static ObjectMapper createObjectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        return mapper;
    }
}
