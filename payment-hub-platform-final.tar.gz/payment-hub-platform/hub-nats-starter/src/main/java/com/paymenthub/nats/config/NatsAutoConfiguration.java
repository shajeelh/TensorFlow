package com.paymenthub.nats.config;

import com.paymenthub.nats.connection.NatsConnectionManager;
import com.paymenthub.nats.health.NatsHealthIndicator;
import com.paymenthub.nats.publisher.NatsJetStreamPublisher;
import com.paymenthub.nats.stream.AuditStreamConfig;
import com.paymenthub.nats.subscriber.NatsJetStreamSubscriber;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

import java.time.Duration;

@AutoConfiguration
@EnableConfigurationProperties(NatsAutoConfiguration.NatsProperties.class)
@ConditionalOnProperty(name = "hub.nats.enabled", havingValue = "true", matchIfMissing = false)
public class NatsAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(NatsAutoConfiguration.class);

    @Bean
    @ConditionalOnMissingBean
    public NatsConnectionManager natsConnectionManager(NatsProperties props) {
        log.info("Configuring NATS connection: servers={}, name={}", props.getServers(), props.getConnectionName());
        return new NatsConnectionManager(
            props.getServers(),
            props.getConnectionName(),
            Duration.ofMillis(props.getConnectTimeoutMs()),
            Duration.ofMillis(props.getReconnectWaitMs()),
            props.getMaxReconnects()
        );
    }

    @Bean
    @ConditionalOnMissingBean
    public NatsJetStreamPublisher natsJetStreamPublisher(NatsConnectionManager connMgr) {
        return new NatsJetStreamPublisher(connMgr);
    }

    @Bean
    @ConditionalOnMissingBean
    public NatsJetStreamSubscriber natsJetStreamSubscriber(NatsConnectionManager connMgr) {
        return new NatsJetStreamSubscriber(connMgr);
    }

    @Bean
    @ConditionalOnMissingBean
    public AuditStreamConfig auditStreamConfig(NatsProperties props) {
        return "production".equals(props.getProfile())
            ? AuditStreamConfig.production()
            : AuditStreamConfig.development();
    }

    @Bean
    @ConditionalOnMissingBean
    public NatsHealthIndicator natsHealthIndicator(NatsConnectionManager connMgr,
                                                     NatsJetStreamSubscriber subscriber) {
        return new NatsHealthIndicator(connMgr, subscriber);
    }

    @ConfigurationProperties(prefix = "hub.nats")
    public static class NatsProperties {
        private boolean enabled = false;
        private String servers = "nats://localhost:4222";
        private String connectionName = "hub-nats";
        private long connectTimeoutMs = 5000;
        private long reconnectWaitMs = 2000;
        private int maxReconnects = -1;
        private String profile = "development";

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean v) { this.enabled = v; }
        public String getServers() { return servers; }
        public void setServers(String v) { this.servers = v; }
        public String getConnectionName() { return connectionName; }
        public void setConnectionName(String v) { this.connectionName = v; }
        public long getConnectTimeoutMs() { return connectTimeoutMs; }
        public void setConnectTimeoutMs(long v) { this.connectTimeoutMs = v; }
        public long getReconnectWaitMs() { return reconnectWaitMs; }
        public void setReconnectWaitMs(long v) { this.reconnectWaitMs = v; }
        public int getMaxReconnects() { return maxReconnects; }
        public void setMaxReconnects(int v) { this.maxReconnects = v; }
        public String getProfile() { return profile; }
        public void setProfile(String v) { this.profile = v; }
    }
}
