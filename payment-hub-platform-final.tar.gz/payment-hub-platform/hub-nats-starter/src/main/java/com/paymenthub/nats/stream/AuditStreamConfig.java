package com.paymenthub.nats.stream;

import io.nats.client.JetStreamManagement;
import io.nats.client.api.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.Duration;

/**
 * JetStream stream and consumer configuration for the audit pipeline.
 *
 * <h3>Streams</h3>
 * <ul>
 *   <li>{@code AUDIT_EVENTS} — primary audit event stream. Captures all
 *       events published to {@code hub.audit.>}. Retention: limits-based
 *       (max 10GB or 30 days). Replicas: 3 for durability.</li>
 *   <li>{@code AUDIT_RECEIPTS} — receipt confirmations for sync audit.
 *       Subject: {@code hub.audit.receipt.>}. Short retention (1 hour).</li>
 *   <li>{@code AUDIT_ALERTS} — anomaly detection alerts.
 *       Subject: {@code hub.audit.alert.>}. WorkQueue policy.</li>
 * </ul>
 *
 * <h3>Consumers</h3>
 * <ul>
 *   <li>{@code audit-processor} — durable push consumer on AUDIT_EVENTS.
 *       Processes events through the hash chain → store → sign pipeline.
 *       Ack wait: 30s. Max deliver: 5. Filter subject: configurable per
 *       deployment profile.</li>
 *   <li>{@code audit-receipt-listener} — ephemeral consumer for receipt
 *       responses. Used by the sync audit path.</li>
 * </ul>
 *
 * <h3>Idempotent Creation</h3>
 * <p>All create methods are idempotent — if the stream/consumer already
 * exists with compatible configuration, the call succeeds. If it exists
 * with incompatible configuration, an update is attempted.</p>
 */
public class AuditStreamConfig {

    private static final Logger log = LoggerFactory.getLogger(AuditStreamConfig.class);

    // ── Stream Names ─────────────────────────────────────────
    public static final String STREAM_AUDIT_EVENTS = "AUDIT_EVENTS";
    public static final String STREAM_AUDIT_RECEIPTS = "AUDIT_RECEIPTS";
    public static final String STREAM_AUDIT_ALERTS = "AUDIT_ALERTS";

    // ── Consumer Names ───────────────────────────────────────
    public static final String CONSUMER_AUDIT_PROCESSOR = "audit-processor";
    public static final String CONSUMER_RECEIPT_LISTENER = "audit-receipt-listener";

    // ── Subjects ─────────────────────────────────────────────
    public static final String SUBJECT_AUDIT_ALL = "hub.audit.>";
    public static final String SUBJECT_RECEIPTS = "hub.audit.receipt.>";
    public static final String SUBJECT_ALERTS = "hub.audit.alert.>";

    private final int replicas;
    private final long maxBytes;
    private final Duration maxAge;
    private final Duration ackWait;
    private final int maxDeliver;

    /**
     * @param replicas   number of stream replicas (1 for dev, 3 for production)
     * @param maxBytes   max stream size in bytes (default: 10GB)
     * @param maxAge     max message age (default: 30 days)
     * @param ackWait    consumer ack timeout (default: 30s)
     * @param maxDeliver max delivery attempts before dead-letter (default: 5)
     */
    public AuditStreamConfig(int replicas, long maxBytes, Duration maxAge,
                               Duration ackWait, int maxDeliver) {
        this.replicas = replicas;
        this.maxBytes = maxBytes;
        this.maxAge = maxAge;
        this.ackWait = ackWait;
        this.maxDeliver = maxDeliver;
    }

    /**
     * Default config for development (single replica, small limits).
     */
    public static AuditStreamConfig development() {
        return new AuditStreamConfig(1, 1_073_741_824L, // 1GB
            Duration.ofDays(7), Duration.ofSeconds(30), 3);
    }

    /**
     * Production config (3 replicas, large limits).
     */
    public static AuditStreamConfig production() {
        return new AuditStreamConfig(3, 10_737_418_240L, // 10GB
            Duration.ofDays(30), Duration.ofSeconds(30), 5);
    }

    // ── Stream Setup ─────────────────────────────────────────

    /**
     * Create or update the primary audit events stream.
     */
    public StreamInfo createAuditEventsStream(JetStreamManagement jsm)
            throws IOException, io.nats.client.JetStreamApiException {

        StreamConfiguration config = StreamConfiguration.builder()
            .name(STREAM_AUDIT_EVENTS)
            .subjects(SUBJECT_AUDIT_ALL)
            .retentionPolicy(RetentionPolicy.Limits)
            .maxBytes(maxBytes)
            .maxAge(maxAge)
            .storageType(StorageType.File)
            .replicas(replicas)
            .duplicateWindow(Duration.ofMinutes(2)) // dedup window
            .discardPolicy(DiscardPolicy.Old)
            .build();

        return createOrUpdateStream(jsm, config);
    }

    /**
     * Create or update the receipt stream.
     */
    public StreamInfo createReceiptsStream(JetStreamManagement jsm)
            throws IOException, io.nats.client.JetStreamApiException {

        StreamConfiguration config = StreamConfiguration.builder()
            .name(STREAM_AUDIT_RECEIPTS)
            .subjects(SUBJECT_RECEIPTS)
            .retentionPolicy(RetentionPolicy.Limits)
            .maxAge(Duration.ofHours(1)) // short-lived receipts
            .storageType(StorageType.Memory) // fast, no persistence needed
            .replicas(Math.min(replicas, 1)) // single replica OK for receipts
            .build();

        return createOrUpdateStream(jsm, config);
    }

    /**
     * Create or update the alerts stream.
     */
    public StreamInfo createAlertsStream(JetStreamManagement jsm)
            throws IOException, io.nats.client.JetStreamApiException {

        StreamConfiguration config = StreamConfiguration.builder()
            .name(STREAM_AUDIT_ALERTS)
            .subjects(SUBJECT_ALERTS)
            .retentionPolicy(RetentionPolicy.WorkQueue) // consumed exactly once
            .storageType(StorageType.File)
            .replicas(replicas)
            .build();

        return createOrUpdateStream(jsm, config);
    }

    // ── Consumer Setup ───────────────────────────────────────

    /**
     * Create the durable audit processor consumer.
     */
    public ConsumerInfo createAuditProcessorConsumer(JetStreamManagement jsm)
            throws IOException, io.nats.client.JetStreamApiException {

        ConsumerConfiguration config = ConsumerConfiguration.builder()
            .durable(CONSUMER_AUDIT_PROCESSOR)
            .filterSubject(SUBJECT_AUDIT_ALL)
            .ackPolicy(AckPolicy.Explicit)
            .ackWait(ackWait)
            .maxDeliver(maxDeliver)
            .deliverPolicy(DeliverPolicy.All)
            .replayPolicy(ReplayPolicy.Instant)
            .build();

        return createOrUpdateConsumer(jsm, STREAM_AUDIT_EVENTS, config);
    }

    // ── Setup All ────────────────────────────────────────────

    /**
     * Create all streams and consumers. Idempotent.
     */
    public void setupAll(JetStreamManagement jsm)
            throws IOException, io.nats.client.JetStreamApiException {
        log.info("Setting up NATS JetStream infrastructure: replicas={}, maxBytes={}, maxAge={}",
            replicas, maxBytes, maxAge);

        createAuditEventsStream(jsm);
        createReceiptsStream(jsm);
        createAlertsStream(jsm);
        createAuditProcessorConsumer(jsm);

        log.info("NATS JetStream infrastructure ready");
    }

    // ── Internal ─────────────────────────────────────────────

    private StreamInfo createOrUpdateStream(JetStreamManagement jsm, StreamConfiguration config)
            throws IOException, io.nats.client.JetStreamApiException {
        try {
            StreamInfo info = jsm.getStreamInfo(config.getName());
            log.debug("Stream '{}' already exists — updating", config.getName());
            return jsm.updateStream(config);
        } catch (io.nats.client.JetStreamApiException e) {
            if (e.getApiErrorCode() == 10059) { // stream not found
                log.info("Creating stream '{}'", config.getName());
                return jsm.addStream(config);
            }
            throw e;
        }
    }

    private ConsumerInfo createOrUpdateConsumer(JetStreamManagement jsm, String streamName,
                                                  ConsumerConfiguration config)
            throws IOException, io.nats.client.JetStreamApiException {
        try {
            jsm.getConsumerInfo(streamName, config.getDurable());
            log.debug("Consumer '{}' already exists on stream '{}'",
                config.getDurable(), streamName);
            return jsm.getConsumerInfo(streamName, config.getDurable());
        } catch (io.nats.client.JetStreamApiException e) {
            if (e.getApiErrorCode() == 10014) { // consumer not found
                log.info("Creating consumer '{}' on stream '{}'",
                    config.getDurable(), streamName);
                return jsm.addOrUpdateConsumer(streamName, config);
            }
            throw e;
        }
    }
}
