package com.paymenthub.nats.subscriber;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.paymenthub.messaging.envelope.MessageEnvelope;
import com.paymenthub.messaging.subscriber.MessageHandler;
import com.paymenthub.nats.connection.NatsConnectionManager;
import com.paymenthub.tenant.context.TenantContext;
import com.paymenthub.tenant.context.TenantContextHolder;
import io.nats.client.*;
import io.nats.client.api.ConsumerConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.io.IOException;
import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * NATS JetStream durable subscriber with tenant context hydration.
 *
 * <h3>Processing Flow</h3>
 * <ol>
 *   <li>Receive message from JetStream push subscription</li>
 *   <li>Deserialize {@link MessageEnvelope} from JSON</li>
 *   <li>Hydrate {@code TenantContextHolder} from envelope tenant fields</li>
 *   <li>Push correlation/tenant to SLF4J MDC</li>
 *   <li>Invoke registered {@link MessageHandler}</li>
 *   <li>On success: ACK the message (removed from stream)</li>
 *   <li>On failure: NAK the message (redelivered after delay)</li>
 *   <li>Always: clear TenantContextHolder and MDC</li>
 * </ol>
 *
 * <h3>Error Handling</h3>
 * <ul>
 *   <li>Deserialization errors → NAK with no delay (poison message detection)</li>
 *   <li>Handler exceptions → NAK with delay (exponential backoff by JetStream)</li>
 *   <li>After max deliveries → message goes to dead-letter (if configured)</li>
 * </ul>
 *
 * <h3>Metrics</h3>
 * <p>Tracks processed count, error count, and last processed timestamp
 * for Actuator health endpoint.</p>
 */
public class NatsJetStreamSubscriber implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(NatsJetStreamSubscriber.class);

    private final NatsConnectionManager connectionManager;
    private final ObjectMapper objectMapper;
    private final AtomicLong processedCount = new AtomicLong(0);
    private final AtomicLong errorCount = new AtomicLong(0);
    private final AtomicBoolean running = new AtomicBoolean(false);
    private volatile JetStreamSubscription subscription;
    private volatile long lastProcessedAt = 0;

    public NatsJetStreamSubscriber(NatsConnectionManager connectionManager) {
        this(connectionManager, createObjectMapper());
    }

    public NatsJetStreamSubscriber(NatsConnectionManager connectionManager,
                                     ObjectMapper objectMapper) {
        this.connectionManager = Objects.requireNonNull(connectionManager);
        this.objectMapper = Objects.requireNonNull(objectMapper);
    }

    /**
     * Subscribe to a JetStream stream with a durable consumer.
     *
     * @param streamName   the stream to subscribe to
     * @param consumerName the durable consumer name
     * @param handler      the message handler
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void subscribe(String streamName, String consumerName,
                           MessageHandler<?> handler) throws IOException, JetStreamApiException {

        Connection conn = connectionManager.getConnection();
        JetStream js = conn.jetStream();

        // Create push subscription with message handler
        Dispatcher dispatcher = conn.createDispatcher();

        PushSubscribeOptions options = PushSubscribeOptions.builder()
            .stream(streamName)
            .configuration(ConsumerConfiguration.builder()
                .durable(consumerName)
                .build())
            .build();

        subscription = js.subscribe(null, dispatcher, msg -> {
            processMessage(msg, (MessageHandler) handler);
        }, false, options);

        running.set(true);
        log.info("Subscribed to stream '{}' with consumer '{}' — ready for messages",
            streamName, consumerName);
    }

    /**
     * Subscribe to a specific subject pattern on a stream.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void subscribe(String streamName, String consumerName,
                           String filterSubject, MessageHandler<?> handler)
            throws IOException, JetStreamApiException {

        Connection conn = connectionManager.getConnection();
        JetStream js = conn.jetStream();
        Dispatcher dispatcher = conn.createDispatcher();

        PushSubscribeOptions options = PushSubscribeOptions.builder()
            .stream(streamName)
            .configuration(ConsumerConfiguration.builder()
                .durable(consumerName)
                .filterSubject(filterSubject)
                .build())
            .build();

        subscription = js.subscribe(filterSubject, dispatcher, msg -> {
            processMessage(msg, (MessageHandler) handler);
        }, false, options);

        running.set(true);
        log.info("Subscribed to stream '{}' consumer '{}' filter '{}'",
            streamName, consumerName, filterSubject);
    }

    // ── Message Processing ───────────────────────────────────

    private void processMessage(Message natsMsg, MessageHandler<Object> handler) {
        String subject = natsMsg.getSubject();
        String msgId = natsMsg.getHeaders() != null
            ? natsMsg.getHeaders().getFirst("Nats-Msg-Id") : null;

        try {
            // 1. Deserialize envelope
            MessageEnvelope<Object> envelope = objectMapper.readValue(
                natsMsg.getData(),
                objectMapper.getTypeFactory().constructParametricType(
                    MessageEnvelope.class, Object.class));

            // 2. Hydrate tenant context
            if (envelope.tenantId() != null) {
                TenantContextHolder.set(TenantContext.of(
                    envelope.tenantId(),
                    envelope.entityId() != null ? envelope.entityId() : envelope.tenantId()));
            }

            // 3. Set MDC for structured logging
            if (envelope.correlationId() != null) MDC.put("correlationId", envelope.correlationId());
            if (envelope.tenantId() != null) MDC.put("tenantId", envelope.tenantId());
            MDC.put("messageId", envelope.messageId());

            // 4. Invoke handler
            log.trace("Processing message: subject={}, msgId={}, type={}",
                subject, msgId, envelope.type());
            handler.handle(envelope);

            // 5. ACK on success
            natsMsg.ack();
            processedCount.incrementAndGet();
            lastProcessedAt = System.currentTimeMillis();

            log.trace("Message processed and ACKed: subject={}, msgId={}", subject, msgId);

        } catch (Exception e) {
            errorCount.incrementAndGet();
            log.error("Message processing failed: subject={}, msgId={}, error={}",
                subject, msgId, e.getMessage(), e);

            // NAK for redelivery
            try {
                natsMsg.nak();
            } catch (Exception nakError) {
                log.error("Failed to NAK message: {}", nakError.getMessage());
            }

        } finally {
            // 6. Always clear context
            TenantContextHolder.clear();
            MDC.remove("correlationId");
            MDC.remove("tenantId");
            MDC.remove("messageId");
        }
    }

    // ── Lifecycle ────────────────────────────────────────────

    @Override
    public void close() {
        running.set(false);
        if (subscription != null) {
            try {
                subscription.drain(Duration.ofSeconds(5));
            } catch (Exception e) {
                log.warn("Error draining subscription: {}", e.getMessage());
            }
            subscription = null;
        }
        log.info("NATS subscriber closed. Processed: {}, Errors: {}",
            processedCount.get(), errorCount.get());
    }

    // ── Metrics ──────────────────────────────────────────────

    public boolean isRunning() { return running.get(); }
    public long getProcessedCount() { return processedCount.get(); }
    public long getErrorCount() { return errorCount.get(); }
    public long getLastProcessedAt() { return lastProcessedAt; }

    private static ObjectMapper createObjectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        return mapper;
    }
}
