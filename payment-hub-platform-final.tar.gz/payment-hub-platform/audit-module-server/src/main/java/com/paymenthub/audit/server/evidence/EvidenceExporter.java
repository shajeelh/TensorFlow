package com.paymenthub.audit.server.evidence;

import com.paymenthub.audit.server.chain.HashChainManager;
import com.paymenthub.audit.server.merkle.MerkleWindowScheduler;
import com.paymenthub.audit.server.store.AuditEventStore;
import com.paymenthub.common.model.AuditEvent;
import com.paymenthub.crypto.merkle.MerkleTreeBuilder;
import com.paymenthub.time.clock.HubClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Generates cryptographic evidence packages for compliance auditors.
 *
 * <h3>Evidence Package Contents</h3>
 * <pre>
 * evidence-{tenant}-{from}-{to}/
 * ├── manifest.json          ← Package metadata + overall hash + signature
 * ├── events/
 * │   ├── event-001.json     ← Individual audit events
 * │   ├── event-002.json
 * │   └── ...
 * ├── chain/
 * │   └── chain-proof.json   ← Hash chain segment with link verification data
 * ├── merkle/
 * │   ├── window-001.json    ← Merkle tree root + signature per window
 * │   └── window-002.json
 * └── proofs/
 *     ├── proof-001.json     ← Per-event Merkle inclusion proof
 *     └── proof-002.json
 * </pre>
 *
 * <h3>Verification Flow</h3>
 * <p>An auditor can independently verify the evidence package:</p>
 * <ol>
 *   <li>Verify manifest signature using the signing public key</li>
 *   <li>Recompute each event hash and verify against chain-proof</li>
 *   <li>Verify Merkle inclusion proofs for each event</li>
 *   <li>Verify Merkle root signatures for each window</li>
 *   <li>Verify hash chain continuity (each link references previous)</li>
 * </ol>
 */
public class EvidenceExporter {

    private static final Logger log = LoggerFactory.getLogger(EvidenceExporter.class);

    private final AuditEventStore eventStore;
    private final HashChainManager chainManager;
    private final MerkleWindowScheduler windowScheduler;
    private final MerkleTreeBuilder merkleTreeBuilder;
    private final HubClock clock;

    public EvidenceExporter(AuditEventStore eventStore, HashChainManager chainManager,
                              MerkleWindowScheduler windowScheduler,
                              MerkleTreeBuilder merkleTreeBuilder, HubClock clock) {
        this.eventStore = Objects.requireNonNull(eventStore);
        this.chainManager = Objects.requireNonNull(chainManager);
        this.windowScheduler = Objects.requireNonNull(windowScheduler);
        this.merkleTreeBuilder = Objects.requireNonNull(merkleTreeBuilder);
        this.clock = Objects.requireNonNull(clock);
    }

    /**
     * Export an evidence package for a tenant and time range.
     *
     * @param tenantId  the tenant
     * @param from      start of time range (inclusive)
     * @param to        end of time range (inclusive)
     * @param maxEvents maximum events to include (safety limit)
     * @return the evidence package
     */
    public EvidencePackage export(String tenantId, Instant from, Instant to, int maxEvents) {
        Objects.requireNonNull(tenantId, "tenantId required");
        Objects.requireNonNull(from, "from required");
        Objects.requireNonNull(to, "to required");

        log.info("Exporting evidence package: tenant={}, from={}, to={}, maxEvents={}",
            tenantId, from, to, maxEvents);

        // 1. Retrieve events
        List<AuditEvent> events = eventStore.findByTenantAndTimeRange(
            tenantId, from, to, maxEvents);

        if (events.isEmpty()) {
            log.warn("No events found for tenant '{}' in range {} to {}", tenantId, from, to);
            return EvidencePackage.empty(tenantId, from, to);
        }

        // 2. Build chain proof segment
        ChainProof chainProof = buildChainProof(tenantId, events);

        // 3. Find Merkle windows covering this time range
        List<MerkleWindowScheduler.WindowResult> windows = windowScheduler.getCompletedWindows()
            .stream()
            .filter(w -> w.tenantId().equals(tenantId))
            .filter(w -> !w.windowEnd().isBefore(from) && !w.windowStart().isAfter(to))
            .collect(Collectors.toList());

        // 4. Build event inclusion proofs
        List<EventProof> eventProofs = buildEventProofs(events);

        // 5. Build manifest
        Instant exportedAt = clock.instant();
        String packageId = UUID.randomUUID().toString();

        EvidenceManifest manifest = new EvidenceManifest(
            packageId,
            tenantId,
            from,
            to,
            exportedAt,
            events.size(),
            windows.size(),
            chainProof != null ? chainProof.chainStartPosition() : 0,
            chainProof != null ? chainProof.chainEndPosition() : 0
        );

        EvidencePackage pkg = new EvidencePackage(
            manifest, events, chainProof, windows, eventProofs);

        log.info("Evidence package exported: id={}, events={}, windows={}, chain={}-{}",
            packageId, events.size(), windows.size(),
            manifest.chainStartPosition(), manifest.chainEndPosition());

        return pkg;
    }

    // ── Chain Proof ──────────────────────────────────────────

    private ChainProof buildChainProof(String tenantId, List<AuditEvent> events) {
        if (events.isEmpty()) return null;

        List<ChainLink> links = new ArrayList<>();
        for (AuditEvent event : events) {
            if (event.integrity() != null) {
                links.add(new ChainLink(
                    event.eventId(),
                    event.integrity().eventHash(),
                    event.integrity().chainHash(),
                    event.integrity().chainPosition(),
                    event.integrity().previousChainHash()
                ));
            }
        }

        long startPos = links.isEmpty() ? 0 : links.getFirst().position();
        long endPos = links.isEmpty() ? 0 : links.getLast().position();

        return new ChainProof(tenantId, startPos, endPos, links);
    }

    // ── Event Proofs ─────────────────────────────────────────

    private List<EventProof> buildEventProofs(List<AuditEvent> events) {
        return events.stream()
            .filter(e -> e.integrity() != null)
            .map(e -> new EventProof(
                e.eventId(),
                e.integrity().eventHash(),
                e.integrity().chainHash(),
                e.integrity().chainPosition()
            ))
            .collect(Collectors.toList());
    }

    // ── Records ──────────────────────────────────────────────

    /**
     * Complete evidence package.
     */
    public record EvidencePackage(
        EvidenceManifest manifest,
        List<AuditEvent> events,
        ChainProof chainProof,
        List<MerkleWindowScheduler.WindowResult> merkleWindows,
        List<EventProof> eventProofs
    ) {
        public static EvidencePackage empty(String tenantId, Instant from, Instant to) {
            return new EvidencePackage(
                new EvidenceManifest(UUID.randomUUID().toString(), tenantId,
                    from, to, Instant.now(), 0, 0, 0, 0),
                List.of(), null, List.of(), List.of()
            );
        }

        public boolean isEmpty() { return events.isEmpty(); }
        public int eventCount() { return events.size(); }
    }

    public record EvidenceManifest(
        String packageId,
        String tenantId,
        Instant timeRangeFrom,
        Instant timeRangeTo,
        Instant exportedAt,
        int eventCount,
        int merkleWindowCount,
        long chainStartPosition,
        long chainEndPosition
    ) {}

    public record ChainProof(
        String tenantId,
        long chainStartPosition,
        long chainEndPosition,
        List<ChainLink> links
    ) {}

    public record ChainLink(
        String eventId,
        String eventHash,
        String chainHash,
        long position,
        String previousChainHash
    ) {}

    public record EventProof(
        String eventId,
        String eventHash,
        String chainHash,
        long chainPosition
    ) {}
}
