package com.paymenthub.audit.server.pipeline;

import com.fasterxml.jackson.databind.JsonNode;
import com.paymenthub.audit.receipt.AuditReceipt;
import com.paymenthub.audit.server.chain.HashChainManager;
import com.paymenthub.audit.server.store.AuditEventStore;
import com.paymenthub.common.enums.SyncMode;
import com.paymenthub.common.model.AuditEvent;
import com.paymenthub.common.model.IntegrityInfo;
import com.paymenthub.crypto.hash.HashService;
import com.paymenthub.pii.PiiJsonSanitizer;
import com.paymenthub.time.clock.HubClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Core audit event processing pipeline.
 *
 * <h3>Pipeline Stages</h3>
 * <pre>
 * Inbound Event (from NATS JetStream consumer)
 *   │
 *   ├─ 1. VALIDATE — null checks, required fields, timestamp bounds
 *   │
 *   ├─ 2. PII SANITIZE — scan payload, mask Tier 2, redact Tier 0,
 *   │     tokenize Tier 1 (via PII Vault, future)
 *   │
 *   ├─ 3. HASH — compute SHA3-256 canonical hash of sanitized event
 *   │     (RFC 8785 deterministic JSON serialization)
 *   │
 *   ├─ 4. CHAIN LINK — extend the per-tenant hash chain:
 *   │     chainHash = SHA3-256(previousHash || eventHash)
 *   │     This creates a backward-linked tamper-evident chain.
 *   │
 *   ├─ 5. STORE — persist to OpenSearch (primary query store) and
 *   │     accumulate for S3 WORM archival batch
 *   │
 *   ├─ 6. SIGN (batched) — events accumulate in a Merkle window.
 *   │     Every 10 minutes, the MerkleWindowScheduler computes the
 *   │     tree root and signs it with the ECDSA-P384 key.
 *   │
 *   └─ 7. RECEIPT — generate AuditReceipt with cryptographic proof
 *         (for SYNC mode callers)
 * </pre>
 *
 * <h3>Ordering</h3>
 * <p>Events are processed in NATS JetStream delivery order within each
 * consumer group. The hash chain is strictly sequential per tenant.</p>
 *
 * <h3>Error Handling</h3>
 * <p>Pipeline failures are classified:</p>
 * <ul>
 *   <li><strong>Validation errors</strong> — event rejected, NAK with no retry</li>
 *   <li><strong>Store errors</strong> — event NAKed for redelivery (transient)</li>
 *   <li><strong>Chain errors</strong> — CRITICAL alert, event held for repair</li>
 * </ul>
 */
public class AuditPipeline {

    private static final Logger log = LoggerFactory.getLogger(AuditPipeline.class);

    private final HashService hashService;
    private final HashChainManager chainManager;
    private final PiiJsonSanitizer piiSanitizer;
    private final AuditEventStore eventStore;
    private final HubClock clock;

    // Metrics
    private final AtomicLong processedCount = new AtomicLong(0);
    private final AtomicLong validationErrors = new AtomicLong(0);
    private final AtomicLong storeErrors = new AtomicLong(0);
    private final AtomicLong chainErrors = new AtomicLong(0);

    public AuditPipeline(HashService hashService, HashChainManager chainManager,
                           PiiJsonSanitizer piiSanitizer, AuditEventStore eventStore,
                           HubClock clock) {
        this.hashService = Objects.requireNonNull(hashService);
        this.chainManager = Objects.requireNonNull(chainManager);
        this.piiSanitizer = Objects.requireNonNull(piiSanitizer);
        this.eventStore = Objects.requireNonNull(eventStore);
        this.clock = Objects.requireNonNull(clock);
    }

    /**
     * Process a single audit event through the full pipeline.
     *
     * @param event    the inbound audit event
     * @param syncMode the sync mode (affects receipt generation)
     * @return pipeline result with receipt and integrity info
     */
    public PipelineResult process(AuditEvent event, SyncMode syncMode) {
        Instant pipelineStart = clock.instant();

        // 1. VALIDATE
        String validationError = validate(event);
        if (validationError != null) {
            validationErrors.incrementAndGet();
            log.warn("Pipeline validation failed: eventId={}, reason={}",
                event != null ? event.eventId() : "null", validationError);
            return PipelineResult.rejected(
                event != null ? event.eventId() : "null", validationError);
        }

        String tenantId = event.resource().tenantId();
        String eventId = event.eventId();

        try {
            // 2. PII SANITIZE
            JsonNode sanitizedPayload = null;
            if (event.payload() != null) {
                sanitizedPayload = piiSanitizer.sanitizeCopy(event.payload());
            }

            // 3. HASH — compute canonical hash of event (with sanitized payload)
            AuditEvent sanitizedEvent = withSanitizedPayload(event, sanitizedPayload);
            byte[] eventHash = hashService.canonicalHash(sanitizedEvent);

            // 4. CHAIN LINK — extend the per-tenant hash chain
            HashChainManager.ChainLink link = chainManager.extendChain(tenantId, eventHash);

            // 5. Build integrity info
            IntegrityInfo integrity = new IntegrityInfo(
                hashService.toHexString(eventHash),
                hashService.toHexString(link.chainHash()),
                link.position(),
                hashService.toHexString(link.previousHash()),
                clock.instant()
            );

            // Attach integrity to event
            AuditEvent finalEvent = withIntegrity(sanitizedEvent, integrity);

            // 6. STORE
            eventStore.store(finalEvent);

            processedCount.incrementAndGet();
            long processingTimeMs = clock.instant().toEpochMilli() - pipelineStart.toEpochMilli();

            log.debug("Pipeline processed: eventId={}, tenant={}, chain={}, time={}ms",
                eventId, tenantId, link.position(), processingTimeMs);

            // 7. RECEIPT
            AuditReceipt receipt;
            if (syncMode == SyncMode.SYNC) {
                receipt = AuditReceipt.committed(eventId,
                    integrity.eventHash(), link.position(), 0);
            } else {
                receipt = AuditReceipt.accepted(eventId, 0);
            }

            return PipelineResult.success(eventId, receipt, integrity, processingTimeMs);

        } catch (Exception e) {
            if (isChainError(e)) {
                chainErrors.incrementAndGet();
                log.error("CRITICAL: Hash chain error for tenant '{}': {}",
                    tenantId, e.getMessage(), e);
            } else {
                storeErrors.incrementAndGet();
                log.error("Pipeline store error: eventId={}, error={}",
                    eventId, e.getMessage(), e);
            }
            return PipelineResult.failed(eventId, e.getMessage());
        }
    }

    // ── Validation ───────────────────────────────────────────

    private String validate(AuditEvent event) {
        if (event == null) return "Event is null";
        if (event.eventId() == null) return "eventId is null";
        if (event.eventType() == null) return "eventType is null";
        if (event.resource() == null) return "resource is null";
        if (event.resource().tenantId() == null) return "tenantId is null";
        if (event.actor() == null) return "actor is null";

        // Timestamp bounds check (reject events more than 5 minutes in the future)
        if (event.timestamp() != null) {
            Instant fiveMinFuture = clock.instant().plusSeconds(300);
            if (event.timestamp().isAfter(fiveMinFuture)) {
                return "Timestamp is more than 5 minutes in the future";
            }
        }
        return null;
    }

    // ── Helpers ──────────────────────────────────────────────

    private AuditEvent withSanitizedPayload(AuditEvent event, JsonNode sanitizedPayload) {
        return new AuditEvent(
            event.eventId(), event.eventType(), event.category(), event.result(),
            event.timestamp(), event.actor(), event.resource(), event.sourceModule(),
            event.correlationId(), event.causationId(), event.traceId(), event.spanId(),
            event.syncMode(), sanitizedPayload, event.tags(), event.integrity()
        );
    }

    private AuditEvent withIntegrity(AuditEvent event, IntegrityInfo integrity) {
        return new AuditEvent(
            event.eventId(), event.eventType(), event.category(), event.result(),
            event.timestamp(), event.actor(), event.resource(), event.sourceModule(),
            event.correlationId(), event.causationId(), event.traceId(), event.spanId(),
            event.syncMode(), event.payload(), event.tags(), integrity
        );
    }

    private boolean isChainError(Exception e) {
        return e.getMessage() != null && (
            e.getMessage().contains("chain") || e.getMessage().contains("Chain"));
    }

    // ── Metrics ──────────────────────────────────────────────

    public long getProcessedCount() { return processedCount.get(); }
    public long getValidationErrors() { return validationErrors.get(); }
    public long getStoreErrors() { return storeErrors.get(); }
    public long getChainErrors() { return chainErrors.get(); }

    /**
     * Result of pipeline processing.
     */
    public record PipelineResult(
        String eventId,
        Status status,
        AuditReceipt receipt,
        IntegrityInfo integrity,
        long processingTimeMs,
        String failureReason
    ) {
        public enum Status { SUCCESS, REJECTED, FAILED }

        public static PipelineResult success(String eventId, AuditReceipt receipt,
                                               IntegrityInfo integrity, long timeMs) {
            return new PipelineResult(eventId, Status.SUCCESS, receipt, integrity, timeMs, null);
        }
        public static PipelineResult rejected(String eventId, String reason) {
            return new PipelineResult(eventId, Status.REJECTED,
                AuditReceipt.rejected(eventId, reason), null, 0, reason);
        }
        public static PipelineResult failed(String eventId, String reason) {
            return new PipelineResult(eventId, Status.FAILED,
                AuditReceipt.failed(eventId, reason), null, 0, reason);
        }

        public boolean isSuccess() { return status == Status.SUCCESS; }
    }
}
