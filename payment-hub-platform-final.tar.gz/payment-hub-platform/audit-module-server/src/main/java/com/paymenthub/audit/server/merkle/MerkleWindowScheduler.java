package com.paymenthub.audit.server.merkle;

import com.paymenthub.crypto.hash.HashService;
import com.paymenthub.crypto.merkle.MerkleTreeBuilder;
import com.paymenthub.crypto.signing.AuditSigner;
import com.paymenthub.crypto.signing.AuditSigner.SignedBatch;
import com.paymenthub.time.clock.HubClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Tumbling window scheduler that collects event hashes, computes Merkle
 * roots, and triggers batch signing at fixed intervals.
 *
 * <h3>Window Lifecycle</h3>
 * <pre>
 * T=0min     T=10min    T=20min
 * ├──────────┤──────────┤──────────┤
 * │ Window 1 │ Window 2 │ Window 3 │
 * │ collect  │ collect  │ collect  │
 * │ hashes   │ hashes   │ hashes   │
 * └────┬─────┘────┬─────┘────┬─────┘
 *      ↓          ↓          ↓
 *   Merkle     Merkle     Merkle
 *   Root +     Root +     Root +
 *   Sign       Sign       Sign
 * </pre>
 *
 * <h3>Per-Tenant Windows</h3>
 * <p>Each tenant has an independent Merkle window. When a window closes,
 * the Merkle tree is computed from all event hashes in the window, the
 * root is signed, and the {@link WindowResult} is persisted.</p>
 *
 * <h3>Signing</h3>
 * <p>The Merkle root is signed using the {@link AuditSigner} (software
 * ECDSA-P384 for SMALL profile, HSM for MEDIUM/LARGE). The signed root
 * provides non-repudiation: proof that these events existed at this time.</p>
 *
 * <h3>Evidence Export</h3>
 * <p>Window results are the foundation of evidence packages. An auditor
 * can request the Merkle tree for any window, verify individual events
 * via inclusion proofs, and verify the root signature.</p>
 */
public class MerkleWindowScheduler implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(MerkleWindowScheduler.class);

    private final MerkleTreeBuilder merkleTreeBuilder;
    private final AuditSigner signer;
    private final HubClock clock;
    private final Duration windowDuration;
    private final ScheduledExecutorService scheduler;

    private final Map<String, TenantWindow> activeWindows = new ConcurrentHashMap<>();
    private final List<WindowResult> completedWindows = new CopyOnWriteArrayList<>();
    private final AtomicLong windowCounter = new AtomicLong(0);

    /**
     * @param merkleTreeBuilder for computing Merkle roots
     * @param signer            for signing roots
     * @param clock             monotonic clock
     * @param windowDuration    window interval (default: 10 minutes)
     */
    public MerkleWindowScheduler(MerkleTreeBuilder merkleTreeBuilder, AuditSigner signer,
                                   HubClock clock, Duration windowDuration) {
        this.merkleTreeBuilder = Objects.requireNonNull(merkleTreeBuilder);
        this.signer = Objects.requireNonNull(signer);
        this.clock = Objects.requireNonNull(clock);
        this.windowDuration = windowDuration != null ? windowDuration : Duration.ofMinutes(10);
        this.scheduler = Executors.newSingleThreadScheduledExecutor(
            r -> Thread.ofVirtual().name("merkle-scheduler").unstarted(r));
    }

    /**
     * Start the scheduler. Closes windows at fixed intervals.
     */
    public void start() {
        scheduler.scheduleAtFixedRate(this::closeAllWindows,
            windowDuration.toMillis(), windowDuration.toMillis(), TimeUnit.MILLISECONDS);
        log.info("Merkle window scheduler started: interval={}", windowDuration);
    }

    /**
     * Add an event hash to the current window for a tenant.
     *
     * @param tenantId  the tenant
     * @param eventHash the SHA3-256 hash of the event
     * @param eventId   the event ID (for proof generation)
     */
    public void addHash(String tenantId, byte[] eventHash, String eventId) {
        TenantWindow window = activeWindows.computeIfAbsent(tenantId,
            t -> new TenantWindow(t, clock.instant()));
        window.addHash(eventHash, eventId);
    }

    /**
     * Close all active windows, compute Merkle roots, and sign.
     */
    public void closeAllWindows() {
        if (activeWindows.isEmpty()) return;

        Instant closeTime = clock.instant();
        log.debug("Closing {} tenant Merkle windows", activeWindows.size());

        // Snapshot and replace active windows
        Map<String, TenantWindow> closingWindows = new HashMap<>(activeWindows);
        activeWindows.clear();

        for (Map.Entry<String, TenantWindow> entry : closingWindows.entrySet()) {
            try {
                WindowResult result = closeWindow(entry.getValue(), closeTime);
                completedWindows.add(result);
                log.info("Merkle window closed: tenant={}, events={}, root={}",
                    result.tenantId(), result.eventCount(),
                    result.merkleRootHex().substring(0, 16) + "...");
            } catch (Exception e) {
                log.error("Failed to close Merkle window for tenant '{}': {}",
                    entry.getKey(), e.getMessage(), e);
            }
        }
    }

    /**
     * Force-close a specific tenant's window (e.g., on tenant offboarding).
     */
    public Optional<WindowResult> closeWindowForTenant(String tenantId) {
        TenantWindow window = activeWindows.remove(tenantId);
        if (window == null) return Optional.empty();
        try {
            WindowResult result = closeWindow(window, clock.instant());
            completedWindows.add(result);
            return Optional.of(result);
        } catch (Exception e) {
            log.error("Failed to close window for tenant '{}': {}", tenantId, e.getMessage());
            return Optional.empty();
        }
    }

    // ── Internal ─────────────────────────────────────────────

    private WindowResult closeWindow(TenantWindow window, Instant closeTime) {
        List<byte[]> hashes = window.getHashes();
        List<String> eventIds = window.getEventIds();

        if (hashes.isEmpty()) {
            return new WindowResult(
                windowCounter.incrementAndGet(), window.tenantId,
                window.openedAt, closeTime, 0, null, null, null, eventIds
            );
        }

        // Compute Merkle root
        byte[] merkleRoot = merkleTreeBuilder.computeRoot(hashes);

        // Sign the root
        SignedBatch signedBatch = signer.sign(List.of(merkleRoot));

        return new WindowResult(
            windowCounter.incrementAndGet(),
            window.tenantId,
            window.openedAt,
            closeTime,
            hashes.size(),
            bytesToHex(merkleRoot),
            signedBatch.signature(),
            signedBatch.keyId(),
            eventIds
        );
    }

    @Override
    public void close() {
        closeAllWindows(); // flush any remaining windows
        scheduler.shutdown();
        try {
            if (!scheduler.awaitTermination(5, TimeUnit.SECONDS)) {
                scheduler.shutdownNow();
            }
        } catch (InterruptedException e) {
            scheduler.shutdownNow();
            Thread.currentThread().interrupt();
        }
        log.info("Merkle window scheduler stopped. Total windows: {}", windowCounter.get());
    }

    // ── Metrics ──────────────────────────────────────────────

    public int activeWindowCount() { return activeWindows.size(); }
    public long completedWindowCount() { return completedWindows.size(); }
    public List<WindowResult> getCompletedWindows() {
        return Collections.unmodifiableList(completedWindows);
    }
    public Duration getWindowDuration() { return windowDuration; }

    // ── Per-Tenant Window ────────────────────────────────────

    private static class TenantWindow {
        final String tenantId;
        final Instant openedAt;
        private final List<byte[]> hashes = new ArrayList<>();
        private final List<String> eventIds = new ArrayList<>();

        TenantWindow(String tenantId, Instant openedAt) {
            this.tenantId = tenantId;
            this.openedAt = openedAt;
        }

        synchronized void addHash(byte[] hash, String eventId) {
            hashes.add(hash);
            eventIds.add(eventId);
        }

        synchronized List<byte[]> getHashes() { return new ArrayList<>(hashes); }
        synchronized List<String> getEventIds() { return new ArrayList<>(eventIds); }
    }

    // ── Window Result ────────────────────────────────────────

    /**
     * Result of a closed Merkle window.
     */
    public record WindowResult(
        long windowId,
        String tenantId,
        Instant windowStart,
        Instant windowEnd,
        int eventCount,
        String merkleRootHex,
        byte[] signature,
        String signingKeyId,
        List<String> eventIds
    ) {}

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
