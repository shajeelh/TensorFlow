package com.paymenthub.audit.server.store;

import com.paymenthub.common.model.AuditEvent;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/**
 * Store for persisted audit events.
 *
 * <p>Implementations:</p>
 * <ul>
 *   <li>{@link InMemoryAuditEventStore} — for dev/test</li>
 *   <li>{@code OpenSearchAuditEventStore} — production primary store.
 *       Events indexed by tenant_id, event_type, timestamp, correlation_id.
 *       Index pattern: {@code audit-events-{tenant_id}-{yyyy.MM}}</li>
 *   <li>{@code PostgresAuditEventStore} — fallback relational store.
 *       Used when OpenSearch is unavailable or for compliance requirements
 *       mandating relational storage.</li>
 * </ul>
 */
public interface AuditEventStore {

    /**
     * Store a single processed audit event.
     */
    void store(AuditEvent event);

    /**
     * Store a batch of events (for bulk indexing).
     */
    void storeBatch(List<AuditEvent> events);

    /**
     * Query events by tenant and time range.
     */
    List<AuditEvent> findByTenantAndTimeRange(String tenantId, Instant from, Instant to, int limit);

    /**
     * Find a single event by ID and tenant.
     */
    Optional<AuditEvent> findByEventId(String tenantId, String eventId);

    /**
     * Find events by correlation ID (trace a distributed transaction).
     */
    List<AuditEvent> findByCorrelationId(String tenantId, UUID correlationId);

    /**
     * Count events for a tenant in a time range.
     */
    long countByTenantAndTimeRange(String tenantId, Instant from, Instant to);

    /**
     * Check if the store is healthy.
     */
    boolean isHealthy();

    /**
     * Get the store type identifier.
     */
    String storeType();

    // ══════════════════════════════════════════════════════════
    // In-Memory Implementation
    // ══════════════════════════════════════════════════════════

    /**
     * In-memory event store for development and testing.
     */
    class InMemoryAuditEventStore implements AuditEventStore {

        private final Map<String, List<AuditEvent>> tenantEvents = new ConcurrentHashMap<>();
        private final Map<String, AuditEvent> eventIndex = new ConcurrentHashMap<>();

        @Override
        public void store(AuditEvent event) {
            Objects.requireNonNull(event, "Event required");
            String tenantId = event.resource().tenantId();
            tenantEvents.computeIfAbsent(tenantId, k -> new CopyOnWriteArrayList<>()).add(event);
            eventIndex.put(tenantId + ":" + event.eventId(), event);
        }

        @Override
        public void storeBatch(List<AuditEvent> events) {
            events.forEach(this::store);
        }

        @Override
        public List<AuditEvent> findByTenantAndTimeRange(String tenantId, Instant from,
                                                            Instant to, int limit) {
            List<AuditEvent> events = tenantEvents.getOrDefault(tenantId, List.of());
            return events.stream()
                .filter(e -> !e.timestamp().isBefore(from) && !e.timestamp().isAfter(to))
                .sorted(Comparator.comparing(AuditEvent::timestamp).reversed())
                .limit(limit)
                .collect(Collectors.toList());
        }

        @Override
        public Optional<AuditEvent> findByEventId(String tenantId, String eventId) {
            return Optional.ofNullable(eventIndex.get(tenantId + ":" + eventId));
        }

        @Override
        public List<AuditEvent> findByCorrelationId(String tenantId, UUID correlationId) {
            List<AuditEvent> events = tenantEvents.getOrDefault(tenantId, List.of());
            return events.stream()
                .filter(e -> correlationId.equals(e.correlationId()))
                .sorted(Comparator.comparing(AuditEvent::timestamp))
                .collect(Collectors.toList());
        }

        @Override
        public long countByTenantAndTimeRange(String tenantId, Instant from, Instant to) {
            return findByTenantAndTimeRange(tenantId, from, to, Integer.MAX_VALUE).size();
        }

        @Override
        public boolean isHealthy() { return true; }

        @Override
        public String storeType() { return "in_memory"; }

        /** Get total event count across all tenants. */
        public long totalEventCount() { return eventIndex.size(); }

        /** Get event count for a specific tenant. */
        public int eventCountForTenant(String tenantId) {
            return tenantEvents.getOrDefault(tenantId, List.of()).size();
        }

        /** Get all events for a tenant (for testing). */
        public List<AuditEvent> getAllForTenant(String tenantId) {
            return List.copyOf(tenantEvents.getOrDefault(tenantId, List.of()));
        }

        /** Clear all events. */
        public void clear() {
            tenantEvents.clear();
            eventIndex.clear();
        }
    }
}
