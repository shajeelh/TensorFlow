package com.paymenthub.audit.server.health;

import com.paymenthub.audit.server.chain.HashChainManager;
import com.paymenthub.audit.server.merkle.MerkleWindowScheduler;
import com.paymenthub.audit.server.pipeline.AuditPipeline;
import com.paymenthub.audit.server.store.AuditEventStore;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

/**
 * Comprehensive health indicator for the audit module.
 *
 * <p>Reports:</p>
 * <ul>
 *   <li>Pipeline stats (processed, errors)</li>
 *   <li>Event store connectivity</li>
 *   <li>Hash chain integrity (error count)</li>
 *   <li>Merkle window status</li>
 * </ul>
 *
 * <p>Status is DOWN if:</p>
 * <ul>
 *   <li>Event store is unhealthy</li>
 *   <li>Chain errors &gt; 0 (indicates tampering or corruption)</li>
 * </ul>
 */
public class AuditHealthIndicator implements HealthIndicator {

    private final AuditPipeline pipeline;
    private final AuditEventStore eventStore;
    private final HashChainManager chainManager;
    private final MerkleWindowScheduler windowScheduler;

    public AuditHealthIndicator(AuditPipeline pipeline, AuditEventStore eventStore,
                                  HashChainManager chainManager,
                                  MerkleWindowScheduler windowScheduler) {
        this.pipeline = pipeline;
        this.eventStore = eventStore;
        this.chainManager = chainManager;
        this.windowScheduler = windowScheduler;
    }

    @Override
    public Health health() {
        boolean storeHealthy = eventStore.isHealthy();
        long chainErrors = pipeline.getChainErrors();

        Health.Builder builder;
        if (!storeHealthy) {
            builder = Health.down().withDetail("reason", "Event store unhealthy");
        } else if (chainErrors > 0) {
            builder = Health.down().withDetail("reason", "Hash chain errors detected: " + chainErrors);
        } else {
            builder = Health.up();
        }

        return builder
            .withDetail("storeType", eventStore.storeType())
            .withDetail("storeHealthy", storeHealthy)
            .withDetail("pipelineProcessed", pipeline.getProcessedCount())
            .withDetail("pipelineValidationErrors", pipeline.getValidationErrors())
            .withDetail("pipelineStoreErrors", pipeline.getStoreErrors())
            .withDetail("pipelineChainErrors", chainErrors)
            .withDetail("activeTenants", chainManager.activeTenantCount())
            .withDetail("activeMerkleWindows", windowScheduler.activeWindowCount())
            .withDetail("completedMerkleWindows", windowScheduler.completedWindowCount())
            .build();
    }
}
