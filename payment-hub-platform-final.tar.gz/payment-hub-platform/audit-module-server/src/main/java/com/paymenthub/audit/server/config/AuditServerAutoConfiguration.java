package com.paymenthub.audit.server.config;

import com.paymenthub.audit.server.archive.S3WormArchiver;
import com.paymenthub.audit.server.chain.HashChainManager;
import com.paymenthub.audit.server.evidence.EvidenceExporter;
import com.paymenthub.audit.server.grpc.AuditGrpcService;
import com.paymenthub.audit.server.health.AuditHealthIndicator;
import com.paymenthub.audit.server.merkle.MerkleWindowScheduler;
import com.paymenthub.audit.server.pipeline.AuditPipeline;
import com.paymenthub.audit.server.store.AuditEventStore;
import com.paymenthub.crypto.hash.HashService;
import com.paymenthub.crypto.merkle.MerkleTreeBuilder;
import com.paymenthub.crypto.signing.AuditSigner;
import com.paymenthub.pii.PiiJsonSanitizer;
import com.paymenthub.security.rbac.PermissionEvaluator;
import com.paymenthub.time.clock.HubClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

import java.time.Duration;

@AutoConfiguration
@EnableConfigurationProperties(AuditServerAutoConfiguration.AuditServerProperties.class)
public class AuditServerAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(AuditServerAutoConfiguration.class);

    @Bean @ConditionalOnMissingBean
    public HashChainManager hashChainManager(HashService hashService) {
        return new HashChainManager(hashService);
    }

    @Bean @ConditionalOnMissingBean
    public AuditEventStore auditEventStore() {
        log.warn("Using InMemoryAuditEventStore — not suitable for production");
        return new AuditEventStore.InMemoryAuditEventStore();
    }

    @Bean @ConditionalOnMissingBean
    public AuditPipeline auditPipeline(HashService hashService, HashChainManager chainManager,
                                         PiiJsonSanitizer piiSanitizer, AuditEventStore store,
                                         HubClock clock) {
        log.info("Audit processing pipeline configured");
        return new AuditPipeline(hashService, chainManager, piiSanitizer, store, clock);
    }

    @Bean(initMethod = "start", destroyMethod = "close")
    @ConditionalOnMissingBean
    public MerkleWindowScheduler merkleWindowScheduler(MerkleTreeBuilder treeBuilder,
                                                         AuditSigner signer, HubClock clock,
                                                         AuditServerProperties props) {
        log.info("Merkle window scheduler: interval={}min", props.getMerkleWindowMinutes());
        return new MerkleWindowScheduler(treeBuilder, signer, clock,
            Duration.ofMinutes(props.getMerkleWindowMinutes()));
    }

    @Bean(initMethod = "start", destroyMethod = "close")
    @ConditionalOnMissingBean
    public S3WormArchiver s3WormArchiver(HubClock clock, AuditServerProperties props) {
        log.info("S3 WORM archiver: bucket={}, batchSize={}", props.getS3Bucket(), props.getArchiveBatchSize());
        return new S3WormArchiver(props.getS3Bucket(), props.getArchiveBatchSize(),
            Duration.ofMinutes(props.getArchiveMaxAgeMinutes()),
            Duration.ofDays(props.getRetentionDays()), clock);
    }

    @Bean @ConditionalOnMissingBean
    public EvidenceExporter evidenceExporter(AuditEventStore store, HashChainManager chain,
                                               MerkleWindowScheduler windowScheduler,
                                               MerkleTreeBuilder treeBuilder, HubClock clock) {
        return new EvidenceExporter(store, chain, windowScheduler, treeBuilder, clock);
    }

    @Bean @ConditionalOnMissingBean
    public AuditGrpcService auditGrpcService(AuditEventStore store, HashChainManager chain,
                                                EvidenceExporter exporter, AuditPipeline pipeline,
                                                PermissionEvaluator evaluator) {
        return new AuditGrpcService(store, chain, exporter, pipeline, evaluator);
    }

    @Bean @ConditionalOnMissingBean
    public AuditHealthIndicator auditHealthIndicator(AuditPipeline pipeline, AuditEventStore store,
                                                       HashChainManager chain,
                                                       MerkleWindowScheduler windowScheduler) {
        return new AuditHealthIndicator(pipeline, store, chain, windowScheduler);
    }

    @ConfigurationProperties(prefix = "hub.audit.server")
    public static class AuditServerProperties {
        private int merkleWindowMinutes = 10;
        private String s3Bucket = "audit-archive-dev";
        private int archiveBatchSize = 1000;
        private int archiveMaxAgeMinutes = 5;
        private int retentionDays = 2555; // ~7 years

        public int getMerkleWindowMinutes() { return merkleWindowMinutes; }
        public void setMerkleWindowMinutes(int v) { this.merkleWindowMinutes = v; }
        public String getS3Bucket() { return s3Bucket; }
        public void setS3Bucket(String v) { this.s3Bucket = v; }
        public int getArchiveBatchSize() { return archiveBatchSize; }
        public void setArchiveBatchSize(int v) { this.archiveBatchSize = v; }
        public int getArchiveMaxAgeMinutes() { return archiveMaxAgeMinutes; }
        public void setArchiveMaxAgeMinutes(int v) { this.archiveMaxAgeMinutes = v; }
        public int getRetentionDays() { return retentionDays; }
        public void setRetentionDays(int v) { this.retentionDays = v; }
    }
}
