package com.paymenthub.audit.server.chain;

import com.paymenthub.crypto.hash.HashService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Per-tenant backward-linked hash chain manager.
 *
 * <h3>Hash Chain Structure</h3>
 * <pre>
 * Genesis:  chainHash₀ = SHA3-256(0x00...00 || eventHash₀)
 * Link N:   chainHashₙ = SHA3-256(chainHashₙ₋₁ || eventHashₙ)
 * </pre>
 *
 * <p>Each tenant maintains an independent hash chain. The chain provides
 * tamper evidence: modifying or removing any event breaks the chain from
 * that point forward, detectable by verification.</p>
 *
 * <h3>Chain State</h3>
 * <p>The latest chain hash and position for each tenant are kept in memory
 * and persisted to the audit store. On startup, the chain state is loaded
 * from the last committed event for each active tenant.</p>
 *
 * <h3>Concurrency</h3>
 * <p>Chain extension is synchronized per-tenant to maintain strict ordering.
 * Different tenants extend their chains concurrently without contention.</p>
 *
 * <h3>Verification</h3>
 * <p>The chain can be verified by replaying all events for a tenant and
 * recomputing each chain hash. The final hash must match the stored chain
 * tip. Any discrepancy indicates tampering.</p>
 */
public class HashChainManager {

    private static final Logger log = LoggerFactory.getLogger(HashChainManager.class);

    private final HashService hashService;
    private final Map<String, ChainState> chains = new ConcurrentHashMap<>();

    public HashChainManager(HashService hashService) {
        this.hashService = Objects.requireNonNull(hashService);
    }

    /**
     * Extend the hash chain for a tenant.
     *
     * @param tenantId  the tenant whose chain to extend
     * @param eventHash the SHA3-256 hash of the new event
     * @return the chain link containing the new chain hash and position
     */
    public ChainLink extendChain(String tenantId, byte[] eventHash) {
        Objects.requireNonNull(tenantId, "tenantId required");
        Objects.requireNonNull(eventHash, "eventHash required");

        ChainState state = chains.computeIfAbsent(tenantId, t -> {
            log.info("Initializing hash chain for tenant '{}'", t);
            return new ChainState();
        });

        // Synchronize per-tenant (different tenants are independent)
        synchronized (state) {
            byte[] previousHash = state.currentHash;
            long newPosition = state.position + 1;

            // Compute chain hash: SHA3-256(previousHash || eventHash)
            byte[] chainHash;
            if (previousHash == null) {
                // Genesis: previous is all zeros
                chainHash = hashService.genesisHash(eventHash);
                log.info("Genesis chain link for tenant '{}': position=1", tenantId);
            } else {
                chainHash = hashService.chainHash(previousHash, eventHash);
            }

            // Update state
            state.currentHash = chainHash;
            state.position = newPosition;

            byte[] prevForLink = previousHash != null
                ? previousHash
                : new byte[hashService.getDigestLength()]; // all zeros for genesis

            return new ChainLink(chainHash, prevForLink, eventHash, newPosition, tenantId);
        }
    }

    /**
     * Get the current chain state for a tenant.
     *
     * @return chain state, or null if no events for this tenant
     */
    public ChainState getChainState(String tenantId) {
        return chains.get(tenantId);
    }

    /**
     * Get the current chain position (event count) for a tenant.
     */
    public long getChainPosition(String tenantId) {
        ChainState state = chains.get(tenantId);
        return state != null ? state.position : 0;
    }

    /**
     * Get the current chain tip hash for a tenant.
     */
    public byte[] getChainTip(String tenantId) {
        ChainState state = chains.get(tenantId);
        return state != null ? state.currentHash : null;
    }

    /**
     * Load chain state from persisted storage (called on startup).
     *
     * @param tenantId      the tenant
     * @param lastChainHash the last committed chain hash
     * @param position      the last committed chain position
     */
    public void loadChainState(String tenantId, byte[] lastChainHash, long position) {
        ChainState state = new ChainState();
        state.currentHash = lastChainHash;
        state.position = position;
        chains.put(tenantId, state);
        log.info("Loaded chain state for tenant '{}': position={}", tenantId, position);
    }

    /**
     * Verify a single chain link.
     *
     * @param previousHash the hash from the previous link
     * @param eventHash    the event hash
     * @param expectedChainHash the expected chain hash to verify
     * @return true if the chain link is valid
     */
    public boolean verifyLink(byte[] previousHash, byte[] eventHash, byte[] expectedChainHash) {
        return hashService.verifyChainLink(previousHash, eventHash, expectedChainHash);
    }

    /**
     * Get the number of active tenant chains.
     */
    public int activeTenantCount() { return chains.size(); }

    // ── Chain State ──────────────────────────────────────────

    /**
     * Mutable chain state for a tenant. Synchronized externally.
     */
    public static class ChainState {
        byte[] currentHash;
        long position;

        public byte[] getCurrentHash() { return currentHash; }
        public long getPosition() { return position; }
    }

    /**
     * Immutable record of a single chain extension.
     */
    public record ChainLink(
        byte[] chainHash,
        byte[] previousHash,
        byte[] eventHash,
        long position,
        String tenantId
    ) {}
}
