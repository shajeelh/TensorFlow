package com.paymenthub.audit.server.merkle;

import com.paymenthub.crypto.hash.ThreadLocalHashService;
import com.paymenthub.crypto.merkle.MerkleTreeBuilder;
import com.paymenthub.crypto.signing.SoftwareAuditSigner;
import com.paymenthub.time.clock.HubClock;
import org.junit.jupiter.api.*;

import java.nio.charset.StandardCharsets;
import java.time.Duration;

import static org.assertj.core.api.Assertions.*;

class MerkleWindowSchedulerTest {

    private MerkleWindowScheduler scheduler;
    private ThreadLocalHashService hashService;

    @BeforeEach
    void setUp() throws Exception {
        hashService = new ThreadLocalHashService();
        var treeBuilder = new MerkleTreeBuilder(hashService);
        var signer = new SoftwareAuditSigner();
        var clock = new HubClock("test-merkle");
        scheduler = new MerkleWindowScheduler(treeBuilder, signer, clock, Duration.ofHours(1));
    }

    @AfterEach
    void tearDown() { scheduler.close(); }

    private byte[] hash(String data) {
        return hashService.hash(data.getBytes(StandardCharsets.UTF_8));
    }

    @Test
    @DisplayName("Add hashes and close window produces result")
    void addAndClose() {
        scheduler.addHash("T1", hash("e1"), "e1");
        scheduler.addHash("T1", hash("e2"), "e2");
        scheduler.addHash("T1", hash("e3"), "e3");

        scheduler.closeAllWindows();

        assertThat(scheduler.completedWindowCount()).isEqualTo(1);
        var result = scheduler.getCompletedWindows().getFirst();
        assertThat(result.tenantId()).isEqualTo("T1");
        assertThat(result.eventCount()).isEqualTo(3);
        assertThat(result.merkleRootHex()).isNotBlank();
        assertThat(result.signature()).isNotNull();
        assertThat(result.signingKeyId()).isNotBlank();
        assertThat(result.eventIds()).containsExactly("e1", "e2", "e3");
    }

    @Test
    @DisplayName("Multiple tenants produce independent windows")
    void multiTenant() {
        scheduler.addHash("T1", hash("e1"), "e1");
        scheduler.addHash("T2", hash("e2"), "e2");
        scheduler.addHash("T2", hash("e3"), "e3");

        scheduler.closeAllWindows();

        assertThat(scheduler.completedWindowCount()).isEqualTo(2);
    }

    @Test
    @DisplayName("Close empties active windows")
    void closeClearsActive() {
        scheduler.addHash("T1", hash("e1"), "e1");
        assertThat(scheduler.activeWindowCount()).isEqualTo(1);

        scheduler.closeAllWindows();
        assertThat(scheduler.activeWindowCount()).isZero();
    }

    @Test
    @DisplayName("Close with no active windows is safe")
    void closeEmpty() {
        assertThatCode(scheduler::closeAllWindows).doesNotThrowAnyException();
        assertThat(scheduler.completedWindowCount()).isZero();
    }

    @Test
    @DisplayName("Force-close specific tenant window")
    void forceCloseTenant() {
        scheduler.addHash("T1", hash("e1"), "e1");
        scheduler.addHash("T2", hash("e2"), "e2");

        var result = scheduler.closeWindowForTenant("T1");
        assertThat(result).isPresent();
        assertThat(result.get().tenantId()).isEqualTo("T1");
        assertThat(scheduler.activeWindowCount()).isEqualTo(1); // T2 still open
    }
}
