package com.paymenthub.audit.server.store;

import com.paymenthub.audit.builder.AuditEventBuilder;
import com.paymenthub.common.enums.*;
import com.paymenthub.common.model.AuditEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.*;

class InMemoryAuditEventStoreTest {

    private AuditEventStore.InMemoryAuditEventStore store;

    @BeforeEach
    void setUp() { store = new AuditEventStore.InMemoryAuditEventStore(); }

    private AuditEvent event(String id, String tenantId, Instant ts) {
        return AuditEventBuilder.create("test.event")
            .eventId(id).tenantId(tenantId).timestamp(ts)
            .actor("u", ActorType.USER).resource("r", id)
            .build();
    }

    @Test
    @DisplayName("Store and retrieve by event ID")
    void storeAndRetrieve() {
        var e = event("e1", "T1", Instant.now());
        store.store(e);
        assertThat(store.findByEventId("T1", "e1")).isPresent();
        assertThat(store.findByEventId("T1", "missing")).isEmpty();
    }

    @Test
    @DisplayName("Query by time range")
    void timeRange() {
        Instant base = Instant.parse("2025-01-15T10:00:00Z");
        store.store(event("e1", "T1", base.plusSeconds(60)));
        store.store(event("e2", "T1", base.plusSeconds(120)));
        store.store(event("e3", "T1", base.plusSeconds(300)));

        var results = store.findByTenantAndTimeRange("T1",
            base, base.plusSeconds(180), 10);
        assertThat(results).hasSize(2);
    }

    @Test
    @DisplayName("Count by time range")
    void count() {
        Instant base = Instant.now();
        store.store(event("e1", "T1", base));
        store.store(event("e2", "T1", base.plusSeconds(1)));
        store.store(event("e3", "T2", base));

        assertThat(store.countByTenantAndTimeRange("T1",
            base.minusSeconds(1), base.plusSeconds(2))).isEqualTo(2);
    }

    @Test
    @DisplayName("Find by correlation ID")
    void correlation() {
        UUID corrId = UUID.randomUUID();
        var e1 = AuditEventBuilder.create("test").tenantId("T1")
            .actor("u", ActorType.USER).resource("r", "1")
            .correlationId(corrId).build();
        var e2 = AuditEventBuilder.create("test").tenantId("T1")
            .actor("u", ActorType.USER).resource("r", "2")
            .correlationId(corrId).build();
        store.store(e1);
        store.store(e2);

        assertThat(store.findByCorrelationId("T1", corrId)).hasSize(2);
    }

    @Test
    @DisplayName("Tenant isolation in queries")
    void tenantIsolation() {
        Instant now = Instant.now();
        store.store(event("e1", "T1", now));
        store.store(event("e2", "T2", now));

        assertThat(store.eventCountForTenant("T1")).isEqualTo(1);
        assertThat(store.eventCountForTenant("T2")).isEqualTo(1);
        assertThat(store.findByEventId("T2", "e1")).isEmpty();
    }

    @Test
    @DisplayName("Batch store")
    void batchStore() {
        Instant now = Instant.now();
        store.storeBatch(List.of(event("e1", "T1", now), event("e2", "T1", now)));
        assertThat(store.totalEventCount()).isEqualTo(2);
    }

    @Test
    @DisplayName("Clear removes everything")
    void clear() {
        store.store(event("e1", "T1", Instant.now()));
        store.clear();
        assertThat(store.totalEventCount()).isZero();
    }
}
