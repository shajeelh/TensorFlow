package com.paymenthub.audit.server.chain;

import com.paymenthub.crypto.hash.ThreadLocalHashService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;

import static org.assertj.core.api.Assertions.*;

class HashChainManagerTest {

    private HashChainManager chainManager;
    private ThreadLocalHashService hashService;

    @BeforeEach
    void setUp() {
        hashService = new ThreadLocalHashService();
        chainManager = new HashChainManager(hashService);
    }

    private byte[] hash(String data) {
        return hashService.hash(data.getBytes(StandardCharsets.UTF_8));
    }

    @Test
    @DisplayName("Genesis link initializes chain at position 1")
    void genesisLink() {
        var link = chainManager.extendChain("T1", hash("event-1"));
        assertThat(link.position()).isEqualTo(1);
        assertThat(link.chainHash()).isNotNull();
        assertThat(link.previousHash()).isNotNull(); // zeros
        assertThat(link.tenantId()).isEqualTo("T1");
    }

    @Test
    @DisplayName("Chain grows with each extension")
    void chainGrows() {
        chainManager.extendChain("T1", hash("e1"));
        chainManager.extendChain("T1", hash("e2"));
        var link3 = chainManager.extendChain("T1", hash("e3"));

        assertThat(link3.position()).isEqualTo(3);
        assertThat(chainManager.getChainPosition("T1")).isEqualTo(3);
    }

    @Test
    @DisplayName("Each chain hash is unique")
    void uniqueChainHashes() {
        var link1 = chainManager.extendChain("T1", hash("e1"));
        var link2 = chainManager.extendChain("T1", hash("e2"));

        assertThat(link1.chainHash()).isNotEqualTo(link2.chainHash());
    }

    @Test
    @DisplayName("Link N references chain hash of link N-1")
    void backwardLink() {
        var link1 = chainManager.extendChain("T1", hash("e1"));
        var link2 = chainManager.extendChain("T1", hash("e2"));

        assertThat(link2.previousHash()).isEqualTo(link1.chainHash());
    }

    @Test
    @DisplayName("Tenants have independent chains")
    void tenantIsolation() {
        chainManager.extendChain("T1", hash("e1"));
        chainManager.extendChain("T1", hash("e2"));
        chainManager.extendChain("T2", hash("e1"));

        assertThat(chainManager.getChainPosition("T1")).isEqualTo(2);
        assertThat(chainManager.getChainPosition("T2")).isEqualTo(1);
        assertThat(chainManager.activeTenantCount()).isEqualTo(2);
    }

    @Test
    @DisplayName("Same event hash at same position produces same chain hash (deterministic)")
    void deterministic() {
        var chain1 = new HashChainManager(hashService);
        var chain2 = new HashChainManager(hashService);

        byte[] eventHash = hash("identical-event");
        var link1 = chain1.extendChain("T1", eventHash);
        var link2 = chain2.extendChain("T1", eventHash);

        assertThat(link1.chainHash()).isEqualTo(link2.chainHash());
    }

    @Test
    @DisplayName("Chain tip tracks latest hash")
    void chainTip() {
        assertThat(chainManager.getChainTip("T1")).isNull();

        var link1 = chainManager.extendChain("T1", hash("e1"));
        assertThat(chainManager.getChainTip("T1")).isEqualTo(link1.chainHash());

        var link2 = chainManager.extendChain("T1", hash("e2"));
        assertThat(chainManager.getChainTip("T1")).isEqualTo(link2.chainHash());
    }

    @Test
    @DisplayName("loadChainState restores chain for startup recovery")
    void loadState() {
        byte[] savedHash = hash("saved-chain-tip");
        chainManager.loadChainState("T1", savedHash, 42);

        assertThat(chainManager.getChainPosition("T1")).isEqualTo(42);
        assertThat(chainManager.getChainTip("T1")).isEqualTo(savedHash);

        // Next extension continues from position 43
        var link = chainManager.extendChain("T1", hash("next"));
        assertThat(link.position()).isEqualTo(43);
        assertThat(link.previousHash()).isEqualTo(savedHash);
    }

    @Test
    @DisplayName("verifyLink confirms valid chain hash computation")
    void verifyLink() {
        var link1 = chainManager.extendChain("T1", hash("e1"));
        var link2 = chainManager.extendChain("T1", hash("e2"));

        boolean valid = chainManager.verifyLink(
            link1.chainHash(), link2.eventHash(), link2.chainHash());
        assertThat(valid).isTrue();

        // Tampered hash should fail
        boolean tampered = chainManager.verifyLink(
            hash("wrong"), link2.eventHash(), link2.chainHash());
        assertThat(tampered).isFalse();
    }
}
