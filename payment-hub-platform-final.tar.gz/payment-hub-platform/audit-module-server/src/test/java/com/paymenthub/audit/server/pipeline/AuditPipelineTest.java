package com.paymenthub.audit.server.pipeline;

import com.paymenthub.audit.builder.AuditEventBuilder;
import com.paymenthub.audit.server.chain.HashChainManager;
import com.paymenthub.audit.server.store.AuditEventStore;
import com.paymenthub.common.enums.*;
import com.paymenthub.common.model.AuditEvent;
import com.paymenthub.crypto.hash.ThreadLocalHashService;
import com.paymenthub.pii.PiiJsonSanitizer;
import com.paymenthub.pii.PiiMasker;
import com.paymenthub.pii.PiiScanner;
import com.paymenthub.time.clock.HubClock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

class AuditPipelineTest {

    private AuditPipeline pipeline;
    private AuditEventStore.InMemoryAuditEventStore store;
    private HashChainManager chainManager;
    private ThreadLocalHashService hashService;

    @BeforeEach
    void setUp() {
        hashService = new ThreadLocalHashService();
        chainManager = new HashChainManager(hashService);
        store = new AuditEventStore.InMemoryAuditEventStore();
        var scanner = new PiiScanner(true);
        var masker = new PiiMasker();
        var sanitizer = new PiiJsonSanitizer(scanner, masker);
        var clock = new HubClock("test-pipeline");
        pipeline = new AuditPipeline(hashService, chainManager, sanitizer, store, clock);
    }

    private AuditEvent testEvent(String id, String tenantId) {
        return AuditEventBuilder.create("payment.transfer_completed")
            .eventId(id)
            .category(EventCategory.BUSINESS)
            .result(ActionResult.SUCCESS)
            .actor("tester", ActorType.USER)
            .resource("payment", "PAY-" + id)
            .tenantId(tenantId)
            .payload("amount", 50000)
            .payload("currency", "USD")
            .build();
    }

    @Nested
    @DisplayName("Successful processing")
    class SuccessPath {

        @Test
        @DisplayName("Single event passes through full pipeline")
        void singleEvent() {
            var result = pipeline.process(testEvent("e1", "MB-001"), SyncMode.ASYNC);

            assertThat(result.isSuccess()).isTrue();
            assertThat(result.status()).isEqualTo(AuditPipeline.PipelineResult.Status.SUCCESS);
            assertThat(result.integrity()).isNotNull();
            assertThat(result.integrity().eventHash()).isNotBlank();
            assertThat(result.integrity().chainHash()).isNotBlank();
            assertThat(result.integrity().chainPosition()).isEqualTo(1);
            assertThat(result.receipt().isSuccess()).isTrue();
            assertThat(result.processingTimeMs()).isGreaterThanOrEqualTo(0);
        }

        @Test
        @DisplayName("Event is stored after processing")
        void eventStored() {
            pipeline.process(testEvent("e1", "MB-001"), SyncMode.ASYNC);

            assertThat(store.eventCountForTenant("MB-001")).isEqualTo(1);
            var stored = store.findByEventId("MB-001", "e1");
            assertThat(stored).isPresent();
            assertThat(stored.get().integrity()).isNotNull();
        }

        @Test
        @DisplayName("Chain position increments with each event")
        void chainGrows() {
            pipeline.process(testEvent("e1", "MB-001"), SyncMode.ASYNC);
            pipeline.process(testEvent("e2", "MB-001"), SyncMode.ASYNC);
            pipeline.process(testEvent("e3", "MB-001"), SyncMode.ASYNC);

            assertThat(chainManager.getChainPosition("MB-001")).isEqualTo(3);
        }

        @Test
        @DisplayName("Different tenants have independent chains")
        void independentChains() {
            pipeline.process(testEvent("e1", "MB-001"), SyncMode.ASYNC);
            pipeline.process(testEvent("e2", "MB-001"), SyncMode.ASYNC);
            pipeline.process(testEvent("e1", "RB-002"), SyncMode.ASYNC);

            assertThat(chainManager.getChainPosition("MB-001")).isEqualTo(2);
            assertThat(chainManager.getChainPosition("RB-002")).isEqualTo(1);
        }

        @Test
        @DisplayName("SYNC mode returns COMMITTED receipt")
        void syncReceipt() {
            var result = pipeline.process(testEvent("e1", "MB-001"), SyncMode.SYNC);
            assertThat(result.receipt().status())
                .isEqualTo(com.paymenthub.audit.receipt.AuditReceipt.Status.COMMITTED);
        }
    }

    @Nested
    @DisplayName("PII sanitization")
    class PiiHandling {

        @Test
        @DisplayName("PII in payload is masked before storage")
        void piiMasked() {
            AuditEvent event = AuditEventBuilder.create("payment.completed")
                .tenantId("MB-001")
                .actor("user", ActorType.USER)
                .resource("payment", "p1")
                .payload("email", "jane@megabank.com")
                .payload("amount", 50000)
                .build();

            pipeline.process(event, SyncMode.ASYNC);

            var stored = store.findByEventId("MB-001", event.eventId()).orElseThrow();
            String storedEmail = stored.payload().get("email").asText();
            assertThat(storedEmail).contains("***"); // masked
        }
    }

    @Nested
    @DisplayName("Validation failures")
    class Validation {

        @Test
        @DisplayName("Null event returns REJECTED")
        void nullEvent() {
            var result = pipeline.process(null, SyncMode.ASYNC);
            assertThat(result.status()).isEqualTo(AuditPipeline.PipelineResult.Status.REJECTED);
        }

        @Test
        @DisplayName("Missing tenantId returns REJECTED")
        void missingTenant() {
            var event = new AuditEvent("e1", "test", EventCategory.BUSINESS,
                ActionResult.SUCCESS, null, null, null, null,
                null, null, null, null, null, null, null, null);
            var result = pipeline.process(event, SyncMode.ASYNC);
            assertThat(result.status()).isEqualTo(AuditPipeline.PipelineResult.Status.REJECTED);
        }
    }

    @Nested
    @DisplayName("Hash chain integrity")
    class ChainIntegrity {

        @Test
        @DisplayName("Each event has unique event hash")
        void uniqueHashes() {
            var r1 = pipeline.process(testEvent("e1", "MB-001"), SyncMode.ASYNC);
            var r2 = pipeline.process(testEvent("e2", "MB-001"), SyncMode.ASYNC);

            assertThat(r1.integrity().eventHash()).isNotEqualTo(r2.integrity().eventHash());
        }

        @Test
        @DisplayName("Chain hash links to previous")
        void chainLinked() {
            var r1 = pipeline.process(testEvent("e1", "MB-001"), SyncMode.ASYNC);
            var r2 = pipeline.process(testEvent("e2", "MB-001"), SyncMode.ASYNC);

            // Second event's previousChainHash should be first event's chainHash
            assertThat(r2.integrity().previousChainHash())
                .isEqualTo(r1.integrity().chainHash());
        }

        @Test
        @DisplayName("Genesis event references zero hash")
        void genesisLink() {
            var r1 = pipeline.process(testEvent("e1", "MB-001"), SyncMode.ASYNC);
            // Genesis previousChainHash should be all zeros
            assertThat(r1.integrity().previousChainHash()).matches("^0+$");
        }
    }

    @Nested
    @DisplayName("Metrics")
    class Metrics {
        @Test
        void metricsTracked() {
            pipeline.process(testEvent("e1", "MB-001"), SyncMode.ASYNC);
            pipeline.process(null, SyncMode.ASYNC); // validation error
            pipeline.process(testEvent("e2", "MB-001"), SyncMode.ASYNC);

            assertThat(pipeline.getProcessedCount()).isEqualTo(2);
            assertThat(pipeline.getValidationErrors()).isEqualTo(1);
        }
    }
}
