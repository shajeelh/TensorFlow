package com.paymenthub.audit.server.evidence;

import com.paymenthub.audit.builder.AuditEventBuilder;
import com.paymenthub.audit.server.chain.HashChainManager;
import com.paymenthub.audit.server.merkle.MerkleWindowScheduler;
import com.paymenthub.audit.server.pipeline.AuditPipeline;
import com.paymenthub.audit.server.store.AuditEventStore;
import com.paymenthub.common.enums.*;
import com.paymenthub.common.model.AuditEvent;
import com.paymenthub.crypto.hash.ThreadLocalHashService;
import com.paymenthub.crypto.merkle.MerkleTreeBuilder;
import com.paymenthub.crypto.signing.SoftwareAuditSigner;
import com.paymenthub.pii.PiiJsonSanitizer;
import com.paymenthub.pii.PiiMasker;
import com.paymenthub.pii.PiiScanner;
import com.paymenthub.time.clock.HubClock;
import org.junit.jupiter.api.*;

import java.time.Duration;
import java.time.Instant;

import static org.assertj.core.api.Assertions.*;

class EvidenceExporterTest {

    private EvidenceExporter exporter;
    private AuditPipeline pipeline;
    private AuditEventStore.InMemoryAuditEventStore store;
    private MerkleWindowScheduler windowScheduler;

    @BeforeEach
    void setUp() throws Exception {
        var hashService = new ThreadLocalHashService();
        var chainManager = new HashChainManager(hashService);
        store = new AuditEventStore.InMemoryAuditEventStore();
        var sanitizer = new PiiJsonSanitizer(new PiiScanner(true), new PiiMasker());
        var clock = new HubClock("test");

        pipeline = new AuditPipeline(hashService, chainManager, sanitizer, store, clock);

        var treeBuilder = new MerkleTreeBuilder(hashService);
        var signer = new SoftwareAuditSigner();
        windowScheduler = new MerkleWindowScheduler(treeBuilder, signer, clock, Duration.ofHours(1));

        exporter = new EvidenceExporter(store, chainManager, windowScheduler, treeBuilder, clock);
    }

    @AfterEach
    void tearDown() { windowScheduler.close(); }

    private AuditEvent testEvent(String id) {
        return AuditEventBuilder.create("test.event")
            .eventId(id).tenantId("MB-001")
            .actor("u", ActorType.USER).resource("r", id)
            .build();
    }

    @Test
    @DisplayName("Export package contains events and chain proof")
    void exportWithEvents() {
        pipeline.process(testEvent("e1"), SyncMode.ASYNC);
        pipeline.process(testEvent("e2"), SyncMode.ASYNC);
        pipeline.process(testEvent("e3"), SyncMode.ASYNC);

        Instant from = Instant.now().minusSeconds(60);
        Instant to = Instant.now().plusSeconds(60);

        var pkg = exporter.export("MB-001", from, to, 100);

        assertThat(pkg.isEmpty()).isFalse();
        assertThat(pkg.eventCount()).isEqualTo(3);
        assertThat(pkg.manifest().tenantId()).isEqualTo("MB-001");
        assertThat(pkg.manifest().eventCount()).isEqualTo(3);
        assertThat(pkg.chainProof()).isNotNull();
        assertThat(pkg.chainProof().links()).hasSize(3);
        assertThat(pkg.eventProofs()).hasSize(3);
    }

    @Test
    @DisplayName("Export empty range returns empty package")
    void emptyExport() {
        var pkg = exporter.export("EMPTY", Instant.now().minusSeconds(60),
            Instant.now().plusSeconds(60), 100);

        assertThat(pkg.isEmpty()).isTrue();
        assertThat(pkg.eventCount()).isZero();
    }

    @Test
    @DisplayName("Chain proof has correct start/end positions")
    void chainPositions() {
        pipeline.process(testEvent("e1"), SyncMode.ASYNC);
        pipeline.process(testEvent("e2"), SyncMode.ASYNC);

        var pkg = exporter.export("MB-001",
            Instant.now().minusSeconds(60), Instant.now().plusSeconds(60), 100);

        assertThat(pkg.chainProof().chainStartPosition()).isEqualTo(1);
        assertThat(pkg.chainProof().chainEndPosition()).isEqualTo(2);
    }
}
