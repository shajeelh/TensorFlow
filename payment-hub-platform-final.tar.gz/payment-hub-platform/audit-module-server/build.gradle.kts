plugins {
    `java-library`
    id("org.springframework.boot")
}
description = "Payment Hub — Audit Module Server (Processing Pipeline, Hash Chain, Store, Archival)"
dependencies {
    implementation(project(":hub-common-model"))
    implementation(project(":hub-crypto-starter"))
    implementation(project(":hub-pii-starter"))
    implementation(project(":hub-observability-starter"))
    implementation(project(":hub-error-starter"))
    implementation(project(":hub-time-starter"))
    implementation(project(":hub-tenant-context-starter"))
    implementation(project(":hub-messaging-starter"))
    implementation(project(":hub-security-starter"))
    implementation(project(":hub-nats-starter"))
    implementation(project(":hub-grpc-starter"))
    implementation(project(":hub-audit-starter"))

    implementation("org.springframework.boot:spring-boot-starter")
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation("com.fasterxml.jackson.core:jackson-databind")
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310")
    implementation("org.slf4j:slf4j-api")

    // OpenSearch client
    compileOnly("org.opensearch.client:opensearch-java")
    compileOnly("org.opensearch.client:opensearch-rest-client")

    // S3 WORM archival
    compileOnly("software.amazon.awssdk:s3")

    // gRPC
    compileOnly("io.grpc:grpc-api")
    compileOnly("io.grpc:grpc-stub")
    compileOnly("io.grpc:grpc-protobuf")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
