package com.paymenthub.security.rbac;

import com.paymenthub.security.context.SecurityContext;
import com.paymenthub.security.context.SecurityContextHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Evaluates permissions against the current security context.
 *
 * <p>This is the central permission enforcement engine. It is called by:</p>
 * <ol>
 *   <li>{@code RequiresPermission} AOP interceptor (annotation-driven)</li>
 *   <li>Service layer code (programmatic checks)</li>
 *   <li>gRPC interceptors (per-RPC permission validation)</li>
 * </ol>
 *
 * <h3>Evaluation Logic</h3>
 * <ol>
 *   <li>Retrieve {@link SecurityContext} from {@link SecurityContextHolder}</li>
 *   <li>Check if any of the user's roles grant the required permission</li>
 *   <li>Check explicit permission grants (beyond role-based grants)</li>
 *   <li>Log the decision (allow/deny) for security audit trail</li>
 *   <li>On deny: log at WARN, optionally trigger a security audit event</li>
 * </ol>
 *
 * <h3>Thread Safety</h3>
 * <p>Thread-safe. Reads from SecurityContextHolder (ThreadLocal) and
 * immutable role/permission data structures.</p>
 */
public class PermissionEvaluator {

    private static final Logger log = LoggerFactory.getLogger(PermissionEvaluator.class);

    /**
     * Check if the current user has a specific permission.
     *
     * @param required the permission to check
     * @return true if the user has the permission
     */
    public boolean hasPermission(Permission required) {
        Objects.requireNonNull(required, "Permission must not be null");
        SecurityContext ctx = SecurityContextHolder.get();
        if (ctx == null) {
            log.debug("No security context — permission '{}' denied", required);
            return false;
        }
        return evaluatePermission(ctx, required);
    }

    /**
     * Check if the current user has ALL of the specified permissions.
     */
    public boolean hasAllPermissions(Permission... required) {
        SecurityContext ctx = SecurityContextHolder.get();
        if (ctx == null) return false;
        for (Permission p : required) {
            if (!evaluatePermission(ctx, p)) return false;
        }
        return true;
    }

    /**
     * Check if the current user has ANY of the specified permissions.
     */
    public boolean hasAnyPermission(Permission... candidates) {
        SecurityContext ctx = SecurityContextHolder.get();
        if (ctx == null) return false;
        for (Permission p : candidates) {
            if (evaluatePermission(ctx, p)) return true;
        }
        return false;
    }

    /**
     * Assert that the current user has a permission.
     * Throws {@code AccessDeniedException} on failure.
     *
     * @param required the required permission
     * @throws AccessDeniedException if the user lacks the permission
     */
    public void requirePermission(Permission required) {
        if (!hasPermission(required)) {
            SecurityContext ctx = SecurityContextHolder.get();
            String identity = ctx != null ? ctx.actorIdentity() : "anonymous";
            String message = "Access denied: '%s' requires permission '%s'"
                .formatted(identity, required.getValue());

            log.warn("SECURITY: {}", message);
            throw new AccessDeniedException(message, required);
        }
    }

    /**
     * Assert that the current user has ALL of the specified permissions.
     */
    public void requireAllPermissions(Permission... required) {
        for (Permission p : required) {
            requirePermission(p);
        }
    }

    /**
     * Get the effective permissions for the current user.
     * Union of all role permissions + explicit grants.
     */
    public Set<Permission> getEffectivePermissions() {
        SecurityContext ctx = SecurityContextHolder.get();
        if (ctx == null) return Set.of();
        return ctx.effectivePermissions();
    }

    // ── Internal ─────────────────────────────────────────────

    private boolean evaluatePermission(SecurityContext ctx, Permission required) {
        // Check explicit permissions first (fastest path)
        if (ctx.explicitPermissions().contains(required)) {
            log.trace("Permission '{}' granted to '{}' via explicit grant",
                required, ctx.actorIdentity());
            return true;
        }

        // Check role-based permissions
        for (Role role : ctx.roles()) {
            if (role.hasPermission(required)) {
                log.trace("Permission '{}' granted to '{}' via role '{}'",
                    required, ctx.actorIdentity(), role.getValue());
                return true;
            }
        }

        log.debug("Permission '{}' denied for '{}' (roles: {})",
            required, ctx.actorIdentity(),
            ctx.roles().stream().map(Role::getValue).collect(Collectors.joining(",")));
        return false;
    }

    /**
     * Exception thrown when a required permission is not held.
     */
    public static class AccessDeniedException extends RuntimeException {
        private final Permission requiredPermission;

        public AccessDeniedException(String message, Permission requiredPermission) {
            super(message);
            this.requiredPermission = requiredPermission;
        }

        public Permission getRequiredPermission() { return requiredPermission; }
    }
}
