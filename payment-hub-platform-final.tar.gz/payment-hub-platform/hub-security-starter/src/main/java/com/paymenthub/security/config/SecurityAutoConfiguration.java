package com.paymenthub.security.config;

import com.paymenthub.security.audit.SecurityAuditBridge;
import com.paymenthub.security.rbac.PermissionEvaluator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
public class SecurityAutoConfiguration {
    private static final Logger log = LoggerFactory.getLogger(SecurityAutoConfiguration.class);

    @Bean
    @ConditionalOnMissingBean
    public PermissionEvaluator permissionEvaluator() {
        log.info("Payment Hub RBAC permission evaluator configured");
        return new PermissionEvaluator();
    }

    @Bean
    @ConditionalOnMissingBean
    public SecurityAuditBridge securityAuditBridge() {
        return new SecurityAuditBridge();
    }
}
