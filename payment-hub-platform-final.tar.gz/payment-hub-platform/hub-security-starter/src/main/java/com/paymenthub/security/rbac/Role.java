package com.paymenthub.security.rbac;

import java.util.*;

/**
 * Predefined roles with associated permission sets.
 *
 * <h3>Role Hierarchy</h3>
 * <pre>
 * PLATFORM_ADMIN
 *   └── TENANT_ADMIN
 *         ├── AUDIT_ADMIN
 *         ├── PAYMENT_ADMIN
 *         └── CONFIG_ADMIN
 *               └── AUDITOR (read-only)
 *                     └── OPERATOR (limited write)
 *                           └── VIEWER (minimal read)
 * </pre>
 *
 * <h3>Tenant Scoping</h3>
 * <p>Roles are always scoped to a tenant. A user with {@code TENANT_ADMIN}
 * in tenant "MB-001" has admin permissions only within that tenant.
 * Cross-tenant access requires explicit multi-tenant role assignment.</p>
 *
 * <h3>Custom Roles</h3>
 * <p>These are the built-in roles. Custom roles can be created by
 * combining permissions via the {@link RoleDefinition} record.</p>
 */
public enum Role {

    /** Full platform administration. Use with extreme caution. */
    PLATFORM_ADMIN("platform_admin", "Platform Administrator",
        EnumSet.allOf(Permission.class)),

    /** Full administration within a single tenant. */
    TENANT_ADMIN("tenant_admin", "Tenant Administrator",
        EnumSet.of(
            Permission.AUDIT_READ, Permission.AUDIT_WRITE, Permission.AUDIT_CONFIG,
            Permission.AUDIT_EXPORT, Permission.AUDIT_VERIFY, Permission.AUDIT_ADMIN,
            Permission.PAYMENT_READ, Permission.PAYMENT_INITIATE, Permission.PAYMENT_APPROVE,
            Permission.PAYMENT_CANCEL, Permission.PAYMENT_ADMIN,
            Permission.CONFIG_READ, Permission.CONFIG_WRITE, Permission.CONFIG_ADMIN,
            Permission.DATA_READ, Permission.DATA_WRITE, Permission.DATA_EXPORT,
            Permission.CRYPTO_KEY_VIEW
        )),

    /** Audit module administration. */
    AUDIT_ADMIN("audit_admin", "Audit Administrator",
        EnumSet.of(
            Permission.AUDIT_READ, Permission.AUDIT_WRITE, Permission.AUDIT_CONFIG,
            Permission.AUDIT_EXPORT, Permission.AUDIT_VERIFY, Permission.AUDIT_ADMIN,
            Permission.CRYPTO_KEY_VIEW
        )),

    /** Read-only audit access for compliance officers. */
    AUDITOR("auditor", "Compliance Auditor",
        EnumSet.of(
            Permission.AUDIT_READ, Permission.AUDIT_EXPORT, Permission.AUDIT_VERIFY,
            Permission.CONFIG_READ
        )),

    /** Payment operations with approval rights. */
    PAYMENT_ADMIN("payment_admin", "Payment Administrator",
        EnumSet.of(
            Permission.PAYMENT_READ, Permission.PAYMENT_INITIATE,
            Permission.PAYMENT_APPROVE, Permission.PAYMENT_CANCEL,
            Permission.PAYMENT_ADMIN, Permission.AUDIT_READ
        )),

    /** Day-to-day operations with limited write access. */
    OPERATOR("operator", "Operations Officer",
        EnumSet.of(
            Permission.PAYMENT_READ, Permission.PAYMENT_INITIATE,
            Permission.AUDIT_READ, Permission.CONFIG_READ,
            Permission.DATA_READ
        )),

    /** Read-only access for monitoring. */
    VIEWER("viewer", "Read-Only Viewer",
        EnumSet.of(
            Permission.AUDIT_READ, Permission.PAYMENT_READ,
            Permission.CONFIG_READ, Permission.DATA_READ
        )),

    /** Internal service account — used by modules for inter-service calls. */
    SERVICE_ACCOUNT("service_account", "Service Account",
        EnumSet.of(
            Permission.AUDIT_READ, Permission.AUDIT_WRITE,
            Permission.DATA_READ, Permission.DATA_WRITE
        ));

    private final String value;
    private final String displayName;
    private final Set<Permission> permissions;

    Role(String value, String displayName, Set<Permission> permissions) {
        this.value = value;
        this.displayName = displayName;
        this.permissions = Collections.unmodifiableSet(permissions);
    }

    public String getValue() { return value; }
    public String getDisplayName() { return displayName; }
    public Set<Permission> getPermissions() { return permissions; }

    /**
     * Check if this role has a specific permission.
     */
    public boolean hasPermission(Permission permission) {
        return permissions.contains(permission);
    }

    /**
     * Check if this role has ALL of the specified permissions.
     */
    public boolean hasAllPermissions(Permission... required) {
        return permissions.containsAll(Set.of(required));
    }

    /**
     * Check if this role has ANY of the specified permissions.
     */
    public boolean hasAnyPermission(Permission... candidates) {
        for (Permission p : candidates) {
            if (permissions.contains(p)) return true;
        }
        return false;
    }

    public static Role fromValue(String value) {
        for (Role r : values()) {
            if (r.value.equals(value)) return r;
        }
        throw new IllegalArgumentException("Unknown role: " + value);
    }
}
