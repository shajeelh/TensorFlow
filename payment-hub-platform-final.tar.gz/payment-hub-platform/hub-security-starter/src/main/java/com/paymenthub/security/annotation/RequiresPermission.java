package com.paymenthub.security.annotation;

import com.paymenthub.security.rbac.Permission;

import java.lang.annotation.*;

/**
 * Marks a method as requiring specific permissions.
 *
 * <p>The AOP interceptor checks permissions before method execution.
 * If the current actor lacks the required permission(s), an
 * {@link com.paymenthub.security.rbac.PermissionEvaluator.AccessDeniedException}
 * is thrown and a security audit event is recorded.</p>
 *
 * <h3>Mode</h3>
 * <ul>
 *   <li>{@code ALL} — all listed permissions are required (AND)</li>
 *   <li>{@code ANY} — at least one permission is sufficient (OR)</li>
 * </ul>
 *
 * <h3>Example</h3>
 * <pre>{@code
 * @RequiresPermission(value = Permission.AUDIT_CONFIG, audited = true)
 * public void updateRetentionPolicy(String tenantId, RetentionPolicy policy) {
 *     // only accessible to users with audit:config permission
 * }
 *
 * @RequiresPermission(
 *     value = { Permission.ADMIN_OVERRIDE, Permission.AUDIT_ADMIN },
 *     mode = RequiresPermission.Mode.ALL,
 *     audited = true
 * )
 * public void overrideAuditConfig(...) {
 *     // requires BOTH permissions (sensitive operation)
 * }
 * }</pre>
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface RequiresPermission {

    /** Required permission(s). */
    Permission[] value();

    /** How to combine multiple permissions. Default: ALL. */
    Mode mode() default Mode.ALL;

    /** Whether to record a security audit event for this access. Default: true. */
    boolean audited() default true;

    /** Evaluation mode. */
    enum Mode {
        /** All permissions required (AND). */
        ALL,
        /** At least one permission sufficient (OR). */
        ANY
    }
}
