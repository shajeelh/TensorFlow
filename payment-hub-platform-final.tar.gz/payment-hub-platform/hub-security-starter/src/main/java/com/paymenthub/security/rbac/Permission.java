package com.paymenthub.security.rbac;

/**
 * Platform-wide permissions organized by domain.
 *
 * <p>Permissions follow the format {@code domain:action} where:</p>
 * <ul>
 *   <li>{@code domain} — the functional area (audit, payment, config, admin)</li>
 *   <li>{@code action} — the specific operation (read, write, delete, override)</li>
 * </ul>
 *
 * <h3>Permission Hierarchy</h3>
 * <p>Some permissions imply others. For example, {@code AUDIT_ADMIN} implies
 * all other audit permissions. This is enforced by {@link Role} definitions,
 * not by the Permission enum itself.</p>
 *
 * <h3>Enforcement</h3>
 * <p>Permissions are checked at two levels:</p>
 * <ol>
 *   <li><strong>Method level</strong> — via {@link com.paymenthub.security.annotation.RequiresPermission}</li>
 *   <li><strong>Service level</strong> — via {@link PermissionEvaluator#hasPermission}</li>
 * </ol>
 */
public enum Permission {

    // ── Audit Domain ─────────────────────────────────────────
    /** Read audit events (query, search, export). */
    AUDIT_READ("audit:read"),
    /** Write audit events (record, batch). Internal only. */
    AUDIT_WRITE("audit:write"),
    /** Manage audit configuration (retention policies, sync config). */
    AUDIT_CONFIG("audit:config"),
    /** Download audit evidence packages. */
    AUDIT_EXPORT("audit:export"),
    /** Verify hash chain and Merkle proofs. */
    AUDIT_VERIFY("audit:verify"),
    /** Full audit administration. */
    AUDIT_ADMIN("audit:admin"),

    // ── Payment Domain ───────────────────────────────────────
    PAYMENT_READ("payment:read"),
    PAYMENT_INITIATE("payment:initiate"),
    PAYMENT_APPROVE("payment:approve"),
    PAYMENT_CANCEL("payment:cancel"),
    PAYMENT_ADMIN("payment:admin"),

    // ── Configuration Domain ─────────────────────────────────
    CONFIG_READ("config:read"),
    CONFIG_WRITE("config:write"),
    CONFIG_ADMIN("config:admin"),

    // ── Administration Domain ────────────────────────────────
    /** Override normal business rules (4-eyes principle required). */
    ADMIN_OVERRIDE("admin:override"),
    /** Manage legal holds on audit data. */
    ADMIN_LEGAL_HOLD("admin:legal_hold"),
    /** View PII data (requires specific compliance approval). */
    ADMIN_VIEW_PII("admin:view_pii"),
    /** System-level administration. */
    ADMIN_SYSTEM("admin:system"),

    // ── Data Access Domain ───────────────────────────────────
    DATA_READ("data:read"),
    DATA_WRITE("data:write"),
    DATA_DELETE("data:delete"),
    DATA_EXPORT("data:export"),

    // ── Crypto Domain ────────────────────────────────────────
    /** Trigger key rotation. */
    CRYPTO_KEY_ROTATE("crypto:key_rotate"),
    /** View signing key metadata (not key material). */
    CRYPTO_KEY_VIEW("crypto:key_view");

    private final String value;

    Permission(String value) { this.value = value; }

    public String getValue() { return value; }

    /**
     * Look up by string value.
     */
    public static Permission fromValue(String value) {
        for (Permission p : values()) {
            if (p.value.equals(value)) return p;
        }
        throw new IllegalArgumentException("Unknown permission: " + value);
    }

    @Override
    public String toString() { return value; }
}
