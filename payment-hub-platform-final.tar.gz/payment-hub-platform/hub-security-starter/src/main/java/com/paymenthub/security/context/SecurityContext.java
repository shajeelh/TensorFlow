package com.paymenthub.security.context;

import com.paymenthub.common.enums.ActorType;
import com.paymenthub.security.rbac.Permission;
import com.paymenthub.security.rbac.Role;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Immutable security identity of the current actor.
 *
 * <p>Contains the actor's identity, type, roles, and explicit permissions.
 * Set by authentication filters and propagated via {@link SecurityContextHolder}.</p>
 *
 * <h3>Permission Resolution</h3>
 * <p>Effective permissions = union of all role permissions + explicit grants.
 * Explicit grants allow fine-grained permission assignment beyond predefined roles.</p>
 *
 * <h3>Delegation (4-Eyes Principle)</h3>
 * <p>When an operation requires dual approval, the context carries both
 * the initiator and the approver identities via {@code delegatedBy}.
 * Both actors are recorded in the audit trail.</p>
 *
 * @param actorIdentity       unique identity (username, service name, API key ID)
 * @param actorType           type of actor (USER, SERVICE, SYSTEM, etc.)
 * @param displayName         human-readable name (for UI/logs)
 * @param roles               assigned roles (determine base permissions)
 * @param explicitPermissions additional permissions beyond role grants
 * @param delegatedBy         identity of delegating actor (4-eyes principle)
 * @param authMethod          how the actor authenticated (JWT, mTLS, API_KEY, etc.)
 * @param sessionId           session identifier for session tracking
 * @param attributes          additional security attributes (department, clearance, etc.)
 */
public record SecurityContext(
    String actorIdentity,
    ActorType actorType,
    String displayName,
    Set<Role> roles,
    Set<Permission> explicitPermissions,
    String delegatedBy,
    String authMethod,
    String sessionId,
    Map<String, String> attributes
) {
    /**
     * Canonical constructor with defensive copies.
     */
    public SecurityContext {
        Objects.requireNonNull(actorIdentity, "actorIdentity is required");
        Objects.requireNonNull(actorType, "actorType is required");
        displayName = displayName != null ? displayName : actorIdentity;
        roles = roles != null ? Set.copyOf(roles) : Set.of();
        explicitPermissions = explicitPermissions != null ? Set.copyOf(explicitPermissions) : Set.of();
        attributes = attributes != null ? Map.copyOf(attributes) : Map.of();
    }

    // ── Factory Methods ──────────────────────────────────────

    /**
     * Create a security context for a human user.
     */
    public static SecurityContext user(String identity, String displayName,
                                        Set<Role> roles, String authMethod) {
        return new SecurityContext(identity, ActorType.USER, displayName,
            roles, Set.of(), null, authMethod, null, Map.of());
    }

    /**
     * Create a security context for an internal service account.
     */
    public static SecurityContext service(String serviceName) {
        return new SecurityContext(serviceName, ActorType.SERVICE, serviceName,
            Set.of(Role.SERVICE_ACCOUNT), Set.of(), null, "mTLS", null, Map.of());
    }

    /**
     * Create a security context for system operations (schedulers, bootstrappers).
     */
    public static SecurityContext system(String component) {
        return new SecurityContext(component, ActorType.SYSTEM, component,
            Set.of(Role.PLATFORM_ADMIN), Set.of(), null, "internal", null, Map.of());
    }

    // ── Permission Queries ───────────────────────────────────

    /**
     * Compute the full set of effective permissions (roles + explicit grants).
     */
    public Set<Permission> effectivePermissions() {
        Set<Permission> effective = EnumSet.noneOf(Permission.class);
        for (Role role : roles) {
            effective.addAll(role.getPermissions());
        }
        effective.addAll(explicitPermissions);
        return Collections.unmodifiableSet(effective);
    }

    /**
     * Check if this context has a specific permission.
     */
    public boolean hasPermission(Permission permission) {
        // Check explicit first (fast path)
        if (explicitPermissions.contains(permission)) return true;
        for (Role role : roles) {
            if (role.hasPermission(permission)) return true;
        }
        return false;
    }

    /**
     * Check if this is a human user (vs service/system).
     */
    public boolean isHuman() {
        return actorType == ActorType.USER || actorType == ActorType.EXTERNAL;
    }

    /**
     * Check if this is an internal service.
     */
    public boolean isService() {
        return actorType == ActorType.SERVICE || actorType == ActorType.SYSTEM;
    }

    /**
     * Check if this operation involves delegation (4-eyes).
     */
    public boolean isDelegated() {
        return delegatedBy != null && !delegatedBy.isBlank();
    }

    /**
     * Check if the actor has a specific role.
     */
    public boolean hasRole(Role role) {
        return roles.contains(role);
    }

    /**
     * Get a specific attribute value.
     */
    public String attribute(String key) {
        return attributes.get(key);
    }

    /**
     * Create a derived context with delegation information.
     */
    public SecurityContext withDelegation(String delegator) {
        return new SecurityContext(actorIdentity, actorType, displayName,
            roles, explicitPermissions, delegator, authMethod, sessionId, attributes);
    }

    /**
     * Create a derived context with additional explicit permissions.
     */
    public SecurityContext withAdditionalPermissions(Permission... additional) {
        Set<Permission> combined = new HashSet<>(explicitPermissions);
        combined.addAll(Set.of(additional));
        return new SecurityContext(actorIdentity, actorType, displayName,
            roles, combined, delegatedBy, authMethod, sessionId, attributes);
    }

    @Override
    public String toString() {
        return "SecurityContext{actor='%s', type=%s, roles=[%s], delegatedBy=%s}"
            .formatted(actorIdentity, actorType,
                roles.stream().map(Role::getValue).collect(Collectors.joining(",")),
                delegatedBy);
    }
}
