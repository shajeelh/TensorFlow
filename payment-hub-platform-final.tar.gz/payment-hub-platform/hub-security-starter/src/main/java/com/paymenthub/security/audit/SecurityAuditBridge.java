package com.paymenthub.security.audit;

import com.paymenthub.common.enums.ActionResult;
import com.paymenthub.security.context.SecurityContext;
import com.paymenthub.security.context.SecurityContextHolder;
import com.paymenthub.security.rbac.Permission;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * Bridge between the security starter and the audit module.
 *
 * <p>Generates structured security event records for:</p>
 * <ul>
 *   <li><strong>Access denied</strong> — user attempted an operation without
 *       sufficient permissions. Always recorded. Triggers P3 alert if
 *       repeated (>5 in 10 minutes from same actor).</li>
 *   <li><strong>Privilege escalation</strong> — user gained elevated permissions
 *       via delegation or role change. Always recorded. Mandatory sync audit.</li>
 *   <li><strong>Sensitive operation</strong> — user performed an operation on
 *       a sensitive resource (config change, key rotation, legal hold).
 *       Always recorded with full context.</li>
 * </ul>
 *
 * <h3>Integration</h3>
 * <p>This bridge produces {@link SecurityEventRecord} instances that
 * the hub-audit-starter converts into full {@code AuditEvent} objects
 * and emits through the audit pipeline. The bridge intentionally does
 * NOT depend on the audit module directly to avoid circular dependencies.</p>
 *
 * <h3>Event Listener</h3>
 * <p>Consumers register a {@link SecurityEventListener} to receive
 * security events. The hub-audit-starter auto-registers itself.</p>
 */
public class SecurityAuditBridge {

    private static final Logger log = LoggerFactory.getLogger(SecurityAuditBridge.class);

    private volatile SecurityEventListener listener;

    /**
     * Register the event listener (typically the audit module).
     */
    public void setListener(SecurityEventListener listener) {
        this.listener = listener;
        log.info("Security audit bridge listener registered: {}",
            listener.getClass().getSimpleName());
    }

    /**
     * Record an access denied event.
     */
    public void recordAccessDenied(Permission requiredPermission, String resource,
                                     String operation) {
        SecurityContext ctx = SecurityContextHolder.get();
        String actor = ctx != null ? ctx.actorIdentity() : "anonymous";

        SecurityEventRecord event = new SecurityEventRecord(
            UUID.randomUUID().toString(),
            "authz.access_denied",
            Instant.now(),
            actor,
            ctx != null ? ctx.actorType().getValue() : "unknown",
            resource,
            operation,
            ActionResult.DENIED,
            Map.of(
                "requiredPermission", requiredPermission.getValue(),
                "authMethod", ctx != null && ctx.authMethod() != null ? ctx.authMethod() : "none"
            )
        );

        log.warn("ACCESS DENIED: actor='{}', permission='{}', resource='{}', operation='{}'",
            actor, requiredPermission.getValue(), resource, operation);
        emit(event);
    }

    /**
     * Record a privilege escalation event (mandatory sync audit).
     */
    public void recordPrivilegeEscalation(String actor, String escalationType,
                                            String fromRole, String toRole) {
        SecurityEventRecord event = new SecurityEventRecord(
            UUID.randomUUID().toString(),
            "authz.privilege_escalation",
            Instant.now(),
            actor,
            "user",
            "rbac.role_assignment",
            "escalate",
            ActionResult.SUCCESS,
            Map.of(
                "escalationType", escalationType,
                "fromRole", fromRole != null ? fromRole : "none",
                "toRole", toRole
            )
        );

        log.warn("PRIVILEGE ESCALATION: actor='{}', type='{}', {}→{}",
            actor, escalationType, fromRole, toRole);
        emit(event);
    }

    /**
     * Record a sensitive operation event.
     */
    public void recordSensitiveOperation(String operation, String resource,
                                           ActionResult result, Map<String, String> details) {
        SecurityContext ctx = SecurityContextHolder.get();
        String actor = ctx != null ? ctx.actorIdentity() : "system";

        SecurityEventRecord event = new SecurityEventRecord(
            UUID.randomUUID().toString(),
            "security." + operation,
            Instant.now(),
            actor,
            ctx != null ? ctx.actorType().getValue() : "system",
            resource,
            operation,
            result,
            details != null ? details : Map.of()
        );

        log.info("SENSITIVE OPERATION: actor='{}', op='{}', resource='{}', result={}",
            actor, operation, resource, result);
        emit(event);
    }

    private void emit(SecurityEventRecord event) {
        SecurityEventListener l = this.listener;
        if (l != null) {
            try {
                l.onSecurityEvent(event);
            } catch (Exception e) {
                log.error("Failed to emit security event: {}", e.getMessage(), e);
            }
        } else {
            log.debug("No security event listener registered — event discarded: {}", event.eventType());
        }
    }

    /**
     * Structured security event record.
     */
    public record SecurityEventRecord(
        String eventId,
        String eventType,
        Instant timestamp,
        String actorIdentity,
        String actorType,
        String resource,
        String operation,
        ActionResult result,
        Map<String, String> metadata
    ) {}

    /**
     * Listener interface for receiving security events.
     */
    @FunctionalInterface
    public interface SecurityEventListener {
        void onSecurityEvent(SecurityEventRecord event);
    }
}
