package com.paymenthub.security.context;

import org.slf4j.MDC;

import java.util.Objects;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Thread-local holder for {@link SecurityContext}.
 *
 * <p>Set by authentication filters (JWT, mTLS, API key) at request entry.
 * Read by {@link com.paymenthub.security.rbac.PermissionEvaluator} and
 * audit event builders. Cleared in a finally block at request exit.</p>
 *
 * <h3>MDC Integration</h3>
 * <p>Pushes {@code actorIdentity} and {@code authMethod} to SLF4J MDC
 * for inclusion in every log line.</p>
 */
public final class SecurityContextHolder {

    private static final InheritableThreadLocal<SecurityContext> CONTEXT =
        new InheritableThreadLocal<>();

    private SecurityContextHolder() {}

    public static void set(SecurityContext context) {
        Objects.requireNonNull(context, "SecurityContext must not be null");
        CONTEXT.set(context);
        MDC.put("actorIdentity", context.actorIdentity());
        MDC.put("actorType", context.actorType().getValue());
        if (context.authMethod() != null) MDC.put("authMethod", context.authMethod());
    }

    public static SecurityContext get() { return CONTEXT.get(); }

    public static Optional<SecurityContext> current() {
        return Optional.ofNullable(CONTEXT.get());
    }

    public static SecurityContext require() {
        SecurityContext ctx = CONTEXT.get();
        if (ctx == null) {
            throw new IllegalStateException("No SecurityContext set on current thread");
        }
        return ctx;
    }

    public static void clear() {
        CONTEXT.remove();
        MDC.remove("actorIdentity");
        MDC.remove("actorType");
        MDC.remove("authMethod");
    }

    public static String getActorIdentity() {
        SecurityContext ctx = CONTEXT.get();
        return ctx != null ? ctx.actorIdentity() : null;
    }

    /**
     * Execute a block with a specific security context.
     */
    public static <T> T withContext(SecurityContext context, Supplier<T> action) {
        SecurityContext previous = CONTEXT.get();
        try {
            set(context);
            return action.get();
        } finally {
            if (previous != null) set(previous);
            else clear();
        }
    }

    public static void withContext(SecurityContext context, Runnable action) {
        SecurityContext previous = CONTEXT.get();
        try {
            set(context);
            action.run();
        } finally {
            if (previous != null) set(previous);
            else clear();
        }
    }
}
