package com.paymenthub.security.rbac;

import com.paymenthub.common.enums.ActorType;
import com.paymenthub.security.context.SecurityContext;
import com.paymenthub.security.context.SecurityContextHolder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.assertj.core.api.Assertions.*;

class PermissionEvaluatorTest {

    private final PermissionEvaluator evaluator = new PermissionEvaluator();

    @AfterEach
    void cleanup() { SecurityContextHolder.clear(); }

    @Nested
    @DisplayName("Permission checks")
    class PermissionChecks {

        @Test
        @DisplayName("Auditor has AUDIT_READ but not AUDIT_WRITE")
        void auditorPermissions() {
            setContext(Set.of(Role.AUDITOR));
            assertThat(evaluator.hasPermission(Permission.AUDIT_READ)).isTrue();
            assertThat(evaluator.hasPermission(Permission.AUDIT_EXPORT)).isTrue();
            assertThat(evaluator.hasPermission(Permission.AUDIT_WRITE)).isFalse();
            assertThat(evaluator.hasPermission(Permission.AUDIT_CONFIG)).isFalse();
            assertThat(evaluator.hasPermission(Permission.ADMIN_OVERRIDE)).isFalse();
        }

        @Test
        @DisplayName("Platform admin has all permissions")
        void platformAdmin() {
            setContext(Set.of(Role.PLATFORM_ADMIN));
            for (Permission p : Permission.values()) {
                assertThat(evaluator.hasPermission(p))
                    .as("PLATFORM_ADMIN should have %s", p)
                    .isTrue();
            }
        }

        @Test
        @DisplayName("Viewer has only read permissions")
        void viewerPermissions() {
            setContext(Set.of(Role.VIEWER));
            assertThat(evaluator.hasPermission(Permission.AUDIT_READ)).isTrue();
            assertThat(evaluator.hasPermission(Permission.PAYMENT_READ)).isTrue();
            assertThat(evaluator.hasPermission(Permission.PAYMENT_INITIATE)).isFalse();
            assertThat(evaluator.hasPermission(Permission.ADMIN_OVERRIDE)).isFalse();
        }

        @Test
        @DisplayName("Multiple roles combine permissions")
        void multipleRoles() {
            setContext(Set.of(Role.AUDITOR, Role.OPERATOR));
            assertThat(evaluator.hasPermission(Permission.AUDIT_EXPORT)).isTrue(); // from AUDITOR
            assertThat(evaluator.hasPermission(Permission.PAYMENT_INITIATE)).isTrue(); // from OPERATOR
        }

        @Test
        @DisplayName("No security context denies all")
        void noContext() {
            assertThat(evaluator.hasPermission(Permission.AUDIT_READ)).isFalse();
        }
    }

    @Nested
    @DisplayName("Explicit permissions")
    class ExplicitPermissions {

        @Test
        @DisplayName("Explicit grant overrides role limitation")
        void explicitGrant() {
            var ctx = new SecurityContext("user", ActorType.USER, "User",
                Set.of(Role.VIEWER),
                Set.of(Permission.AUDIT_CONFIG), // explicit grant beyond VIEWER role
                null, "JWT", null, null);
            SecurityContextHolder.set(ctx);

            assertThat(evaluator.hasPermission(Permission.AUDIT_CONFIG)).isTrue();
            assertThat(evaluator.hasPermission(Permission.ADMIN_OVERRIDE)).isFalse();
        }
    }

    @Nested
    @DisplayName("requirePermission")
    class RequirePermission {

        @Test
        @DisplayName("Passes when permission held")
        void passes() {
            setContext(Set.of(Role.AUDITOR));
            assertThatCode(() -> evaluator.requirePermission(Permission.AUDIT_READ))
                .doesNotThrowAnyException();
        }

        @Test
        @DisplayName("Throws AccessDeniedException when lacking permission")
        void throws_() {
            setContext(Set.of(Role.VIEWER));
            assertThatThrownBy(() -> evaluator.requirePermission(Permission.ADMIN_OVERRIDE))
                .isInstanceOf(PermissionEvaluator.AccessDeniedException.class)
                .satisfies(e -> {
                    var ade = (PermissionEvaluator.AccessDeniedException) e;
                    assertThat(ade.getRequiredPermission()).isEqualTo(Permission.ADMIN_OVERRIDE);
                });
        }
    }

    @Nested
    @DisplayName("hasAllPermissions / hasAnyPermission")
    class CombinedChecks {

        @Test
        @DisplayName("hasAllPermissions requires ALL")
        void hasAll() {
            setContext(Set.of(Role.AUDITOR));
            assertThat(evaluator.hasAllPermissions(
                Permission.AUDIT_READ, Permission.AUDIT_EXPORT)).isTrue();
            assertThat(evaluator.hasAllPermissions(
                Permission.AUDIT_READ, Permission.AUDIT_WRITE)).isFalse();
        }

        @Test
        @DisplayName("hasAnyPermission requires at least one")
        void hasAny() {
            setContext(Set.of(Role.VIEWER));
            assertThat(evaluator.hasAnyPermission(
                Permission.AUDIT_READ, Permission.ADMIN_OVERRIDE)).isTrue();
            assertThat(evaluator.hasAnyPermission(
                Permission.ADMIN_OVERRIDE, Permission.CRYPTO_KEY_ROTATE)).isFalse();
        }
    }

    @Nested
    @DisplayName("Effective permissions")
    class EffectivePermissions {
        @Test
        void effectivePermissions() {
            setContext(Set.of(Role.AUDITOR));
            var effective = evaluator.getEffectivePermissions();
            assertThat(effective).contains(Permission.AUDIT_READ, Permission.AUDIT_EXPORT);
            assertThat(effective).doesNotContain(Permission.ADMIN_OVERRIDE);
        }
    }

    private void setContext(Set<Role> roles) {
        SecurityContextHolder.set(SecurityContext.user("test-user", "Test User", roles, "JWT"));
    }
}
