package com.paymenthub.security.context;

import com.paymenthub.common.enums.ActorType;
import com.paymenthub.security.rbac.Permission;
import com.paymenthub.security.rbac.Role;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.assertj.core.api.Assertions.*;

class SecurityContextTest {

    @AfterEach
    void cleanup() { SecurityContextHolder.clear(); }

    @Test
    @DisplayName("User factory creates correct context")
    void userFactory() {
        var ctx = SecurityContext.user("jane@megabank.com", "Jane Doe",
            Set.of(Role.AUDITOR), "JWT");
        assertThat(ctx.actorIdentity()).isEqualTo("jane@megabank.com");
        assertThat(ctx.actorType()).isEqualTo(ActorType.USER);
        assertThat(ctx.isHuman()).isTrue();
        assertThat(ctx.isService()).isFalse();
        assertThat(ctx.hasRole(Role.AUDITOR)).isTrue();
    }

    @Test
    @DisplayName("Service factory creates service account context")
    void serviceFactory() {
        var ctx = SecurityContext.service("audit-module");
        assertThat(ctx.actorType()).isEqualTo(ActorType.SERVICE);
        assertThat(ctx.isService()).isTrue();
        assertThat(ctx.hasRole(Role.SERVICE_ACCOUNT)).isTrue();
        assertThat(ctx.authMethod()).isEqualTo("mTLS");
    }

    @Test
    @DisplayName("System factory creates admin context")
    void systemFactory() {
        var ctx = SecurityContext.system("scheduler");
        assertThat(ctx.hasRole(Role.PLATFORM_ADMIN)).isTrue();
        assertThat(ctx.hasPermission(Permission.ADMIN_OVERRIDE)).isTrue();
    }

    @Test
    @DisplayName("Delegation creates derived context")
    void delegation() {
        var ctx = SecurityContext.user("operator", "Op", Set.of(Role.OPERATOR), "JWT");
        var delegated = ctx.withDelegation("supervisor");
        assertThat(delegated.isDelegated()).isTrue();
        assertThat(delegated.delegatedBy()).isEqualTo("supervisor");
        assertThat(delegated.actorIdentity()).isEqualTo("operator");
    }

    @Test
    @DisplayName("Additional permissions augment context")
    void additionalPermissions() {
        var ctx = SecurityContext.user("user", "U", Set.of(Role.VIEWER), "JWT");
        assertThat(ctx.hasPermission(Permission.AUDIT_CONFIG)).isFalse();

        var augmented = ctx.withAdditionalPermissions(Permission.AUDIT_CONFIG);
        assertThat(augmented.hasPermission(Permission.AUDIT_CONFIG)).isTrue();
        assertThat(augmented.hasPermission(Permission.AUDIT_READ)).isTrue(); // from VIEWER role
    }

    @Test
    @DisplayName("SecurityContextHolder lifecycle")
    void holderLifecycle() {
        assertThat(SecurityContextHolder.get()).isNull();
        assertThat(SecurityContextHolder.getActorIdentity()).isNull();

        var ctx = SecurityContext.user("jane", "Jane", Set.of(Role.AUDITOR), "JWT");
        SecurityContextHolder.set(ctx);
        assertThat(SecurityContextHolder.getActorIdentity()).isEqualTo("jane");
        assertThat(SecurityContextHolder.require()).isEqualTo(ctx);

        SecurityContextHolder.clear();
        assertThat(SecurityContextHolder.get()).isNull();
    }

    @Test
    @DisplayName("withContext restores previous context")
    void scopedContext() {
        var outer = SecurityContext.user("outer", "O", Set.of(Role.VIEWER), "JWT");
        var inner = SecurityContext.service("inner-svc");

        SecurityContextHolder.set(outer);
        String result = SecurityContextHolder.withContext(inner,
            () -> SecurityContextHolder.getActorIdentity());

        assertThat(result).isEqualTo("inner-svc");
        assertThat(SecurityContextHolder.getActorIdentity()).isEqualTo("outer");
    }

    @Test
    @DisplayName("Null identity throws")
    void nullIdentity() {
        assertThatThrownBy(() -> new SecurityContext(null, ActorType.USER, null,
            null, null, null, null, null, null))
            .isInstanceOf(NullPointerException.class);
    }
}
