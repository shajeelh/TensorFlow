plugins { `java-library` }
description = "Payment Hub — RBAC, Permission Enforcement, @RequiresPermission, Security Audit Bridge"
dependencies {
    api(project(":hub-common-model"))
    implementation(project(":hub-observability-starter"))
    implementation(project(":hub-tenant-context-starter"))

    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("org.slf4j:slf4j-api")
    compileOnly("org.springframework:spring-context")
    compileOnly("org.springframework.security:spring-security-core")

    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
