package com.paymenthub.observability.context;

import com.paymenthub.common.enums.ActorType;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.*;

class CorrelationContextTest {

    @AfterEach
    void cleanup() { CorrelationContextHolder.clear(); }

    @Nested
    @DisplayName("Context lifecycle")
    class Lifecycle {

        @Test
        @DisplayName("Set and get context")
        void setAndGet() {
            var ctx = CorrelationContext.newRequest("MB-001", "MAIN_BANK",
                "jane@test.com", ActorType.USER, "payment-orch");
            CorrelationContextHolder.set(ctx);

            assertThat(CorrelationContextHolder.get()).isNotNull();
            assertThat(CorrelationContextHolder.getCorrelationId()).isNotNull();
            assertThat(CorrelationContextHolder.getTenantId()).isEqualTo("MB-001");
            assertThat(CorrelationContextHolder.getActorIdentity()).isEqualTo("jane@test.com");
        }

        @Test
        @DisplayName("Clear removes context")
        void clearContext() {
            CorrelationContextHolder.set(CorrelationContext.newRequest(
                "T1", "E1", "user", ActorType.USER, "mod"));
            CorrelationContextHolder.clear();
            assertThat(CorrelationContextHolder.get()).isNull();
            assertThat(CorrelationContextHolder.getTenantId()).isNull();
        }

        @Test
        @DisplayName("require() throws when no context set")
        void requireThrows() {
            assertThatThrownBy(CorrelationContextHolder::require)
                .isInstanceOf(IllegalStateException.class);
        }

        @Test
        @DisplayName("withContext restores previous context")
        void withContextRestore() {
            var outer = CorrelationContext.newRequest("OUTER", "E", "u", ActorType.USER, "m");
            var inner = CorrelationContext.newRequest("INNER", "E", "u", ActorType.USER, "m");

            CorrelationContextHolder.set(outer);
            String result = CorrelationContextHolder.withContext(inner,
                () -> CorrelationContextHolder.getTenantId());

            assertThat(result).isEqualTo("INNER");
            assertThat(CorrelationContextHolder.getTenantId()).isEqualTo("OUTER");
        }

        @Test
        @DisplayName("Context propagates to child threads")
        void threadPropagation() throws Exception {
            var ctx = CorrelationContext.newRequest("MB-001", "MAIN", "u", ActorType.USER, "m");
            CorrelationContextHolder.set(ctx);

            AtomicReference<String> childTenant = new AtomicReference<>();
            Thread child = new Thread(() -> childTenant.set(CorrelationContextHolder.getTenantId()));
            child.start();
            child.join(1000);

            assertThat(childTenant.get()).isEqualTo("MB-001");
        }
    }

    @Nested
    @DisplayName("Context derivation")
    class Derivation {

        @Test
        @DisplayName("childContext preserves correlationId")
        void childPreservesCorrelation() {
            var parent = CorrelationContext.newRequest("T", "E", "u", ActorType.USER, "module-a");
            var child = parent.childContext("module-b");

            assertThat(child.correlationId()).isEqualTo(parent.correlationId());
            assertThat(child.causationId()).isEqualTo(parent.correlationId());
            assertThat(child.sourceModule()).isEqualTo("module-b");
            assertThat(child.tenantId()).isEqualTo("T");
        }

        @Test
        @DisplayName("withTrace updates trace/span IDs")
        void withTrace() {
            var ctx = CorrelationContext.newRequest("T", "E", "u", ActorType.USER, "m");
            var traced = ctx.withTrace("trace-123", "span-456");

            assertThat(traced.traceId()).isEqualTo("trace-123");
            assertThat(traced.spanId()).isEqualTo("span-456");
            assertThat(traced.correlationId()).isEqualTo(ctx.correlationId());
        }

        @Test
        @DisplayName("withTenant updates tenant context")
        void withTenant() {
            var ctx = CorrelationContext.newRequest("T1", "E1", "u", ActorType.USER, "m");
            var updated = ctx.withTenant("T2", "E2");

            assertThat(updated.tenantId()).isEqualTo("T2");
            assertThat(updated.entityId()).isEqualTo("E2");
            assertThat(updated.correlationId()).isEqualTo(ctx.correlationId());
        }
    }

    @Nested
    @DisplayName("Header serialization")
    class Serialization {

        @Test
        @DisplayName("Round-trip through headers")
        void roundTrip() {
            var original = CorrelationContext.newRequest("MB-001", "MAIN_BANK",
                "jane@test.com", ActorType.USER, "payment-orch");

            Map<String, String> headers = CorrelationContextSerializer.toHeaders(original);
            CorrelationContext deserialized = CorrelationContextSerializer.fromHeaders(headers);

            assertThat(deserialized).isNotNull();
            assertThat(deserialized.correlationId()).isEqualTo(original.correlationId());
            assertThat(deserialized.tenantId()).isEqualTo("MB-001");
            assertThat(deserialized.entityId()).isEqualTo("MAIN_BANK");
            assertThat(deserialized.actorIdentity()).isEqualTo("jane@test.com");
            assertThat(deserialized.actorType()).isEqualTo(ActorType.USER);
            assertThat(deserialized.sourceModule()).isEqualTo("payment-orch");
        }

        @Test
        @DisplayName("Null context produces empty headers")
        void nullContext() {
            assertThat(CorrelationContextSerializer.toHeaders(null)).isEmpty();
        }

        @Test
        @DisplayName("Empty headers produce null context")
        void emptyHeaders() {
            assertThat(CorrelationContextSerializer.fromHeaders(Map.of())).isNull();
        }

        @Test
        @DisplayName("Missing correlation ID returns null")
        void missingCorrelation() {
            Map<String, String> headers = Map.of("X-Tenant-Id", "T1");
            assertThat(CorrelationContextSerializer.fromHeaders(headers)).isNull();
        }
    }
}
