package com.paymenthub.observability.context;

import com.paymenthub.common.enums.ActorType;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Function;

/**
 * Serializes/deserializes {@link CorrelationContext} to/from message headers.
 *
 * <p>Used by NATS, Kafka, gRPC, and HTTP interceptors to propagate
 * context across module boundaries.</p>
 */
public final class CorrelationContextSerializer {

    private CorrelationContextSerializer() {}

    /**
     * Serialize context to a map of header key-value pairs.
     */
    public static Map<String, String> toHeaders(CorrelationContext ctx) {
        if (ctx == null) return Map.of();
        Map<String, String> headers = new HashMap<>();
        putIfNotNull(headers, CorrelationContext.HEADER_CORRELATION_ID, ctx.correlationId());
        putIfNotNull(headers, CorrelationContext.HEADER_TRACE_ID, ctx.traceId());
        putIfNotNull(headers, CorrelationContext.HEADER_SPAN_ID, ctx.spanId());
        putIfNotNull(headers, CorrelationContext.HEADER_CAUSATION_ID, ctx.causationId());
        putIfNotNull(headers, CorrelationContext.HEADER_TENANT_ID, ctx.tenantId());
        putIfNotNull(headers, CorrelationContext.HEADER_ENTITY_ID, ctx.entityId());
        putIfNotNull(headers, CorrelationContext.HEADER_ACTOR_IDENTITY, ctx.actorIdentity());
        if (ctx.actorType() != null) headers.put(CorrelationContext.HEADER_ACTOR_TYPE, ctx.actorType().getValue());
        putIfNotNull(headers, CorrelationContext.HEADER_SOURCE_MODULE, ctx.sourceModule());
        if (ctx.requestTimestamp() != null) {
            headers.put(CorrelationContext.HEADER_REQUEST_TIMESTAMP, ctx.requestTimestamp().toString());
        }
        return headers;
    }

    /**
     * Write headers using a consumer (adapter for different transport APIs).
     */
    public static void writeHeaders(CorrelationContext ctx, BiConsumer<String, String> headerWriter) {
        toHeaders(ctx).forEach(headerWriter);
    }

    /**
     * Deserialize context from a header reader function.
     */
    public static CorrelationContext fromHeaders(Function<String, String> headerReader) {
        String corrId = headerReader.apply(CorrelationContext.HEADER_CORRELATION_ID);
        if (corrId == null) return null;

        String causId = headerReader.apply(CorrelationContext.HEADER_CAUSATION_ID);
        String tsStr = headerReader.apply(CorrelationContext.HEADER_REQUEST_TIMESTAMP);
        String actorTypeStr = headerReader.apply(CorrelationContext.HEADER_ACTOR_TYPE);

        return new CorrelationContext(
            parseUuid(corrId),
            headerReader.apply(CorrelationContext.HEADER_TRACE_ID),
            headerReader.apply(CorrelationContext.HEADER_SPAN_ID),
            causId != null ? parseUuid(causId) : null,
            headerReader.apply(CorrelationContext.HEADER_TENANT_ID),
            headerReader.apply(CorrelationContext.HEADER_ENTITY_ID),
            headerReader.apply(CorrelationContext.HEADER_ACTOR_IDENTITY),
            actorTypeStr != null ? ActorType.fromValue(actorTypeStr) : null,
            headerReader.apply(CorrelationContext.HEADER_SOURCE_MODULE),
            tsStr != null ? Instant.parse(tsStr) : null
        );
    }

    /**
     * Deserialize context from a map of headers.
     */
    public static CorrelationContext fromHeaders(Map<String, String> headers) {
        if (headers == null || headers.isEmpty()) return null;
        return fromHeaders(headers::get);
    }

    private static void putIfNotNull(Map<String, String> map, String key, Object value) {
        if (value != null) map.put(key, value.toString());
    }

    private static UUID parseUuid(String str) {
        try { return UUID.fromString(str); } catch (Exception e) { return null; }
    }
}
