package com.paymenthub.observability.context;

import com.paymenthub.common.enums.ActorType;

import java.time.Instant;
import java.util.UUID;

/**
 * Immutable correlation context propagated across all payment hub modules.
 *
 * <p>Every inter-module call (NATS, gRPC, Kafka, REST) carries this context
 * via message headers. Within a module, it's available via
 * {@link CorrelationContextHolder} (InheritableThreadLocal / ScopedValue).</p>
 *
 * <h3>Fields</h3>
 * <ul>
 *   <li>{@code correlationId} — unique per end-to-end transaction.
 *       Set once by the entry point (API gateway, scheduler, webhook) and
 *       propagated unchanged through all downstream calls.</li>
 *   <li>{@code traceId} / {@code spanId} — OpenTelemetry trace context.
 *       Used for distributed tracing (Jaeger/Zipkin).</li>
 *   <li>{@code causationId} — the correlation ID of the upstream call
 *       that caused this operation. Forms a DAG of operations.</li>
 *   <li>{@code tenantId} / {@code entityId} — multi-tenant identity.
 *       Determines data routing, policy selection, and row-level security.</li>
 *   <li>{@code actorIdentity} / {@code actorType} — who initiated this.
 *       Propagated from the original authentication context.</li>
 *   <li>{@code sourceModule} — which module created this context.</li>
 *   <li>{@code requestTimestamp} — when the request entered the platform.</li>
 * </ul>
 *
 * <h3>Propagation</h3>
 * <p>The context is serialized to message headers using a standard prefix:</p>
 * <ul>
 *   <li>NATS: {@code X-Correlation-Id}, {@code X-Tenant-Id}, etc.</li>
 *   <li>Kafka: Same header names in Kafka record headers</li>
 *   <li>gRPC: Metadata keys with {@code x-} prefix</li>
 *   <li>HTTP: Standard request headers</li>
 * </ul>
 */
public record CorrelationContext(
    UUID correlationId,
    String traceId,
    String spanId,
    UUID causationId,
    String tenantId,
    String entityId,
    String actorIdentity,
    ActorType actorType,
    String sourceModule,
    Instant requestTimestamp
) {
    /** Header prefix for serialization. */
    public static final String HEADER_CORRELATION_ID = "X-Correlation-Id";
    public static final String HEADER_TRACE_ID = "X-Trace-Id";
    public static final String HEADER_SPAN_ID = "X-Span-Id";
    public static final String HEADER_CAUSATION_ID = "X-Causation-Id";
    public static final String HEADER_TENANT_ID = "X-Tenant-Id";
    public static final String HEADER_ENTITY_ID = "X-Entity-Id";
    public static final String HEADER_ACTOR_IDENTITY = "X-Actor-Identity";
    public static final String HEADER_ACTOR_TYPE = "X-Actor-Type";
    public static final String HEADER_SOURCE_MODULE = "X-Source-Module";
    public static final String HEADER_REQUEST_TIMESTAMP = "X-Request-Timestamp";

    /**
     * Create a new context for an incoming request (entry point).
     */
    public static CorrelationContext newRequest(String tenantId, String entityId,
                                                  String actorIdentity, ActorType actorType,
                                                  String sourceModule) {
        return new CorrelationContext(
            UUID.randomUUID(), null, null, null,
            tenantId, entityId, actorIdentity, actorType,
            sourceModule, Instant.now()
        );
    }

    /**
     * Derive a child context for a downstream call.
     * Preserves correlationId, sets causationId to this context's correlationId.
     */
    public CorrelationContext childContext(String newSourceModule) {
        return new CorrelationContext(
            correlationId, traceId, null, correlationId,
            tenantId, entityId, actorIdentity, actorType,
            newSourceModule, requestTimestamp
        );
    }

    /**
     * Create a copy with updated trace/span IDs (from OpenTelemetry).
     */
    public CorrelationContext withTrace(String traceId, String spanId) {
        return new CorrelationContext(
            correlationId, traceId, spanId, causationId,
            tenantId, entityId, actorIdentity, actorType,
            sourceModule, requestTimestamp
        );
    }

    /**
     * Create a copy with updated tenant context.
     */
    public CorrelationContext withTenant(String tenantId, String entityId) {
        return new CorrelationContext(
            correlationId, traceId, spanId, causationId,
            tenantId, entityId, actorIdentity, actorType,
            sourceModule, requestTimestamp
        );
    }

    /**
     * Create a copy with updated actor.
     */
    public CorrelationContext withActor(String actorIdentity, ActorType actorType) {
        return new CorrelationContext(
            correlationId, traceId, spanId, causationId,
            tenantId, entityId, actorIdentity, actorType,
            sourceModule, requestTimestamp
        );
    }
}
