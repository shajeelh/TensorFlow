package com.paymenthub.observability.context;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.util.Optional;

/**
 * Thread-local holder for {@link CorrelationContext}.
 *
 * <p>Uses {@link InheritableThreadLocal} to automatically propagate
 * context to child threads (including virtual threads spawned via
 * {@code Executors.newVirtualThreadPerTaskExecutor()}).</p>
 *
 * <h3>Usage</h3>
 * <pre>{@code
 * // Set context at entry point (filter, interceptor, NATS listener)
 * CorrelationContextHolder.set(context);
 * try {
 *     // Business logic — context available everywhere
 *     var ctx = CorrelationContextHolder.get();
 *     var tenantId = CorrelationContextHolder.getTenantId();
 * } finally {
 *     CorrelationContextHolder.clear();
 * }
 * }</pre>
 *
 * <h3>MDC Integration</h3>
 * <p>When context is set, key fields are pushed to SLF4J MDC for
 * automatic inclusion in log output:</p>
 * <ul>
 *   <li>{@code correlationId} — in every log line</li>
 *   <li>{@code tenantId} — for tenant-scoped log filtering</li>
 *   <li>{@code actorIdentity} — for user action tracing</li>
 *   <li>{@code sourceModule} — for module-scoped log filtering</li>
 * </ul>
 *
 * <h3>Thread Safety</h3>
 * <p>Thread-safe via ThreadLocal. Each thread has its own context.</p>
 */
public final class CorrelationContextHolder {

    private static final Logger log = LoggerFactory.getLogger(CorrelationContextHolder.class);

    private static final InheritableThreadLocal<CorrelationContext> CONTEXT =
        new InheritableThreadLocal<>();

    private CorrelationContextHolder() {}

    /**
     * Set the correlation context for the current thread.
     * Also pushes key fields to SLF4J MDC.
     */
    public static void set(CorrelationContext context) {
        CONTEXT.set(context);
        if (context != null) {
            pushToMdc(context);
        }
    }

    /**
     * Get the current correlation context.
     *
     * @return the context, or null if not set
     */
    public static CorrelationContext get() {
        return CONTEXT.get();
    }

    /**
     * Get the current context as an Optional.
     */
    public static Optional<CorrelationContext> current() {
        return Optional.ofNullable(CONTEXT.get());
    }

    /**
     * Get the current context, throwing if not set.
     *
     * @throws IllegalStateException if no context is set
     */
    public static CorrelationContext require() {
        CorrelationContext ctx = CONTEXT.get();
        if (ctx == null) {
            throw new IllegalStateException("No CorrelationContext set on current thread");
        }
        return ctx;
    }

    /**
     * Clear the context for the current thread.
     * Must be called in a finally block to prevent context leaks.
     */
    public static void clear() {
        CONTEXT.remove();
        clearMdc();
    }

    // ── Convenience accessors ────────────────────────────────

    /**
     * Get the current correlation ID, or null if no context.
     */
    public static String getCorrelationId() {
        CorrelationContext ctx = CONTEXT.get();
        return ctx != null && ctx.correlationId() != null
            ? ctx.correlationId().toString()
            : null;
    }

    /**
     * Get the current tenant ID, or null if no context.
     */
    public static String getTenantId() {
        CorrelationContext ctx = CONTEXT.get();
        return ctx != null ? ctx.tenantId() : null;
    }

    /**
     * Get the current entity ID, or null if no context.
     */
    public static String getEntityId() {
        CorrelationContext ctx = CONTEXT.get();
        return ctx != null ? ctx.entityId() : null;
    }

    /**
     * Get the current actor identity, or null if no context.
     */
    public static String getActorIdentity() {
        CorrelationContext ctx = CONTEXT.get();
        return ctx != null ? ctx.actorIdentity() : null;
    }

    /**
     * Execute a block with a specific context, restoring the previous
     * context afterward.
     */
    public static <T> T withContext(CorrelationContext context, java.util.function.Supplier<T> action) {
        CorrelationContext previous = CONTEXT.get();
        try {
            set(context);
            return action.get();
        } finally {
            if (previous != null) {
                set(previous);
            } else {
                clear();
            }
        }
    }

    /**
     * Execute a block with a specific context (void version).
     */
    public static void withContext(CorrelationContext context, Runnable action) {
        CorrelationContext previous = CONTEXT.get();
        try {
            set(context);
            action.run();
        } finally {
            if (previous != null) {
                set(previous);
            } else {
                clear();
            }
        }
    }

    // ── MDC integration ──────────────────────────────────────

    private static void pushToMdc(CorrelationContext ctx) {
        if (ctx.correlationId() != null) MDC.put("correlationId", ctx.correlationId().toString());
        if (ctx.tenantId() != null) MDC.put("tenantId", ctx.tenantId());
        if (ctx.entityId() != null) MDC.put("entityId", ctx.entityId());
        if (ctx.actorIdentity() != null) MDC.put("actorIdentity", ctx.actorIdentity());
        if (ctx.sourceModule() != null) MDC.put("sourceModule", ctx.sourceModule());
        if (ctx.traceId() != null) MDC.put("traceId", ctx.traceId());
        if (ctx.spanId() != null) MDC.put("spanId", ctx.spanId());
    }

    private static void clearMdc() {
        MDC.remove("correlationId");
        MDC.remove("tenantId");
        MDC.remove("entityId");
        MDC.remove("actorIdentity");
        MDC.remove("sourceModule");
        MDC.remove("traceId");
        MDC.remove("spanId");
    }
}
