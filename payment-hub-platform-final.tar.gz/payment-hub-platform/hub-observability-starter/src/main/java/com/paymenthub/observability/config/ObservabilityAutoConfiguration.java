package com.paymenthub.observability.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/**
 * Auto-configuration for observability starter.
 *
 * <h3>Configuration Properties</h3>
 * <pre>
 * hub.observability:
 *   module-name: payment-orchestration
 *   module-version: 2.1.0
 *   environment: production
 * </pre>
 */
@AutoConfiguration
@EnableConfigurationProperties(ObservabilityAutoConfiguration.ObservabilityProperties.class)
public class ObservabilityAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(ObservabilityAutoConfiguration.class);

    public ObservabilityAutoConfiguration(ObservabilityProperties props) {
        log.info("Observability configured: module={} v{}, env={}",
            props.getModuleName(), props.getModuleVersion(), props.getEnvironment());
    }

    @ConfigurationProperties(prefix = "hub.observability")
    public static class ObservabilityProperties {
        private String moduleName = "unknown";
        private String moduleVersion = "0.0.0";
        private String environment = "development";

        public String getModuleName() { return moduleName; }
        public void setModuleName(String v) { this.moduleName = v; }
        public String getModuleVersion() { return moduleVersion; }
        public void setModuleVersion(String v) { this.moduleVersion = v; }
        public String getEnvironment() { return environment; }
        public void setEnvironment(String v) { this.environment = v; }
    }
}
