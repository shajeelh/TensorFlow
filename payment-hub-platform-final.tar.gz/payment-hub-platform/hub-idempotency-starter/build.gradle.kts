plugins { `java-library` }
description = "Payment Hub — @Idempotent AOP annotation, Idempotency Key Store"
dependencies {
    api(project(":hub-common-model"))
    implementation(project(":hub-observability-starter"))
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("org.slf4j:slf4j-api")
    compileOnly("org.springframework:spring-context")
    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
