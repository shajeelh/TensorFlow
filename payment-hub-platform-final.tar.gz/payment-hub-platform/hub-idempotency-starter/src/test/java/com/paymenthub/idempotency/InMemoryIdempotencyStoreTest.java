package com.paymenthub.idempotency;

import com.paymenthub.idempotency.store.InMemoryIdempotencyStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Duration;

import static org.assertj.core.api.Assertions.*;

class InMemoryIdempotencyStoreTest {

    private InMemoryIdempotencyStore store;

    @BeforeEach
    void setUp() { store = new InMemoryIdempotencyStore(); }

    @Test
    @DisplayName("First acquire returns true, second returns false")
    void acquireOnce() {
        assertThat(store.tryAcquire("key-1", Duration.ofMinutes(5))).isTrue();
        assertThat(store.tryAcquire("key-1", Duration.ofMinutes(5))).isFalse();
    }

    @Test
    @DisplayName("Different keys are independent")
    void independentKeys() {
        assertThat(store.tryAcquire("key-1", Duration.ofMinutes(5))).isTrue();
        assertThat(store.tryAcquire("key-2", Duration.ofMinutes(5))).isTrue();
    }

    @Test
    @DisplayName("Store and retrieve result")
    void storeResult() {
        store.tryAcquire("key-1", Duration.ofMinutes(5));
        store.storeResult("key-1", "cached-result", Duration.ofMinutes(5));

        assertThat(store.getResult("key-1")).hasValue("cached-result");
    }

    @Test
    @DisplayName("Expired entries are evicted")
    void expiration() throws Exception {
        store.tryAcquire("key-1", Duration.ofMillis(50));
        Thread.sleep(100);
        // After expiration, acquire should succeed again
        assertThat(store.tryAcquire("key-1", Duration.ofMinutes(5))).isTrue();
    }

    @Test
    @DisplayName("Release removes entry")
    void release() {
        store.tryAcquire("key-1", Duration.ofMinutes(5));
        store.release("key-1");
        assertThat(store.tryAcquire("key-1", Duration.ofMinutes(5))).isTrue();
    }

    @Test
    @DisplayName("Missing key returns empty")
    void missing() {
        assertThat(store.getResult("nonexistent")).isEmpty();
    }
}
