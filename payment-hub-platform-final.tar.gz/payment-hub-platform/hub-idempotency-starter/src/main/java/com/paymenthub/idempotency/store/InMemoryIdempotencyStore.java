package com.paymenthub.idempotency.store;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory idempotency store for development and testing.
 * Uses a ConcurrentHashMap with TTL-based expiration.
 *
 * <p>Entries are lazily evicted on access. For production use,
 * prefer {@code RedisIdempotencyStore}.</p>
 */
public class InMemoryIdempotencyStore implements IdempotencyStore {

    private final Map<String, Entry> store = new ConcurrentHashMap<>();

    @Override
    public boolean tryAcquire(String key, Duration ttl) {
        evictExpired();
        Entry existing = store.putIfAbsent(key, new Entry(null, Instant.now().plus(ttl)));
        return existing == null;
    }

    @Override
    public void storeResult(String key, Object result, Duration ttl) {
        store.put(key, new Entry(result, Instant.now().plus(ttl)));
    }

    @Override
    public Optional<Object> getResult(String key) {
        Entry entry = store.get(key);
        if (entry == null || entry.isExpired()) {
            store.remove(key);
            return Optional.empty();
        }
        return Optional.ofNullable(entry.result);
    }

    @Override
    public void release(String key) {
        store.remove(key);
    }

    public int size() {
        evictExpired();
        return store.size();
    }

    private void evictExpired() {
        store.entrySet().removeIf(e -> e.getValue().isExpired());
    }

    private record Entry(Object result, Instant expiresAt) {
        boolean isExpired() { return Instant.now().isAfter(expiresAt); }
    }
}
