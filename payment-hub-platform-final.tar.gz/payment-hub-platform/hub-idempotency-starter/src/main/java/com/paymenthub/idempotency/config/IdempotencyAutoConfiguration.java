package com.paymenthub.idempotency.config;

import com.paymenthub.idempotency.store.IdempotencyStore;
import com.paymenthub.idempotency.store.InMemoryIdempotencyStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
public class IdempotencyAutoConfiguration {
    private static final Logger log = LoggerFactory.getLogger(IdempotencyAutoConfiguration.class);

    @Bean
    @ConditionalOnMissingBean
    public IdempotencyStore idempotencyStore() {
        log.warn("Using InMemoryIdempotencyStore — not suitable for production clusters");
        return new InMemoryIdempotencyStore();
    }
}
