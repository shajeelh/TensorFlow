package com.paymenthub.idempotency.annotation;

import java.lang.annotation.*;

/**
 * Marks a method as idempotent — duplicate calls with the same
 * idempotency key return the cached result without re-execution.
 *
 * <p>The idempotency key is extracted from method parameters via
 * {@code keyExpression} (SpEL) or defaults to the first parameter.</p>
 *
 * <p>Example:</p>
 * <pre>{@code
 * @Idempotent(keyExpression = "#event.idempotencyKey()", ttlMinutes = 60)
 * public AuditReceipt recordEvent(AuditEvent event) { ... }
 * }</pre>
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Idempotent {

    /** SpEL expression to extract the idempotency key. */
    String keyExpression() default "";

    /** How long to retain the cached result (minutes). Default: 60. */
    int ttlMinutes() default 60;

    /** Whether to throw on duplicate or return cached result. Default: return cached. */
    boolean throwOnDuplicate() default false;
}
