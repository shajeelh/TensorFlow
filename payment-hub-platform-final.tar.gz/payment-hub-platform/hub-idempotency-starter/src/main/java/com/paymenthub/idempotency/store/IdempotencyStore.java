package com.paymenthub.idempotency.store;

import java.time.Duration;
import java.util.Optional;

/**
 * Store for idempotency keys and their associated results.
 *
 * <p>Implementations:</p>
 * <ul>
 *   <li>{@link InMemoryIdempotencyStore} — ConcurrentHashMap with TTL (dev/test)</li>
 *   <li>{@code RedisIdempotencyStore} — Redis with TTL (production)</li>
 *   <li>{@code PostgresIdempotencyStore} — PostgreSQL upsert (if Redis unavailable)</li>
 * </ul>
 */
public interface IdempotencyStore {

    /**
     * Try to acquire the idempotency lock for a key.
     *
     * @param key the idempotency key
     * @param ttl time-to-live for the entry
     * @return true if the key was newly inserted (first call), false if already exists
     */
    boolean tryAcquire(String key, Duration ttl);

    /**
     * Store the result associated with an idempotency key.
     */
    void storeResult(String key, Object result, Duration ttl);

    /**
     * Retrieve the cached result for an idempotency key.
     */
    Optional<Object> getResult(String key);

    /**
     * Remove an idempotency key (e.g., on failure, allow retry).
     */
    void release(String key);
}
