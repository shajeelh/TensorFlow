plugins { `java-library` }
description = "Payment Hub — Multi-Tenant Context, Resolution, Row-Level Security, Repository Isolation"
dependencies {
    api(project(":hub-common-model"))
    implementation(project(":hub-observability-starter"))

    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("org.slf4j:slf4j-api")
    compileOnly("org.springframework:spring-web")
    compileOnly("org.springframework:spring-webmvc")
    compileOnly("org.springframework:spring-jdbc")
    compileOnly("jakarta.servlet:jakarta.servlet-api")

    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
