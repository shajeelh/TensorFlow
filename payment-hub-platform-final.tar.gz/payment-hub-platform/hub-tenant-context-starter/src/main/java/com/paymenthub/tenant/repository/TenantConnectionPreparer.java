package com.paymenthub.tenant.repository;

import com.paymenthub.tenant.context.TenantContextHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Prepares database connections with the current tenant context for
 * PostgreSQL Row-Level Security enforcement.
 *
 * <h3>How RLS Works</h3>
 * <p>PostgreSQL RLS policies reference a session variable to filter rows:</p>
 * <pre>{@code
 * -- Table definition
 * CREATE TABLE audit_events (
 *     id UUID PRIMARY KEY,
 *     tenant_id VARCHAR(64) NOT NULL,
 *     -- ... other columns
 * );
 *
 * -- Enable RLS
 * ALTER TABLE audit_events ENABLE ROW LEVEL SECURITY;
 *
 * -- Policy: users can only see rows matching their tenant
 * CREATE POLICY tenant_isolation ON audit_events
 *     USING (tenant_id = current_setting('app.current_tenant', true));
 *
 * -- Force policy on table owner too
 * ALTER TABLE audit_events FORCE ROW LEVEL SECURITY;
 * }</pre>
 *
 * <h3>Connection Preparation</h3>
 * <p>This class sets the session variable before the connection is used:</p>
 * <pre>{@code
 * SET LOCAL app.current_tenant = 'MB-001';
 * }</pre>
 *
 * <p>{@code SET LOCAL} scopes the setting to the current transaction.
 * When the transaction completes (commit or rollback), the setting is
 * automatically cleared — no cleanup needed.</p>
 *
 * <h3>Integration</h3>
 * <p>Called by the DataSource proxy or connection pool callback on every
 * connection checkout. Works with HikariCP's {@code connectionInitSql}
 * or as a Spring JDBC {@code ConnectionPreparer}.</p>
 */
public class TenantConnectionPreparer {

    private static final Logger log = LoggerFactory.getLogger(TenantConnectionPreparer.class);

    /**
     * PostgreSQL session variable name used by RLS policies.
     */
    public static final String SESSION_VARIABLE = "app.current_tenant";

    /**
     * Entity-level variable for more granular filtering.
     */
    public static final String ENTITY_VARIABLE = "app.current_entity";

    /**
     * Prepare a connection with the current tenant context.
     *
     * <p>Must be called within a thread that has a TenantContext set
     * via {@link TenantContextHolder}.</p>
     *
     * @param connection the JDBC connection to prepare
     * @throws SQLException if the SET command fails
     * @throws IllegalStateException if no tenant context is set
     */
    public void prepare(Connection connection) throws SQLException {
        String tenantId = TenantContextHolder.getTenantId();
        if (tenantId == null) {
            log.warn("No tenant context — skipping RLS variable. " +
                "Queries will be blocked by RLS policy.");
            return;
        }

        setSessionVariable(connection, SESSION_VARIABLE, tenantId);

        String entityId = TenantContextHolder.getEntityId();
        if (entityId != null) {
            setSessionVariable(connection, ENTITY_VARIABLE, entityId);
        }

        log.trace("Connection prepared for tenant='{}', entity='{}'", tenantId, entityId);
    }

    /**
     * Clear tenant context from a connection.
     * Called when returning connection to pool (defense in depth).
     */
    public void reset(Connection connection) throws SQLException {
        try (PreparedStatement stmt = connection.prepareStatement(
                "RESET " + SESSION_VARIABLE)) {
            stmt.execute();
        }
        try (PreparedStatement stmt = connection.prepareStatement(
                "RESET " + ENTITY_VARIABLE)) {
            stmt.execute();
        }
    }

    /**
     * Prepare a connection for a specific tenant (used by system jobs
     * that iterate over tenants).
     */
    public void prepareForTenant(Connection connection, String tenantId, String entityId)
            throws SQLException {
        setSessionVariable(connection, SESSION_VARIABLE, tenantId);
        if (entityId != null) {
            setSessionVariable(connection, ENTITY_VARIABLE, entityId);
        }
    }

    // ── Internal ─────────────────────────────────────────────

    private void setSessionVariable(Connection connection, String variable, String value)
            throws SQLException {
        // Use SET LOCAL so the setting is scoped to the current transaction
        // and automatically cleared on commit/rollback
        String sql = "SET LOCAL " + variable + " = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, value);
            stmt.execute();
        }
    }
}
