package com.paymenthub.tenant.resolver;

import com.paymenthub.tenant.context.TenantContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

/**
 * Resolves tenant from an API key via a key→tenant mapping.
 *
 * <p>Used for partner integrations that authenticate with static
 * API keys rather than OAuth2 tokens. The mapping is loaded from
 * configuration or a database at startup and cached.</p>
 *
 * <h3>Key Lookup</h3>
 * <p>The API key is read from the {@code X-API-Key} header. The resolver
 * looks it up in the mapping to find the associated tenant. If no mapping
 * exists, the resolver returns empty and the next resolver in the chain
 * is tried.</p>
 *
 * <h3>Security</h3>
 * <ul>
 *   <li>API keys are compared using constant-time comparison to prevent timing attacks</li>
 *   <li>Failed lookups are logged at WARN level for security monitoring</li>
 *   <li>The mapping is in-memory only — keys are never logged or serialized</li>
 * </ul>
 */
public class ApiKeyTenantResolver implements TenantResolver<Function<String, String>> {

    private static final Logger log = LoggerFactory.getLogger(ApiKeyTenantResolver.class);
    public static final String HEADER_API_KEY = "X-API-Key";

    private final Map<String, TenantContext> keyToTenant;

    public ApiKeyTenantResolver() {
        this.keyToTenant = new ConcurrentHashMap<>();
    }

    public ApiKeyTenantResolver(Map<String, TenantContext> initialMappings) {
        this.keyToTenant = new ConcurrentHashMap<>(initialMappings);
    }

    @Override
    public Optional<TenantContext> resolve(Function<String, String> headerReader) {
        String apiKey = headerReader.apply(HEADER_API_KEY);
        if (apiKey == null || apiKey.isBlank()) {
            return Optional.empty();
        }

        // Constant-time lookup: iterate all keys rather than hash lookup
        // to prevent timing-based key enumeration
        TenantContext match = null;
        for (Map.Entry<String, TenantContext> entry : keyToTenant.entrySet()) {
            if (constantTimeEquals(apiKey, entry.getKey())) {
                match = entry.getValue();
            }
        }

        if (match == null) {
            log.warn("API key lookup failed: key prefix={}...",
                apiKey.length() > 8 ? apiKey.substring(0, 8) : "***");
            return Optional.empty();
        }

        log.debug("Resolved tenant from API key: {}", match);
        return Optional.of(match);
    }

    /**
     * Register a new API key → tenant mapping.
     *
     * @param apiKey  the API key
     * @param context the tenant context for this key
     */
    public void registerKey(String apiKey, TenantContext context) {
        keyToTenant.put(apiKey, context);
        log.info("Registered API key for tenant: {}", context.tenantId());
    }

    /**
     * Revoke an API key.
     */
    public void revokeKey(String apiKey) {
        TenantContext removed = keyToTenant.remove(apiKey);
        if (removed != null) {
            log.info("Revoked API key for tenant: {}", removed.tenantId());
        }
    }

    /**
     * Get the number of registered keys.
     */
    public int registeredKeyCount() {
        return keyToTenant.size();
    }

    @Override
    public int priority() { return 75; } // Between header (50) and JWT (100)

    @Override
    public String name() { return "api-key"; }

    // ── Internal ─────────────────────────────────────────────

    /**
     * Constant-time string comparison to prevent timing attacks.
     */
    private static boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) return false;
        if (a.length() != b.length()) return false;
        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }
}
