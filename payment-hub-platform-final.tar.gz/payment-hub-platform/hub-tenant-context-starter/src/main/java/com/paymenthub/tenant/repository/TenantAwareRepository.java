package com.paymenthub.tenant.repository;

import com.paymenthub.common.exception.TenantIsolationViolationException;
import com.paymenthub.tenant.context.TenantContext;
import com.paymenthub.tenant.context.TenantContextHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

/**
 * Base class for tenant-aware data repositories.
 *
 * <p>Provides utilities for enforcing tenant isolation at the application
 * layer, complementing PostgreSQL Row-Level Security (RLS) at the DB layer.</p>
 *
 * <h3>Dual-Layer Isolation</h3>
 * <ol>
 *   <li><strong>Application layer</strong> (this class): validates that every
 *       query includes the correct tenant_id and that returned data belongs
 *       to the current tenant. This catches bugs early and provides clear
 *       error messages.</li>
 *   <li><strong>Database layer</strong> (PostgreSQL RLS): the DB connection sets
 *       {@code SET app.current_tenant = 'MB-001'} via
 *       {@link TenantConnectionPreparer}. RLS policies then filter all
 *       queries to only rows matching the current tenant. This is the
 *       defense-in-depth layer — even if the application layer has a bug,
 *       RLS prevents cross-tenant data access.</li>
 * </ol>
 *
 * <h3>Usage</h3>
 * <pre>{@code
 * public class AuditEventRepository extends TenantAwareRepository {
 *
 *     public List<AuditEvent> findByCorrelationId(String tenantId, UUID correlationId) {
 *         assertTenantContext(tenantId);  // Validates tenant match
 *         // query with tenant_id in WHERE clause
 *         return jdbcTemplate.query(
 *             "SELECT * FROM audit_events WHERE tenant_id = ? AND correlation_id = ?",
 *             mapper, tenantId, correlationId);
 *     }
 * }
 * }</pre>
 */
public abstract class TenantAwareRepository {

    private static final Logger log = LoggerFactory.getLogger(TenantAwareRepository.class);

    /**
     * Assert that the requested tenant matches the current context.
     * Call this at the top of every repository method.
     *
     * @param requestedTenantId the tenant ID in the query parameter
     * @throws TenantIsolationViolationException if mismatch
     * @throws IllegalStateException if no tenant context is set
     */
    protected void assertTenantContext(String requestedTenantId) {
        TenantContext ctx = TenantContextHolder.require();
        if (!ctx.tenantId().equals(requestedTenantId)) {
            log.error("SECURITY: Tenant isolation violation! " +
                "Context tenant='{}', requested tenant='{}'. " +
                "This is a P1 security incident.",
                ctx.tenantId(), requestedTenantId);
            throw new TenantIsolationViolationException(requestedTenantId, ctx.tenantId());
        }
    }

    /**
     * Get the current tenant ID for use in queries.
     * Ensures tenant context is set before any data access.
     *
     * @return the current tenant ID
     * @throws IllegalStateException if no tenant context is set
     */
    protected String currentTenantId() {
        return TenantContextHolder.require().tenantId();
    }

    /**
     * Get the current entity ID for use in queries.
     */
    protected String currentEntityId() {
        return TenantContextHolder.require().entityId();
    }

    /**
     * Validate that a data record belongs to the current tenant.
     * Call this after reading data from the database to catch RLS bypass bugs.
     *
     * @param dataTenantId the tenant_id field from the data record
     * @param recordId     the record identifier (for error messages)
     */
    protected void validateDataOwnership(String dataTenantId, String recordId) {
        String contextTenantId = currentTenantId();
        if (!Objects.equals(contextTenantId, dataTenantId)) {
            log.error("SECURITY: Data ownership violation! Record '{}' belongs to " +
                "tenant '{}' but current context is tenant '{}'. " +
                "Possible RLS bypass — investigate immediately.",
                recordId, dataTenantId, contextTenantId);
            throw new TenantIsolationViolationException(dataTenantId, contextTenantId);
        }
    }
}
