package com.paymenthub.tenant.resolver;

import com.paymenthub.tenant.context.TenantContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

/**
 * Resolves tenant context from HTTP headers or message headers.
 *
 * <p>This resolver is transport-agnostic — it works with any header source
 * via the {@link Function} adapter pattern. Convenience factories are provided
 * for common transports.</p>
 *
 * <h3>Header Names</h3>
 * <ul>
 *   <li>{@code X-Tenant-Id} — mandatory, identifies the tenant</li>
 *   <li>{@code X-Entity-Id} — optional, identifies the entity within the tenant</li>
 * </ul>
 *
 * <h3>Security Note</h3>
 * <p>This resolver trusts the header value. It should ONLY be used for
 * internal service-to-service calls on a trusted network (mTLS, service mesh).
 * For external requests, use {@link JwtClaimTenantResolver} which validates
 * the JWT signature before extracting the tenant claim.</p>
 */
public class HeaderTenantResolver implements TenantResolver<Function<String, String>> {

    private static final Logger log = LoggerFactory.getLogger(HeaderTenantResolver.class);

    public static final String HEADER_TENANT_ID = "X-Tenant-Id";
    public static final String HEADER_ENTITY_ID = "X-Entity-Id";
    public static final String HEADER_TENANT_NAME = "X-Tenant-Name";

    @Override
    public Optional<TenantContext> resolve(Function<String, String> headerReader) {
        String tenantId = headerReader.apply(HEADER_TENANT_ID);
        if (tenantId == null || tenantId.isBlank()) {
            return Optional.empty();
        }

        String entityId = headerReader.apply(HEADER_ENTITY_ID);
        String tenantName = headerReader.apply(HEADER_TENANT_NAME);

        TenantContext ctx = new TenantContext(
            tenantId.trim(),
            entityId != null ? entityId.trim() : null,
            tenantName,
            null,
            null
        );

        log.debug("Resolved tenant from header: {}", ctx);
        return Optional.of(ctx);
    }

    /**
     * Resolve from a Map of headers (e.g., NATS, Kafka).
     */
    public Optional<TenantContext> resolveFromMap(Map<String, String> headers) {
        if (headers == null || headers.isEmpty()) return Optional.empty();
        return resolve(headers::get);
    }

    @Override
    public int priority() { return 50; } // Higher priority than JWT (internal calls are trusted)

    @Override
    public String name() { return "header"; }
}
