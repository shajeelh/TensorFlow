package com.paymenthub.tenant.interceptor;

import com.paymenthub.tenant.context.TenantContext;
import com.paymenthub.tenant.context.TenantContextHolder;
import com.paymenthub.tenant.resolver.HeaderTenantResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Function;

/**
 * Propagates tenant context through NATS JetStream, Kafka, and gRPC headers.
 *
 * <h3>Outbound (Publishing)</h3>
 * <p>When a module publishes a message, the interceptor reads the current
 * {@link TenantContextHolder} and writes tenant headers onto the message:</p>
 * <ul>
 *   <li>{@code X-Tenant-Id} — tenant identifier</li>
 *   <li>{@code X-Entity-Id} — entity within tenant</li>
 * </ul>
 *
 * <h3>Inbound (Consuming)</h3>
 * <p>When a module receives a message, the interceptor reads the tenant
 * headers, resolves the {@link TenantContext}, and sets it on
 * {@link TenantContextHolder} before the handler processes the message.
 * The context is cleared after processing.</p>
 *
 * <h3>Transport Agnostic</h3>
 * <p>Uses {@link BiConsumer} for writing headers and {@link Function}
 * for reading headers, making it compatible with any transport that
 * supports string key-value headers.</p>
 */
public class NatsTenantInterceptor {

    private static final Logger log = LoggerFactory.getLogger(NatsTenantInterceptor.class);

    private final HeaderTenantResolver headerResolver;

    public NatsTenantInterceptor() {
        this.headerResolver = new HeaderTenantResolver();
    }

    // ── Outbound ─────────────────────────────────────────────

    /**
     * Write tenant context headers before publishing a message.
     *
     * @param headerWriter function that writes a header (key, value)
     * @throws IllegalStateException if no tenant context is set
     */
    public void writeOutboundHeaders(BiConsumer<String, String> headerWriter) {
        TenantContext ctx = TenantContextHolder.get();
        if (ctx == null) {
            log.warn("No tenant context when publishing message — headers will be empty");
            return;
        }

        headerWriter.accept(HeaderTenantResolver.HEADER_TENANT_ID, ctx.tenantId());
        if (ctx.entityId() != null) {
            headerWriter.accept(HeaderTenantResolver.HEADER_ENTITY_ID, ctx.entityId());
        }
        if (ctx.tenantName() != null) {
            headerWriter.accept(HeaderTenantResolver.HEADER_TENANT_NAME, ctx.tenantName());
        }

        log.trace("Wrote outbound tenant headers: tenant={}, entity={}",
            ctx.tenantId(), ctx.entityId());
    }

    /**
     * Get outbound headers as a Map (for transports that accept Map headers).
     */
    public Map<String, String> getOutboundHeaders() {
        Map<String, String> headers = new HashMap<>();
        writeOutboundHeaders(headers::put);
        return headers;
    }

    /**
     * Get outbound headers as byte arrays (for NATS native headers).
     */
    public Map<String, byte[]> getOutboundHeaderBytes() {
        Map<String, byte[]> headers = new HashMap<>();
        writeOutboundHeaders((k, v) ->
            headers.put(k, v.getBytes(StandardCharsets.UTF_8)));
        return headers;
    }

    // ── Inbound ──────────────────────────────────────────────

    /**
     * Read tenant context from inbound message headers and set on context holder.
     *
     * @param headerReader function that reads a header value by name
     * @return the resolved tenant context, or empty if no tenant headers present
     */
    public Optional<TenantContext> readInboundHeaders(Function<String, String> headerReader) {
        Optional<TenantContext> resolved = headerResolver.resolve(headerReader);

        if (resolved.isPresent()) {
            TenantContextHolder.set(resolved.get());
            log.trace("Set inbound tenant context: {}", resolved.get());
        } else {
            log.warn("No tenant context in inbound message headers");
        }

        return resolved;
    }

    /**
     * Read from a Map of string headers.
     */
    public Optional<TenantContext> readInboundHeaders(Map<String, String> headers) {
        if (headers == null) return Optional.empty();
        return readInboundHeaders(headers::get);
    }

    /**
     * Read from byte array headers (NATS native).
     */
    public Optional<TenantContext> readInboundHeaderBytes(Map<String, byte[]> headers) {
        if (headers == null) return Optional.empty();
        return readInboundHeaders(key -> {
            byte[] value = headers.get(key);
            return value != null ? new String(value, StandardCharsets.UTF_8) : null;
        });
    }

    // ── Scoped Processing ────────────────────────────────────

    /**
     * Process a message with tenant context from its headers.
     * Sets context before processing and clears it after.
     *
     * @param headerReader function to read message headers
     * @param processor    the message processing logic
     * @throws IllegalStateException if tenant headers are missing and required
     */
    public void processWithTenantContext(Function<String, String> headerReader,
                                          Runnable processor) {
        try {
            Optional<TenantContext> ctx = readInboundHeaders(headerReader);
            if (ctx.isEmpty()) {
                throw new IllegalStateException(
                    "Tenant context required for message processing but not found in headers");
            }
            processor.run();
        } finally {
            TenantContextHolder.clear();
        }
    }
}
