package com.paymenthub.tenant.context;

import com.paymenthub.common.exception.TenantIsolationViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.util.Objects;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Thread-local holder for {@link TenantContext} with MDC integration
 * and cross-tenant access protection.
 *
 * <h3>Lifecycle</h3>
 * <ol>
 *   <li>{@link #set(TenantContext)} — called by servlet filter, NATS listener,
 *       Kafka consumer, or gRPC interceptor at request entry</li>
 *   <li>{@link #get()} / {@link #require()} — called by any code that needs
 *       the tenant context (repositories, services, audit pipeline)</li>
 *   <li>{@link #clear()} — called in a {@code finally} block at request exit</li>
 * </ol>
 *
 * <h3>Leak Detection</h3>
 * <p>If {@code set()} is called when a context is already present from a
 * different request (indicating a thread pool reuse without proper cleanup),
 * a warning is logged. This helps catch missing {@code clear()} calls.</p>
 *
 * <h3>MDC Integration</h3>
 * <p>When tenant context is set, {@code tenantId} and {@code entityId} are
 * pushed to SLF4J MDC for automatic inclusion in every log line.</p>
 */
public final class TenantContextHolder {

    private static final Logger log = LoggerFactory.getLogger(TenantContextHolder.class);

    private static final InheritableThreadLocal<TenantContext> CONTEXT =
        new InheritableThreadLocal<>();

    private TenantContextHolder() {}

    // ── Core Operations ──────────────────────────────────────

    /**
     * Set the tenant context for the current thread.
     *
     * @param context the tenant context (must not be null)
     * @throws NullPointerException if context is null
     */
    public static void set(TenantContext context) {
        Objects.requireNonNull(context, "TenantContext must not be null");

        // Leak detection: warn if overwriting without clear
        TenantContext existing = CONTEXT.get();
        if (existing != null && !existing.tenantId().equals(context.tenantId())) {
            log.warn("Overwriting tenant context without clear(): {} → {}. " +
                "Possible thread pool leak.", existing.tenantId(), context.tenantId());
        }

        CONTEXT.set(context);
        pushToMdc(context);
    }

    /**
     * Get the current tenant context.
     *
     * @return the context, or null if not set
     */
    public static TenantContext get() {
        return CONTEXT.get();
    }

    /**
     * Get the current context as Optional.
     */
    public static Optional<TenantContext> current() {
        return Optional.ofNullable(CONTEXT.get());
    }

    /**
     * Get the current context, throwing if not set.
     *
     * @return the tenant context
     * @throws IllegalStateException if no context is set
     */
    public static TenantContext require() {
        TenantContext ctx = CONTEXT.get();
        if (ctx == null) {
            throw new IllegalStateException(
                "No TenantContext set. Ensure TenantContextFilter is configured " +
                "or context is manually set before data access.");
        }
        return ctx;
    }

    /**
     * Clear the tenant context. MUST be called in a finally block.
     */
    public static void clear() {
        CONTEXT.remove();
        clearMdc();
    }

    // ── Convenience Accessors ────────────────────────────────

    /**
     * Get the current tenant ID, or null if no context.
     */
    public static String getTenantId() {
        TenantContext ctx = CONTEXT.get();
        return ctx != null ? ctx.tenantId() : null;
    }

    /**
     * Get the current entity ID, or null if no context.
     */
    public static String getEntityId() {
        TenantContext ctx = CONTEXT.get();
        return ctx != null ? ctx.entityId() : null;
    }

    // ── Isolation Enforcement ────────────────────────────────

    /**
     * Assert that the current context matches the requested tenant.
     * This is the primary isolation enforcement point called by repositories.
     *
     * @param requestedTenantId the tenant ID being accessed
     * @throws TenantIsolationViolationException if mismatch
     * @throws IllegalStateException if no tenant context is set
     */
    public static void assertTenant(String requestedTenantId) {
        TenantContext ctx = require();
        ctx.assertTenantMatch(requestedTenantId);
    }

    /**
     * Assert that data belongs to the current tenant.
     * Convenience for checking a data object's tenant field.
     *
     * @param dataTenantId tenant ID from the data being accessed
     * @throws TenantIsolationViolationException if the data doesn't belong to current tenant
     */
    public static void assertDataBelongsToCurrentTenant(String dataTenantId) {
        assertTenant(dataTenantId);
    }

    // ── Scoped Execution ─────────────────────────────────────

    /**
     * Execute a block within a specific tenant context, restoring
     * the previous context afterward.
     *
     * <p>Used for cross-entity operations within the same tenant,
     * or for system operations that need to impersonate a tenant.</p>
     */
    public static <T> T withTenant(TenantContext context, Supplier<T> action) {
        TenantContext previous = CONTEXT.get();
        try {
            set(context);
            return action.get();
        } finally {
            if (previous != null) {
                set(previous);
            } else {
                clear();
            }
        }
    }

    /**
     * Execute a void block within a specific tenant context.
     */
    public static void withTenant(TenantContext context, Runnable action) {
        TenantContext previous = CONTEXT.get();
        try {
            set(context);
            action.run();
        } finally {
            if (previous != null) {
                set(previous);
            } else {
                clear();
            }
        }
    }

    // ── MDC Integration ──────────────────────────────────────

    private static void pushToMdc(TenantContext ctx) {
        MDC.put("tenantId", ctx.tenantId());
        MDC.put("entityId", ctx.entityId());
    }

    private static void clearMdc() {
        MDC.remove("tenantId");
        MDC.remove("entityId");
    }
}
