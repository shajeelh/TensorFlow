package com.paymenthub.tenant.filter;

import com.paymenthub.tenant.context.TenantContext;
import com.paymenthub.tenant.context.TenantContextHolder;
import com.paymenthub.tenant.resolver.CompositeTenantResolver;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Optional;
import java.util.Set;

/**
 * Servlet filter that resolves and sets the {@link TenantContext} for every
 * incoming HTTP request.
 *
 * <h3>Processing Flow</h3>
 * <ol>
 *   <li>Check if the request path is in the exclusion set (health, metrics, etc.)</li>
 *   <li>Resolve tenant using {@link CompositeTenantResolver}</li>
 *   <li>If resolved: set {@link TenantContextHolder}, continue filter chain</li>
 *   <li>If not resolved: return 401 Unauthorized (tenant is mandatory)</li>
 *   <li>Always clear context in finally block (prevent thread pool leaks)</li>
 * </ol>
 *
 * <h3>Excluded Paths</h3>
 * <p>The following paths do not require tenant context:</p>
 * <ul>
 *   <li>{@code /actuator/**} — health checks, metrics, info</li>
 *   <li>{@code /health} — load balancer health check</li>
 *   <li>{@code /readyz} — Kubernetes readiness probe</li>
 *   <li>{@code /livez} — Kubernetes liveness probe</li>
 * </ul>
 *
 * <h3>Error Response</h3>
 * <p>When tenant context cannot be resolved, the filter returns:</p>
 * <pre>{@code HTTP 401 Unauthorized
 * Content-Type: application/json
 * {"errorCode":"TENANT-0003","message":"Tenant context required"}}</pre>
 */
public class TenantContextFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(TenantContextFilter.class);

    private static final Set<String> DEFAULT_EXCLUDED_PREFIXES = Set.of(
        "/actuator", "/health", "/readyz", "/livez", "/favicon.ico"
    );

    private static final String ERROR_RESPONSE_BODY =
        "{\"errorCode\":\"TENANT-0003\",\"message\":\"Tenant context required. " +
        "Provide X-Tenant-Id header, API key, or JWT with tenant_id claim.\"}";

    private final CompositeTenantResolver resolver;
    private final Set<String> excludedPrefixes;
    private final boolean tenantRequired;

    /**
     * Create with default settings (tenant required, default exclusions).
     */
    public TenantContextFilter(CompositeTenantResolver resolver) {
        this(resolver, DEFAULT_EXCLUDED_PREFIXES, true);
    }

    /**
     * Create with custom exclusions and requirement settings.
     */
    public TenantContextFilter(CompositeTenantResolver resolver,
                                Set<String> excludedPrefixes,
                                boolean tenantRequired) {
        this.resolver = resolver;
        this.excludedPrefixes = excludedPrefixes;
        this.tenantRequired = tenantRequired;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                     HttpServletResponse response,
                                     FilterChain chain)
            throws ServletException, IOException {

        String path = request.getRequestURI();

        // Skip excluded paths
        if (isExcluded(path)) {
            chain.doFilter(request, response);
            return;
        }

        try {
            Optional<TenantContext> resolved = resolver.resolve(request::getHeader);

            if (resolved.isPresent()) {
                TenantContextHolder.set(resolved.get());
                log.trace("Tenant context set for {}: {}", path, resolved.get());
                chain.doFilter(request, response);

            } else if (tenantRequired) {
                log.warn("Tenant context required but not resolved for {} {} from {}",
                    request.getMethod(), path, request.getRemoteAddr());
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write(ERROR_RESPONSE_BODY);

            } else {
                // Tenant not required — continue without context
                log.trace("No tenant context for {} (not required)", path);
                chain.doFilter(request, response);
            }

        } finally {
            TenantContextHolder.clear();
        }
    }

    private boolean isExcluded(String path) {
        for (String prefix : excludedPrefixes) {
            if (path.startsWith(prefix)) return true;
        }
        return false;
    }
}
