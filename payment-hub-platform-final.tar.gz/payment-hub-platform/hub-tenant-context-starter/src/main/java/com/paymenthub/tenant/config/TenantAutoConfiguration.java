package com.paymenthub.tenant.config;

import com.paymenthub.tenant.interceptor.NatsTenantInterceptor;
import com.paymenthub.tenant.repository.TenantConnectionPreparer;
import com.paymenthub.tenant.resolver.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

import java.util.List;

/**
 * Auto-configuration for multi-tenant context management.
 *
 * <h3>Configuration Properties</h3>
 * <pre>
 * hub.tenant:
 *   required: true                          # Reject requests without tenant context
 *   jwt-claim-names:
 *     tenant-id: tenant_id                  # JWT claim for tenant ID
 *     entity-id: entity_id                  # JWT claim for entity ID
 *   resolvers:
 *     header: true                          # Enable X-Tenant-Id header resolver
 *     jwt: true                             # Enable JWT claim resolver
 *     api-key: false                        # Enable API key resolver
 * </pre>
 */
@AutoConfiguration
@EnableConfigurationProperties(TenantAutoConfiguration.TenantProperties.class)
public class TenantAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(TenantAutoConfiguration.class);

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(name = "hub.tenant.resolvers.header", havingValue = "true", matchIfMissing = true)
    public HeaderTenantResolver headerTenantResolver() {
        return new HeaderTenantResolver();
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(name = "hub.tenant.resolvers.jwt", havingValue = "true", matchIfMissing = true)
    public JwtClaimTenantResolver jwtClaimTenantResolver(TenantProperties props) {
        return new JwtClaimTenantResolver(
            props.getJwtClaimNames().getTenantId(),
            props.getJwtClaimNames().getEntityId(),
            props.getJwtClaimNames().getTenantName(),
            props.getJwtClaimNames().getFeatures()
        );
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(name = "hub.tenant.resolvers.api-key", havingValue = "true")
    public ApiKeyTenantResolver apiKeyTenantResolver() {
        return new ApiKeyTenantResolver();
    }

    @SuppressWarnings("rawtypes")
    @Bean
    @ConditionalOnMissingBean
    public CompositeTenantResolver compositeTenantResolver(List<TenantResolver> resolvers) {
        log.info("Configuring composite tenant resolver with {} resolvers", resolvers.size());
        return new CompositeTenantResolver(resolvers);
    }

    @Bean
    @ConditionalOnMissingBean
    public TenantConnectionPreparer tenantConnectionPreparer() {
        return new TenantConnectionPreparer();
    }

    @Bean
    @ConditionalOnMissingBean
    public NatsTenantInterceptor natsTenantInterceptor() {
        return new NatsTenantInterceptor();
    }

    // ── Configuration Properties ─────────────────────────────

    @ConfigurationProperties(prefix = "hub.tenant")
    public static class TenantProperties {

        /** Whether tenant context is required for all requests. Default: true. */
        private boolean required = true;

        /** JWT claim name configuration. */
        private JwtClaimNames jwtClaimNames = new JwtClaimNames();

        /** Resolver enablement flags. */
        private Resolvers resolvers = new Resolvers();

        public boolean isRequired() { return required; }
        public void setRequired(boolean v) { this.required = v; }
        public JwtClaimNames getJwtClaimNames() { return jwtClaimNames; }
        public void setJwtClaimNames(JwtClaimNames v) { this.jwtClaimNames = v; }
        public Resolvers getResolvers() { return resolvers; }
        public void setResolvers(Resolvers v) { this.resolvers = v; }

        public static class JwtClaimNames {
            private String tenantId = "tenant_id";
            private String entityId = "entity_id";
            private String tenantName = "tenant_name";
            private String features = "features";

            public String getTenantId() { return tenantId; }
            public void setTenantId(String v) { this.tenantId = v; }
            public String getEntityId() { return entityId; }
            public void setEntityId(String v) { this.entityId = v; }
            public String getTenantName() { return tenantName; }
            public void setTenantName(String v) { this.tenantName = v; }
            public String getFeatures() { return features; }
            public void setFeatures(String v) { this.features = v; }
        }

        public static class Resolvers {
            private boolean header = true;
            private boolean jwt = true;
            private boolean apiKey = false;

            public boolean isHeader() { return header; }
            public void setHeader(boolean v) { this.header = v; }
            public boolean isJwt() { return jwt; }
            public void setJwt(boolean v) { this.jwt = v; }
            public boolean isApiKey() { return apiKey; }
            public void setApiKey(boolean v) { this.apiKey = v; }
        }
    }
}
