package com.paymenthub.tenant.resolver;

import com.paymenthub.tenant.context.TenantContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.function.Function;

/**
 * Resolves tenant context from JWT token claims.
 *
 * <p>Used for external API requests authenticated via OAuth2/OIDC.
 * The JWT is expected to contain:</p>
 * <ul>
 *   <li>{@code tenant_id} — mandatory claim identifying the tenant</li>
 *   <li>{@code entity_id} — optional claim identifying the entity</li>
 *   <li>{@code tenant_name} — optional human-readable name</li>
 *   <li>{@code features} — optional comma-separated feature flags</li>
 * </ul>
 *
 * <h3>JWT Validation</h3>
 * <p>This resolver does NOT validate the JWT signature — that is
 * handled by Spring Security's OAuth2 resource server filter which
 * runs before the tenant resolution filter. By the time this resolver
 * is called, the JWT has been verified and the claims are trusted.</p>
 *
 * <p>The resolver works with a generic claim reader function, making
 * it testable and transport-agnostic (works with any JWT library).</p>
 */
public class JwtClaimTenantResolver implements TenantResolver<Function<String, Object>> {

    private static final Logger log = LoggerFactory.getLogger(JwtClaimTenantResolver.class);

    private final String tenantIdClaim;
    private final String entityIdClaim;
    private final String tenantNameClaim;
    private final String featuresClaim;

    /**
     * Create with default claim names.
     */
    public JwtClaimTenantResolver() {
        this("tenant_id", "entity_id", "tenant_name", "features");
    }

    /**
     * Create with custom claim names.
     */
    public JwtClaimTenantResolver(String tenantIdClaim, String entityIdClaim,
                                    String tenantNameClaim, String featuresClaim) {
        this.tenantIdClaim = tenantIdClaim;
        this.entityIdClaim = entityIdClaim;
        this.tenantNameClaim = tenantNameClaim;
        this.featuresClaim = featuresClaim;
    }

    @Override
    public Optional<TenantContext> resolve(Function<String, Object> claimReader) {
        Object tenantIdObj = claimReader.apply(tenantIdClaim);
        if (tenantIdObj == null) {
            return Optional.empty();
        }

        String tenantId = tenantIdObj.toString().trim();
        if (tenantId.isBlank()) {
            log.warn("JWT contains blank tenant_id claim");
            return Optional.empty();
        }

        String entityId = readStringClaim(claimReader, entityIdClaim);
        String tenantName = readStringClaim(claimReader, tenantNameClaim);
        Set<String> features = readFeaturesClaim(claimReader);

        TenantContext ctx = new TenantContext(tenantId, entityId, tenantName, features, null);
        log.debug("Resolved tenant from JWT: {}", ctx);
        return Optional.of(ctx);
    }

    @Override
    public int priority() { return 100; }

    @Override
    public String name() { return "jwt-claim"; }

    // ── Internal ─────────────────────────────────────────────

    private String readStringClaim(Function<String, Object> reader, String claim) {
        Object value = reader.apply(claim);
        return value != null ? value.toString().trim() : null;
    }

    @SuppressWarnings("unchecked")
    private Set<String> readFeaturesClaim(Function<String, Object> reader) {
        Object value = reader.apply(featuresClaim);
        if (value == null) return Set.of();

        if (value instanceof Collection<?> collection) {
            Set<String> result = new HashSet<>();
            for (Object item : collection) {
                if (item != null) result.add(item.toString());
            }
            return result;
        }

        if (value instanceof String str) {
            if (str.isBlank()) return Set.of();
            return Set.of(str.split(","));
        }

        return Set.of();
    }
}
