package com.paymenthub.tenant.resolver;

import com.paymenthub.tenant.context.TenantContext;

import java.util.Optional;

/**
 * Strategy interface for resolving the tenant identity from an incoming request.
 *
 * <p>Multiple resolvers can be chained in priority order by the
 * {@link CompositeTenantResolver}. The first resolver that returns
 * a non-empty result wins.</p>
 *
 * <h3>Built-in Implementations</h3>
 * <ul>
 *   <li>{@link HeaderTenantResolver} — resolves from {@code X-Tenant-Id} HTTP header.
 *       Used for internal service-to-service calls where the calling module has
 *       already authenticated the tenant.</li>
 *   <li>{@link JwtClaimTenantResolver} — resolves from JWT {@code tenant_id} claim.
 *       Used for external API requests authenticated via OAuth2/OIDC.</li>
 *   <li>{@link ApiKeyTenantResolver} — resolves from API key lookup.
 *       Used for partner integrations with static API keys.</li>
 * </ul>
 *
 * <h3>Custom Implementations</h3>
 * <p>Register a custom resolver as a Spring bean. It will be picked up
 * by the auto-configuration and added to the composite chain.</p>
 *
 * @param <R> the request type (e.g., {@code HttpServletRequest}, NATS Message, Kafka ConsumerRecord)
 */
public interface TenantResolver<R> {

    /**
     * Attempt to resolve the tenant from the given request.
     *
     * @param request the incoming request
     * @return resolved tenant context, or empty if this resolver cannot determine the tenant
     */
    Optional<TenantContext> resolve(R request);

    /**
     * The priority of this resolver. Lower values = higher priority.
     * Default: 100.
     */
    default int priority() {
        return 100;
    }

    /**
     * Human-readable name for logging and diagnostics.
     */
    String name();
}
