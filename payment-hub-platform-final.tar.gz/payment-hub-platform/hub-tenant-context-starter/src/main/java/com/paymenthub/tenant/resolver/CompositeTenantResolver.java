package com.paymenthub.tenant.resolver;

import com.paymenthub.tenant.context.TenantContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.function.Function;

/**
 * Chains multiple {@link TenantResolver} instances in priority order.
 *
 * <p>Resolution stops at the first resolver that returns a non-empty result.
 * If no resolver can determine the tenant, the composite returns empty.</p>
 *
 * <p>Default chain order (by priority):</p>
 * <ol>
 *   <li>HeaderTenantResolver (50) — trusted internal headers</li>
 *   <li>ApiKeyTenantResolver (75) — partner API keys</li>
 *   <li>JwtClaimTenantResolver (100) — external JWT claims</li>
 * </ol>
 */
public class CompositeTenantResolver {

    private static final Logger log = LoggerFactory.getLogger(CompositeTenantResolver.class);

    private final List<ResolverEntry> resolvers;

    /**
     * Create with a list of resolvers. They will be sorted by priority.
     */
    @SuppressWarnings("rawtypes")
    public CompositeTenantResolver(List<TenantResolver> resolvers) {
        this.resolvers = new ArrayList<>();
        for (TenantResolver resolver : resolvers) {
            this.resolvers.add(new ResolverEntry(resolver));
        }
        this.resolvers.sort(Comparator.comparingInt(e -> e.priority));
        log.info("Tenant resolver chain configured: {}",
            this.resolvers.stream().map(e -> e.name + "(" + e.priority + ")").toList());
    }

    /**
     * Resolve tenant by trying each resolver in priority order.
     *
     * @param headerReader function that reads a header value by name
     * @return resolved tenant context, or empty if no resolver succeeded
     */
    public Optional<TenantContext> resolve(Function<String, String> headerReader) {
        for (ResolverEntry entry : resolvers) {
            try {
                @SuppressWarnings("unchecked")
                Optional<TenantContext> result = entry.resolver.resolve(headerReader);
                if (result.isPresent()) {
                    log.trace("Tenant resolved by '{}': {}", entry.name, result.get());
                    return result;
                }
            } catch (Exception e) {
                log.warn("Resolver '{}' threw exception: {}", entry.name, e.getMessage());
            }
        }

        log.debug("No resolver could determine tenant from request");
        return Optional.empty();
    }

    /**
     * Resolve from a Map of headers.
     */
    public Optional<TenantContext> resolveFromMap(Map<String, String> headers) {
        if (headers == null) return Optional.empty();
        return resolve(headers::get);
    }

    public int resolverCount() { return resolvers.size(); }

    @SuppressWarnings("rawtypes")
    private record ResolverEntry(TenantResolver resolver, String name, int priority) {
        ResolverEntry(TenantResolver resolver) {
            this(resolver, resolver.name(), resolver.priority());
        }
    }
}
