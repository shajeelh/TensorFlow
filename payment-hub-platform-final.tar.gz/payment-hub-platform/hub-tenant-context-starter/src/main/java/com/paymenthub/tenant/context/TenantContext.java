package com.paymenthub.tenant.context;

import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Immutable tenant identity context propagated through every operation.
 *
 * <p>The payment hub uses a two-level multi-tenancy model:</p>
 * <ul>
 *   <li><strong>Tenant</strong> — top-level organizational boundary
 *       (e.g., "MB-001" = MegaBank). All data is partitioned by tenant.
 *       PostgreSQL Row-Level Security enforces isolation at the DB layer.</li>
 *   <li><strong>Entity</strong> — subdivision within a tenant
 *       (e.g., "MAIN_BANK", "SUBSIDIARY_EU"). Entities share a tenant's
 *       infrastructure but have independent audit chains and policies.</li>
 * </ul>
 *
 * <h3>Resolution</h3>
 * <p>Tenant context is resolved at the platform entry point by
 * {@link com.paymenthub.tenant.resolver.TenantResolver} and set via
 * {@link TenantContextHolder}. It flows through:</p>
 * <ul>
 *   <li>HTTP requests — resolved from JWT claims or API key</li>
 *   <li>NATS messages — propagated in message headers</li>
 *   <li>Kafka records — propagated in record headers</li>
 *   <li>gRPC calls — propagated in metadata</li>
 *   <li>Scheduled jobs — set from job configuration</li>
 * </ul>
 *
 * <h3>Security Invariants</h3>
 * <ul>
 *   <li>Every database query includes {@code tenant_id} in WHERE clause</li>
 *   <li>Cross-tenant access throws {@code TenantIsolationViolationException}</li>
 *   <li>Tenant context must be set before any data access</li>
 *   <li>Tenant context is immutable — changing tenant requires explicit transition</li>
 * </ul>
 *
 * @param tenantId    unique tenant identifier (e.g., "MB-001")
 * @param entityId    entity within the tenant (e.g., "MAIN_BANK")
 * @param tenantName  human-readable tenant name (for logging only)
 * @param features    enabled feature flags for this tenant
 * @param metadata    additional tenant-specific configuration
 */
public record TenantContext(
    String tenantId,
    String entityId,
    String tenantName,
    Set<String> features,
    Map<String, String> metadata
) {
    /**
     * Canonical constructor with validation.
     */
    public TenantContext {
        Objects.requireNonNull(tenantId, "tenantId is required");
        if (tenantId.isBlank()) throw new IllegalArgumentException("tenantId must not be blank");
        entityId = entityId != null ? entityId : tenantId;
        tenantName = tenantName != null ? tenantName : tenantId;
        features = features != null ? Set.copyOf(features) : Set.of();
        metadata = metadata != null ? Map.copyOf(metadata) : Map.of();
    }

    /**
     * Simple factory for the common case.
     */
    public static TenantContext of(String tenantId, String entityId) {
        return new TenantContext(tenantId, entityId, null, null, null);
    }

    /**
     * Minimal factory with tenant ID only (entity defaults to tenant).
     */
    public static TenantContext of(String tenantId) {
        return of(tenantId, tenantId);
    }

    /**
     * Check if a specific feature is enabled for this tenant.
     */
    public boolean hasFeature(String feature) {
        return features.contains(feature);
    }

    /**
     * Get a metadata value with a default.
     */
    public String metadata(String key, String defaultValue) {
        return metadata.getOrDefault(key, defaultValue);
    }

    /**
     * Verify that a requested tenant ID matches this context.
     * This is the core isolation check.
     *
     * @param requestedTenantId the tenant ID being accessed
     * @throws com.paymenthub.common.exception.TenantIsolationViolationException if mismatch
     */
    public void assertTenantMatch(String requestedTenantId) {
        if (!tenantId.equals(requestedTenantId)) {
            throw new com.paymenthub.common.exception.TenantIsolationViolationException(
                requestedTenantId, tenantId);
        }
    }

    /**
     * Create a derived context for a different entity within the same tenant.
     */
    public TenantContext withEntity(String newEntityId) {
        return new TenantContext(tenantId, newEntityId, tenantName, features, metadata);
    }

    @Override
    public String toString() {
        return "TenantContext{tenant='%s', entity='%s'}".formatted(tenantId, entityId);
    }
}
