package com.paymenthub.tenant.resolver;

import com.paymenthub.tenant.context.TenantContext;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.assertj.core.api.Assertions.*;

class TenantResolverTest {

    @Nested
    @DisplayName("HeaderTenantResolver")
    class HeaderTests {

        private final HeaderTenantResolver resolver = new HeaderTenantResolver();

        @Test
        @DisplayName("Resolves tenant from X-Tenant-Id header")
        void resolveFromHeader() {
            Map<String, String> headers = Map.of(
                "X-Tenant-Id", "MB-001",
                "X-Entity-Id", "MAIN_BANK"
            );

            var ctx = resolver.resolveFromMap(headers);
            assertThat(ctx).isPresent();
            assertThat(ctx.get().tenantId()).isEqualTo("MB-001");
            assertThat(ctx.get().entityId()).isEqualTo("MAIN_BANK");
        }

        @Test
        @DisplayName("Returns empty when X-Tenant-Id is missing")
        void missingHeader() {
            assertThat(resolver.resolveFromMap(Map.of("X-Other", "value"))).isEmpty();
        }

        @Test
        @DisplayName("Returns empty for blank tenant ID")
        void blankTenantId() {
            assertThat(resolver.resolveFromMap(Map.of("X-Tenant-Id", "  "))).isEmpty();
        }

        @Test
        @DisplayName("Entity defaults to tenant when not provided")
        void entityDefaultsToTenant() {
            var ctx = resolver.resolveFromMap(Map.of("X-Tenant-Id", "MB-001"));
            assertThat(ctx).isPresent();
            assertThat(ctx.get().entityId()).isEqualTo("MB-001");
        }

        @Test
        @DisplayName("Null map returns empty")
        void nullMap() {
            assertThat(resolver.resolveFromMap(null)).isEmpty();
        }

        @Test
        @DisplayName("Priority is 50")
        void priority() {
            assertThat(resolver.priority()).isEqualTo(50);
        }
    }

    @Nested
    @DisplayName("JwtClaimTenantResolver")
    class JwtTests {

        private final JwtClaimTenantResolver resolver = new JwtClaimTenantResolver();

        @Test
        @DisplayName("Resolves tenant from JWT claims")
        void resolveFromClaims() {
            Map<String, Object> claims = Map.of(
                "tenant_id", "MB-001",
                "entity_id", "SUBSIDIARY_EU",
                "tenant_name", "MegaBank",
                "features", "REAL_TIME_AUDIT,PCI_DSS"
            );

            var ctx = resolver.resolve(claims::get);
            assertThat(ctx).isPresent();
            assertThat(ctx.get().tenantId()).isEqualTo("MB-001");
            assertThat(ctx.get().entityId()).isEqualTo("SUBSIDIARY_EU");
            assertThat(ctx.get().tenantName()).isEqualTo("MegaBank");
            assertThat(ctx.get().features()).contains("REAL_TIME_AUDIT", "PCI_DSS");
        }

        @Test
        @DisplayName("Features as collection")
        void featuresAsCollection() {
            Map<String, Object> claims = Map.of(
                "tenant_id", "T1",
                "features", List.of("F1", "F2", "F3")
            );
            var ctx = resolver.resolve(claims::get);
            assertThat(ctx.get().features()).containsExactlyInAnyOrder("F1", "F2", "F3");
        }

        @Test
        @DisplayName("Returns empty when tenant_id claim missing")
        void missingClaim() {
            assertThat(resolver.resolve(k -> null)).isEmpty();
        }

        @Test
        @DisplayName("Returns empty for blank tenant_id")
        void blankClaim() {
            assertThat(resolver.resolve(k -> k.equals("tenant_id") ? "  " : null)).isEmpty();
        }

        @Test
        @DisplayName("Custom claim names")
        void customClaimNames() {
            var custom = new JwtClaimTenantResolver("org_id", "unit_id", "org_name", "flags");
            Map<String, Object> claims = Map.of("org_id", "ORG-42", "unit_id", "UNIT-A");
            var ctx = custom.resolve(claims::get);
            assertThat(ctx.get().tenantId()).isEqualTo("ORG-42");
            assertThat(ctx.get().entityId()).isEqualTo("UNIT-A");
        }

        @Test
        @DisplayName("Priority is 100")
        void priority() {
            assertThat(resolver.priority()).isEqualTo(100);
        }
    }

    @Nested
    @DisplayName("ApiKeyTenantResolver")
    class ApiKeyTests {

        @Test
        @DisplayName("Resolves tenant from API key")
        void resolveFromApiKey() {
            var resolver = new ApiKeyTenantResolver(Map.of(
                "pk_live_abc123def456", TenantContext.of("MB-001", "MAIN_BANK")
            ));

            var ctx = resolver.resolve(k ->
                k.equals("X-API-Key") ? "pk_live_abc123def456" : null);
            assertThat(ctx).isPresent();
            assertThat(ctx.get().tenantId()).isEqualTo("MB-001");
        }

        @Test
        @DisplayName("Unknown API key returns empty")
        void unknownKey() {
            var resolver = new ApiKeyTenantResolver();
            var ctx = resolver.resolve(k -> k.equals("X-API-Key") ? "unknown_key" : null);
            assertThat(ctx).isEmpty();
        }

        @Test
        @DisplayName("Missing X-API-Key header returns empty")
        void missingHeader() {
            var resolver = new ApiKeyTenantResolver();
            assertThat(resolver.resolve(k -> null)).isEmpty();
        }

        @Test
        @DisplayName("Register and revoke keys")
        void registerRevoke() {
            var resolver = new ApiKeyTenantResolver();
            assertThat(resolver.registeredKeyCount()).isZero();

            resolver.registerKey("key-1", TenantContext.of("T1"));
            assertThat(resolver.registeredKeyCount()).isEqualTo(1);

            resolver.revokeKey("key-1");
            assertThat(resolver.registeredKeyCount()).isZero();
        }

        @Test
        @DisplayName("Priority is 75")
        void priority() {
            var resolver = new ApiKeyTenantResolver();
            assertThat(resolver.priority()).isEqualTo(75);
        }
    }

    @Nested
    @DisplayName("CompositeTenantResolver")
    class CompositeTests {

        @Test
        @SuppressWarnings("rawtypes")
        @DisplayName("Resolves using first matching resolver (header wins over JWT)")
        void headerWins() {
            var headerResolver = new HeaderTenantResolver();
            var jwtResolver = new JwtClaimTenantResolver();

            var composite = new CompositeTenantResolver(List.of(jwtResolver, headerResolver));

            // Both resolvers could match, but header has lower priority number (50 < 100)
            Map<String, String> headers = Map.of(
                "X-Tenant-Id", "HEADER_TENANT"
            );

            var result = composite.resolveFromMap(headers);
            assertThat(result).isPresent();
            assertThat(result.get().tenantId()).isEqualTo("HEADER_TENANT");
        }

        @Test
        @SuppressWarnings("rawtypes")
        @DisplayName("Falls through to next resolver when first returns empty")
        void fallthrough() {
            var emptyResolver = new TenantResolver<>() {
                @Override public Optional<TenantContext> resolve(Object request) { return Optional.empty(); }
                @Override public String name() { return "empty"; }
                @Override public int priority() { return 1; }
            };
            var headerResolver = new HeaderTenantResolver();

            var composite = new CompositeTenantResolver(List.of(emptyResolver, headerResolver));
            var result = composite.resolveFromMap(Map.of("X-Tenant-Id", "MB-001"));

            assertThat(result).isPresent();
            assertThat(result.get().tenantId()).isEqualTo("MB-001");
        }

        @Test
        @SuppressWarnings("rawtypes")
        @DisplayName("Returns empty when no resolver matches")
        void noMatch() {
            var composite = new CompositeTenantResolver(List.of(new HeaderTenantResolver()));
            assertThat(composite.resolveFromMap(Map.of("other", "value"))).isEmpty();
        }

        @Test
        @SuppressWarnings("rawtypes")
        @DisplayName("Handles resolver exceptions gracefully")
        void exceptionHandling() {
            var throwingResolver = new TenantResolver<>() {
                @Override public Optional<TenantContext> resolve(Object r) { throw new RuntimeException("boom"); }
                @Override public String name() { return "throwing"; }
                @Override public int priority() { return 1; }
            };
            var headerResolver = new HeaderTenantResolver();

            var composite = new CompositeTenantResolver(List.of(throwingResolver, headerResolver));
            var result = composite.resolveFromMap(Map.of("X-Tenant-Id", "MB-001"));

            assertThat(result).isPresent(); // fell through to header resolver
        }
    }
}
