package com.paymenthub.tenant.repository;

import com.paymenthub.common.exception.TenantIsolationViolationException;
import com.paymenthub.tenant.context.TenantContext;
import com.paymenthub.tenant.context.TenantContextHolder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

class TenantAwareRepositoryTest {

    // Concrete subclass for testing
    static class TestRepository extends TenantAwareRepository {
        String exposedCurrentTenantId() { return currentTenantId(); }
        String exposedCurrentEntityId() { return currentEntityId(); }
        void exposedAssertTenantContext(String tenantId) { assertTenantContext(tenantId); }
        void exposedValidateDataOwnership(String dataTenantId, String recordId) {
            validateDataOwnership(dataTenantId, recordId);
        }
    }

    private final TestRepository repo = new TestRepository();

    @AfterEach
    void cleanup() { TenantContextHolder.clear(); }

    @Nested
    @DisplayName("Tenant context access")
    class ContextAccess {

        @Test
        @DisplayName("currentTenantId returns tenant from context")
        void currentTenantId() {
            TenantContextHolder.set(TenantContext.of("MB-001", "MAIN"));
            assertThat(repo.exposedCurrentTenantId()).isEqualTo("MB-001");
            assertThat(repo.exposedCurrentEntityId()).isEqualTo("MAIN");
        }

        @Test
        @DisplayName("currentTenantId throws when no context")
        void noContext() {
            assertThatThrownBy(repo::exposedCurrentTenantId)
                .isInstanceOf(IllegalStateException.class);
        }
    }

    @Nested
    @DisplayName("Isolation assertions")
    class Isolation {

        @Test
        @DisplayName("assertTenantContext passes for matching tenant")
        void matchingTenant() {
            TenantContextHolder.set(TenantContext.of("MB-001"));
            assertThatCode(() -> repo.exposedAssertTenantContext("MB-001"))
                .doesNotThrowAnyException();
        }

        @Test
        @DisplayName("assertTenantContext throws on cross-tenant access")
        void crossTenantAccess() {
            TenantContextHolder.set(TenantContext.of("MB-001"));
            assertThatThrownBy(() -> repo.exposedAssertTenantContext("MB-002"))
                .isInstanceOf(TenantIsolationViolationException.class);
        }

        @Test
        @DisplayName("validateDataOwnership passes for correct data")
        void validOwnership() {
            TenantContextHolder.set(TenantContext.of("MB-001"));
            assertThatCode(() -> repo.exposedValidateDataOwnership("MB-001", "record-1"))
                .doesNotThrowAnyException();
        }

        @Test
        @DisplayName("validateDataOwnership throws on foreign data")
        void foreignData() {
            TenantContextHolder.set(TenantContext.of("MB-001"));
            assertThatThrownBy(() -> repo.exposedValidateDataOwnership("MB-002", "record-1"))
                .isInstanceOf(TenantIsolationViolationException.class);
        }
    }
}
