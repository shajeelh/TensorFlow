package com.paymenthub.tenant.filter;

import com.paymenthub.tenant.context.TenantContext;
import com.paymenthub.tenant.context.TenantContextHolder;
import com.paymenthub.tenant.interceptor.NatsTenantInterceptor;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.*;

class NatsTenantInterceptorTest {

    private final NatsTenantInterceptor interceptor = new NatsTenantInterceptor();

    @AfterEach
    void cleanup() { TenantContextHolder.clear(); }

    @Nested
    @DisplayName("Outbound headers")
    class Outbound {

        @Test
        @DisplayName("Writes tenant headers from context")
        void writesHeaders() {
            TenantContextHolder.set(TenantContext.of("MB-001", "MAIN_BANK"));
            Map<String, String> headers = interceptor.getOutboundHeaders();

            assertThat(headers).containsEntry("X-Tenant-Id", "MB-001");
            assertThat(headers).containsEntry("X-Entity-Id", "MAIN_BANK");
        }

        @Test
        @DisplayName("Returns empty headers when no context")
        void noContext() {
            Map<String, String> headers = interceptor.getOutboundHeaders();
            assertThat(headers).isEmpty();
        }

        @Test
        @DisplayName("Byte headers for NATS native format")
        void byteHeaders() {
            TenantContextHolder.set(TenantContext.of("MB-001"));
            var headers = interceptor.getOutboundHeaderBytes();
            assertThat(headers).containsKey("X-Tenant-Id");
            assertThat(new String(headers.get("X-Tenant-Id"))).isEqualTo("MB-001");
        }
    }

    @Nested
    @DisplayName("Inbound headers")
    class Inbound {

        @Test
        @DisplayName("Reads tenant context from headers and sets on holder")
        void readsHeaders() {
            var ctx = interceptor.readInboundHeaders(Map.of(
                "X-Tenant-Id", "MB-001",
                "X-Entity-Id", "SUBSIDIARY_EU"
            ));

            assertThat(ctx).isPresent();
            assertThat(ctx.get().tenantId()).isEqualTo("MB-001");
            assertThat(TenantContextHolder.getTenantId()).isEqualTo("MB-001");
        }

        @Test
        @DisplayName("Returns empty for missing tenant header")
        void missingHeader() {
            var ctx = interceptor.readInboundHeaders(Map.of("other", "value"));
            assertThat(ctx).isEmpty();
            assertThat(TenantContextHolder.get()).isNull();
        }

        @Test
        @DisplayName("Byte header deserialization")
        void byteHeaders() {
            Map<String, byte[]> headers = new HashMap<>();
            headers.put("X-Tenant-Id", "MB-001".getBytes());
            headers.put("X-Entity-Id", "MAIN".getBytes());

            var ctx = interceptor.readInboundHeaderBytes(headers);
            assertThat(ctx).isPresent();
            assertThat(ctx.get().tenantId()).isEqualTo("MB-001");
        }
    }

    @Nested
    @DisplayName("Scoped processing")
    class ScopedProcessing {

        @Test
        @DisplayName("processWithTenantContext sets and clears context")
        void setsAndClearsContext() {
            AtomicReference<String> capturedTenant = new AtomicReference<>();

            interceptor.processWithTenantContext(
                k -> k.equals("X-Tenant-Id") ? "MB-001" : null,
                () -> capturedTenant.set(TenantContextHolder.getTenantId())
            );

            assertThat(capturedTenant.get()).isEqualTo("MB-001");
            assertThat(TenantContextHolder.get()).isNull(); // cleared
        }

        @Test
        @DisplayName("processWithTenantContext clears context even on exception")
        void clearsOnException() {
            assertThatThrownBy(() ->
                interceptor.processWithTenantContext(
                    k -> k.equals("X-Tenant-Id") ? "MB-001" : null,
                    () -> { throw new RuntimeException("handler error"); }
                )
            ).isInstanceOf(RuntimeException.class);

            assertThat(TenantContextHolder.get()).isNull(); // still cleared
        }

        @Test
        @DisplayName("processWithTenantContext throws when no tenant headers")
        void throwsWhenNoHeaders() {
            assertThatThrownBy(() ->
                interceptor.processWithTenantContext(k -> null, () -> {})
            ).isInstanceOf(IllegalStateException.class)
             .hasMessageContaining("not found in headers");
        }
    }

    @Nested
    @DisplayName("Round-trip: outbound → inbound")
    class RoundTrip {

        @Test
        @DisplayName("Context survives outbound/inbound header round-trip")
        void roundTrip() {
            // Module A sets context and writes outbound headers
            TenantContextHolder.set(new TenantContext(
                "MB-001", "MAIN_BANK", "MegaBank", null, null));
            Map<String, String> wireHeaders = interceptor.getOutboundHeaders();
            TenantContextHolder.clear();

            // Module B reads inbound headers
            var resolved = interceptor.readInboundHeaders(wireHeaders);
            assertThat(resolved).isPresent();
            assertThat(resolved.get().tenantId()).isEqualTo("MB-001");
            assertThat(resolved.get().entityId()).isEqualTo("MAIN_BANK");
        }
    }
}
