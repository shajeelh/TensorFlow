package com.paymenthub.tenant.context;

import com.paymenthub.common.exception.TenantIsolationViolationException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.*;

class TenantContextHolderTest {

    @AfterEach
    void cleanup() { TenantContextHolder.clear(); }

    @Nested
    @DisplayName("TenantContext creation")
    class ContextCreation {

        @Test
        @DisplayName("Minimal construction with tenantId only")
        void minimal() {
            var ctx = TenantContext.of("MB-001");
            assertThat(ctx.tenantId()).isEqualTo("MB-001");
            assertThat(ctx.entityId()).isEqualTo("MB-001"); // defaults to tenant
            assertThat(ctx.tenantName()).isEqualTo("MB-001"); // defaults to tenant
            assertThat(ctx.features()).isEmpty();
            assertThat(ctx.metadata()).isEmpty();
        }

        @Test
        @DisplayName("Full construction")
        void full() {
            var ctx = new TenantContext("MB-001", "MAIN_BANK", "MegaBank",
                Set.of("REAL_TIME_AUDIT", "PCI_DSS"), Map.of("region", "EU"));

            assertThat(ctx.tenantId()).isEqualTo("MB-001");
            assertThat(ctx.entityId()).isEqualTo("MAIN_BANK");
            assertThat(ctx.tenantName()).isEqualTo("MegaBank");
            assertThat(ctx.hasFeature("REAL_TIME_AUDIT")).isTrue();
            assertThat(ctx.hasFeature("NONEXISTENT")).isFalse();
            assertThat(ctx.metadata("region", "US")).isEqualTo("EU");
            assertThat(ctx.metadata("missing", "default")).isEqualTo("default");
        }

        @Test
        @DisplayName("Null tenantId throws")
        void nullTenantId() {
            assertThatThrownBy(() -> TenantContext.of(null))
                .isInstanceOf(NullPointerException.class);
        }

        @Test
        @DisplayName("Blank tenantId throws")
        void blankTenantId() {
            assertThatThrownBy(() -> TenantContext.of("  "))
                .isInstanceOf(IllegalArgumentException.class);
        }

        @Test
        @DisplayName("Features and metadata are immutable copies")
        void immutability() {
            var features = new java.util.HashSet<>(Set.of("F1"));
            var metadata = new java.util.HashMap<>(Map.of("k", "v"));
            var ctx = new TenantContext("T1", "E1", null, features, metadata);

            features.add("F2");
            metadata.put("k2", "v2");

            assertThat(ctx.features()).hasSize(1); // unaffected
            assertThat(ctx.metadata()).hasSize(1); // unaffected
        }

        @Test
        @DisplayName("withEntity creates derived context")
        void withEntity() {
            var ctx = new TenantContext("MB-001", "MAIN", "MegaBank",
                Set.of("F1"), Map.of("k", "v"));
            var derived = ctx.withEntity("SUBSIDIARY_EU");

            assertThat(derived.tenantId()).isEqualTo("MB-001");
            assertThat(derived.entityId()).isEqualTo("SUBSIDIARY_EU");
            assertThat(derived.tenantName()).isEqualTo("MegaBank");
            assertThat(derived.features()).containsExactly("F1");
        }
    }

    @Nested
    @DisplayName("TenantContextHolder lifecycle")
    class HolderLifecycle {

        @Test
        @DisplayName("Set and get context")
        void setAndGet() {
            var ctx = TenantContext.of("MB-001", "MAIN_BANK");
            TenantContextHolder.set(ctx);

            assertThat(TenantContextHolder.get()).isEqualTo(ctx);
            assertThat(TenantContextHolder.getTenantId()).isEqualTo("MB-001");
            assertThat(TenantContextHolder.getEntityId()).isEqualTo("MAIN_BANK");
        }

        @Test
        @DisplayName("Clear removes context")
        void clearContext() {
            TenantContextHolder.set(TenantContext.of("T1"));
            TenantContextHolder.clear();

            assertThat(TenantContextHolder.get()).isNull();
            assertThat(TenantContextHolder.getTenantId()).isNull();
        }

        @Test
        @DisplayName("require() throws when no context")
        void requireThrows() {
            assertThatThrownBy(TenantContextHolder::require)
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("No TenantContext");
        }

        @Test
        @DisplayName("current() returns Optional")
        void currentOptional() {
            assertThat(TenantContextHolder.current()).isEmpty();

            TenantContextHolder.set(TenantContext.of("T1"));
            assertThat(TenantContextHolder.current()).isPresent();
        }

        @Test
        @DisplayName("Context propagates to child threads")
        void threadPropagation() throws Exception {
            TenantContextHolder.set(TenantContext.of("MB-001", "MAIN"));

            AtomicReference<String> childTenant = new AtomicReference<>();
            Thread child = new Thread(() -> childTenant.set(TenantContextHolder.getTenantId()));
            child.start();
            child.join(1000);

            assertThat(childTenant.get()).isEqualTo("MB-001");
        }

        @Test
        @DisplayName("Null context set throws NPE")
        void nullContext() {
            assertThatThrownBy(() -> TenantContextHolder.set(null))
                .isInstanceOf(NullPointerException.class);
        }
    }

    @Nested
    @DisplayName("Tenant isolation enforcement")
    class IsolationEnforcement {

        @Test
        @DisplayName("assertTenant passes for matching tenant")
        void matchingTenant() {
            TenantContextHolder.set(TenantContext.of("MB-001"));
            assertThatCode(() -> TenantContextHolder.assertTenant("MB-001"))
                .doesNotThrowAnyException();
        }

        @Test
        @DisplayName("assertTenant throws TenantIsolationViolationException on mismatch")
        void mismatchedTenant() {
            TenantContextHolder.set(TenantContext.of("MB-001"));
            assertThatThrownBy(() -> TenantContextHolder.assertTenant("MB-002"))
                .isInstanceOf(TenantIsolationViolationException.class);
        }

        @Test
        @DisplayName("assertTenantMatch on context directly")
        void contextAssertMatch() {
            var ctx = TenantContext.of("MB-001");
            assertThatCode(() -> ctx.assertTenantMatch("MB-001"))
                .doesNotThrowAnyException();
            assertThatThrownBy(() -> ctx.assertTenantMatch("MB-002"))
                .isInstanceOf(TenantIsolationViolationException.class);
        }
    }

    @Nested
    @DisplayName("Scoped execution")
    class ScopedExecution {

        @Test
        @DisplayName("withTenant runs in different context and restores")
        void withTenantRestore() {
            var outer = TenantContext.of("OUTER");
            var inner = TenantContext.of("INNER");

            TenantContextHolder.set(outer);
            String result = TenantContextHolder.withTenant(inner,
                () -> TenantContextHolder.getTenantId());

            assertThat(result).isEqualTo("INNER");
            assertThat(TenantContextHolder.getTenantId()).isEqualTo("OUTER"); // restored
        }

        @Test
        @DisplayName("withTenant clears context if none existed before")
        void withTenantClearsWhenNoPrevious() {
            var ctx = TenantContext.of("TEMP");
            TenantContextHolder.withTenant(ctx, () -> {
                assertThat(TenantContextHolder.getTenantId()).isEqualTo("TEMP");
            });
            assertThat(TenantContextHolder.get()).isNull(); // cleared
        }

        @Test
        @DisplayName("withTenant restores context even on exception")
        void withTenantRestoredOnException() {
            var outer = TenantContext.of("OUTER");
            TenantContextHolder.set(outer);

            assertThatThrownBy(() ->
                TenantContextHolder.withTenant(TenantContext.of("INNER"), () -> {
                    throw new RuntimeException("boom");
                })
            ).isInstanceOf(RuntimeException.class);

            assertThat(TenantContextHolder.getTenantId()).isEqualTo("OUTER"); // restored
        }
    }
}
