package com.paymenthub.audit.buffer;

import com.lmax.disruptor.*;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;
import com.paymenthub.audit.handler.AuditEventHandler;
import com.paymenthub.common.enums.SyncMode;
import com.paymenthub.common.model.AuditEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * LMAX Disruptor-based ring buffer for lock-free audit event batching.
 *
 * <h3>Why Disruptor?</h3>
 * <p>The audit pipeline must handle 50,000+ events/second on the SMALL
 * profile without blocking the caller's business thread. Traditional
 * queues (ArrayBlockingQueue, ConcurrentLinkedQueue) have significant
 * overhead from locks and memory allocation. The Disruptor achieves
 * sub-microsecond publish latency by:</p>
 * <ul>
 *   <li>Pre-allocating all event slots in a fixed-size ring</li>
 *   <li>Using CAS-based sequence counters instead of locks</li>
 *   <li>Exploiting CPU cache line padding to prevent false sharing</li>
 *   <li>Batching consumer reads for throughput</li>
 * </ul>
 *
 * <h3>Buffer Sizing</h3>
 * <ul>
 *   <li>SMALL profile: 8,192 slots (8K events in flight)</li>
 *   <li>MEDIUM profile: 65,536 slots (64K events in flight)</li>
 *   <li>LARGE profile: 262,144 slots (256K events in flight)</li>
 * </ul>
 *
 * <h3>Backpressure</h3>
 * <p>When the ring buffer is full (consumer can't keep up):</p>
 * <ul>
 *   <li>Default: block until a slot is available (prevents event loss)</li>
 *   <li>Configurable: throw to fail fast (for fire-and-forget events)</li>
 * </ul>
 *
 * <h3>Consumer Pipeline</h3>
 * <p>The Disruptor consumer chain processes events in order:</p>
 * <ol>
 *   <li>{@link AuditEventHandler} — dispatches to the messaging transport
 *       (NATS JetStream publish). Runs on a dedicated virtual thread.</li>
 * </ol>
 */
public class AuditRingBuffer implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(AuditRingBuffer.class);

    /** Default buffer size for SMALL profile. Must be power of 2. */
    public static final int DEFAULT_BUFFER_SIZE = 8192;

    private final Disruptor<AuditEventSlot> disruptor;
    private final RingBuffer<AuditEventSlot> ringBuffer;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicLong publishedCount = new AtomicLong(0);
    private final AtomicLong droppedCount = new AtomicLong(0);
    private final int bufferSize;

    /**
     * Create a ring buffer with the specified size and event handler.
     *
     * @param bufferSize    must be a power of 2
     * @param eventHandler  the downstream handler (publishes to NATS/Kafka)
     */
    public AuditRingBuffer(int bufferSize, AuditEventHandler eventHandler) {
        this.bufferSize = bufferSize;

        ThreadFactory threadFactory = r -> {
            Thread t = Thread.ofVirtual().name("audit-disruptor-", 0).unstarted(r);
            return t;
        };

        this.disruptor = new Disruptor<>(
            AuditEventSlot::new,
            bufferSize,
            threadFactory,
            ProducerType.MULTI,     // multiple producer threads
            new BlockingWaitStrategy() // block when full (prevent event loss)
        );

        // Wire event handler
        disruptor.handleEventsWith((slot, sequence, endOfBatch) -> {
            try {
                if (slot.event != null) {
                    eventHandler.onEvent(slot.event, slot.syncMode, sequence, endOfBatch);
                }
            } finally {
                slot.clear(); // release reference for GC
            }
        });

        // Exception handler
        disruptor.setDefaultExceptionHandler(new ExceptionHandler<>() {
            @Override
            public void handleEventException(Throwable ex, long sequence, AuditEventSlot event) {
                log.error("Disruptor handler exception at seq {}: {}", sequence, ex.getMessage(), ex);
            }
            @Override
            public void handleOnStartException(Throwable ex) {
                log.error("Disruptor start exception: {}", ex.getMessage(), ex);
            }
            @Override
            public void handleOnShutdownException(Throwable ex) {
                log.error("Disruptor shutdown exception: {}", ex.getMessage(), ex);
            }
        });

        this.ringBuffer = disruptor.getRingBuffer();
    }

    /**
     * Start the ring buffer (begins consuming events).
     */
    public void start() {
        if (running.compareAndSet(false, true)) {
            disruptor.start();
            log.info("Audit ring buffer started: size={}, remaining={}",
                bufferSize, ringBuffer.remainingCapacity());
        }
    }

    /**
     * Publish an audit event to the ring buffer.
     *
     * @param event    the audit event
     * @param syncMode the sync mode for this event
     * @return the ring buffer sequence number
     */
    public long publish(AuditEvent event, SyncMode syncMode) {
        long sequence = ringBuffer.next();
        try {
            AuditEventSlot slot = ringBuffer.get(sequence);
            slot.event = event;
            slot.syncMode = syncMode;
            slot.publishedAt = System.nanoTime();
        } finally {
            ringBuffer.publish(sequence);
        }
        publishedCount.incrementAndGet();
        return sequence;
    }

    /**
     * Try to publish without blocking. Returns -1 if buffer is full.
     */
    public long tryPublish(AuditEvent event, SyncMode syncMode) {
        try {
            long sequence = ringBuffer.tryNext();
            try {
                AuditEventSlot slot = ringBuffer.get(sequence);
                slot.event = event;
                slot.syncMode = syncMode;
                slot.publishedAt = System.nanoTime();
            } finally {
                ringBuffer.publish(sequence);
            }
            publishedCount.incrementAndGet();
            return sequence;
        } catch (InsufficientCapacityException e) {
            droppedCount.incrementAndGet();
            log.warn("Ring buffer full — event dropped: id={}", event.eventId());
            return -1;
        }
    }

    @Override
    public void close() {
        if (running.compareAndSet(true, false)) {
            log.info("Shutting down audit ring buffer. Published: {}, Dropped: {}",
                publishedCount.get(), droppedCount.get());
            disruptor.shutdown();
        }
    }

    // ── Metrics ──────────────────────────────────────────────

    public boolean isHealthy() { return running.get(); }
    public long remainingCapacity() { return ringBuffer.remainingCapacity(); }
    public long getPublishedCount() { return publishedCount.get(); }
    public long getDroppedCount() { return droppedCount.get(); }
    public int getBufferSize() { return bufferSize; }
    public double getUtilization() {
        return 1.0 - ((double) ringBuffer.remainingCapacity() / bufferSize);
    }

    // ── Ring Buffer Slot ─────────────────────────────────────

    /**
     * Pre-allocated slot in the ring buffer.
     * Mutable — written by producer, read by consumer, then cleared.
     */
    public static class AuditEventSlot {
        public AuditEvent event;
        public SyncMode syncMode;
        public long publishedAt;

        public void clear() {
            event = null;
            syncMode = null;
            publishedAt = 0;
        }
    }
}
