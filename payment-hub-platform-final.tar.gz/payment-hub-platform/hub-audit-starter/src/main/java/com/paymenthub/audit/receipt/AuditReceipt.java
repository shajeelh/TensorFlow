package com.paymenthub.audit.receipt;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paymenthub.common.enums.SyncMode;

import java.time.Instant;
import java.util.UUID;

/**
 * Acknowledgment record returned to callers after an audit event is emitted.
 *
 * <h3>Receipt Types by SyncMode</h3>
 * <ul>
 *   <li><strong>ASYNC</strong> — receipt is returned immediately after the event
 *       is placed in the ring buffer. {@code status} = ACCEPTED. The event
 *       has NOT been persisted yet.</li>
 *   <li><strong>SYNC</strong> — receipt is returned after the event has been
 *       durably persisted to the audit store and the hash chain extended.
 *       {@code status} = COMMITTED. The receipt includes the event hash
 *       and chain position.</li>
 *   <li><strong>FIRE_AND_FORGET</strong> — no receipt returned (void).
 *       Used for high-volume, low-criticality events.</li>
 * </ul>
 *
 * <h3>Evidence Value</h3>
 * <p>For SYNC receipts, the receipt itself is a cryptographic proof that
 * the event was recorded. The {@code eventHash} can be independently
 * verified against the hash chain and Merkle tree.</p>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record AuditReceipt(
    /** Unique receipt ID. */
    String receiptId,

    /** The event ID this receipt acknowledges. */
    String eventId,

    /** Acknowledgment status. */
    Status status,

    /** How the event was submitted. */
    SyncMode syncMode,

    /** When the receipt was generated. */
    Instant timestamp,

    /** SHA3-256 hash of the canonical event (SYNC only). */
    String eventHash,

    /** Position in the tenant's hash chain (SYNC only). */
    Long chainPosition,

    /** Transport sequence number (JetStream seq, Kafka offset). */
    Long transportSequence,

    /** Failure reason if status is REJECTED or FAILED. */
    String failureReason
) {
    public enum Status {
        /** Event accepted into ring buffer (ASYNC path). */
        ACCEPTED,
        /** Event durably committed to audit store (SYNC path). */
        COMMITTED,
        /** Event rejected (validation failure, PCI violation). */
        REJECTED,
        /** Event processing failed (store unavailable, etc.). */
        FAILED
    }

    // ── Factories ────────────────────────────────────────────

    /**
     * Create an ACCEPTED receipt for async emission.
     */
    public static AuditReceipt accepted(String eventId, long transportSeq) {
        return new AuditReceipt(
            UUID.randomUUID().toString(), eventId, Status.ACCEPTED,
            SyncMode.ASYNC, Instant.now(), null, null, transportSeq, null
        );
    }

    /**
     * Create a COMMITTED receipt for sync emission with cryptographic proof.
     */
    public static AuditReceipt committed(String eventId, String eventHash,
                                           long chainPosition, long transportSeq) {
        return new AuditReceipt(
            UUID.randomUUID().toString(), eventId, Status.COMMITTED,
            SyncMode.SYNC, Instant.now(), eventHash, chainPosition, transportSeq, null
        );
    }

    /**
     * Create a REJECTED receipt (validation failure).
     */
    public static AuditReceipt rejected(String eventId, String reason) {
        return new AuditReceipt(
            UUID.randomUUID().toString(), eventId, Status.REJECTED,
            null, Instant.now(), null, null, null, reason
        );
    }

    /**
     * Create a FAILED receipt (processing failure).
     */
    public static AuditReceipt failed(String eventId, String reason) {
        return new AuditReceipt(
            UUID.randomUUID().toString(), eventId, Status.FAILED,
            null, Instant.now(), null, null, null, reason
        );
    }

    /**
     * Check if the event was successfully processed.
     */
    public boolean isSuccess() {
        return status == Status.ACCEPTED || status == Status.COMMITTED;
    }
}
