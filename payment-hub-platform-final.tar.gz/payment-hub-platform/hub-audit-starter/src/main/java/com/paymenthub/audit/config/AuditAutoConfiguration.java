package com.paymenthub.audit.config;

import com.paymenthub.audit.buffer.AuditRingBuffer;
import com.paymenthub.audit.emitter.AuditEmitter;
import com.paymenthub.audit.handler.AuditEventHandler;
import com.paymenthub.messaging.publisher.MessagePublisher;
import com.paymenthub.pii.PiiScanner;
import com.paymenthub.time.clock.HubClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@EnableConfigurationProperties(AuditAutoConfiguration.AuditProperties.class)
public class AuditAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(AuditAutoConfiguration.class);

    @Bean
    @ConditionalOnMissingBean
    public AuditEventHandler auditEventHandler(
            MessagePublisher publisher,
            @Value("${hub.observability.module-name:unknown}") String moduleName) {
        return new AuditEventHandler(publisher, moduleName);
    }

    @Bean(initMethod = "start", destroyMethod = "close")
    @ConditionalOnMissingBean
    public AuditRingBuffer auditRingBuffer(AuditEventHandler handler, AuditProperties props) {
        log.info("Configuring audit ring buffer: size={}", props.getBufferSize());
        return new AuditRingBuffer(props.getBufferSize(), handler);
    }

    @Bean
    @ConditionalOnMissingBean
    public AuditEmitter auditEmitter(AuditRingBuffer ringBuffer,
                                       PiiScanner piiScanner,
                                       HubClock clock,
                                       AuditProperties props) {
        log.info("Audit emitter configured: pciPreScreen={}", props.isPciPreScreenEnabled());
        return new AuditEmitter(ringBuffer, piiScanner, clock, props.isPciPreScreenEnabled());
    }

    @ConfigurationProperties(prefix = "hub.audit")
    public static class AuditProperties {
        /** Ring buffer size (must be power of 2). Default: 8192. */
        private int bufferSize = AuditRingBuffer.DEFAULT_BUFFER_SIZE;
        /** Enable PCI pre-screening on event payloads. Default: true. */
        private boolean pciPreScreenEnabled = true;

        public int getBufferSize() { return bufferSize; }
        public void setBufferSize(int v) { this.bufferSize = v; }
        public boolean isPciPreScreenEnabled() { return pciPreScreenEnabled; }
        public void setPciPreScreenEnabled(boolean v) { this.pciPreScreenEnabled = v; }
    }
}
