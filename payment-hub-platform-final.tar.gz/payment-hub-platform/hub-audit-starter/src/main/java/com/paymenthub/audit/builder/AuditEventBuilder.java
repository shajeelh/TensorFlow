package com.paymenthub.audit.builder;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.paymenthub.common.enums.*;
import com.paymenthub.common.model.*;
import com.paymenthub.observability.context.CorrelationContext;
import com.paymenthub.observability.context.CorrelationContextHolder;
import com.paymenthub.security.context.SecurityContext;
import com.paymenthub.security.context.SecurityContextHolder;
import com.paymenthub.tenant.context.TenantContextHolder;

import java.time.Instant;
import java.util.*;

/**
 * Fluent builder for constructing {@link AuditEvent} instances with automatic
 * context enrichment.
 *
 * <h3>Auto-Enrichment</h3>
 * <p>When {@link #build()} is called, the builder automatically populates
 * fields from the current thread's context holders:</p>
 * <ul>
 *   <li>{@code TenantContextHolder} → tenantId, entityId on AuditResource</li>
 *   <li>{@code SecurityContextHolder} → actorIdentity, actorType, authMethod on AuditActor</li>
 *   <li>{@code CorrelationContextHolder} → correlationId, causationId, traceId, spanId</li>
 * </ul>
 * <p>Explicitly set values are NEVER overwritten by auto-enrichment.</p>
 *
 * <h3>Usage</h3>
 * <pre>{@code
 * AuditEvent event = AuditEventBuilder.create("payment.transfer_completed")
 *     .category(EventCategory.BUSINESS)
 *     .result(ActionResult.SUCCESS)
 *     .resource("payment", "PAY-12345")
 *     .payload("amount", 50000)
 *     .payload("currency", "USD")
 *     .payload("beneficiary", "ACME Corp")
 *     .build();
 * }</pre>
 *
 * <h3>PII Safety</h3>
 * <p>The builder does NOT sanitize PII. Sanitization happens downstream
 * in the audit pipeline (PiiJsonSanitizer) after the event is emitted.
 * This separation ensures the original event is available for Tier 1/2
 * tokenization while masked versions go to logs and OpenSearch.</p>
 */
public class AuditEventBuilder {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    // Core event fields
    private String eventId;
    private String eventType;
    private EventCategory category;
    private ActionResult result;
    private Instant timestamp;
    private String sourceModule;
    private SyncMode syncMode;

    // Actor fields
    private String actorIdentity;
    private ActorType actorType;
    private String actorDisplayName;
    private String actorIpAddress;
    private String actorAuthMethod;
    private String delegatedBy;

    // Resource fields
    private String resourceType;
    private String resourceId;
    private String tenantId;
    private String entityId;

    // Correlation fields
    private UUID correlationId;
    private UUID causationId;
    private String traceId;
    private String spanId;

    // Payload
    private final ObjectNode payload = MAPPER.createObjectNode();

    // Tags and metadata
    private final Map<String, String> tags = new LinkedHashMap<>();

    private AuditEventBuilder(String eventType) {
        this.eventType = Objects.requireNonNull(eventType, "eventType required");
        this.eventId = UUID.randomUUID().toString();
    }

    /**
     * Create a new builder for the given event type.
     *
     * @param eventType e.g., "payment.transfer_completed", "authz.access_denied"
     */
    public static AuditEventBuilder create(String eventType) {
        return new AuditEventBuilder(eventType);
    }

    // ── Core Fields ──────────────────────────────────────────

    public AuditEventBuilder eventId(String eventId) { this.eventId = eventId; return this; }
    public AuditEventBuilder category(EventCategory category) { this.category = category; return this; }
    public AuditEventBuilder result(ActionResult result) { this.result = result; return this; }
    public AuditEventBuilder timestamp(Instant timestamp) { this.timestamp = timestamp; return this; }
    public AuditEventBuilder sourceModule(String module) { this.sourceModule = module; return this; }
    public AuditEventBuilder syncMode(SyncMode mode) { this.syncMode = mode; return this; }

    // ── Actor ────────────────────────────────────────────────

    public AuditEventBuilder actor(String identity, ActorType type) {
        this.actorIdentity = identity;
        this.actorType = type;
        return this;
    }

    public AuditEventBuilder actorDisplayName(String name) { this.actorDisplayName = name; return this; }
    public AuditEventBuilder actorIpAddress(String ip) { this.actorIpAddress = ip; return this; }
    public AuditEventBuilder actorAuthMethod(String method) { this.actorAuthMethod = method; return this; }
    public AuditEventBuilder delegatedBy(String delegator) { this.delegatedBy = delegator; return this; }

    // ── Resource ─────────────────────────────────────────────

    public AuditEventBuilder resource(String type, String id) {
        this.resourceType = type;
        this.resourceId = id;
        return this;
    }

    public AuditEventBuilder tenantId(String tenantId) { this.tenantId = tenantId; return this; }
    public AuditEventBuilder entityId(String entityId) { this.entityId = entityId; return this; }

    // ── Correlation ──────────────────────────────────────────

    public AuditEventBuilder correlationId(UUID id) { this.correlationId = id; return this; }
    public AuditEventBuilder causationId(UUID id) { this.causationId = id; return this; }
    public AuditEventBuilder traceId(String id) { this.traceId = id; return this; }
    public AuditEventBuilder spanId(String id) { this.spanId = id; return this; }

    // ── Payload ──────────────────────────────────────────────

    public AuditEventBuilder payload(String key, String value) {
        payload.put(key, value); return this;
    }

    public AuditEventBuilder payload(String key, long value) {
        payload.put(key, value); return this;
    }

    public AuditEventBuilder payload(String key, double value) {
        payload.put(key, value); return this;
    }

    public AuditEventBuilder payload(String key, boolean value) {
        payload.put(key, value); return this;
    }

    public AuditEventBuilder payload(String key, JsonNode value) {
        payload.set(key, value); return this;
    }

    public AuditEventBuilder payloadFromObject(String key, Object value) {
        payload.set(key, MAPPER.valueToTree(value));
        return this;
    }

    public AuditEventBuilder payloadNode(ObjectNode node) {
        node.fields().forEachRemaining(e -> payload.set(e.getKey(), e.getValue()));
        return this;
    }

    // ── Tags ─────────────────────────────────────────────────

    public AuditEventBuilder tag(String key, String value) {
        tags.put(key, value); return this;
    }

    // ── Build ────────────────────────────────────────────────

    /**
     * Build the AuditEvent with auto-enrichment from context holders.
     */
    public AuditEvent build() {
        enrichFromContextHolders();

        AuditActor actor = new AuditActor(
            actorIdentity != null ? actorIdentity : "unknown",
            actorType != null ? actorType : ActorType.SYSTEM,
            actorDisplayName,
            actorIpAddress,
            actorAuthMethod,
            delegatedBy
        );

        AuditResource resource = new AuditResource(
            resourceType != null ? resourceType : "unknown",
            resourceId,
            tenantId != null ? tenantId : "UNKNOWN",
            entityId
        );

        return new AuditEvent(
            eventId,
            eventType,
            category != null ? category : EventCategory.BUSINESS,
            result != null ? result : ActionResult.SUCCESS,
            timestamp != null ? timestamp : Instant.now(),
            actor,
            resource,
            sourceModule,
            correlationId,
            causationId,
            traceId,
            spanId,
            syncMode != null ? syncMode : SyncMode.ASYNC,
            payload.isEmpty() ? null : payload,
            tags.isEmpty() ? null : Map.copyOf(tags),
            null // integrity info added by pipeline
        );
    }

    // ── Auto-Enrichment ──────────────────────────────────────

    private void enrichFromContextHolders() {
        // Tenant context
        if (tenantId == null) tenantId = TenantContextHolder.getTenantId();
        if (entityId == null) entityId = TenantContextHolder.getEntityId();

        // Security context
        SecurityContext secCtx = SecurityContextHolder.get();
        if (secCtx != null) {
            if (actorIdentity == null) actorIdentity = secCtx.actorIdentity();
            if (actorType == null) actorType = secCtx.actorType();
            if (actorDisplayName == null) actorDisplayName = secCtx.displayName();
            if (actorAuthMethod == null) actorAuthMethod = secCtx.authMethod();
            if (delegatedBy == null && secCtx.isDelegated()) delegatedBy = secCtx.delegatedBy();
        }

        // Correlation context
        CorrelationContext corrCtx = CorrelationContextHolder.get();
        if (corrCtx != null) {
            if (correlationId == null) correlationId = corrCtx.correlationId();
            if (causationId == null) causationId = corrCtx.causationId();
            if (traceId == null) traceId = corrCtx.traceId();
            if (spanId == null) spanId = corrCtx.spanId();
            if (sourceModule == null) sourceModule = corrCtx.sourceModule();
        }
    }
}
