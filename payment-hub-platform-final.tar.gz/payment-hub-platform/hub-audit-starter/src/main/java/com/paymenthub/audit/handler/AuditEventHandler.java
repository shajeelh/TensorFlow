package com.paymenthub.audit.handler;

import com.paymenthub.common.enums.SyncMode;
import com.paymenthub.common.model.AuditEvent;
import com.paymenthub.messaging.envelope.MessageEnvelope;
import com.paymenthub.messaging.publisher.MessagePublisher;
import com.paymenthub.messaging.routing.SubjectRouter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Disruptor event handler that dispatches audit events to the messaging transport.
 *
 * <h3>Processing</h3>
 * <p>Called by the Disruptor consumer thread for each event in the ring buffer.
 * The handler:</p>
 * <ol>
 *   <li>Builds the NATS subject from the event (tenant + category + type)</li>
 *   <li>Wraps the event in a {@link MessageEnvelope}</li>
 *   <li>Publishes via {@link MessagePublisher} to the transport</li>
 * </ol>
 *
 * <h3>Batching</h3>
 * <p>The Disruptor signals {@code endOfBatch} on the last event in a
 * contiguous sequence. This can be used to flush transport buffers
 * for optimal throughput (e.g., Kafka batch send).</p>
 *
 * <h3>Error Handling</h3>
 * <p>If the transport publish fails, the event is logged at ERROR level.
 * The Disruptor exception handler will catch the exception and log it
 * without stopping the consumer. Events that fail transport delivery
 * are NOT retried at this layer — retry is handled by the transport
 * itself (NATS JetStream acknowledgment + redelivery).</p>
 */
public class AuditEventHandler {

    private static final Logger log = LoggerFactory.getLogger(AuditEventHandler.class);

    private final MessagePublisher publisher;
    private final String sourceModule;
    private final AtomicLong dispatchedCount = new AtomicLong(0);
    private final AtomicLong errorCount = new AtomicLong(0);

    /**
     * @param publisher    the messaging transport publisher
     * @param sourceModule the name of this module (for envelope source field)
     */
    public AuditEventHandler(MessagePublisher publisher, String sourceModule) {
        this.publisher = Objects.requireNonNull(publisher, "Publisher required");
        this.sourceModule = sourceModule != null ? sourceModule : "unknown";
    }

    /**
     * Called by the Disruptor for each event.
     *
     * @param event      the audit event
     * @param syncMode   the sync mode requested by the caller
     * @param sequence   the ring buffer sequence number
     * @param endOfBatch true if this is the last event in the current batch
     */
    public void onEvent(AuditEvent event, SyncMode syncMode,
                          long sequence, boolean endOfBatch) {
        try {
            String subject = SubjectRouter.subjectFor(event);

            MessageEnvelope<AuditEvent> envelope = MessageEnvelope.<AuditEvent>builder()
                .subject(subject)
                .type(event.eventType())
                .source(sourceModule)
                .correlationId(event.correlationId() != null
                    ? event.correlationId().toString() : null)
                .tenantId(event.resource().tenantId())
                .entityId(event.resource().entityId())
                .payload(event)
                .build();

            publisher.publish(envelope);
            dispatchedCount.incrementAndGet();

            if (log.isTraceEnabled()) {
                log.trace("Dispatched event: seq={}, subject={}, id={}, batch={}",
                    sequence, subject, event.eventId(), endOfBatch);
            }

        } catch (Exception e) {
            errorCount.incrementAndGet();
            log.error("Failed to dispatch audit event: seq={}, id={}, type={}, error={}",
                sequence, event.eventId(), event.eventType(), e.getMessage(), e);
        }
    }

    // ── Metrics ──────────────────────────────────────────────

    public long getDispatchedCount() { return dispatchedCount.get(); }
    public long getErrorCount() { return errorCount.get(); }
}
