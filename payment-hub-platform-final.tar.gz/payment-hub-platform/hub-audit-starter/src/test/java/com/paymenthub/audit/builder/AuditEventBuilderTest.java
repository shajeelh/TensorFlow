package com.paymenthub.audit.builder;

import com.paymenthub.common.enums.*;
import com.paymenthub.common.model.AuditEvent;
import com.paymenthub.security.context.SecurityContext;
import com.paymenthub.security.context.SecurityContextHolder;
import com.paymenthub.security.rbac.Role;
import com.paymenthub.tenant.context.TenantContext;
import com.paymenthub.tenant.context.TenantContextHolder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.assertj.core.api.Assertions.*;

class AuditEventBuilderTest {

    @AfterEach
    void cleanup() {
        TenantContextHolder.clear();
        SecurityContextHolder.clear();
    }

    @Nested
    @DisplayName("Manual construction")
    class Manual {

        @Test
        @DisplayName("Builds complete event with all fields")
        void completeEvent() {
            AuditEvent event = AuditEventBuilder.create("payment.transfer_completed")
                .category(EventCategory.BUSINESS)
                .result(ActionResult.SUCCESS)
                .actor("jane@megabank.com", ActorType.USER)
                .actorDisplayName("Jane Doe")
                .actorIpAddress("10.1.42.100")
                .resource("payment", "PAY-12345")
                .tenantId("MB-001")
                .entityId("MAIN_BANK")
                .sourceModule("payment-orch")
                .payload("amount", 50000)
                .payload("currency", "USD")
                .tag("priority", "high")
                .build();

            assertThat(event.eventId()).isNotBlank();
            assertThat(event.eventType()).isEqualTo("payment.transfer_completed");
            assertThat(event.category()).isEqualTo(EventCategory.BUSINESS);
            assertThat(event.result()).isEqualTo(ActionResult.SUCCESS);
            assertThat(event.actor().identity()).isEqualTo("jane@megabank.com");
            assertThat(event.actor().type()).isEqualTo(ActorType.USER);
            assertThat(event.actor().displayName()).isEqualTo("Jane Doe");
            assertThat(event.resource().type()).isEqualTo("payment");
            assertThat(event.resource().resourceId()).isEqualTo("PAY-12345");
            assertThat(event.resource().tenantId()).isEqualTo("MB-001");
            assertThat(event.sourceModule()).isEqualTo("payment-orch");
            assertThat(event.payload().get("amount").asLong()).isEqualTo(50000);
            assertThat(event.payload().get("currency").asText()).isEqualTo("USD");
            assertThat(event.tags()).containsEntry("priority", "high");
            assertThat(event.timestamp()).isNotNull();
        }

        @Test
        @DisplayName("Minimal event with defaults")
        void minimalEvent() {
            AuditEvent event = AuditEventBuilder.create("test.event")
                .tenantId("T1")
                .build();

            assertThat(event.eventType()).isEqualTo("test.event");
            assertThat(event.category()).isEqualTo(EventCategory.BUSINESS);
            assertThat(event.result()).isEqualTo(ActionResult.SUCCESS);
            assertThat(event.actor().identity()).isEqualTo("unknown");
            assertThat(event.resource().tenantId()).isEqualTo("T1");
        }
    }

    @Nested
    @DisplayName("Auto-enrichment from context holders")
    class AutoEnrichment {

        @Test
        @DisplayName("Enriches from TenantContextHolder")
        void tenantEnrichment() {
            TenantContextHolder.set(TenantContext.of("MB-001", "MAIN_BANK"));

            AuditEvent event = AuditEventBuilder.create("test.event").build();

            assertThat(event.resource().tenantId()).isEqualTo("MB-001");
            assertThat(event.resource().entityId()).isEqualTo("MAIN_BANK");
        }

        @Test
        @DisplayName("Enriches from SecurityContextHolder")
        void securityEnrichment() {
            TenantContextHolder.set(TenantContext.of("T1"));
            SecurityContextHolder.set(SecurityContext.user(
                "jane@test.com", "Jane", Set.of(Role.AUDITOR), "JWT"));

            AuditEvent event = AuditEventBuilder.create("test.event").build();

            assertThat(event.actor().identity()).isEqualTo("jane@test.com");
            assertThat(event.actor().type()).isEqualTo(ActorType.USER);
            assertThat(event.actor().displayName()).isEqualTo("Jane");
            assertThat(event.actor().authMethod()).isEqualTo("JWT");
        }

        @Test
        @DisplayName("Explicit values are NOT overwritten by context")
        void explicitWins() {
            TenantContextHolder.set(TenantContext.of("CONTEXT_TENANT"));
            SecurityContextHolder.set(SecurityContext.user(
                "context_user", "CU", Set.of(Role.VIEWER), "JWT"));

            AuditEvent event = AuditEventBuilder.create("test.event")
                .tenantId("EXPLICIT_TENANT")
                .actor("explicit_user", ActorType.EXTERNAL)
                .build();

            assertThat(event.resource().tenantId()).isEqualTo("EXPLICIT_TENANT");
            assertThat(event.actor().identity()).isEqualTo("explicit_user");
            assertThat(event.actor().type()).isEqualTo(ActorType.EXTERNAL);
        }

        @Test
        @DisplayName("Delegation info from SecurityContext")
        void delegationEnrichment() {
            TenantContextHolder.set(TenantContext.of("T1"));
            SecurityContextHolder.set(
                SecurityContext.user("op", "Op", Set.of(Role.OPERATOR), "JWT")
                    .withDelegation("supervisor"));

            AuditEvent event = AuditEventBuilder.create("admin.override").build();

            assertThat(event.actor().delegatedBy()).isEqualTo("supervisor");
        }
    }
}
