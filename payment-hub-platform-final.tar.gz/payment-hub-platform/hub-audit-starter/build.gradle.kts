plugins { `java-library` }
description = "Payment Hub — Audit Event Emission API (LMAX Disruptor Ring Buffer, Builder, Receipt)"
dependencies {
    api(project(":hub-common-model"))
    implementation(project(":hub-crypto-starter"))
    implementation(project(":hub-pii-starter"))
    implementation(project(":hub-observability-starter"))
    implementation(project(":hub-tenant-context-starter"))
    implementation(project(":hub-security-starter"))
    implementation(project(":hub-messaging-starter"))
    implementation(project(":hub-time-starter"))

    api("com.lmax:disruptor:4.0.0")
    implementation("com.fasterxml.jackson.core:jackson-databind")
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("org.springframework.boot:spring-boot-actuator")
    implementation("org.slf4j:slf4j-api")

    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
