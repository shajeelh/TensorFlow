rootProject.name = "payment-hub-platform"

include(
    // Tier 1 — Foundation
    "hub-common-model",
    "hub-crypto-starter",
    "hub-pii-starter",
    "hub-observability-starter",
    "hub-error-starter",
    "hub-time-starter",
    "hub-resilience-starter",
    "hub-idempotency-starter",
    "hub-secret-starter",

    // Tier 2 — Integration
    "hub-tenant-context-starter",
    "hub-messaging-starter",
    "hub-security-starter",
    "hub-nats-starter",
    "hub-grpc-starter",

    // Tier 3 — Audit Client
    "hub-audit-starter",

    // Tier 4 — Audit Server
    "audit-module-server"
)
