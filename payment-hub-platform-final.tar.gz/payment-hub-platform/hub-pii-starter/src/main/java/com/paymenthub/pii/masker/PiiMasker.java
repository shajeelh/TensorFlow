package com.paymenthub.pii.masker;

/**
 * Format-preserving PII masking for display and logging.
 *
 * <p>Masking preserves enough structure to identify the data type
 * while hiding the sensitive content. Used in log output, query
 * responses, and error messages.</p>
 *
 * <h3>Masking Rules</h3>
 * <ul>
 *   <li>PAN: show last 4 digits → {@code ****4567}</li>
 *   <li>Email: show first char + domain shape → {@code j***e@b***.com}</li>
 *   <li>Phone: show country code + last 2 → {@code +1*****42}</li>
 *   <li>IBAN: show last 4 → {@code ****3456}</li>
 *   <li>SSN: fully masked → {@code ***-**-****}</li>
 *   <li>IP: mask to /24 → {@code 10.1.42.***}</li>
 *   <li>Name: show first char → {@code J*** D**}</li>
 *   <li>Generic: center mask → {@code ab***ef}</li>
 * </ul>
 *
 * <h3>Thread Safety</h3>
 * <p>All methods are stateless and thread-safe.</p>
 */
public final class PiiMasker {

    private static final char MASK_CHAR = '*';

    private PiiMasker() {}

    // ── Tier 0: PCI ──────────────────────────────────────────

    /**
     * Mask a PAN showing only the last 4 digits.
     * Returns {@code ****4567} regardless of PAN length.
     */
    public static String maskPan(String pan) {
        if (pan == null || pan.length() < 4) return "****";
        String digits = pan.replaceAll("\\D", "");
        if (digits.length() < 4) return "****";
        return MASK_CHAR + "***" + digits.substring(digits.length() - 4);
    }

    /**
     * Fully redact CVV/CVC — never show any digits.
     */
    public static String maskCvv(String cvv) {
        return "***";
    }

    // ── Tier 1: PII High ─────────────────────────────────────

    /**
     * Fully mask SSN: {@code ***-**-****}
     */
    public static String maskSsn(String ssn) {
        return "***-**-****";
    }

    /**
     * Mask passport: show first 2 chars. {@code AB*****}
     */
    public static String maskPassport(String passport) {
        if (passport == null || passport.length() < 3) return "***";
        return passport.substring(0, 2) + repeat(MASK_CHAR, passport.length() - 2);
    }

    // ── Tier 2: PII Standard ─────────────────────────────────

    /**
     * Mask email: first and last char of local part + masked domain.
     * {@code jane.doe@megabank.com} → {@code j***e@m***.com}
     */
    public static String maskEmail(String email) {
        if (email == null) return null;
        int atIndex = email.indexOf('@');
        if (atIndex < 1) return maskGeneric(email);

        String local = email.substring(0, atIndex);
        String domain = email.substring(atIndex + 1);

        String maskedLocal;
        if (local.length() <= 2) {
            maskedLocal = local.charAt(0) + "***";
        } else {
            maskedLocal = local.charAt(0) + repeat(MASK_CHAR, local.length() - 2) + local.charAt(local.length() - 1);
        }

        int dotIndex = domain.lastIndexOf('.');
        String maskedDomain;
        if (dotIndex > 0) {
            String domainName = domain.substring(0, dotIndex);
            String tld = domain.substring(dotIndex);
            maskedDomain = domainName.charAt(0) + repeat(MASK_CHAR, domainName.length() - 1) + tld;
        } else {
            maskedDomain = maskGeneric(domain);
        }

        return maskedLocal + "@" + maskedDomain;
    }

    /**
     * Mask phone: show country code + last 2 digits.
     * {@code +441234567890} → {@code +44********90}
     */
    public static String maskPhone(String phone) {
        if (phone == null || phone.length() < 5) return "****";
        // Find end of country code (first 2-4 chars after +)
        int codeEnd = Math.min(phone.length(), phone.startsWith("+") ? 3 : 2);
        String countryCode = phone.substring(0, codeEnd);
        String rest = phone.substring(codeEnd);
        if (rest.length() <= 2) return countryCode + rest;
        return countryCode + repeat(MASK_CHAR, rest.length() - 2) + rest.substring(rest.length() - 2);
    }

    /**
     * Mask IBAN: show country code and last 4 characters.
     * {@code GB82 WEST 1234 5698 7654 32} → {@code GB** **** **** **** **54 32}
     */
    public static String maskIban(String iban) {
        if (iban == null || iban.length() < 6) return "****";
        String cleaned = iban.replaceAll("\\s", "");
        String country = cleaned.substring(0, 2);
        String last4 = cleaned.substring(cleaned.length() - 4);
        int middleLen = cleaned.length() - 6;
        return country + repeat(MASK_CHAR, 2) + repeat(MASK_CHAR, middleLen) + last4;
    }

    /**
     * Mask IP address to /24 subnet.
     * {@code 10.1.42.99} → {@code 10.1.42.***}
     */
    public static String maskIpAddress(String ip) {
        if (ip == null) return null;
        int lastDot = ip.lastIndexOf('.');
        if (lastDot < 0) return maskGeneric(ip);
        return ip.substring(0, lastDot + 1) + "***";
    }

    /**
     * Mask date of birth: show year only.
     * {@code 1990-03-15} → {@code 1990-**-**}
     */
    public static String maskDob(String dob) {
        if (dob == null || dob.length() < 10) return "****-**-**";
        if (dob.charAt(4) == '-') {
            return dob.substring(0, 5) + "**-**";
        }
        // DD/MM/YYYY format
        return "**/**/" + dob.substring(dob.length() - 4);
    }

    /**
     * Mask a full name: show first character of each part.
     * {@code Jane Marie Doe} → {@code J*** M**** D**}
     */
    public static String maskName(String name) {
        if (name == null || name.isBlank()) return "***";
        String[] parts = name.split("\\s+");
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) result.append(' ');
            String part = parts[i];
            if (part.length() <= 1) {
                result.append(part);
            } else {
                result.append(part.charAt(0)).append(repeat(MASK_CHAR, part.length() - 1));
            }
        }
        return result.toString();
    }

    // ── Generic ──────────────────────────────────────────────

    /**
     * Generic masking: show first 2 and last 2 characters, mask middle.
     * For short strings (≤4 chars), mask everything.
     */
    public static String maskGeneric(String value) {
        if (value == null) return null;
        if (value.length() <= 4) return repeat(MASK_CHAR, value.length());
        return value.substring(0, 2) + repeat(MASK_CHAR, value.length() - 4) + value.substring(value.length() - 2);
    }

    /**
     * Mask based on detected PII type.
     */
    public static String maskByType(String value, String piiType) {
        if (value == null) return null;
        return switch (piiType.toUpperCase()) {
            case "PAN" -> maskPan(value);
            case "CVV" -> maskCvv(value);
            case "SSN" -> maskSsn(value);
            case "PASSPORT" -> maskPassport(value);
            case "EMAIL" -> maskEmail(value);
            case "PHONE" -> maskPhone(value);
            case "IBAN" -> maskIban(value);
            case "DOB" -> maskDob(value);
            case "IP_ADDRESS" -> maskIpAddress(value);
            case "NAME" -> maskName(value);
            default -> maskGeneric(value);
        };
    }

    private static String repeat(char c, int count) {
        if (count <= 0) return "";
        return String.valueOf(c).repeat(count);
    }
}
