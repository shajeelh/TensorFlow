package com.paymenthub.pii.config;

import com.paymenthub.pii.masker.PiiMasker;
import com.paymenthub.pii.sanitizer.PiiJsonSanitizer;
import com.paymenthub.pii.scanner.PiiScanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * Auto-configuration for the PII starter.
 *
 * <h3>Configuration Properties</h3>
 * <pre>
 * hub.pii:
 *   luhn-validation: true            # Validate PANs with Luhn checksum
 *   log-masking-enabled: true        # Enable PII masking in log output (ADR-020: non-optional)
 * </pre>
 */
@AutoConfiguration
@EnableConfigurationProperties(PiiAutoConfiguration.PiiProperties.class)
public class PiiAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(PiiAutoConfiguration.class);

    @Bean
    @ConditionalOnMissingBean
    public PiiScanner piiScanner(PiiProperties properties) {
        log.info("Configuring PiiScanner: luhnValidation={}", properties.isLuhnValidation());
        return new PiiScanner(properties.isLuhnValidation());
    }

    @Bean
    @ConditionalOnMissingBean
    public PiiJsonSanitizer piiJsonSanitizer(PiiScanner scanner) {
        return new PiiJsonSanitizer(scanner);
    }

    @ConfigurationProperties(prefix = "hub.pii")
    public static class PiiProperties {

        /** Enable Luhn checksum validation for PAN detection. Default: true. */
        private boolean luhnValidation = true;

        /** Enable PII masking in log output. ADR-020: non-optional in production. */
        private boolean logMaskingEnabled = true;

        public boolean isLuhnValidation() { return luhnValidation; }
        public void setLuhnValidation(boolean v) { this.luhnValidation = v; }
        public boolean isLogMaskingEnabled() { return logMaskingEnabled; }
        public void setLogMaskingEnabled(boolean v) { this.logMaskingEnabled = v; }
    }
}
