package com.paymenthub.pii.sanitizer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.paymenthub.common.enums.DataClassification;
import com.paymenthub.pii.masker.PiiMasker;
import com.paymenthub.pii.scanner.PiiScanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Recursive JSON tree sanitizer for audit event payloads.
 *
 * <p>Walks every node in a JSON tree (audit event state change,
 * metadata, etc.), scanning each text value for PII. Detected
 * PII is handled according to its classification tier.</p>
 *
 * <h3>Processing Rules</h3>
 * <ul>
 *   <li>Tier 0 (PCI): <strong>Redacted</strong> — replaced with {@code [REDACTED-PCI]}.
 *       The original value is irreversibly destroyed.</li>
 *   <li>Tier 1 (PII High): <strong>Tokenized</strong> — replaced with a format-preserving
 *       token. Original stored in PII Vault (not implemented here).</li>
 *   <li>Tier 2 (PII Standard): <strong>Masked</strong> — replaced with
 *       format-preserving mask (e.g., {@code j***e@m***.com}).</li>
 *   <li>Tier 3 (Business): <strong>Unchanged</strong></li>
 * </ul>
 *
 * <h3>Field Name Heuristics</h3>
 * <p>In addition to content scanning, field names are checked against
 * a known set of PII field names (e.g., "email", "pan", "ssn",
 * "cardNumber", "iban"). Fields matching these names are always
 * sanitized regardless of content detection results.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Thread-safe. Uses per-invocation state only.</p>
 */
public class PiiJsonSanitizer {

    private static final Logger log = LoggerFactory.getLogger(PiiJsonSanitizer.class);

    private static final ObjectMapper MAPPER = new ObjectMapper();

    /** Field names that always indicate PII, regardless of content. */
    private static final Map<String, DataClassification> PII_FIELD_NAMES = Map.ofEntries(
        // Tier 0
        Map.entry("pan", DataClassification.TIER_0_PCI),
        Map.entry("cardNumber", DataClassification.TIER_0_PCI),
        Map.entry("card_number", DataClassification.TIER_0_PCI),
        Map.entry("primaryAccountNumber", DataClassification.TIER_0_PCI),
        Map.entry("cvv", DataClassification.TIER_0_PCI),
        Map.entry("cvc", DataClassification.TIER_0_PCI),
        Map.entry("trackData", DataClassification.TIER_0_PCI),
        Map.entry("pinBlock", DataClassification.TIER_0_PCI),
        // Tier 1
        Map.entry("ssn", DataClassification.TIER_1_PII_HIGH),
        Map.entry("socialSecurityNumber", DataClassification.TIER_1_PII_HIGH),
        Map.entry("tin", DataClassification.TIER_1_PII_HIGH),
        Map.entry("taxId", DataClassification.TIER_1_PII_HIGH),
        Map.entry("passportNumber", DataClassification.TIER_1_PII_HIGH),
        Map.entry("passport", DataClassification.TIER_1_PII_HIGH),
        Map.entry("bankAccountNumber", DataClassification.TIER_1_PII_HIGH),
        // Tier 2
        Map.entry("email", DataClassification.TIER_2_PII_STANDARD),
        Map.entry("emailAddress", DataClassification.TIER_2_PII_STANDARD),
        Map.entry("phone", DataClassification.TIER_2_PII_STANDARD),
        Map.entry("phoneNumber", DataClassification.TIER_2_PII_STANDARD),
        Map.entry("mobile", DataClassification.TIER_2_PII_STANDARD),
        Map.entry("iban", DataClassification.TIER_2_PII_STANDARD),
        Map.entry("dateOfBirth", DataClassification.TIER_2_PII_STANDARD),
        Map.entry("dob", DataClassification.TIER_2_PII_STANDARD),
        Map.entry("fullName", DataClassification.TIER_2_PII_STANDARD),
        Map.entry("firstName", DataClassification.TIER_2_PII_STANDARD),
        Map.entry("lastName", DataClassification.TIER_2_PII_STANDARD),
        Map.entry("address", DataClassification.TIER_2_PII_STANDARD),
        Map.entry("sourceIp", DataClassification.TIER_2_PII_STANDARD),
        Map.entry("ipAddress", DataClassification.TIER_2_PII_STANDARD)
    );

    private final PiiScanner scanner;

    public PiiJsonSanitizer(PiiScanner scanner) {
        this.scanner = Objects.requireNonNull(scanner, "PiiScanner required");
    }

    /**
     * Sanitize a JSON tree in-place, replacing PII values according to their tier.
     *
     * @param node the root JSON node to sanitize
     * @return the sanitized node (same reference, mutated)
     */
    public JsonNode sanitize(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) return node;
        sanitizeNode(node, null, null);
        return node;
    }

    /**
     * Sanitize a deep copy of the JSON tree (non-destructive).
     */
    public JsonNode sanitizeCopy(JsonNode node) {
        if (node == null) return null;
        JsonNode copy = node.deepCopy();
        sanitize(copy);
        return copy;
    }

    /**
     * Get a report of which fields were sanitized and at what tier.
     */
    public List<SanitizationRecord> sanitizeWithReport(JsonNode node) {
        if (node == null) return List.of();
        List<SanitizationRecord> records = new ArrayList<>();
        sanitizeNodeWithReport(node, "", records);
        return Collections.unmodifiableList(records);
    }

    // ── Internal ─────────────────────────────────────────────

    private void sanitizeNode(JsonNode node, String fieldName, ObjectNode parent) {
        if (node.isObject()) {
            ObjectNode obj = (ObjectNode) node;
            Iterator<Map.Entry<String, JsonNode>> fields = obj.fields();
            List<Map.Entry<String, JsonNode>> fieldList = new ArrayList<>();
            fields.forEachRemaining(fieldList::add);

            for (Map.Entry<String, JsonNode> field : fieldList) {
                sanitizeNode(field.getValue(), field.getKey(), obj);
            }
        } else if (node.isArray()) {
            ArrayNode arr = (ArrayNode) node;
            for (int i = 0; i < arr.size(); i++) {
                sanitizeNode(arr.get(i), fieldName, null);
            }
        } else if (node.isTextual() && parent != null && fieldName != null) {
            String value = node.asText();
            String sanitized = sanitizeValue(value, fieldName);
            if (!sanitized.equals(value)) {
                parent.set(fieldName, TextNode.valueOf(sanitized));
            }
        }
    }

    private void sanitizeNodeWithReport(JsonNode node, String path, List<SanitizationRecord> records) {
        if (node.isObject()) {
            ObjectNode obj = (ObjectNode) node;
            Iterator<Map.Entry<String, JsonNode>> fields = obj.fields();
            List<Map.Entry<String, JsonNode>> fieldList = new ArrayList<>();
            fields.forEachRemaining(fieldList::add);

            for (Map.Entry<String, JsonNode> field : fieldList) {
                String childPath = path.isEmpty() ? field.getKey() : path + "." + field.getKey();
                if (field.getValue().isTextual()) {
                    String original = field.getValue().asText();
                    String sanitized = sanitizeValue(original, field.getKey());
                    if (!sanitized.equals(original)) {
                        obj.set(field.getKey(), TextNode.valueOf(sanitized));
                        DataClassification tier = inferTier(field.getKey(), original);
                        records.add(new SanitizationRecord(childPath, tier, original.length()));
                    }
                } else {
                    sanitizeNodeWithReport(field.getValue(), childPath, records);
                }
            }
        } else if (node.isArray()) {
            for (int i = 0; i < node.size(); i++) {
                sanitizeNodeWithReport(node.get(i), path + "[" + i + "]", records);
            }
        }
    }

    private String sanitizeValue(String value, String fieldName) {
        if (value == null || value.isEmpty()) return value;

        // 1. Check field name heuristic first
        DataClassification fieldTier = PII_FIELD_NAMES.get(fieldName);
        if (fieldTier != null) {
            return applyTierMasking(value, fieldTier, fieldName);
        }

        // 2. Fall back to content scanning
        var matches = scanner.scan(value);
        if (matches.isEmpty()) return value;

        // Return the most restrictive (lowest tier) match handling
        return scanner.scanAndRedact(value);
    }

    private String applyTierMasking(String value, DataClassification tier, String fieldName) {
        return switch (tier) {
            case TIER_0_PCI -> "[REDACTED-PCI]";
            case TIER_1_PII_HIGH -> "[TOKENIZED]";
            case TIER_2_PII_STANDARD -> maskByFieldName(value, fieldName);
            case TIER_3_BUSINESS -> value;
        };
    }

    private String maskByFieldName(String value, String fieldName) {
        String lower = fieldName.toLowerCase();
        if (lower.contains("email")) return PiiMasker.maskEmail(value);
        if (lower.contains("phone") || lower.contains("mobile")) return PiiMasker.maskPhone(value);
        if (lower.contains("iban")) return PiiMasker.maskIban(value);
        if (lower.contains("ip")) return PiiMasker.maskIpAddress(value);
        if (lower.contains("dob") || lower.contains("birth")) return PiiMasker.maskDob(value);
        if (lower.contains("name")) return PiiMasker.maskName(value);
        if (lower.contains("address")) return PiiMasker.maskGeneric(value);
        return PiiMasker.maskGeneric(value);
    }

    private DataClassification inferTier(String fieldName, String value) {
        DataClassification fromName = PII_FIELD_NAMES.get(fieldName);
        if (fromName != null) return fromName;
        var matches = scanner.scan(value);
        if (!matches.isEmpty()) return matches.getFirst().classification();
        return DataClassification.TIER_3_BUSINESS;
    }

    /**
     * Record of a field that was sanitized.
     *
     * @param fieldPath      JSON path (e.g., "stateChange.after.email")
     * @param classification the PII tier
     * @param originalLength length of the original value (for audit logging)
     */
    public record SanitizationRecord(
        String fieldPath,
        DataClassification classification,
        int originalLength
    ) {}
}
