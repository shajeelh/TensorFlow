package com.paymenthub.pii.scanner;

import com.paymenthub.common.enums.DataClassification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Scans text for PII and PCI data, classifying each match by tier.
 *
 * <h3>Detection Tiers (per PII-PCI Addendum)</h3>
 * <table>
 *   <tr><th>Tier</th><th>Data</th><th>Action</th></tr>
 *   <tr><td>0 — PCI</td><td>PAN (with Luhn), CVV, track data, PIN block</td><td>REDACT immediately</td></tr>
 *   <tr><td>1 — PII High</td><td>SSN/TIN, passport number, bank account</td><td>TOKENIZE</td></tr>
 *   <tr><td>2 — PII Standard</td><td>Email, phone, IBAN, date of birth</td><td>ENCRYPT + MASK in logs</td></tr>
 *   <tr><td>3 — Business</td><td>Everything else</td><td>No action</td></tr>
 * </table>
 *
 * <h3>PAN Detection</h3>
 * <p>Credit card numbers are detected by pattern (Visa, Mastercard, Amex, Discover)
 * AND validated with the Luhn algorithm to reduce false positives. Numbers that
 * match the pattern but fail Luhn are classified as Tier 3 (business data).</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Thread-safe. All regex patterns are pre-compiled and immutable.</p>
 */
public class PiiScanner {

    private static final Logger log = LoggerFactory.getLogger(PiiScanner.class);

    // ── Tier 0: PCI (MUST NEVER persist) ─────────────────────

    /** Visa, Mastercard, Amex, Discover, JCB, Diners Club, UnionPay */
    private static final Pattern PAN_PATTERN = Pattern.compile(
        "\\b(?:" +
            "4[0-9]{12}(?:[0-9]{3})?" +          // Visa
            "|5[1-5][0-9]{14}" +                   // Mastercard
            "|3[47][0-9]{13}" +                    // Amex
            "|6(?:011|5[0-9]{2})[0-9]{12}" +       // Discover
            "|(?:2131|1800|35\\d{3})\\d{11}" +     // JCB
            "|3(?:0[0-5]|[68][0-9])[0-9]{11}" +   // Diners
            "|62[0-9]{14,17}" +                     // UnionPay
        ")\\b"
    );

    /** CVV/CVC: 3-4 digits in specific contexts */
    private static final Pattern CVV_PATTERN = Pattern.compile(
        "(?i)(?:cvv|cvc|cvv2|cvc2|cid)[\\s:=]*([0-9]{3,4})\\b"
    );

    // ── Tier 1: PII High (tokenize) ─────────────────────────

    /** US SSN: XXX-XX-XXXX */
    private static final Pattern SSN_PATTERN = Pattern.compile(
        "\\b(?!000|666|9\\d{2})\\d{3}-(?!00)\\d{2}-(?!0000)\\d{4}\\b"
    );

    /** Passport: 1-2 letters + 6-9 digits */
    private static final Pattern PASSPORT_PATTERN = Pattern.compile(
        "\\b[A-Z]{1,2}[0-9]{6,9}\\b"
    );

    // ── Tier 2: PII Standard (encrypt + mask) ────────────────

    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b"
    );

    /** International phone: +country-code followed by digits */
    private static final Pattern PHONE_PATTERN = Pattern.compile(
        "\\+[1-9]\\d{1,14}\\b"
    );

    /** IBAN: 2-letter country + 2 check digits + up to 30 alphanumeric */
    private static final Pattern IBAN_PATTERN = Pattern.compile(
        "\\b[A-Z]{2}\\d{2}\\s?[A-Z0-9]{4}\\s?(?:[A-Z0-9]{4}\\s?){1,7}[A-Z0-9]{1,4}\\b"
    );

    /** Date of birth: YYYY-MM-DD or DD/MM/YYYY patterns */
    private static final Pattern DOB_PATTERN = Pattern.compile(
        "\\b(?:\\d{4}-(?:0[1-9]|1[012])-(?:0[1-9]|[12]\\d|3[01])" +
        "|(?:0[1-9]|[12]\\d|3[01])[/.](?:0[1-9]|1[012])[/.]\\d{4})\\b"
    );

    /** IPv4 address */
    private static final Pattern IPV4_PATTERN = Pattern.compile(
        "\\b(?:(?:25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(?:25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\b"
    );

    private final boolean luhnValidation;

    /**
     * @param luhnValidation if true, PAN matches are validated with Luhn algorithm
     */
    public PiiScanner(boolean luhnValidation) {
        this.luhnValidation = luhnValidation;
    }

    public PiiScanner() {
        this(true);
    }

    // ── Scanning ─────────────────────────────────────────────

    /**
     * Scan text for all PII/PCI data.
     *
     * @param text text to scan (null-safe)
     * @return list of detected PII matches, ordered by position
     */
    public List<PiiMatch> scan(String text) {
        if (text == null || text.isEmpty()) return List.of();

        List<PiiMatch> matches = new ArrayList<>();

        // Tier 0
        scanPattern(text, PAN_PATTERN, DataClassification.TIER_0_PCI, "PAN", matches, true);
        scanPattern(text, CVV_PATTERN, DataClassification.TIER_0_PCI, "CVV", matches, false);

        // Tier 1
        scanPattern(text, SSN_PATTERN, DataClassification.TIER_1_PII_HIGH, "SSN", matches, false);
        scanPattern(text, PASSPORT_PATTERN, DataClassification.TIER_1_PII_HIGH, "PASSPORT", matches, false);

        // Tier 2
        scanPattern(text, EMAIL_PATTERN, DataClassification.TIER_2_PII_STANDARD, "EMAIL", matches, false);
        scanPattern(text, PHONE_PATTERN, DataClassification.TIER_2_PII_STANDARD, "PHONE", matches, false);
        scanPattern(text, IBAN_PATTERN, DataClassification.TIER_2_PII_STANDARD, "IBAN", matches, false);
        scanPattern(text, DOB_PATTERN, DataClassification.TIER_2_PII_STANDARD, "DOB", matches, false);
        scanPattern(text, IPV4_PATTERN, DataClassification.TIER_2_PII_STANDARD, "IP_ADDRESS", matches, false);

        matches.sort(Comparator.comparingInt(PiiMatch::start));
        return Collections.unmodifiableList(matches);
    }

    /**
     * Check if text contains any Tier 0 (PCI) data.
     * Optimized fast-path for log message pre-screening.
     */
    public boolean containsTier0(String text) {
        if (text == null || text.isEmpty()) return false;
        Matcher m = PAN_PATTERN.matcher(text);
        while (m.find()) {
            String candidate = m.group().replaceAll("\\s", "");
            if (!luhnValidation || passesLuhn(candidate)) return true;
        }
        return CVV_PATTERN.matcher(text).find();
    }

    /**
     * Scan and immediately redact all PII, returning cleaned text.
     * Tier 0 → "[REDACTED-PCI]", Tier 1 → "[REDACTED-PII]",
     * Tier 2 → masked value.
     */
    public String scanAndRedact(String text) {
        if (text == null) return null;
        List<PiiMatch> matches = scan(text);
        if (matches.isEmpty()) return text;

        StringBuilder result = new StringBuilder(text);
        // Process in reverse order to preserve positions
        for (int i = matches.size() - 1; i >= 0; i--) {
            PiiMatch match = matches.get(i);
            String replacement = switch (match.classification()) {
                case TIER_0_PCI -> "[REDACTED-PCI]";
                case TIER_1_PII_HIGH -> "[REDACTED-PII]";
                case TIER_2_PII_STANDARD -> "[MASKED-" + match.type() + "]";
                default -> match.value();
            };
            result.replace(match.start(), match.end(), replacement);
        }
        return result.toString();
    }

    // ── Luhn Algorithm ───────────────────────────────────────

    /**
     * Luhn checksum validation for credit card numbers.
     * Reduces false positives in PAN detection by ~95%.
     */
    public static boolean passesLuhn(String number) {
        if (number == null || number.length() < 13) return false;
        String digits = number.replaceAll("\\D", "");
        if (digits.length() < 13 || digits.length() > 19) return false;

        int sum = 0;
        boolean alternate = false;
        for (int i = digits.length() - 1; i >= 0; i--) {
            int n = digits.charAt(i) - '0';
            if (alternate) {
                n *= 2;
                if (n > 9) n -= 9;
            }
            sum += n;
            alternate = !alternate;
        }
        return (sum % 10 == 0);
    }

    // ── Internal ─────────────────────────────────────────────

    private void scanPattern(String text, Pattern pattern, DataClassification classification,
                              String type, List<PiiMatch> matches, boolean requireLuhn) {
        Matcher matcher = pattern.matcher(text);
        while (matcher.find()) {
            String value = matcher.group();
            if (requireLuhn && luhnValidation) {
                String cleaned = value.replaceAll("\\s", "");
                if (!passesLuhn(cleaned)) continue;
            }
            matches.add(new PiiMatch(value, classification, type, matcher.start(), matcher.end()));
        }
    }

    /**
     * A detected PII match within scanned text.
     *
     * @param value          the matched text
     * @param classification data tier
     * @param type           detection type (PAN, EMAIL, SSN, etc.)
     * @param start          start position in original text
     * @param end            end position in original text
     */
    public record PiiMatch(
        String value,
        DataClassification classification,
        String type,
        int start,
        int end
    ) {}
}
