package com.paymenthub.pii.logging;

import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.classic.spi.ILoggingEvent;
import com.paymenthub.pii.scanner.PiiScanner;

import java.nio.charset.StandardCharsets;

/**
 * Logback encoder that scans every log message for PII/PCI data
 * and redacts it before output.
 *
 * <p><strong>ADR-020: PII log masking is non-optional in production.</strong></p>
 *
 * <p>This encoder wraps the standard {@link PatternLayoutEncoder} and
 * post-processes every log line through the {@link PiiScanner}. Tier 0
 * data is always redacted. Tier 2 data is masked.</p>
 *
 * <h3>Performance</h3>
 * <p>Scanning adds ~10-50μs per log line (regex matching). For high-throughput
 * paths, consider using structured logging with pre-classified fields
 * rather than embedding PII in free-text messages.</p>
 *
 * <h3>Configuration (logback-spring.xml)</h3>
 * <pre>{@code
 * <appender name="STDOUT" class="ch.qos.logback.core.ConsoleAppender">
 *     <encoder class="com.paymenthub.pii.logging.PiiMaskingLogEncoder">
 *         <pattern>%d{ISO8601} [%thread] %-5level %logger{36} - %msg%n</pattern>
 *     </encoder>
 * </appender>
 * }</pre>
 */
public class PiiMaskingLogEncoder extends PatternLayoutEncoder {

    private final PiiScanner scanner = new PiiScanner(true);
    private boolean enabled = true;

    @Override
    public byte[] encode(ILoggingEvent event) {
        byte[] original = super.encode(event);
        if (!enabled) return original;

        String logLine = new String(original, StandardCharsets.UTF_8);

        // Fast-path: skip scanning if no digit sequences that could be PANs
        // and no @ signs that could be emails
        if (!mightContainPii(logLine)) return original;

        String sanitized = scanner.scanAndRedact(logLine);
        if (sanitized.equals(logLine)) return original;

        return sanitized.getBytes(StandardCharsets.UTF_8);
    }

    /**
     * Quick pre-screen to avoid expensive regex scanning on log lines
     * that are very unlikely to contain PII.
     */
    private boolean mightContainPii(String text) {
        boolean hasLongDigitSequence = false;
        int consecutiveDigits = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '@') return true; // email
            if (c == '+' && i + 1 < text.length() && Character.isDigit(text.charAt(i + 1))) return true; // phone
            if (Character.isDigit(c)) {
                consecutiveDigits++;
                if (consecutiveDigits >= 9) { hasLongDigitSequence = true; break; }
            } else {
                consecutiveDigits = 0;
            }
        }
        return hasLongDigitSequence;
    }

    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public boolean isEnabled() { return enabled; }
}
