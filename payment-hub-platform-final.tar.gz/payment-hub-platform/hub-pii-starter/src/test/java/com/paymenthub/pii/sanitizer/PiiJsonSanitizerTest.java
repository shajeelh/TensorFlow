package com.paymenthub.pii.sanitizer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.paymenthub.common.enums.DataClassification;
import com.paymenthub.pii.scanner.PiiScanner;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.*;

class PiiJsonSanitizerTest {

    private PiiJsonSanitizer sanitizer;
    private ObjectMapper mapper;

    @BeforeEach
    void setUp() {
        sanitizer = new PiiJsonSanitizer(new PiiScanner(true));
        mapper = new ObjectMapper();
    }

    @Test
    @DisplayName("Field named 'email' is masked by field name heuristic")
    void emailFieldMasked() {
        ObjectNode node = mapper.createObjectNode();
        node.put("email", "jane.doe@megabank.com");
        node.put("transactionId", "TXN-001");

        sanitizer.sanitize(node);

        assertThat(node.get("email").asText()).contains("*");
        assertThat(node.get("email").asText()).doesNotContain("jane.doe");
        assertThat(node.get("transactionId").asText()).isEqualTo("TXN-001"); // unchanged
    }

    @Test
    @DisplayName("Field named 'pan' is redacted as PCI")
    void panFieldRedacted() {
        ObjectNode node = mapper.createObjectNode();
        node.put("pan", "4111111111111111");

        sanitizer.sanitize(node);

        assertThat(node.get("pan").asText()).isEqualTo("[REDACTED-PCI]");
    }

    @Test
    @DisplayName("Field named 'ssn' is tokenized")
    void ssnFieldTokenized() {
        ObjectNode node = mapper.createObjectNode();
        node.put("ssn", "123-45-6789");

        sanitizer.sanitize(node);

        assertThat(node.get("ssn").asText()).isEqualTo("[TOKENIZED]");
    }

    @Test
    @DisplayName("Nested objects are recursively sanitized")
    void nestedSanitization() {
        ObjectNode root = mapper.createObjectNode();
        ObjectNode customer = mapper.createObjectNode();
        customer.put("email", "test@example.com");
        customer.put("iban", "GB82WEST12345698765432");
        root.set("customer", customer);
        root.put("amount", "1000.00");

        sanitizer.sanitize(root);

        assertThat(root.get("customer").get("email").asText()).contains("*");
        assertThat(root.get("customer").get("iban").asText()).contains("*");
        assertThat(root.get("amount").asText()).isEqualTo("1000.00"); // unchanged
    }

    @Test
    @DisplayName("Content scanning detects PAN in unknown field names")
    void contentScanning() {
        ObjectNode node = mapper.createObjectNode();
        node.put("reference", "Payment for card 4111111111111111");

        sanitizer.sanitize(node);

        assertThat(node.get("reference").asText()).doesNotContain("4111111111111111");
        assertThat(node.get("reference").asText()).contains("[REDACTED-PCI]");
    }

    @Test
    @DisplayName("Arrays are sanitized")
    void arraySanitization() throws Exception {
        String json = """
            {
                "contacts": [
                    {"email": "a@test.com", "name": "Alice"},
                    {"email": "b@test.com", "name": "Bob"}
                ]
            }
            """;
        JsonNode node = mapper.readTree(json);
        sanitizer.sanitize(node);

        JsonNode contacts = node.get("contacts");
        assertThat(contacts.get(0).get("email").asText()).contains("*");
        assertThat(contacts.get(1).get("email").asText()).contains("*");
    }

    @Test
    @DisplayName("sanitizeCopy does not modify original")
    void nonDestructive() {
        ObjectNode original = mapper.createObjectNode();
        original.put("email", "original@test.com");

        JsonNode sanitized = sanitizer.sanitizeCopy(original);

        assertThat(original.get("email").asText()).isEqualTo("original@test.com"); // unchanged
        assertThat(sanitized.get("email").asText()).contains("*"); // masked copy
    }

    @Test
    @DisplayName("sanitizeWithReport tracks sanitized fields")
    void withReport() {
        ObjectNode node = mapper.createObjectNode();
        node.put("email", "jane@test.com");
        node.put("pan", "4111111111111111");
        node.put("status", "ACTIVE");

        List<PiiJsonSanitizer.SanitizationRecord> records = sanitizer.sanitizeWithReport(node);

        assertThat(records)
            .hasSizeGreaterThanOrEqualTo(2)
            .anyMatch(r -> r.fieldPath().equals("email") &&
                r.classification() == DataClassification.TIER_2_PII_STANDARD)
            .anyMatch(r -> r.fieldPath().equals("pan") &&
                r.classification() == DataClassification.TIER_0_PCI);
    }

    @Test
    @DisplayName("IP address field is masked to /24")
    void ipAddressMasked() {
        ObjectNode node = mapper.createObjectNode();
        node.put("sourceIp", "10.1.42.99");

        sanitizer.sanitize(node);

        assertThat(node.get("sourceIp").asText()).isEqualTo("10.1.42.***");
    }

    @Test
    @DisplayName("Null and empty nodes are safe")
    void nullSafety() {
        assertThat(sanitizer.sanitize(null)).isNull();
        assertThat(sanitizer.sanitize(mapper.nullNode())).isNotNull();
    }

    @Test
    @DisplayName("Business fields are unchanged")
    void businessFieldsUnchanged() {
        ObjectNode node = mapper.createObjectNode();
        node.put("transactionId", "TXN-2025-00142857");
        node.put("currency", "EUR");
        node.put("amount", "5000.00");
        node.put("status", "COMPLETED");

        sanitizer.sanitize(node);

        assertThat(node.get("transactionId").asText()).isEqualTo("TXN-2025-00142857");
        assertThat(node.get("currency").asText()).isEqualTo("EUR");
        assertThat(node.get("amount").asText()).isEqualTo("5000.00");
        assertThat(node.get("status").asText()).isEqualTo("COMPLETED");
    }
}
