package com.paymenthub.pii.masker;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

class PiiMaskerTest {

    @Test
    @DisplayName("maskPan shows only last 4 digits")
    void maskPan() {
        assertThat(PiiMasker.maskPan("4111111111111111")).isEqualTo("****1111");
        assertThat(PiiMasker.maskPan("378282246310005")).isEqualTo("****0005");
        assertThat(PiiMasker.maskPan(null)).isEqualTo("****");
    }

    @Test
    @DisplayName("maskCvv fully redacts")
    void maskCvv() {
        assertThat(PiiMasker.maskCvv("123")).isEqualTo("***");
    }

    @Test
    @DisplayName("maskSsn fully masks")
    void maskSsn() {
        assertThat(PiiMasker.maskSsn("123-45-6789")).isEqualTo("***-**-****");
    }

    @Test
    @DisplayName("maskEmail preserves structure")
    void maskEmail() {
        String masked = PiiMasker.maskEmail("jane.doe@megabank.com");
        assertThat(masked).startsWith("j");
        assertThat(masked).contains("@");
        assertThat(masked).endsWith(".com");
        assertThat(masked).contains("*");
        assertThat(masked).doesNotContain("jane.doe");
        assertThat(masked).doesNotContain("megabank");
    }

    @Test
    @DisplayName("maskEmail with short local part")
    void maskShortEmail() {
        String masked = PiiMasker.maskEmail("ab@x.com");
        assertThat(masked).contains("@");
        assertThat(masked).contains("*");
    }

    @Test
    @DisplayName("maskPhone shows country code and last 2")
    void maskPhone() {
        String masked = PiiMasker.maskPhone("+441234567890");
        assertThat(masked).startsWith("+44");
        assertThat(masked).endsWith("90");
        assertThat(masked).contains("*");
    }

    @Test
    @DisplayName("maskIban shows country and last 4")
    void maskIban() {
        String masked = PiiMasker.maskIban("GB82WEST12345698765432");
        assertThat(masked).startsWith("GB");
        assertThat(masked).endsWith("5432");
        assertThat(masked).contains("*");
    }

    @Test
    @DisplayName("maskIpAddress masks to /24")
    void maskIp() {
        assertThat(PiiMasker.maskIpAddress("10.1.42.99")).isEqualTo("10.1.42.***");
        assertThat(PiiMasker.maskIpAddress("192.168.0.1")).isEqualTo("192.168.0.***");
    }

    @Test
    @DisplayName("maskDob shows year only")
    void maskDob() {
        assertThat(PiiMasker.maskDob("1990-03-15")).isEqualTo("1990-**-**");
    }

    @Test
    @DisplayName("maskName shows first character of each part")
    void maskName() {
        String masked = PiiMasker.maskName("Jane Marie Doe");
        assertThat(masked).startsWith("J");
        assertThat(masked).contains("M");
        assertThat(masked).contains("D");
        assertThat(masked).doesNotContain("ane");
        assertThat(masked).doesNotContain("oe");
    }

    @Test
    @DisplayName("maskGeneric shows first 2 and last 2")
    void maskGeneric() {
        assertThat(PiiMasker.maskGeneric("abcdef")).isEqualTo("ab**ef");
        assertThat(PiiMasker.maskGeneric("abcdefghij")).isEqualTo("ab******ij");
    }

    @Test
    @DisplayName("maskGeneric for short strings")
    void maskGenericShort() {
        assertThat(PiiMasker.maskGeneric("ab")).isEqualTo("**");
        assertThat(PiiMasker.maskGeneric("abcd")).isEqualTo("****");
    }

    @Test
    @DisplayName("maskByType dispatches correctly")
    void maskByType() {
        assertThat(PiiMasker.maskByType("4111111111111111", "PAN")).isEqualTo("****1111");
        assertThat(PiiMasker.maskByType("***-**-****", "SSN")).isEqualTo("***-**-****");
        assertThat(PiiMasker.maskByType("10.1.42.99", "IP_ADDRESS")).isEqualTo("10.1.42.***");
    }

    @Test
    @DisplayName("Null inputs handled safely")
    void nullSafety() {
        assertThat(PiiMasker.maskEmail(null)).isNull();
        assertThat(PiiMasker.maskIpAddress(null)).isNull();
        assertThat(PiiMasker.maskGeneric(null)).isNull();
        assertThat(PiiMasker.maskByType(null, "EMAIL")).isNull();
    }
}
