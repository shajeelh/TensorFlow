package com.paymenthub.pii.scanner;

import com.paymenthub.common.enums.DataClassification;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.*;

class PiiScannerTest {

    private PiiScanner scanner;

    @BeforeEach
    void setUp() {
        scanner = new PiiScanner(true); // Luhn enabled
    }

    @Nested
    @DisplayName("Tier 0: PCI (PAN detection)")
    class PanDetection {

        @Test
        @DisplayName("Detect valid Visa PAN (passes Luhn)")
        void validVisa() {
            // 4111111111111111 is a well-known Luhn-valid test PAN
            var matches = scanner.scan("Payment with card 4111111111111111 processed");
            assertThat(matches)
                .hasSize(1)
                .first()
                .satisfies(m -> {
                    assertThat(m.classification()).isEqualTo(DataClassification.TIER_0_PCI);
                    assertThat(m.type()).isEqualTo("PAN");
                    assertThat(m.value()).isEqualTo("4111111111111111");
                });
        }

        @Test
        @DisplayName("Detect valid Mastercard PAN")
        void validMastercard() {
            var matches = scanner.scan("Card: 5500000000000004");
            assertThat(matches).hasSize(1);
            assertThat(matches.getFirst().classification()).isEqualTo(DataClassification.TIER_0_PCI);
        }

        @Test
        @DisplayName("Reject PAN-shaped number that fails Luhn")
        void failsLuhn() {
            // Change last digit to make Luhn fail
            var matches = scanner.scan("Not a card: 4111111111111112");
            assertThat(matches).isEmpty();
        }

        @Test
        @DisplayName("Without Luhn, PAN-shaped numbers are detected")
        void noLuhnValidation() {
            var noLuhn = new PiiScanner(false);
            var matches = noLuhn.scan("Number: 4111111111111112");
            assertThat(matches).hasSize(1);
        }

        @Test
        @DisplayName("Detect Amex PAN (15 digits)")
        void amex() {
            var matches = scanner.scan("Amex 378282246310005");
            assertThat(matches).hasSize(1);
            assertThat(matches.getFirst().type()).isEqualTo("PAN");
        }

        @Test
        @DisplayName("containsTier0 fast-path returns true for PAN")
        void containsTier0() {
            assertThat(scanner.containsTier0("Card 4111111111111111 ok")).isTrue();
            assertThat(scanner.containsTier0("No PII here")).isFalse();
        }
    }

    @Nested
    @DisplayName("Tier 1: PII High (SSN)")
    class SsnDetection {

        @Test
        @DisplayName("Detect valid SSN pattern")
        void validSsn() {
            var matches = scanner.scan("SSN: 123-45-6789");
            assertThat(matches)
                .anyMatch(m -> m.type().equals("SSN") &&
                    m.classification() == DataClassification.TIER_1_PII_HIGH);
        }

        @Test
        @DisplayName("Reject invalid SSN (starts with 000)")
        void invalidSsn000() {
            var matches = scanner.scan("Invalid: 000-12-3456");
            assertThat(matches).noneMatch(m -> m.type().equals("SSN"));
        }

        @Test
        @DisplayName("Reject invalid SSN (starts with 666)")
        void invalidSsn666() {
            var matches = scanner.scan("Invalid: 666-12-3456");
            assertThat(matches).noneMatch(m -> m.type().equals("SSN"));
        }
    }

    @Nested
    @DisplayName("Tier 2: PII Standard")
    class Tier2Detection {

        @Test
        @DisplayName("Detect email address")
        void email() {
            var matches = scanner.scan("Contact: jane.doe@megabank.com for info");
            assertThat(matches)
                .anyMatch(m -> m.type().equals("EMAIL") &&
                    m.classification() == DataClassification.TIER_2_PII_STANDARD &&
                    m.value().equals("jane.doe@megabank.com"));
        }

        @Test
        @DisplayName("Detect international phone number")
        void phone() {
            var matches = scanner.scan("Call +447911123456 for support");
            assertThat(matches)
                .anyMatch(m -> m.type().equals("PHONE") &&
                    m.classification() == DataClassification.TIER_2_PII_STANDARD);
        }

        @Test
        @DisplayName("Detect IBAN")
        void iban() {
            var matches = scanner.scan("Transfer to GB82WEST12345698765432");
            assertThat(matches)
                .anyMatch(m -> m.type().equals("IBAN") &&
                    m.classification() == DataClassification.TIER_2_PII_STANDARD);
        }

        @Test
        @DisplayName("Detect IPv4 address")
        void ipv4() {
            var matches = scanner.scan("Request from 192.168.1.42");
            assertThat(matches)
                .anyMatch(m -> m.type().equals("IP_ADDRESS"));
        }

        @Test
        @DisplayName("Detect date of birth YYYY-MM-DD")
        void dob() {
            var matches = scanner.scan("DOB: 1990-03-15");
            assertThat(matches)
                .anyMatch(m -> m.type().equals("DOB"));
        }
    }

    @Nested
    @DisplayName("scanAndRedact")
    class RedactionTests {

        @Test
        @DisplayName("PAN is replaced with [REDACTED-PCI]")
        void redactPan() {
            String result = scanner.scanAndRedact("Card 4111111111111111 charged");
            assertThat(result).contains("[REDACTED-PCI]");
            assertThat(result).doesNotContain("4111111111111111");
        }

        @Test
        @DisplayName("Email is replaced with [MASKED-EMAIL]")
        void redactEmail() {
            String result = scanner.scanAndRedact("User jane.doe@example.com logged in");
            assertThat(result).contains("[MASKED-EMAIL]");
            assertThat(result).doesNotContain("jane.doe@example.com");
        }

        @Test
        @DisplayName("Multiple PII types in one string")
        void multiplePii() {
            String result = scanner.scanAndRedact(
                "Card 4111111111111111, email jane@test.com, IP 10.1.42.99");
            assertThat(result).doesNotContain("4111111111111111");
            assertThat(result).doesNotContain("jane@test.com");
        }

        @Test
        @DisplayName("Clean text is unchanged")
        void cleanText() {
            String clean = "Payment PAY-2025-001 completed with status SUCCESS";
            assertThat(scanner.scanAndRedact(clean)).isEqualTo(clean);
        }

        @Test
        @DisplayName("Null input returns null")
        void nullInput() {
            assertThat(scanner.scanAndRedact(null)).isNull();
        }
    }

    @Nested
    @DisplayName("Luhn algorithm")
    class LuhnTests {

        @Test
        @DisplayName("Known valid PANs pass Luhn")
        void validPans() {
            assertThat(PiiScanner.passesLuhn("4111111111111111")).isTrue(); // Visa
            assertThat(PiiScanner.passesLuhn("5500000000000004")).isTrue(); // MC
            assertThat(PiiScanner.passesLuhn("378282246310005")).isTrue();  // Amex
            assertThat(PiiScanner.passesLuhn("6011111111111117")).isTrue(); // Discover
        }

        @Test
        @DisplayName("Invalid numbers fail Luhn")
        void invalidPans() {
            assertThat(PiiScanner.passesLuhn("4111111111111112")).isFalse();
            assertThat(PiiScanner.passesLuhn("1234567890123456")).isFalse();
        }

        @Test
        @DisplayName("Too short for Luhn")
        void tooShort() {
            assertThat(PiiScanner.passesLuhn("1234")).isFalse();
            assertThat(PiiScanner.passesLuhn(null)).isFalse();
        }
    }
}
