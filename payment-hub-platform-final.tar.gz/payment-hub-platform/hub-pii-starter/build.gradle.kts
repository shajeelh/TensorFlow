plugins {
    `java-library`
}

description = "Payment Hub — PII Detection, Masking, Tokenization, and Log Sanitization"

dependencies {
    api(project(":hub-common-model"))
    implementation(project(":hub-crypto-starter"))

    implementation("com.fasterxml.jackson.core:jackson-databind")
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("org.slf4j:slf4j-api")
    implementation("ch.qos.logback:logback-classic")

    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
