package com.paymenthub.common.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Classification of the entity that initiated an audited operation.
 *
 * <p>Every audit event must identify its actor. The type determines
 * which identity fields are expected to be populated:</p>
 * <ul>
 *   <li>{@link #USER} — requires {@code identity} (email/ID),
 *       {@code authMethod}, optional {@code sessionId}, {@code sourceIp}</li>
 *   <li>{@link #SERVICE} — requires {@code identity} (service principal),
 *       {@code authMethod} (mTLS/OAuth2 client credentials)</li>
 *   <li>{@link #SYSTEM} — internal platform operations (health checks,
 *       heartbeats, scheduled jobs). Identity = module name.</li>
 *   <li>{@link #SCHEDULER} — cron-triggered operations.
 *       Identity = scheduler name + job ID.</li>
 *   <li>{@link #EXTERNAL} — third-party rail callbacks (SWIFT, SEPA).
 *       Identity = rail identifier + certificate DN.</li>
 * </ul>
 */
public enum ActorType {

    USER("user"),
    SERVICE("service"),
    SYSTEM("system"),
    SCHEDULER("scheduler"),
    EXTERNAL("external");

    private final String value;

    ActorType(String value) { this.value = value; }

    @JsonValue
    public String getValue() { return value; }

    /**
     * Parse from string, case-insensitive.
     * Returns {@link #SYSTEM} for null/unknown values (safe default).
     */
    public static ActorType fromValue(String v) {
        if (v == null || v.isBlank()) return SYSTEM;
        for (ActorType t : values()) {
            if (t.value.equalsIgnoreCase(v) || t.name().equalsIgnoreCase(v)) return t;
        }
        return SYSTEM;
    }
}
