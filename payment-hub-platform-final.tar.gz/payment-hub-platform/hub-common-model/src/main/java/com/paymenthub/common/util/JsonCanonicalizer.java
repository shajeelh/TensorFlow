package com.paymenthub.common.util;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.TreeMap;

/**
 * RFC 8785 compliant JSON Canonicalization Scheme (JCS).
 *
 * <p>Produces deterministic JSON output for cryptographic hashing.
 * Key guarantees:</p>
 * <ul>
 *   <li>Object keys sorted lexicographically (Unicode code point order)</li>
 *   <li>No whitespace between tokens</li>
 *   <li>Numbers serialized in a canonical form</li>
 *   <li>UTF-8 encoding</li>
 *   <li>Consistent handling of null, boolean, and special values</li>
 * </ul>
 *
 * <p>This is critical for hash chain integrity — the same logical event
 * must always produce the same hash regardless of field insertion order
 * in the source object.</p>
 */
public final class JsonCanonicalizer {

    private static final ObjectMapper MAPPER = JsonMapper.builder()
        .addModule(new JavaTimeModule())
        .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
        .disable(SerializationFeature.INDENT_OUTPUT)
        .disable(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS) // we sort ourselves
        .enable(JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN)
        .build();

    private JsonCanonicalizer() {}

    /**
     * Serialize an object to canonical JSON string (RFC 8785).
     * Object keys are sorted lexicographically, no whitespace.
     */
    public static String canonicalize(Object obj) {
        try {
            // Convert to a tree of sorted maps
            Object normalized = normalize(MAPPER.convertValue(obj, Object.class));
            return MAPPER.writeValueAsString(normalized);
        } catch (Exception e) {
            throw new IllegalArgumentException("Failed to canonicalize: " + e.getMessage(), e);
        }
    }

    /**
     * Serialize to canonical JSON bytes (UTF-8) for hashing.
     */
    public static byte[] canonicalizeToBytes(Object obj) {
        return canonicalize(obj).getBytes(StandardCharsets.UTF_8);
    }

    /**
     * Recursively normalize a value — sort map keys, recurse into lists.
     */
    @SuppressWarnings("unchecked")
    private static Object normalize(Object value) {
        if (value == null) return null;

        if (value instanceof Map<?, ?> map) {
            // Sort keys lexicographically (RFC 8785 requires Unicode code point order)
            TreeMap<String, Object> sorted = new TreeMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                String key = String.valueOf(entry.getKey());
                sorted.put(key, normalize(entry.getValue()));
            }
            return sorted;
        }

        if (value instanceof Iterable<?> iterable) {
            return java.util.stream.StreamSupport.stream(iterable.spliterator(), false)
                .map(JsonCanonicalizer::normalize)
                .toList();
        }

        // Primitives (String, Number, Boolean) — return as-is
        return value;
    }

    /**
     * Get the shared ObjectMapper configured for canonical serialization.
     * Use for consistent serialization throughout the platform.
     */
    public static ObjectMapper mapper() { return MAPPER; }
}
