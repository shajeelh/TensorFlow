package com.paymenthub.common.exception;

/**
 * Base exception for all Payment Hub platform errors.
 *
 * <p>Every exception carries a machine-readable {@code errorCode},
 * a {@code severity} classification, and a {@code retrySafe} flag
 * that tells callers whether retrying the operation is safe.</p>
 */
public abstract sealed class HubException extends RuntimeException
    permits HubBusinessException, HubTechnicalException, HubSecurityException {

    private final String errorCode;
    private final Severity severity;
    private final boolean retrySafe;

    protected HubException(String errorCode, String message, Severity severity, boolean retrySafe) {
        super(message);
        this.errorCode = errorCode;
        this.severity = severity;
        this.retrySafe = retrySafe;
    }

    protected HubException(String errorCode, String message, Severity severity, boolean retrySafe, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.severity = severity;
        this.retrySafe = retrySafe;
    }

    public String errorCode() { return errorCode; }
    public Severity severity() { return severity; }
    public boolean retrySafe() { return retrySafe; }

    public enum Severity { BUSINESS, TECHNICAL, SECURITY }
}
