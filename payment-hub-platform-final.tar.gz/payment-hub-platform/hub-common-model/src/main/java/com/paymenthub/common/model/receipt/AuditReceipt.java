package com.paymenthub.common.model.receipt;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.paymenthub.common.enums.ReceiptStatus;

import java.time.Instant;
import java.util.UUID;

/**
 * Proof of durable recording returned by the synchronous audit API.
 *
 * <p>For SYNC mode events, the business operation blocks until this
 * receipt is received with status {@link ReceiptStatus#CONFIRMED} or
 * {@link ReceiptStatus#CONFIRMED_SIGNED}. A {@link ReceiptStatus#FAILED}
 * status means the business operation MUST NOT proceed.</p>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonDeserialize(builder = AuditReceipt.Builder.class)
public final class AuditReceipt {

    private final UUID eventId;
    private final byte[] recordHash;
    private final byte[] previousHash;
    private final long sequenceNumber;
    private final Instant recordedAt;
    private final String clockId;
    private final PersistenceConfirmation persistence;
    private final ReceiptStatus status;
    private final String failureReason;

    private AuditReceipt(Builder b) {
        this.eventId = b.eventId;
        this.recordHash = b.recordHash;
        this.previousHash = b.previousHash;
        this.sequenceNumber = b.sequenceNumber;
        this.recordedAt = b.recordedAt;
        this.clockId = b.clockId;
        this.persistence = b.persistence;
        this.status = b.status != null ? b.status : ReceiptStatus.FAILED;
        this.failureReason = b.failureReason;
    }

    public UUID eventId() { return eventId; }
    public byte[] recordHash() { return recordHash; }
    public byte[] previousHash() { return previousHash; }
    public long sequenceNumber() { return sequenceNumber; }
    public Instant recordedAt() { return recordedAt; }
    public String clockId() { return clockId; }
    public PersistenceConfirmation persistence() { return persistence; }
    public ReceiptStatus status() { return status; }
    public String failureReason() { return failureReason; }

    public boolean isConfirmed() { return status.isDurabilityConfirmed(); }

    public static Builder builder() { return new Builder(); }

    @Override
    public String toString() {
        return "AuditReceipt{eventId=%s, status=%s, seq=%d}".formatted(eventId, status, sequenceNumber);
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static final class Builder {
        private UUID eventId;
        private byte[] recordHash;
        private byte[] previousHash;
        private long sequenceNumber;
        private Instant recordedAt;
        private String clockId;
        private PersistenceConfirmation persistence;
        private ReceiptStatus status;
        private String failureReason;

        private Builder() {}

        public Builder eventId(UUID v) { this.eventId = v; return this; }
        public Builder recordHash(byte[] v) { this.recordHash = v; return this; }
        public Builder previousHash(byte[] v) { this.previousHash = v; return this; }
        public Builder sequenceNumber(long v) { this.sequenceNumber = v; return this; }
        public Builder recordedAt(Instant v) { this.recordedAt = v; return this; }
        public Builder clockId(String v) { this.clockId = v; return this; }
        public Builder persistence(PersistenceConfirmation v) { this.persistence = v; return this; }
        public Builder status(ReceiptStatus v) { this.status = v; return this; }
        public Builder failureReason(String v) { this.failureReason = v; return this; }

        public AuditReceipt build() { return new AuditReceipt(this); }
    }
}
