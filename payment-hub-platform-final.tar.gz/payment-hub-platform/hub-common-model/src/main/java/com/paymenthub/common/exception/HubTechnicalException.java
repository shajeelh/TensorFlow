package com.paymenthub.common.exception;

/**
 * Technical/infrastructure failure — database timeout, network error,
 * serialization failure. Typically retry-safe. Logged at ERROR level.
 */
public non-sealed class HubTechnicalException extends HubException {

    public HubTechnicalException(String errorCode, String message) {
        super(errorCode, message, Severity.TECHNICAL, true);
    }

    public HubTechnicalException(String errorCode, String message, boolean retrySafe) {
        super(errorCode, message, Severity.TECHNICAL, retrySafe);
    }

    public HubTechnicalException(String errorCode, String message, Throwable cause) {
        super(errorCode, message, Severity.TECHNICAL, true, cause);
    }
}
