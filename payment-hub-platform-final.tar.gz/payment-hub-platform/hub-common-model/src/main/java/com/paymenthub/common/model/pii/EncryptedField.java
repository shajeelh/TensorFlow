package com.paymenthub.common.model.pii;

/**
 * An encrypted PII field (Tier 2). Encrypted with AES-256-GCM.
 * Can be decrypted for authorized queries with access logging.
 *
 * @param ciphertext   Base64-encoded IV + ciphertext
 * @param keyId        identifier of the encryption key
 * @param fieldPath    original field path
 */
public record EncryptedField(
    String ciphertext,
    String keyId,
    String fieldPath
) {}
