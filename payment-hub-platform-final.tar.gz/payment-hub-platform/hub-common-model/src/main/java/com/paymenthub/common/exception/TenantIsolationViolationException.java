package com.paymenthub.common.exception;

/**
 * Thrown when a cross-tenant data access is detected.
 * P1 alert — indicates a potential data breach.
 */
public final class TenantIsolationViolationException extends HubSecurityException {

    private final String requestedTenantId;
    private final String contextTenantId;

    public TenantIsolationViolationException(String requestedTenantId, String contextTenantId) {
        super("TENANT-001",
            "Tenant isolation violation: requested '%s' but context is '%s'"
                .formatted(requestedTenantId, contextTenantId));
        this.requestedTenantId = requestedTenantId;
        this.contextTenantId = contextTenantId;
    }

    public String requestedTenantId() { return requestedTenantId; }
    public String contextTenantId() { return contextTenantId; }
}
