package com.paymenthub.common.model.integrity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.paymenthub.common.util.HexUtils;

import java.util.Objects;

/**
 * Cryptographic integrity metadata attached to every audit event
 * by the audit module server's processing pipeline.
 *
 * <p>Three layers of integrity protection:</p>
 * <ol>
 *   <li><strong>Record hash</strong> — SHA3-256 of the canonical JSON event
 *       (excluding this integrity block to avoid circular dependency)</li>
 *   <li><strong>Hash chain</strong> — previous event's hash linked to this one:
 *       {@code previousHash} forms the backward pointer</li>
 *   <li><strong>Sequence number</strong> — monotonically increasing per chain partition,
 *       enabling gap detection</li>
 * </ol>
 *
 * <p>This information is populated by
 * {@code com.paymenthub.audit.server.processing.chain.HashChainService}
 * and is immutable once set. The batch signature and Merkle proof are
 * stored separately in {@link SignatureInfo} and {@link MerkleProof}.</p>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonDeserialize(builder = IntegrityInfo.Builder.class)
public final class IntegrityInfo {

    private final byte[] recordHash;
    private final byte[] previousHash;
    private final long sequenceNumber;
    private final String hashAlgorithm;
    private final String chainId;
    private final SignatureInfo signature;

    private IntegrityInfo(Builder b) {
        this.recordHash = b.recordHash;
        this.previousHash = b.previousHash;
        this.sequenceNumber = b.sequenceNumber;
        this.hashAlgorithm = b.hashAlgorithm != null ? b.hashAlgorithm : "SHA3-256";
        this.chainId = b.chainId;
        this.signature = b.signature;
    }

    public byte[] recordHash() { return recordHash; }
    public byte[] previousHash() { return previousHash; }
    public long sequenceNumber() { return sequenceNumber; }
    public String hashAlgorithm() { return hashAlgorithm; }
    public String chainId() { return chainId; }
    public SignatureInfo signature() { return signature; }

    /** Hex string of the record hash for display/logging. */
    public String recordHashHex() {
        return recordHash != null ? HexUtils.toHex(recordHash) : null;
    }

    /** Whether this is the genesis event (first in chain). */
    public boolean isGenesis() {
        if (previousHash == null) return true;
        for (byte b : previousHash) { if (b != 0) return false; }
        return true;
    }

    public static Builder builder() { return new Builder(); }

    @Override
    public String toString() {
        return "IntegrityInfo{seq=%d, hash=%s, genesis=%b}"
            .formatted(sequenceNumber, recordHashHex(), isGenesis());
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static final class Builder {
        private byte[] recordHash;
        private byte[] previousHash;
        private long sequenceNumber;
        private String hashAlgorithm;
        private String chainId;
        private SignatureInfo signature;

        private Builder() {}

        public Builder recordHash(byte[] v) { this.recordHash = v; return this; }
        public Builder previousHash(byte[] v) { this.previousHash = v; return this; }
        public Builder sequenceNumber(long v) { this.sequenceNumber = v; return this; }
        public Builder hashAlgorithm(String v) { this.hashAlgorithm = v; return this; }
        public Builder chainId(String v) { this.chainId = v; return this; }
        public Builder signature(SignatureInfo v) { this.signature = v; return this; }

        public IntegrityInfo build() { return new IntegrityInfo(this); }
    }
}
