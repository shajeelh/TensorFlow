package com.paymenthub.common.exception;

/**
 * Thrown when a synchronous audit recording fails.
 * The business operation MUST abort when this is thrown (ADR-008).
 *
 * <p>This is the single most critical exception in the platform — it
 * means we cannot guarantee the audit trail is complete, so we
 * refuse to proceed with the business operation.</p>
 */
public final class AuditRecordingFailedException extends HubSecurityException {

    private final String eventType;
    private final String correlationId;

    public AuditRecordingFailedException(String message, String eventType, String correlationId) {
        super("AUDIT-001", message);
        this.eventType = eventType;
        this.correlationId = correlationId;
    }

    public AuditRecordingFailedException(String message, Throwable cause) {
        super("AUDIT-001", message, cause);
        this.eventType = null;
        this.correlationId = null;
    }

    public String eventType() { return eventType; }
    public String correlationId() { return correlationId; }
}
