package com.paymenthub.common.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Status of an {@code AuditReceipt} returned by the synchronous audit API.
 */
public enum ReceiptStatus {

    /** Event durably persisted but not yet batch-signed. */
    CONFIRMED("confirmed"),

    /** Event persisted and included in a signed batch. */
    CONFIRMED_SIGNED("confirmed_signed"),

    /** Persistence failed — business operation MUST abort. */
    FAILED("failed"),

    /** Duplicate idempotency key — event already recorded. */
    DUPLICATE("duplicate"),

    /** Recording timed out — deadline exceeded. */
    TIMEOUT("timeout");

    private final String value;

    ReceiptStatus(String value) { this.value = value; }

    @JsonValue
    public String getValue() { return value; }

    public boolean isSuccess() {
        return this == CONFIRMED || this == CONFIRMED_SIGNED || this == DUPLICATE;
    }

    public boolean isDurabilityConfirmed() {
        return this == CONFIRMED || this == CONFIRMED_SIGNED;
    }

    public static ReceiptStatus fromValue(String v) {
        if (v == null) return FAILED;
        for (ReceiptStatus s : values()) {
            if (s.value.equalsIgnoreCase(v) || s.name().equalsIgnoreCase(v)) return s;
        }
        return FAILED;
    }
}
