package com.paymenthub.common.model.receipt;

/**
 * Confirms where and how an audit event was durably persisted.
 *
 * @param storeType      storage backend (e.g., "postgresql", "opensearch", "s3-worm")
 * @param storeReference specific reference (e.g., partition name, shard ID)
 * @param replicated     whether the write was replicated to a secondary
 * @param replicaCount   number of confirmed replicas (0 if not replicated)
 */
public record PersistenceConfirmation(
    String storeType,
    String storeReference,
    boolean replicated,
    int replicaCount
) {
    public static PersistenceConfirmation postgresql(String reference) {
        return new PersistenceConfirmation("postgresql", reference, false, 0);
    }

    public static PersistenceConfirmation opensearch(String reference, int replicas) {
        return new PersistenceConfirmation("opensearch", reference, replicas > 0, replicas);
    }
}
