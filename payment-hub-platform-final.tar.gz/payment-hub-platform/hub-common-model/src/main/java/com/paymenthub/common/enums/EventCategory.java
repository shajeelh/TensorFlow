package com.paymenthub.common.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Top-level categorization of audit events.
 * Determines the hash chain partition (one chain per entity per category).
 *
 * <p>Derived from the event type prefix (e.g., {@code payment.initiated} → BUSINESS,
 * {@code admin.manual_override} → ADMIN).</p>
 */
public enum EventCategory {

    BUSINESS("business"),
    SECURITY("security"),
    ADMIN("admin"),
    CONFIG("config"),
    DATA_ACCESS("data_access"),
    TECHNICAL("technical"),
    LIFECYCLE("lifecycle");

    private final String value;

    EventCategory(String value) { this.value = value; }

    @JsonValue
    public String getValue() { return value; }

    /**
     * Infer category from dot-notation event type.
     * Falls back to {@link #BUSINESS} for unrecognized prefixes.
     */
    public static EventCategory fromEventType(String eventType) {
        if (eventType == null || eventType.isBlank()) return BUSINESS;
        String prefix = eventType.contains(".")
            ? eventType.substring(0, eventType.indexOf('.'))
            : eventType;
        return switch (prefix.toLowerCase()) {
            case "payment", "fx", "fee", "settlement" -> BUSINESS;
            case "auth", "authz", "mfa" -> SECURITY;
            case "admin" -> ADMIN;
            case "config", "rule" -> CONFIG;
            case "data", "export", "query" -> DATA_ACCESS;
            case "crypto", "circuit", "health", "deploy" -> TECHNICAL;
            case "startup", "shutdown", "failover" -> LIFECYCLE;
            default -> BUSINESS;
        };
    }
}
