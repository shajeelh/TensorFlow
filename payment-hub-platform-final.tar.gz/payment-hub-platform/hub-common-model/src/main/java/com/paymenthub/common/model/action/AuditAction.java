package com.paymenthub.common.model.action;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.paymenthub.common.enums.ActionResult;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.Map;
import java.util.Objects;

/**
 * Describes the operation that was performed in an audited action.
 *
 * <p>{@code operation} follows a verb convention: CREATE, READ, UPDATE,
 * DELETE, VALIDATE, APPROVE, REJECT, OVERRIDE, EXECUTE, CANCEL, RETRY.</p>
 *
 * <p>{@code durationUs} captures the wall-clock execution time in microseconds.
 * This is critical for performance forensics and SLA compliance monitoring.</p>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonDeserialize(builder = AuditAction.Builder.class)
public final class AuditAction {

    private final String operation;
    private final ActionResult result;
    private final String reasonCode;
    private final String reasonDetail;
    private final long durationUs;
    private final Map<String, String> metadata;

    private AuditAction(Builder b) {
        this.operation = Objects.requireNonNull(b.operation, "Operation is required");
        this.result = Objects.requireNonNull(b.result, "Result is required");
        this.reasonCode = b.reasonCode;
        this.reasonDetail = b.reasonDetail;
        this.durationUs = b.durationUs;
        this.metadata = b.metadata != null ? Map.copyOf(b.metadata) : Map.of();
    }

    @NotBlank public String operation() { return operation; }
    @NotNull public ActionResult result() { return result; }
    public String reasonCode() { return reasonCode; }
    public String reasonDetail() { return reasonDetail; }
    public long durationUs() { return durationUs; }
    public Map<String, String> metadata() { return metadata; }

    /** Whether the action completed with a failure. */
    public boolean isFailed() { return result == ActionResult.FAILURE || result == ActionResult.ERROR; }

    /** Whether this action represents a security-relevant denial. */
    public boolean isDenied() { return result == ActionResult.DENIED; }

    public static Builder builder() { return new Builder(); }

    public Builder toBuilder() {
        return new Builder()
            .operation(operation).result(result).reasonCode(reasonCode)
            .reasonDetail(reasonDetail).durationUs(durationUs).metadata(metadata);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AuditAction a)) return false;
        return Objects.equals(operation, a.operation) && result == a.result;
    }

    @Override
    public int hashCode() { return Objects.hash(operation, result); }

    @Override
    public String toString() {
        return "AuditAction{op='%s', result=%s, %dμs}".formatted(operation, result, durationUs);
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static final class Builder {
        private String operation;
        private ActionResult result;
        private String reasonCode;
        private String reasonDetail;
        private long durationUs;
        private Map<String, String> metadata;

        private Builder() {}

        public Builder operation(String operation) { this.operation = operation; return this; }
        public Builder result(ActionResult result) { this.result = result; return this; }
        public Builder reasonCode(String reasonCode) { this.reasonCode = reasonCode; return this; }
        public Builder reasonDetail(String reasonDetail) { this.reasonDetail = reasonDetail; return this; }
        public Builder durationUs(long durationUs) { this.durationUs = durationUs; return this; }
        public Builder metadata(Map<String, String> metadata) { this.metadata = metadata; return this; }

        public AuditAction build() { return new AuditAction(this); }
    }
}
