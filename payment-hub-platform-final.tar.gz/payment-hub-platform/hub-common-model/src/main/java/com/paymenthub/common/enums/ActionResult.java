package com.paymenthub.common.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Outcome of an audited operation.
 *
 * <p>{@link #PARTIAL} is specific to batch operations where some items
 * succeeded and others failed — common in bulk payment processing.</p>
 */
public enum ActionResult {

    SUCCESS("success"),
    FAILURE("failure"),
    PARTIAL("partial"),
    DENIED("denied"),
    ERROR("error"),
    TIMEOUT("timeout"),
    SKIPPED("skipped");

    private final String value;

    ActionResult(String value) { this.value = value; }

    @JsonValue
    public String getValue() { return value; }

    public boolean isSuccessful() { return this == SUCCESS; }

    public boolean isTerminal() {
        return this == SUCCESS || this == FAILURE || this == DENIED;
    }

    public static ActionResult fromValue(String v) {
        if (v == null) return ERROR;
        for (ActionResult r : values()) {
            if (r.value.equalsIgnoreCase(v) || r.name().equalsIgnoreCase(v)) return r;
        }
        return ERROR;
    }
}
