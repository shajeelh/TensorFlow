package com.paymenthub.common.model.pii;

import com.paymenthub.common.enums.DataClassification;

/**
 * Classification metadata for a single field within an audit event payload.
 * Used by the PII pipeline to determine handling strategy.
 *
 * @param fieldPath        JSON path (e.g., "stateChange.after.accountNumber")
 * @param classification   the data tier
 * @param tokenizedField   tokenized replacement (Tier 1 only)
 * @param encryptedField   encrypted replacement (Tier 2 only)
 */
public record FieldClassification(
    String fieldPath,
    DataClassification classification,
    String tokenizedField,
    String encryptedField
) {
    /** Convenience factory for Tier 0 (redacted). */
    public static FieldClassification tier0Redacted(String path) {
        return new FieldClassification(path, DataClassification.TIER_0_PCI, null, null);
    }

    /** Convenience factory for Tier 3 (no handling). */
    public static FieldClassification business(String path) {
        return new FieldClassification(path, DataClassification.TIER_3_BUSINESS, null, null);
    }
}
