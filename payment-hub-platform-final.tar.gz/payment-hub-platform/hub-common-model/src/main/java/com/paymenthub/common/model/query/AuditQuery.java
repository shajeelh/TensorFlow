package com.paymenthub.common.model.query;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;

import java.time.Instant;
import java.util.List;
import java.util.Set;

/**
 * Audit query parameters — used by both REST and gRPC query APIs.
 *
 * <p>Supports multiple query patterns:</p>
 * <ul>
 *   <li>Correlation trace: {@code correlationId} — follow a single transaction</li>
 *   <li>Resource timeline: {@code resourceId} + time range — full history of an entity</li>
 *   <li>Actor audit: {@code actorIdentity} + time range — what did this person do?</li>
 *   <li>Full-text search: {@code fullTextQuery} — PostgreSQL tsvector / OpenSearch query_string</li>
 *   <li>Event type filter: {@code eventTypes} — filter by specific event types</li>
 * </ul>
 *
 * <p>Tenant isolation is mandatory — every query must specify {@code tenantId}.
 * This is enforced at the repository level via row-level security.</p>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonDeserialize(builder = AuditQuery.Builder.class)
public final class AuditQuery {

    private final String tenantId;
    private final String correlationId;
    private final String resourceId;
    private final String resourceType;
    private final String actorIdentity;
    private final String eventType;
    private final Set<String> eventTypes;
    private final Instant timeFrom;
    private final Instant timeTo;
    private final String fullTextQuery;
    private final int pageSize;
    private final String pageToken;
    private final boolean includeMerkleProof;
    private final SortOrder sortOrder;

    private AuditQuery(Builder b) {
        this.tenantId = b.tenantId;
        this.correlationId = b.correlationId;
        this.resourceId = b.resourceId;
        this.resourceType = b.resourceType;
        this.actorIdentity = b.actorIdentity;
        this.eventType = b.eventType;
        this.eventTypes = b.eventTypes != null ? Set.copyOf(b.eventTypes) : Set.of();
        this.timeFrom = b.timeFrom;
        this.timeTo = b.timeTo;
        this.fullTextQuery = b.fullTextQuery;
        this.pageSize = b.pageSize > 0 ? Math.min(b.pageSize, 1000) : 50;
        this.pageToken = b.pageToken;
        this.includeMerkleProof = b.includeMerkleProof;
        this.sortOrder = b.sortOrder != null ? b.sortOrder : SortOrder.TIMESTAMP_DESC;
    }

    public String tenantId() { return tenantId; }
    public String correlationId() { return correlationId; }
    public String resourceId() { return resourceId; }
    public String resourceType() { return resourceType; }
    public String actorIdentity() { return actorIdentity; }
    public String eventType() { return eventType; }
    public Set<String> eventTypes() { return eventTypes; }
    public Instant timeFrom() { return timeFrom; }
    public Instant timeTo() { return timeTo; }
    public String fullTextQuery() { return fullTextQuery; }
    public int pageSize() { return pageSize; }
    public String pageToken() { return pageToken; }
    public boolean includeMerkleProof() { return includeMerkleProof; }
    public SortOrder sortOrder() { return sortOrder; }

    /** Whether this query has a time range filter. */
    public boolean hasTimeRange() { return timeFrom != null || timeTo != null; }

    /** Whether this query is a correlation-trace (single transaction follow). */
    public boolean isCorrelationTrace() { return correlationId != null; }

    public static Builder builder() { return new Builder(); }

    public enum SortOrder {
        TIMESTAMP_ASC,
        TIMESTAMP_DESC,
        SEQUENCE_ASC,
        SEQUENCE_DESC
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static final class Builder {
        private String tenantId;
        private String correlationId;
        private String resourceId;
        private String resourceType;
        private String actorIdentity;
        private String eventType;
        private Set<String> eventTypes;
        private Instant timeFrom;
        private Instant timeTo;
        private String fullTextQuery;
        private int pageSize;
        private String pageToken;
        private boolean includeMerkleProof;
        private SortOrder sortOrder;

        private Builder() {}

        public Builder tenantId(String v) { this.tenantId = v; return this; }
        public Builder correlationId(String v) { this.correlationId = v; return this; }
        public Builder resourceId(String v) { this.resourceId = v; return this; }
        public Builder resourceType(String v) { this.resourceType = v; return this; }
        public Builder actorIdentity(String v) { this.actorIdentity = v; return this; }
        public Builder eventType(String v) { this.eventType = v; return this; }
        public Builder eventTypes(Set<String> v) { this.eventTypes = v; return this; }
        public Builder timeFrom(Instant v) { this.timeFrom = v; return this; }
        public Builder timeTo(Instant v) { this.timeTo = v; return this; }
        public Builder fullTextQuery(String v) { this.fullTextQuery = v; return this; }
        public Builder pageSize(int v) { this.pageSize = v; return this; }
        public Builder pageToken(String v) { this.pageToken = v; return this; }
        public Builder includeMerkleProof(boolean v) { this.includeMerkleProof = v; return this; }
        public Builder sortOrder(SortOrder v) { this.sortOrder = v; return this; }

        public AuditQuery build() { return new AuditQuery(this); }
    }
}
