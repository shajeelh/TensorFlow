package com.paymenthub.common.model.actor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.paymenthub.common.enums.ActorType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.Objects;

/**
 * Identifies who performed an audited operation.
 *
 * <p>Immutable value object. All audit events must include an actor.
 * The combination of {@code type} + {@code identity} uniquely identifies
 * the actor within the platform.</p>
 *
 * <p>Fields are classified per the PII-PCI Addendum:</p>
 * <ul>
 *   <li>{@code identity} — Tier 2 PII (encrypted at rest, masked in logs)</li>
 *   <li>{@code sourceIp} — Tier 2 PII (masked to /24 subnet in logs)</li>
 *   <li>{@code deviceFingerprint} — Tier 2 PII</li>
 *   <li>{@code sessionId} — Tier 3 Business (no masking)</li>
 * </ul>
 *
 * <p>Example usage:</p>
 * <pre>{@code
 * var actor = AuditActor.builder()
 *     .type(ActorType.USER)
 *     .identity("jane.doe@megabank.com")
 *     .authMethod("oauth2-pkce")
 *     .sessionId("sess-abc123")
 *     .sourceIp("10.1.42.99")
 *     .geoLocation("US-NY")
 *     .build();
 * }</pre>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonDeserialize(builder = AuditActor.Builder.class)
public final class AuditActor {

    private final ActorType type;
    private final String identity;
    private final String displayName;
    private final String authMethod;
    private final String sessionId;
    private final String sourceIp;
    private final String geoLocation;
    private final String deviceFingerprint;
    private final String delegatedBy;
    private final String onBehalfOf;

    private AuditActor(Builder b) {
        this.type = Objects.requireNonNull(b.type, "Actor type is required");
        this.identity = Objects.requireNonNull(b.identity, "Actor identity is required");
        this.displayName = b.displayName;
        this.authMethod = b.authMethod;
        this.sessionId = b.sessionId;
        this.sourceIp = b.sourceIp;
        this.geoLocation = b.geoLocation;
        this.deviceFingerprint = b.deviceFingerprint;
        this.delegatedBy = b.delegatedBy;
        this.onBehalfOf = b.onBehalfOf;
    }

    // Accessors
    public ActorType type() { return type; }
    @NotNull public ActorType getType() { return type; }
    @NotBlank public String identity() { return identity; }
    public String getIdentity() { return identity; }
    public String displayName() { return displayName; }
    public String authMethod() { return authMethod; }
    public String sessionId() { return sessionId; }
    public String sourceIp() { return sourceIp; }
    public String geoLocation() { return geoLocation; }
    public String deviceFingerprint() { return deviceFingerprint; }
    public String delegatedBy() { return delegatedBy; }
    public String onBehalfOf() { return onBehalfOf; }

    /** Whether this actor represents a delegation chain (4-eyes principle). */
    public boolean isDelegated() { return delegatedBy != null; }

    /** Whether this is a human actor (USER or EXTERNAL). */
    public boolean isHuman() { return type == ActorType.USER || type == ActorType.EXTERNAL; }

    public static Builder builder() { return new Builder(); }

    public Builder toBuilder() {
        return new Builder()
            .type(type).identity(identity).displayName(displayName)
            .authMethod(authMethod).sessionId(sessionId).sourceIp(sourceIp)
            .geoLocation(geoLocation).deviceFingerprint(deviceFingerprint)
            .delegatedBy(delegatedBy).onBehalfOf(onBehalfOf);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AuditActor a)) return false;
        return type == a.type && Objects.equals(identity, a.identity);
    }

    @Override
    public int hashCode() { return Objects.hash(type, identity); }

    @Override
    public String toString() {
        return "AuditActor{type=%s, identity='%s'}".formatted(type, identity);
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static final class Builder {
        private ActorType type;
        private String identity;
        private String displayName;
        private String authMethod;
        private String sessionId;
        private String sourceIp;
        private String geoLocation;
        private String deviceFingerprint;
        private String delegatedBy;
        private String onBehalfOf;

        private Builder() {}

        public Builder type(ActorType type) { this.type = type; return this; }
        public Builder identity(String identity) { this.identity = identity; return this; }
        public Builder displayName(String displayName) { this.displayName = displayName; return this; }
        public Builder authMethod(String authMethod) { this.authMethod = authMethod; return this; }
        public Builder sessionId(String sessionId) { this.sessionId = sessionId; return this; }
        public Builder sourceIp(String sourceIp) { this.sourceIp = sourceIp; return this; }
        public Builder geoLocation(String geoLocation) { this.geoLocation = geoLocation; return this; }
        public Builder deviceFingerprint(String fp) { this.deviceFingerprint = fp; return this; }
        public Builder delegatedBy(String delegatedBy) { this.delegatedBy = delegatedBy; return this; }
        public Builder onBehalfOf(String onBehalfOf) { this.onBehalfOf = onBehalfOf; return this; }

        public AuditActor build() { return new AuditActor(this); }
    }
}
