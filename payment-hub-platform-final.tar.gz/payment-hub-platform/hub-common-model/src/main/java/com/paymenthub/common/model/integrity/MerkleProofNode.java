package com.paymenthub.common.model.integrity;

/**
 * Single node in a Merkle proof path.
 *
 * @param hash     sibling hash at this level
 * @param position whether the sibling is LEFT or RIGHT of the current node
 */
public record MerkleProofNode(
    byte[] hash,
    Position position
) {
    public enum Position { LEFT, RIGHT }
}
