package com.paymenthub.common.validation;

import com.paymenthub.common.model.event.AuditEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Validates audit events against the v2.1 schema contract.
 *
 * <p>Validation is performed at two points:</p>
 * <ol>
 *   <li>At emission time in {@code hub-audit-starter} (fail-fast)</li>
 *   <li>At ingestion time in {@code audit-module-server} (defense-in-depth)</li>
 * </ol>
 */
public final class EventValidator {

    private EventValidator() {}

    /**
     * Validate an audit event. Returns a list of validation errors.
     * Empty list = valid event.
     */
    public static List<String> validate(AuditEvent event) {
        List<String> errors = new ArrayList<>();

        if (event == null) {
            errors.add("Event is null");
            return errors;
        }

        // Identity
        if (event.eventId() == null) errors.add("eventId is required");
        if (isBlank(event.eventType())) errors.add("eventType is required");
        if (event.eventType() != null && !event.eventType().contains(".")) {
            errors.add("eventType must be dot-notation (e.g., 'payment.initiated')");
        }
        if (event.correlationId() == null) errors.add("correlationId is required");
        if (event.timestamp() == null) errors.add("timestamp is required");

        // Actor
        if (event.actor() == null) {
            errors.add("actor is required");
        } else {
            if (event.actor().type() == null) errors.add("actor.type is required");
            if (isBlank(event.actor().identity())) errors.add("actor.identity is required");
        }

        // Resource
        if (event.resource() == null) {
            errors.add("resource is required");
        } else {
            if (isBlank(event.resource().type())) errors.add("resource.type is required");
            if (isBlank(event.resource().id())) errors.add("resource.id is required");
            if (isBlank(event.resource().tenantId())) errors.add("resource.tenantId is required");
        }

        // Action
        if (event.action() == null) {
            errors.add("action is required");
        } else {
            if (isBlank(event.action().operation())) errors.add("action.operation is required");
            if (event.action().result() == null) errors.add("action.result is required");
        }

        return errors;
    }

    /**
     * Validate and throw if invalid.
     *
     * @throws IllegalArgumentException if validation fails
     */
    public static void validateOrThrow(AuditEvent event) {
        List<String> errors = validate(event);
        if (!errors.isEmpty()) {
            throw new IllegalArgumentException(
                "Invalid audit event: " + String.join("; ", errors));
        }
    }

    private static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }
}
