package com.paymenthub.common.model.integrity;

import java.util.List;

/**
 * Merkle inclusion proof — proves that a specific audit event's record hash
 * is included in a signed Merkle root without revealing other events.
 *
 * <p>Verification: starting from {@code leafHash}, walk the {@code path}
 * combining sibling hashes bottom-up. The result must equal {@code rootHash}.</p>
 *
 * @param leafHash  the record hash of the event being proved
 * @param rootHash  the Merkle root this proof anchors to
 * @param path      ordered list of sibling nodes from leaf to root
 * @param leafIndex position of the leaf in the tree
 */
public record MerkleProof(
    byte[] leafHash,
    byte[] rootHash,
    List<MerkleProofNode> path,
    int leafIndex
) {
    public int treeDepth() { return path != null ? path.size() : 0; }
}
