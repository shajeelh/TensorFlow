package com.paymenthub.common.model.resource;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.paymenthub.common.enums.DataClassification;
import jakarta.validation.constraints.NotBlank;

import java.util.Map;
import java.util.Objects;

/**
 * Identifies what was affected by an audited operation.
 *
 * <p>The resource anchors an audit event to a specific business entity
 * within the multi-tenant hierarchy: tenant → entity → resource type → resource ID.</p>
 *
 * <p>Example resources:</p>
 * <ul>
 *   <li>Payment: type="payment", id="PAY-2025-0001"</li>
 *   <li>FX Deal: type="fx_deal", id="FX-EUR-USD-12345"</li>
 *   <li>User Account: type="user", id="USR-jane-doe"</li>
 *   <li>Configuration: type="routing_rule", id="RULE-SWIFT-001"</li>
 * </ul>
 *
 * <p>{@code tenantId} is <strong>mandatory</strong> — it partitions all audit
 * data and enforces row-level security in PostgreSQL (ADR-007).</p>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonDeserialize(builder = AuditResource.Builder.class)
public final class AuditResource {

    private final String type;
    private final String id;
    private final String tenantId;
    private final String entityId;
    private final String parentResourceId;
    private final String parentResourceType;
    private final DataClassification classification;
    private final String jurisdiction;
    private final Map<String, String> identifiers;

    private AuditResource(Builder b) {
        this.type = Objects.requireNonNull(b.type, "Resource type is required");
        this.id = Objects.requireNonNull(b.id, "Resource ID is required");
        this.tenantId = Objects.requireNonNull(b.tenantId, "Tenant ID is required");
        this.entityId = b.entityId != null ? b.entityId : b.tenantId;
        this.parentResourceId = b.parentResourceId;
        this.parentResourceType = b.parentResourceType;
        this.classification = b.classification != null ? b.classification : DataClassification.TIER_3_BUSINESS;
        this.jurisdiction = b.jurisdiction;
        this.identifiers = b.identifiers != null ? Map.copyOf(b.identifiers) : Map.of();
    }

    @NotBlank public String type() { return type; }
    @NotBlank public String id() { return id; }
    @NotBlank public String tenantId() { return tenantId; }
    public String entityId() { return entityId; }
    public String parentResourceId() { return parentResourceId; }
    public String parentResourceType() { return parentResourceType; }
    public DataClassification classification() { return classification; }
    public String jurisdiction() { return jurisdiction; }
    public Map<String, String> identifiers() { return identifiers; }

    /** Composite key used for hash chain partitioning: tenantId:resourceType. */
    public String chainPartitionKey() {
        return tenantId + ":" + type;
    }

    /** Whether this resource has a parent (child operation in a workflow). */
    public boolean isChildResource() {
        return parentResourceId != null;
    }

    public static Builder builder() { return new Builder(); }

    public Builder toBuilder() {
        return new Builder()
            .type(type).id(id).tenantId(tenantId).entityId(entityId)
            .parentResourceId(parentResourceId).parentResourceType(parentResourceType)
            .classification(classification).jurisdiction(jurisdiction)
            .identifiers(identifiers);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AuditResource r)) return false;
        return Objects.equals(tenantId, r.tenantId) && Objects.equals(type, r.type) && Objects.equals(id, r.id);
    }

    @Override
    public int hashCode() { return Objects.hash(tenantId, type, id); }

    @Override
    public String toString() {
        return "AuditResource{tenant='%s', type='%s', id='%s'}".formatted(tenantId, type, id);
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static final class Builder {
        private String type;
        private String id;
        private String tenantId;
        private String entityId;
        private String parentResourceId;
        private String parentResourceType;
        private DataClassification classification;
        private String jurisdiction;
        private Map<String, String> identifiers;

        private Builder() {}

        public Builder type(String type) { this.type = type; return this; }
        public Builder id(String id) { this.id = id; return this; }
        public Builder tenantId(String tenantId) { this.tenantId = tenantId; return this; }
        public Builder entityId(String entityId) { this.entityId = entityId; return this; }
        public Builder parentResourceId(String parentResourceId) { this.parentResourceId = parentResourceId; return this; }
        public Builder parentResourceType(String parentResourceType) { this.parentResourceType = parentResourceType; return this; }
        public Builder classification(DataClassification c) { this.classification = c; return this; }
        public Builder jurisdiction(String jurisdiction) { this.jurisdiction = jurisdiction; return this; }
        public Builder identifiers(Map<String, String> identifiers) { this.identifiers = identifiers; return this; }

        public AuditResource build() { return new AuditResource(this); }
    }
}
