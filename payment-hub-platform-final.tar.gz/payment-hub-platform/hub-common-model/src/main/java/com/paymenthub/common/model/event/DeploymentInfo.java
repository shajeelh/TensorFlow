package com.paymenthub.common.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paymenthub.common.enums.DeploymentProfile;

/**
 * Deployment metadata attached to audit events by the server.
 *
 * @param profile the active deployment profile (LARGE/MEDIUM/SMALL)
 * @param instanceId unique identifier for this audit module instance
 * @param region cloud region or data center identifier
 * @param cluster Kubernetes cluster name
 * @param availabilityZone specific AZ within the region
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record DeploymentInfo(
    DeploymentProfile profile,
    String instanceId,
    String region,
    String cluster,
    String availabilityZone
) {
    public static DeploymentInfo of(DeploymentProfile profile, String instanceId) {
        return new DeploymentInfo(profile, instanceId, null, null, null);
    }
}
