package com.paymenthub.common.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Four-tier PII/PCI data classification per PII-PCI Addendum.
 *
 * <p>Determines how a field is handled throughout the audit pipeline:</p>
 * <ul>
 *   <li>{@link #TIER_0_PCI} — Never stored in audit. Redacted immediately.
 *       (PAN, CVV, track data, PIN block)</li>
 *   <li>{@link #TIER_1_PII_HIGH} — Tokenized before storage. Original
 *       stored in PII Vault with access logging.
 *       (SSN/TIN, passport number, bank account number)</li>
 *   <li>{@link #TIER_2_PII_STANDARD} — Encrypted at rest (AES-256-GCM),
 *       masked in logs and query responses.
 *       (Full name, email, phone, DOB, address, IBAN)</li>
 *   <li>{@link #TIER_3_BUSINESS} — Stored as-is. No special handling.
 *       (Transaction ID, status codes, amounts, currency codes)</li>
 * </ul>
 *
 * @see com.paymenthub.common.model.pii.FieldClassification
 */
public enum DataClassification {

    TIER_0_PCI("tier_0_pci", 0, true),
    TIER_1_PII_HIGH("tier_1_pii_high", 1, true),
    TIER_2_PII_STANDARD("tier_2_pii_standard", 2, true),
    TIER_3_BUSINESS("tier_3_business", 3, false);

    private final String value;
    private final int tier;
    private final boolean sensitive;

    DataClassification(String value, int tier, boolean sensitive) {
        this.value = value;
        this.tier = tier;
        this.sensitive = sensitive;
    }

    @JsonValue
    public String getValue() { return value; }
    public int getTier() { return tier; }
    public boolean isSensitive() { return sensitive; }
    public boolean requiresEncryption() { return tier <= 2; }
    public boolean requiresTokenization() { return tier <= 1; }
    public boolean mustNeverPersist() { return tier == 0; }

    public static DataClassification fromValue(String v) {
        if (v == null) return TIER_3_BUSINESS;
        for (DataClassification c : values()) {
            if (c.value.equalsIgnoreCase(v) || c.name().equalsIgnoreCase(v)) return c;
        }
        return TIER_3_BUSINESS;
    }
}
