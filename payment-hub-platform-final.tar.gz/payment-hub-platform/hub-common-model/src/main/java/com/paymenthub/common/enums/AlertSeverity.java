package com.paymenthub.common.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Anomaly alert severity per Section 7.1 of the v3 design.
 *
 * <ul>
 *   <li>{@link #P1} — Immediate page: hash chain break, signing key compromise, data exfiltration</li>
 *   <li>{@link #P2} — Urgent ticket: config change, excessive failed auth, privilege escalation</li>
 *   <li>{@link #P3} — Daily review: unusual query patterns, missing heartbeats</li>
 *   <li>{@link #P4} — Weekly report: capacity warnings, slow queries</li>
 * </ul>
 */
public enum AlertSeverity {

    P1("P1", "Critical — immediate page"),
    P2("P2", "Urgent — ticket within 15 min"),
    P3("P3", "Important — daily review"),
    P4("P4", "Informational — weekly report");

    private final String value;
    private final String description;

    AlertSeverity(String value, String description) {
        this.value = value;
        this.description = description;
    }

    @JsonValue
    public String getValue() { return value; }
    public String getDescription() { return description; }
    public boolean requiresImmediateAction() { return this == P1; }

    public static AlertSeverity fromValue(String v) {
        if (v == null) return P3;
        for (AlertSeverity s : values()) {
            if (s.value.equalsIgnoreCase(v) || s.name().equalsIgnoreCase(v)) return s;
        }
        return P3;
    }
}
