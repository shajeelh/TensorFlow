package com.paymenthub.common.util;

/**
 * Hex encoding/decoding utilities for hash display and logging.
 * Thread-safe, no external dependencies.
 */
public final class HexUtils {

    private static final char[] HEX_CHARS = "0123456789abcdef".toCharArray();

    private HexUtils() {}

    /**
     * Convert byte array to lowercase hex string.
     * Returns empty string for null/empty input.
     */
    public static String toHex(byte[] bytes) {
        if (bytes == null || bytes.length == 0) return "";
        char[] hex = new char[bytes.length * 2];
        for (int i = 0; i < bytes.length; i++) {
            int v = bytes[i] & 0xFF;
            hex[i * 2] = HEX_CHARS[v >>> 4];
            hex[i * 2 + 1] = HEX_CHARS[v & 0x0F];
        }
        return new String(hex);
    }

    /**
     * Convert hex string to byte array.
     * Handles both upper and lower case. Returns empty array for null/empty input.
     *
     * @throws IllegalArgumentException if input has odd length or invalid hex chars
     */
    public static byte[] fromHex(String hex) {
        if (hex == null || hex.isEmpty()) return new byte[0];
        if (hex.length() % 2 != 0) {
            throw new IllegalArgumentException("Hex string must have even length: " + hex.length());
        }
        byte[] bytes = new byte[hex.length() / 2];
        for (int i = 0; i < bytes.length; i++) {
            int hi = Character.digit(hex.charAt(i * 2), 16);
            int lo = Character.digit(hex.charAt(i * 2 + 1), 16);
            if (hi == -1 || lo == -1) {
                throw new IllegalArgumentException("Invalid hex character at position " + (i * 2));
            }
            bytes[i] = (byte) ((hi << 4) | lo);
        }
        return bytes;
    }

    /**
     * Truncated hex display for logging (first 8 + last 4 characters).
     */
    public static String toShortHex(byte[] bytes) {
        String full = toHex(bytes);
        if (full.length() <= 16) return full;
        return full.substring(0, 8) + "..." + full.substring(full.length() - 4);
    }
}
