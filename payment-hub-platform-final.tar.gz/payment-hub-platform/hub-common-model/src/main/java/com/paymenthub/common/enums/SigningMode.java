package com.paymenthub.common.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Cryptographic signing mode for audit batch signatures.
 *
 * <p>Per ADR-004, software signing is acceptable for SMALL profile
 * with mitigations: key rotation every 90 days, keys never leave
 * the JVM, signing key stored in Vault.</p>
 */
public enum SigningMode {

    /** HSM via PKCS#11 — LARGE and MEDIUM profiles. */
    HSM("hsm"),

    /** Software ECDSA-P384 via BouncyCastle — SMALL profile. */
    SOFTWARE("software"),

    /** AWS CloudHSM — cloud-native alternative to on-prem HSM. */
    CLOUD_HSM("cloud_hsm"),

    /** No signing — development/test only. MUST NOT be used in production. */
    NONE("none");

    private final String value;

    SigningMode(String value) { this.value = value; }

    @JsonValue
    public String getValue() { return value; }

    public boolean isProductionGrade() { return this != NONE; }

    public static SigningMode fromValue(String v) {
        if (v == null) return SOFTWARE;
        for (SigningMode m : values()) {
            if (m.value.equalsIgnoreCase(v) || m.name().equalsIgnoreCase(v)) return m;
        }
        return SOFTWARE;
    }
}
