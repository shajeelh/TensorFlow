package com.paymenthub.common.model.integrity;

import java.util.List;

/**
 * A batch of record hashes signed together with a single ECDSA/HSM signature.
 * Batch size is profile-dependent: Large=500, Medium=200, Small=50.
 *
 * @param batchId       monotonically increasing batch identifier
 * @param recordHashes  list of record hashes included in this batch
 * @param batchDigest   SHA3-256 of concatenated record hashes
 * @param signature     ECDSA-P384 signature over the batch digest
 * @param signingKeyId  identifier of the key used
 * @param signingMode   HSM/SOFTWARE/CLOUD_HSM
 */
public record SignedBatch(
    long batchId,
    List<byte[]> recordHashes,
    byte[] batchDigest,
    byte[] signature,
    String signingKeyId,
    String signingMode
) {
    public int size() { return recordHashes != null ? recordHashes.size() : 0; }

    public boolean containsHash(byte[] hash) {
        if (recordHashes == null || hash == null) return false;
        for (byte[] h : recordHashes) {
            if (java.util.Arrays.equals(h, hash)) return true;
        }
        return false;
    }
}
