package com.paymenthub.common.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Message transport for audit event delivery.
 *
 * <p>Profile mapping:</p>
 * <ul>
 *   <li>LARGE → {@link #KAFKA}</li>
 *   <li>MEDIUM → {@link #KAFKA}</li>
 *   <li>SMALL → {@link #NATS_JETSTREAM}</li>
 * </ul>
 */
public enum TransportType {

    KAFKA("kafka"),
    NATS_JETSTREAM("nats-jetstream"),
    RABBITMQ("rabbitmq"),
    IN_MEMORY("in-memory");

    private final String value;

    TransportType(String value) { this.value = value; }

    @JsonValue
    public String getValue() { return value; }

    public boolean isDurable() { return this != IN_MEMORY; }

    public static TransportType fromValue(String v) {
        if (v == null) return NATS_JETSTREAM;
        for (TransportType t : values()) {
            if (t.value.equalsIgnoreCase(v) || t.name().equalsIgnoreCase(v)) return t;
        }
        return NATS_JETSTREAM;
    }
}
