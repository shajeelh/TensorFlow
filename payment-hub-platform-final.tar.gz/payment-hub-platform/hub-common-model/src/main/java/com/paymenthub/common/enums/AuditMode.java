package com.paymenthub.common.enums;

/**
 * Controls how an audit event is recorded relative to the business operation.
 *
 * <p>Per ADR-008, certain critical control events (e.g., admin overrides,
 * privilege escalation, key ceremonies) <strong>must</strong> use {@link #SYNC}
 * mode — the business operation blocks until the audit module confirms
 * durable persistence and returns an {@code AuditReceipt}.</p>
 *
 * <p>Most business events use {@link #ASYNC} mode where the event is
 * published to a ring buffer (LMAX Disruptor) with sub-microsecond
 * overhead and the business operation proceeds immediately.</p>
 *
 * @see com.paymenthub.common.model.config.SyncEventConfiguration
 */
public enum AuditMode {

    /**
     * Resolved at runtime based on entity-level configuration.
     * If the event type appears in the mandatory-sync list, it
     * becomes {@link #SYNC}; otherwise defaults to {@link #ASYNC}.
     */
    AUTO,

    /**
     * Synchronous — business operation blocks until AuditReceipt
     * confirms durable recording. Default deadline: 5 seconds.
     * Used for: admin overrides, privilege escalation, key ceremonies,
     * legal hold operations, masking bypass.
     */
    SYNC,

    /**
     * Asynchronous — event published to LMAX ring buffer.
     * Sub-microsecond overhead. Fire-and-forget from the caller's
     * perspective. Loss window bounded by ring buffer + transport ack.
     */
    ASYNC
}
