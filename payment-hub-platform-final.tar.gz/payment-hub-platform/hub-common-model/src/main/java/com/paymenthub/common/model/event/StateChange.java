package com.paymenthub.common.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;

/**
 * Captures before/after state of a mutating operation.
 *
 * <p>Both {@code before} and {@code after} are stored as JSON trees.
 * PII fields within these trees are sanitized by the audit pipeline
 * according to their {@link com.paymenthub.common.enums.DataClassification}.</p>
 *
 * <p>For non-mutating operations (reads, queries), both fields are null.</p>
 *
 * @param before state before the operation (null for CREATE)
 * @param after state after the operation (null for DELETE, FAILURE)
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record StateChange(
    JsonNode before,
    JsonNode after
) {
    /** Whether this represents a creation (no prior state). */
    public boolean isCreation() { return before == null && after != null; }

    /** Whether this represents a deletion (no resulting state). */
    public boolean isDeletion() { return before != null && after == null; }

    /** Whether both states are present (update). */
    public boolean isUpdate() { return before != null && after != null; }

    /** Empty state change (no capture). */
    public static StateChange empty() { return new StateChange(null, null); }
}
