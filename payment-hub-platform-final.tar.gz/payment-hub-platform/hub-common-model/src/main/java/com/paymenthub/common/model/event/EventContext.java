package com.paymenthub.common.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;

import java.util.Map;
import java.util.Objects;

/**
 * Runtime context of the module that produced the audit event.
 *
 * <p>Captures the physical deployment location and software version
 * to enable forensic root-cause analysis. These fields are automatically
 * populated by {@code hub-observability-starter}.</p>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonDeserialize(builder = EventContext.Builder.class)
public final class EventContext {

    private final String module;
    private final String moduleVersion;
    private final String environment;
    private final String region;
    private final String cluster;
    private final String pod;
    private final String node;
    private final String deploymentId;
    private final String buildCommit;
    private final Map<String, String> metadata;

    private EventContext(Builder b) {
        this.module = b.module;
        this.moduleVersion = b.moduleVersion;
        this.environment = b.environment;
        this.region = b.region;
        this.cluster = b.cluster;
        this.pod = b.pod;
        this.node = b.node;
        this.deploymentId = b.deploymentId;
        this.buildCommit = b.buildCommit;
        this.metadata = b.metadata != null ? Map.copyOf(b.metadata) : Map.of();
    }

    public String module() { return module; }
    public String moduleVersion() { return moduleVersion; }
    public String environment() { return environment; }
    public String region() { return region; }
    public String cluster() { return cluster; }
    public String pod() { return pod; }
    public String node() { return node; }
    public String deploymentId() { return deploymentId; }
    public String buildCommit() { return buildCommit; }
    public Map<String, String> metadata() { return metadata; }

    public static Builder builder() { return new Builder(); }

    @Override
    public String toString() {
        return "EventContext{module='%s' v%s, env=%s, region=%s}"
            .formatted(module, moduleVersion, environment, region);
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static final class Builder {
        private String module;
        private String moduleVersion;
        private String environment;
        private String region;
        private String cluster;
        private String pod;
        private String node;
        private String deploymentId;
        private String buildCommit;
        private Map<String, String> metadata;

        private Builder() {}

        public Builder module(String v) { this.module = v; return this; }
        public Builder moduleVersion(String v) { this.moduleVersion = v; return this; }
        public Builder environment(String v) { this.environment = v; return this; }
        public Builder region(String v) { this.region = v; return this; }
        public Builder cluster(String v) { this.cluster = v; return this; }
        public Builder pod(String v) { this.pod = v; return this; }
        public Builder node(String v) { this.node = v; return this; }
        public Builder deploymentId(String v) { this.deploymentId = v; return this; }
        public Builder buildCommit(String v) { this.buildCommit = v; return this; }
        public Builder metadata(Map<String, String> v) { this.metadata = v; return this; }

        public EventContext build() { return new EventContext(this); }
    }
}
