package com.paymenthub.common.model.pii;

/**
 * A tokenized PII field. The original value has been replaced with
 * a format-preserving token that can be de-tokenized only via the
 * PII Vault with proper authorization and access logging.
 *
 * @param token       the replacement token (format-preserving)
 * @param vaultRef    reference to the PII Vault entry
 * @param fieldPath   original field path in the audit event
 */
public record TokenizedField(
    String token,
    String vaultRef,
    String fieldPath
) {}
