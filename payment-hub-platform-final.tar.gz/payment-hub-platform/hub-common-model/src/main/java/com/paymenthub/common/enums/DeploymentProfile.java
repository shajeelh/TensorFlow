package com.paymenthub.common.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Deployment profile — determines infrastructure selection via Spring
 * conditional auto-configuration. Same binary, configuration-driven scaling.
 *
 * <table>
 *   <tr><th>Profile</th><th>TPS</th><th>Transport</th><th>Query Store</th><th>Signing</th></tr>
 *   <tr><td>LARGE</td><td>5K-15K</td><td>Kafka dedicated</td><td>OpenSearch dedicated</td><td>HSM PKCS#11</td></tr>
 *   <tr><td>MEDIUM</td><td>500-5K</td><td>Kafka shared</td><td>OpenSearch shared</td><td>HSM shared</td></tr>
 *   <tr><td>SMALL</td><td>10-500</td><td>NATS JetStream</td><td>PostgreSQL + tsvector</td><td>Software ECDSA</td></tr>
 * </table>
 */
public enum DeploymentProfile {

    LARGE("large", 15_000),
    MEDIUM("medium", 5_000),
    SMALL("small", 500);

    private final String value;
    private final int maxTps;

    DeploymentProfile(String value, int maxTps) {
        this.value = value;
        this.maxTps = maxTps;
    }

    @JsonValue
    public String getValue() { return value; }
    public int getMaxTps() { return maxTps; }

    public boolean requiresKafka() { return this == LARGE || this == MEDIUM; }
    public boolean requiresOpenSearch() { return this == LARGE || this == MEDIUM; }
    public boolean requiresHsm() { return this == LARGE || this == MEDIUM; }

    public static DeploymentProfile fromValue(String v) {
        if (v == null) return SMALL;
        for (DeploymentProfile p : values()) {
            if (p.value.equalsIgnoreCase(v) || p.name().equalsIgnoreCase(v)) return p;
        }
        return SMALL;
    }
}
