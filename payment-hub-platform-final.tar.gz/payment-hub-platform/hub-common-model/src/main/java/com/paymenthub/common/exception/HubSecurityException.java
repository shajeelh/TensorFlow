package com.paymenthub.common.exception;

/**
 * Security violation — unauthorized access, tenant isolation breach,
 * tamper detection, key compromise. NEVER retry-safe.
 * Always triggers P1/P2 alert and audit event.
 */
public non-sealed class HubSecurityException extends HubException {

    public HubSecurityException(String errorCode, String message) {
        super(errorCode, message, Severity.SECURITY, false);
    }

    public HubSecurityException(String errorCode, String message, Throwable cause) {
        super(errorCode, message, Severity.SECURITY, false, cause);
    }
}
