package com.paymenthub.common.exception;

/**
 * Business rule violation — expected failures that should be handled
 * gracefully (insufficient funds, validation failure, limit exceeded).
 * These are logged at WARN level and DO NOT trigger retry.
 */
public non-sealed class HubBusinessException extends HubException {

    public HubBusinessException(String errorCode, String message) {
        super(errorCode, message, Severity.BUSINESS, false);
    }

    public HubBusinessException(String errorCode, String message, Throwable cause) {
        super(errorCode, message, Severity.BUSINESS, false, cause);
    }
}
