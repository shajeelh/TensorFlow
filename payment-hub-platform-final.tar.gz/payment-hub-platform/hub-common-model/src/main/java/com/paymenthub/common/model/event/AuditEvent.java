package com.paymenthub.common.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.paymenthub.common.enums.EventCategory;
import com.paymenthub.common.model.action.AuditAction;
import com.paymenthub.common.model.actor.AuditActor;
import com.paymenthub.common.model.integrity.IntegrityInfo;
import com.paymenthub.common.model.resource.AuditResource;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/**
 * The canonical audit event — the fundamental unit of the audit trail.
 *
 * <p>Every operation across every module in the payment hub produces
 * one or more {@code AuditEvent} instances. This class represents the
 * v2.1 schema defined in the Tamper-Proof Audit Module Technical Design
 * Specification v3.0.</p>
 *
 * <h3>Schema Version: 2.1</h3>
 *
 * <h3>Lifecycle</h3>
 * <ol>
 *   <li><strong>Created</strong> by {@code @Audited} AOP aspect in the originating module</li>
 *   <li><strong>Sanitized</strong> — PII fields classified and masked/tokenized/encrypted</li>
 *   <li><strong>Emitted</strong> — published to transport (Kafka/NATS/RabbitMQ)</li>
 *   <li><strong>Enriched</strong> — audit server adds {@link IntegrityInfo} (hash, chain, sequence)</li>
 *   <li><strong>Stored</strong> — persisted to PostgreSQL (durable), OpenSearch (query), S3 (archive)</li>
 *   <li><strong>Signed</strong> — included in batch ECDSA/HSM signature</li>
 *   <li><strong>Anchored</strong> — Merkle tree root computed for 10-minute window</li>
 * </ol>
 *
 * <h3>Immutability Contract</h3>
 * <p>Once created, an AuditEvent is <strong>never modified</strong>. The PostgreSQL
 * table has triggers preventing UPDATE and DELETE. The hash chain links each
 * event to its predecessor — any modification breaks the chain and triggers
 * a P1 alert.</p>
 *
 * <h3>Hash Chain</h3>
 * <p>The canonical JSON representation (RFC 8785) of this event (excluding
 * the {@code integrity} block) is hashed with SHA3-256. This hash is then
 * chained to the previous event's hash in the same partition:
 * {@code chainHash = SHA3-256(previousHash || recordHash)}.</p>
 *
 * <h3>Example</h3>
 * <pre>{@code
 * var event = AuditEvent.builder()
 *     .eventId(UUID.randomUUID())
 *     .eventType("payment.initiated")
 *     .correlationId(correlationId)
 *     .timestamp(clock.instant())
 *     .actor(AuditActor.builder()
 *         .type(ActorType.USER)
 *         .identity("jane.doe@megabank.com")
 *         .authMethod("oauth2-pkce")
 *         .build())
 *     .resource(AuditResource.builder()
 *         .type("payment")
 *         .id("PAY-2025-00142857")
 *         .tenantId("MB-001")
 *         .entityId("MAIN_BANK")
 *         .build())
 *     .action(AuditAction.builder()
 *         .operation("CREATE")
 *         .result(ActionResult.SUCCESS)
 *         .durationUs(1250)
 *         .build())
 *     .stateChange(new StateChange(null, afterState))
 *     .build();
 * }</pre>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonDeserialize(builder = AuditEvent.Builder.class)
public final class AuditEvent {

    // ── Identity ──────────────────────────────────────────────
    private final UUID eventId;
    private final String eventType;
    private final String eventVersion;

    // ── Correlation ───────────────────────────────────────────
    private final UUID correlationId;
    private final UUID causationId;
    private final String idempotencyKey;

    // ── Timestamp ─────────────────────────────────────────────
    private final Instant timestamp;
    private final String clockId;

    // ── Who / What / How ──────────────────────────────────────
    private final AuditActor actor;
    private final AuditResource resource;
    private final AuditAction action;

    // ── State ─────────────────────────────────────────────────
    private final StateChange stateChange;

    // ── Context ───────────────────────────────────────────────
    private final EventContext context;
    private final DeploymentInfo deployment;

    // ── Integrity (populated by audit server) ─────────────────
    private final IntegrityInfo integrity;

    private AuditEvent(Builder b) {
        this.eventId = Objects.requireNonNull(b.eventId, "eventId is required");
        this.eventType = Objects.requireNonNull(b.eventType, "eventType is required");
        this.eventVersion = b.eventVersion != null ? b.eventVersion : "2.1";
        this.correlationId = Objects.requireNonNull(b.correlationId, "correlationId is required");
        this.causationId = b.causationId;
        this.idempotencyKey = b.idempotencyKey;
        this.timestamp = Objects.requireNonNull(b.timestamp, "timestamp is required");
        this.clockId = b.clockId;
        this.actor = Objects.requireNonNull(b.actor, "actor is required");
        this.resource = Objects.requireNonNull(b.resource, "resource is required");
        this.action = Objects.requireNonNull(b.action, "action is required");
        this.stateChange = b.stateChange;
        this.context = b.context;
        this.deployment = b.deployment;
        this.integrity = b.integrity;
    }

    // ── Accessors ─────────────────────────────────────────────

    @NotNull public UUID eventId() { return eventId; }
    @NotBlank public String eventType() { return eventType; }
    public String eventVersion() { return eventVersion; }
    @NotNull public UUID correlationId() { return correlationId; }
    public UUID causationId() { return causationId; }
    public String idempotencyKey() { return idempotencyKey; }
    @NotNull public Instant timestamp() { return timestamp; }
    public String clockId() { return clockId; }
    @Valid @NotNull public AuditActor actor() { return actor; }
    @Valid @NotNull public AuditResource resource() { return resource; }
    @Valid @NotNull public AuditAction action() { return action; }
    public StateChange stateChange() { return stateChange; }
    public EventContext context() { return context; }
    public DeploymentInfo deployment() { return deployment; }
    public IntegrityInfo integrity() { return integrity; }

    // ── Derived ───────────────────────────────────────────────

    /** Derive the event category from the event type prefix. */
    public EventCategory category() {
        return EventCategory.fromEventType(eventType);
    }

    /** Hash chain partition key: tenantId + ":" + category. */
    public String chainId() {
        return resource.tenantId() + ":" + category().getValue();
    }

    /** Whether this event requires synchronous recording (ADR-008). */
    public boolean requiresSyncRecording() {
        return eventType != null && (
            eventType.startsWith("admin.manual_override") ||
            eventType.startsWith("admin.audit_config_change") ||
            eventType.startsWith("admin.legal_hold") ||
            eventType.startsWith("authz.privilege_escalation") ||
            eventType.startsWith("crypto.key_") ||
            eventType.startsWith("data.masking_bypass")
        );
    }

    /** Whether the integrity block has been populated (event has been processed). */
    public boolean isProcessed() {
        return integrity != null && integrity.recordHash() != null;
    }

    // ── Builder ───────────────────────────────────────────────

    public static Builder builder() { return new Builder(); }

    /**
     * Create a copy-builder with the integrity block populated.
     * This is the only mutation allowed — adding integrity after processing.
     */
    public AuditEvent withIntegrity(IntegrityInfo integrity) {
        return this.toBuilder().integrity(integrity).build();
    }

    public Builder toBuilder() {
        return new Builder()
            .eventId(eventId).eventType(eventType).eventVersion(eventVersion)
            .correlationId(correlationId).causationId(causationId)
            .idempotencyKey(idempotencyKey).timestamp(timestamp).clockId(clockId)
            .actor(actor).resource(resource).action(action)
            .stateChange(stateChange).context(context).deployment(deployment)
            .integrity(integrity);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AuditEvent e)) return false;
        return Objects.equals(eventId, e.eventId);
    }

    @Override
    public int hashCode() { return Objects.hash(eventId); }

    @Override
    public String toString() {
        return "AuditEvent{id=%s, type='%s', actor=%s, resource=%s, result=%s}"
            .formatted(eventId, eventType, actor.identity(), resource.id(), action.result());
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static final class Builder {
        private UUID eventId;
        private String eventType;
        private String eventVersion;
        private UUID correlationId;
        private UUID causationId;
        private String idempotencyKey;
        private Instant timestamp;
        private String clockId;
        private AuditActor actor;
        private AuditResource resource;
        private AuditAction action;
        private StateChange stateChange;
        private EventContext context;
        private DeploymentInfo deployment;
        private IntegrityInfo integrity;

        private Builder() {}

        public Builder eventId(UUID v) { this.eventId = v; return this; }
        public Builder eventType(String v) { this.eventType = v; return this; }
        public Builder eventVersion(String v) { this.eventVersion = v; return this; }
        public Builder correlationId(UUID v) { this.correlationId = v; return this; }
        public Builder causationId(UUID v) { this.causationId = v; return this; }
        public Builder idempotencyKey(String v) { this.idempotencyKey = v; return this; }
        public Builder timestamp(Instant v) { this.timestamp = v; return this; }
        public Builder clockId(String v) { this.clockId = v; return this; }
        public Builder actor(AuditActor v) { this.actor = v; return this; }
        public Builder resource(AuditResource v) { this.resource = v; return this; }
        public Builder action(AuditAction v) { this.action = v; return this; }
        public Builder stateChange(StateChange v) { this.stateChange = v; return this; }
        public Builder context(EventContext v) { this.context = v; return this; }
        public Builder deployment(DeploymentInfo v) { this.deployment = v; return this; }
        public Builder integrity(IntegrityInfo v) { this.integrity = v; return this; }

        public AuditEvent build() { return new AuditEvent(this); }
    }
}
