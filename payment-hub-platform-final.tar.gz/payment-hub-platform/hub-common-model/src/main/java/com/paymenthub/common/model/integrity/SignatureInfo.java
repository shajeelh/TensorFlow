package com.paymenthub.common.model.integrity;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Batch signature information. Populated when the event's record hash
 * has been included in a signed batch.
 *
 * @param signature   raw ECDSA/RSA signature bytes
 * @param signingKeyId identifier of the signing key (for rotation tracking)
 * @param signingMode  HSM, SOFTWARE, or CLOUD_HSM
 * @param batchSigned  whether this event is part of a batch signature
 * @param batchId      the batch identifier (monotonically increasing)
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record SignatureInfo(
    byte[] signature,
    String signingKeyId,
    String signingMode,
    boolean batchSigned,
    long batchId
) {
    public static SignatureInfo unsigned() {
        return new SignatureInfo(null, null, null, false, 0);
    }

    public boolean isSigned() { return signature != null && signature.length > 0; }
}
