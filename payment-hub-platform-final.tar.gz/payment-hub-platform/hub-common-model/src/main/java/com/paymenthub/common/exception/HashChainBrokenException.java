package com.paymenthub.common.exception;

/**
 * Thrown when hash chain integrity verification detects a break.
 * This is a P1 alert — indicates potential tampering.
 */
public final class HashChainBrokenException extends HubSecurityException {

    private final String chainId;
    private final long expectedSequence;
    private final long actualSequence;

    public HashChainBrokenException(String chainId, long expected, long actual) {
        super("INTEGRITY-001",
            "Hash chain break in '%s': expected seq %d, found %d".formatted(chainId, expected, actual));
        this.chainId = chainId;
        this.expectedSequence = expected;
        this.actualSequence = actual;
    }

    public String chainId() { return chainId; }
    public long expectedSequence() { return expectedSequence; }
    public long actualSequence() { return actualSequence; }
}
