package com.paymenthub.common.model.integrity;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.Instant;

/**
 * Signed Merkle tree root for a 10-minute tumbling window.
 * Anchors all events within that window to a single signed root hash.
 *
 * @param windowId     unique window identifier (e.g., "MB-001:2025-01-15T14:30:00Z")
 * @param rootHash     SHA3-256 Merkle root
 * @param signature    ECDSA signature over the root hash
 * @param signingKeyId key used for signing
 * @param eventCount   number of events in this window
 * @param windowStart  start of the 10-minute window
 * @param windowEnd    end of the 10-minute window
 * @param entityId     entity this window belongs to
 * @param tenantId     tenant this window belongs to
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record MerkleRoot(
    String windowId,
    byte[] rootHash,
    byte[] signature,
    String signingKeyId,
    int eventCount,
    Instant windowStart,
    Instant windowEnd,
    String entityId,
    String tenantId
) {}
