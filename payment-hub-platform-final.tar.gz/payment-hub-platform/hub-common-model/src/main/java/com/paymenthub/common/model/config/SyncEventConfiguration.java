package com.paymenthub.common.model.config;

import java.util.List;
import java.util.Set;

/**
 * Configuration for mandatory-sync audit events per ADR-008.
 *
 * <p>Events in the {@code mandatory} list MUST be recorded synchronously —
 * the business operation blocks until the audit module confirms durable
 * persistence. Events in the {@code defaultSync} list are sync by default
 * but can be overridden per entity.</p>
 */
public record SyncEventConfiguration(
    Set<String> mandatory,
    Set<String> defaultSync
) {
    /** The hardcoded set of events that can NEVER be made async. */
    public static final Set<String> IMMUTABLE_MANDATORY = Set.of(
        "admin.manual_override",
        "admin.audit_config_change",
        "admin.legal_hold_placed",
        "admin.legal_hold_removed",
        "authz.privilege_escalation",
        "crypto.key_generated",
        "crypto.key_rotated",
        "crypto.key_destroyed",
        "data.masking_bypass"
    );

    /** Check if an event type requires synchronous recording. */
    public boolean requiresSync(String eventType) {
        return IMMUTABLE_MANDATORY.contains(eventType)
            || mandatory.contains(eventType)
            || defaultSync.contains(eventType);
    }

    public static SyncEventConfiguration defaults() {
        return new SyncEventConfiguration(
            IMMUTABLE_MANDATORY,
            Set.of("payment.sanctions_override", "payment.batch_approved", "config.rule_change")
        );
    }
}
