package com.paymenthub.common.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

class HexUtilsTest {

    @Test
    @DisplayName("Round-trip encoding/decoding")
    void roundTrip() {
        byte[] original = {0x01, (byte) 0xAB, (byte) 0xCD, (byte) 0xEF};
        String hex = HexUtils.toHex(original);
        assertThat(hex).isEqualTo("01abcdef");
        assertThat(HexUtils.fromHex(hex)).isEqualTo(original);
    }

    @Test
    @DisplayName("Null and empty handling")
    void nullEmpty() {
        assertThat(HexUtils.toHex(null)).isEmpty();
        assertThat(HexUtils.toHex(new byte[0])).isEmpty();
        assertThat(HexUtils.fromHex(null)).isEmpty();
        assertThat(HexUtils.fromHex("")).isEmpty();
    }

    @Test
    @DisplayName("Odd-length hex throws exception")
    void oddLength() {
        assertThatThrownBy(() -> HexUtils.fromHex("abc"))
            .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("Short hex truncation for logging")
    void shortHex() {
        byte[] hash = new byte[32]; // SHA-256 size
        hash[0] = (byte) 0xAB;
        hash[31] = (byte) 0xCD;
        String short_ = HexUtils.toShortHex(hash);
        assertThat(short_).startsWith("ab").contains("...").endsWith("00cd");
    }
}
