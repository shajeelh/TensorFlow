package com.paymenthub.common.model;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.paymenthub.common.enums.*;
import com.paymenthub.common.model.action.AuditAction;
import com.paymenthub.common.model.actor.AuditActor;
import com.paymenthub.common.model.event.*;
import com.paymenthub.common.model.integrity.IntegrityInfo;
import com.paymenthub.common.model.resource.AuditResource;
import com.paymenthub.common.validation.EventValidator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.assertj.core.api.Assertions.*;

class AuditEventTest {

    @Nested
    @DisplayName("Builder and immutability")
    class BuilderTests {

        @Test
        @DisplayName("Build a complete audit event with all fields")
        void buildComplete() {
            UUID eventId = UUID.randomUUID();
            UUID correlationId = UUID.randomUUID();
            Instant now = Instant.now();

            AuditEvent event = AuditEvent.builder()
                .eventId(eventId)
                .eventType("payment.initiated")
                .eventVersion("2.1")
                .correlationId(correlationId)
                .timestamp(now)
                .actor(AuditActor.builder()
                    .type(ActorType.USER)
                    .identity("jane.doe@megabank.com")
                    .authMethod("oauth2-pkce")
                    .sourceIp("10.1.42.99")
                    .build())
                .resource(AuditResource.builder()
                    .type("payment")
                    .id("PAY-2025-00142857")
                    .tenantId("MB-001")
                    .entityId("MAIN_BANK")
                    .build())
                .action(AuditAction.builder()
                    .operation("CREATE")
                    .result(ActionResult.SUCCESS)
                    .durationUs(1250)
                    .build())
                .context(EventContext.builder()
                    .module("payment-orchestration")
                    .moduleVersion("2.1.0")
                    .environment("production")
                    .region("eu-west-1")
                    .build())
                .build();

            assertThat(event.eventId()).isEqualTo(eventId);
            assertThat(event.eventType()).isEqualTo("payment.initiated");
            assertThat(event.eventVersion()).isEqualTo("2.1");
            assertThat(event.correlationId()).isEqualTo(correlationId);
            assertThat(event.timestamp()).isEqualTo(now);
            assertThat(event.actor().identity()).isEqualTo("jane.doe@megabank.com");
            assertThat(event.actor().type()).isEqualTo(ActorType.USER);
            assertThat(event.resource().tenantId()).isEqualTo("MB-001");
            assertThat(event.action().operation()).isEqualTo("CREATE");
            assertThat(event.action().result()).isEqualTo(ActionResult.SUCCESS);
            assertThat(event.context().module()).isEqualTo("payment-orchestration");
        }

        @Test
        @DisplayName("Missing required fields throw NullPointerException")
        void missingRequiredFields() {
            assertThatThrownBy(() -> AuditEvent.builder().build())
                .isInstanceOf(NullPointerException.class);

            assertThatThrownBy(() -> AuditEvent.builder()
                .eventId(UUID.randomUUID())
                .eventType("test")
                .correlationId(UUID.randomUUID())
                .timestamp(Instant.now())
                .actor(AuditActor.builder().type(ActorType.SYSTEM).identity("sys").build())
                // missing resource
                .action(AuditAction.builder().operation("TEST").result(ActionResult.SUCCESS).build())
                .build())
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("resource");
        }

        @Test
        @DisplayName("toBuilder creates independent copy")
        void toBuilderCopy() {
            AuditEvent original = createTestEvent("payment.initiated");
            AuditEvent copy = original.toBuilder().eventType("payment.validated").build();

            assertThat(copy.eventType()).isEqualTo("payment.validated");
            assertThat(original.eventType()).isEqualTo("payment.initiated"); // unchanged
            assertThat(copy.eventId()).isEqualTo(original.eventId());
        }

        @Test
        @DisplayName("withIntegrity returns new event with integrity block")
        void withIntegrity() {
            AuditEvent original = createTestEvent("payment.initiated");
            assertThat(original.integrity()).isNull();
            assertThat(original.isProcessed()).isFalse();

            IntegrityInfo integrity = IntegrityInfo.builder()
                .recordHash(new byte[]{1, 2, 3})
                .previousHash(new byte[32])
                .sequenceNumber(1)
                .build();

            AuditEvent processed = original.withIntegrity(integrity);

            assertThat(processed.isProcessed()).isTrue();
            assertThat(processed.integrity().sequenceNumber()).isEqualTo(1);
            assertThat(original.isProcessed()).isFalse(); // original unchanged
        }
    }

    @Nested
    @DisplayName("Derived fields")
    class DerivedFieldTests {

        @Test
        @DisplayName("category() derives from event type prefix")
        void categoryDerivation() {
            assertThat(createTestEvent("payment.initiated").category()).isEqualTo(EventCategory.BUSINESS);
            assertThat(createTestEvent("auth.failed").category()).isEqualTo(EventCategory.SECURITY);
            assertThat(createTestEvent("admin.manual_override").category()).isEqualTo(EventCategory.ADMIN);
            assertThat(createTestEvent("config.rule_change").category()).isEqualTo(EventCategory.CONFIG);
            assertThat(createTestEvent("crypto.key_generated").category()).isEqualTo(EventCategory.TECHNICAL);
        }

        @Test
        @DisplayName("chainId() combines tenantId and category")
        void chainId() {
            AuditEvent event = createTestEvent("payment.initiated");
            assertThat(event.chainId()).isEqualTo("MB-001:business");
        }

        @Test
        @DisplayName("requiresSyncRecording() identifies mandatory-sync events")
        void syncRecording() {
            assertThat(createTestEvent("admin.manual_override").requiresSyncRecording()).isTrue();
            assertThat(createTestEvent("authz.privilege_escalation").requiresSyncRecording()).isTrue();
            assertThat(createTestEvent("crypto.key_generated").requiresSyncRecording()).isTrue();
            assertThat(createTestEvent("data.masking_bypass").requiresSyncRecording()).isTrue();
            assertThat(createTestEvent("payment.initiated").requiresSyncRecording()).isFalse();
        }
    }

    @Nested
    @DisplayName("JSON serialization")
    class SerializationTests {

        private final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        @Test
        @DisplayName("Round-trip JSON serialization preserves all fields")
        void roundTrip() throws Exception {
            AuditEvent original = createTestEvent("payment.initiated");
            String json = mapper.writeValueAsString(original);
            AuditEvent deserialized = mapper.readValue(json, AuditEvent.class);

            assertThat(deserialized.eventId()).isEqualTo(original.eventId());
            assertThat(deserialized.eventType()).isEqualTo(original.eventType());
            assertThat(deserialized.actor().identity()).isEqualTo(original.actor().identity());
            assertThat(deserialized.resource().tenantId()).isEqualTo(original.resource().tenantId());
            assertThat(deserialized.action().result()).isEqualTo(original.action().result());
        }

        @Test
        @DisplayName("Null fields are excluded from JSON")
        void nullExclusion() throws Exception {
            AuditEvent event = createTestEvent("payment.initiated");
            String json = mapper.writeValueAsString(event);

            assertThat(json).doesNotContain("causationId");
            assertThat(json).doesNotContain("integrity");
            assertThat(json).doesNotContain("deployment");
        }
    }

    @Nested
    @DisplayName("Validation")
    class ValidationTests {

        @Test
        @DisplayName("Valid event passes validation")
        void validEvent() {
            AuditEvent event = createTestEvent("payment.initiated");
            assertThat(EventValidator.validate(event)).isEmpty();
        }

        @Test
        @DisplayName("Missing dot-notation in eventType is flagged")
        void missingDotNotation() {
            AuditEvent event = AuditEvent.builder()
                .eventId(UUID.randomUUID())
                .eventType("payment_initiated") // missing dot
                .correlationId(UUID.randomUUID())
                .timestamp(Instant.now())
                .actor(AuditActor.builder().type(ActorType.SYSTEM).identity("sys").build())
                .resource(AuditResource.builder().type("t").id("i").tenantId("t").build())
                .action(AuditAction.builder().operation("X").result(ActionResult.SUCCESS).build())
                .build();

            assertThat(EventValidator.validate(event))
                .anyMatch(e -> e.contains("dot-notation"));
        }

        @Test
        @DisplayName("Null event returns validation error")
        void nullEvent() {
            assertThat(EventValidator.validate(null))
                .containsExactly("Event is null");
        }
    }

    @Nested
    @DisplayName("Equality and hashing")
    class EqualityTests {

        @Test
        @DisplayName("Events with same ID are equal")
        void sameIdEquals() {
            UUID id = UUID.randomUUID();
            AuditEvent e1 = createTestEventWithId(id, "payment.initiated");
            AuditEvent e2 = createTestEventWithId(id, "payment.validated");

            assertThat(e1).isEqualTo(e2);
            assertThat(e1.hashCode()).isEqualTo(e2.hashCode());
        }

        @Test
        @DisplayName("Events with different IDs are not equal")
        void differentIdNotEquals() {
            AuditEvent e1 = createTestEvent("payment.initiated");
            AuditEvent e2 = createTestEvent("payment.initiated");

            assertThat(e1).isNotEqualTo(e2);
        }
    }

    // ── Test helpers ──────────────────────────────────────────

    private static AuditEvent createTestEvent(String eventType) {
        return createTestEventWithId(UUID.randomUUID(), eventType);
    }

    private static AuditEvent createTestEventWithId(UUID id, String eventType) {
        return AuditEvent.builder()
            .eventId(id)
            .eventType(eventType)
            .correlationId(UUID.randomUUID())
            .timestamp(Instant.now())
            .actor(AuditActor.builder()
                .type(ActorType.USER)
                .identity("test@example.com")
                .authMethod("jwt")
                .build())
            .resource(AuditResource.builder()
                .type("payment")
                .id("PAY-" + UUID.randomUUID().toString().substring(0, 8))
                .tenantId("MB-001")
                .entityId("MAIN_BANK")
                .build())
            .action(AuditAction.builder()
                .operation("TEST")
                .result(ActionResult.SUCCESS)
                .durationUs(100)
                .build())
            .build();
    }
}
