package com.paymenthub.common.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class JsonCanonicalizerTest {

    @Test
    @DisplayName("Keys are sorted lexicographically")
    void keySorting() {
        // Insert in reverse order
        var map = new LinkedHashMap<String, Object>();
        map.put("zebra", 1);
        map.put("apple", 2);
        map.put("mango", 3);

        String result = JsonCanonicalizer.canonicalize(map);
        assertThat(result).isEqualTo("{\"apple\":2,\"mango\":3,\"zebra\":1}");
    }

    @Test
    @DisplayName("Nested objects have sorted keys")
    void nestedSorting() {
        var inner = new LinkedHashMap<String, Object>();
        inner.put("b", 2);
        inner.put("a", 1);
        var outer = new LinkedHashMap<String, Object>();
        outer.put("inner", inner);

        String result = JsonCanonicalizer.canonicalize(outer);
        assertThat(result).isEqualTo("{\"inner\":{\"a\":1,\"b\":2}}");
    }

    @Test
    @DisplayName("Same logical content always produces same canonical form")
    void deterministic() {
        var map1 = new LinkedHashMap<String, Object>();
        map1.put("a", 1);
        map1.put("b", 2);

        var map2 = new LinkedHashMap<String, Object>();
        map2.put("b", 2);
        map2.put("a", 1);

        assertThat(JsonCanonicalizer.canonicalize(map1))
            .isEqualTo(JsonCanonicalizer.canonicalize(map2));
    }

    @Test
    @DisplayName("canonicalizeToBytes returns UTF-8")
    void utf8Bytes() {
        byte[] bytes = JsonCanonicalizer.canonicalizeToBytes(Map.of("key", "value"));
        assertThat(new String(bytes)).isEqualTo("{\"key\":\"value\"}");
    }

    @Test
    @DisplayName("Lists maintain order")
    void listOrder() {
        String result = JsonCanonicalizer.canonicalize(Map.of("items", List.of(3, 1, 2)));
        assertThat(result).isEqualTo("{\"items\":[3,1,2]}");
    }
}
