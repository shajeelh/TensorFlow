plugins {
    `java-library`
}

description = "Payment Hub — Common Domain Model (events, enums, value objects, exceptions)"

dependencies {
    api("com.fasterxml.jackson.core:jackson-annotations")
    api("com.fasterxml.jackson.core:jackson-databind")
    api("com.fasterxml.jackson.datatype:jackson-datatype-jsr310")
    api("jakarta.validation:jakarta.validation-api")

    compileOnly("org.springframework.boot:spring-boot-autoconfigure")
}
