package com.paymenthub.resilience;

import com.paymenthub.resilience.annotation.Resilient;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

import static org.assertj.core.api.Assertions.*;

class ResilientAnnotationTest {

    @Test
    @DisplayName("Annotation defaults are correct")
    void defaults() throws Exception {
        Method method = AnnotatedService.class.getMethod("defaultSettings");
        Resilient ann = method.getAnnotation(Resilient.class);

        assertThat(ann.maxRetries()).isEqualTo(3);
        assertThat(ann.timeoutMs()).isEqualTo(5000);
        assertThat(ann.failureThreshold()).isEqualTo(50);
        assertThat(ann.waitDurationSeconds()).isEqualTo(30);
        assertThat(ann.fallback()).isEmpty();
        assertThat(ann.propagateException()).isTrue();
    }

    @Test
    @DisplayName("Custom annotation values are preserved")
    void customValues() throws Exception {
        Method method = AnnotatedService.class.getMethod("customSettings");
        Resilient ann = method.getAnnotation(Resilient.class);

        assertThat(ann.name()).isEqualTo("audit-store");
        assertThat(ann.maxRetries()).isEqualTo(5);
        assertThat(ann.timeoutMs()).isEqualTo(10000);
        assertThat(ann.fallback()).isEqualTo("persistFallback");
    }

    static class AnnotatedService {
        @Resilient
        public void defaultSettings() {}

        @Resilient(name = "audit-store", maxRetries = 5, timeoutMs = 10000, fallback = "persistFallback")
        public void customSettings() {}
    }
}
