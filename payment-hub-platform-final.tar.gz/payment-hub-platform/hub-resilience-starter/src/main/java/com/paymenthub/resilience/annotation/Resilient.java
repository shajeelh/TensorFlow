package com.paymenthub.resilience.annotation;

import java.lang.annotation.*;

/**
 * Marks a method for automatic resilience wrapping (circuit breaker + retry).
 *
 * <p>When applied, the method call is wrapped with:</p>
 * <ol>
 *   <li><strong>Circuit Breaker</strong> — opens after {@code failureThreshold}
 *       failures within the sliding window. Half-open after {@code waitDuration}.</li>
 *   <li><strong>Retry</strong> — retries up to {@code maxRetries} times with
 *       exponential backoff. Only retries on {@code retrySafe} exceptions.</li>
 *   <li><strong>Timeout</strong> — fails fast after {@code timeoutMs}.</li>
 * </ol>
 *
 * <p>Example:</p>
 * <pre>{@code
 * @Resilient(name = "audit-store", maxRetries = 3, timeoutMs = 5000)
 * public void persistEvent(AuditEvent event) {
 *     auditStore.save(event);
 * }
 * }</pre>
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Resilient {

    /** Logical name for the resilience instance (used in metrics/config). */
    String name() default "";

    /** Maximum retry attempts. Default: 3. */
    int maxRetries() default 3;

    /** Timeout in milliseconds. Default: 5000. */
    long timeoutMs() default 5000;

    /** Circuit breaker failure rate threshold (percentage). Default: 50. */
    int failureThreshold() default 50;

    /** Circuit breaker wait duration in seconds before half-open. Default: 30. */
    int waitDurationSeconds() default 30;

    /** Fallback method name (in the same class). Empty = no fallback. */
    String fallback() default "";

    /** Whether to propagate the original exception type. Default: true. */
    boolean propagateException() default true;
}
