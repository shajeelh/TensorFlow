package com.paymenthub.resilience.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;

@AutoConfiguration
public class ResilienceAutoConfiguration {
    private static final Logger log = LoggerFactory.getLogger(ResilienceAutoConfiguration.class);
    public ResilienceAutoConfiguration() {
        log.info("Payment Hub resilience configured");
    }
}
