package com.paymenthub.messaging.publisher;

import com.paymenthub.messaging.envelope.MessageEnvelope;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.*;

class InMemoryMessagePublisherTest {

    private InMemoryMessagePublisher publisher;

    @BeforeEach
    void setUp() {
        publisher = new InMemoryMessagePublisher(true);
    }

    private MessageEnvelope<String> testMessage(String subject) {
        return MessageEnvelope.<String>builder()
            .subject(subject).type("test").tenantId("T1").payload("data").build();
    }

    @Nested
    @DisplayName("Publishing")
    class Publishing {

        @Test
        @DisplayName("Publish returns success result")
        void publishSuccess() {
            var result = publisher.publish(testMessage("sub.1")).join();
            assertThat(result.acked()).isTrue();
            assertThat(result.sequence()).isEqualTo(1);
            assertThat(publisher.publishedCount()).isEqualTo(1);
        }

        @Test
        @DisplayName("Messages are stored in order")
        void messageOrder() {
            publisher.publish(testMessage("sub.1"));
            publisher.publish(testMessage("sub.2"));
            publisher.publish(testMessage("sub.3"));

            assertThat(publisher.publishedCount()).isEqualTo(3);
            assertThat(publisher.getPublishedMessages().get(0).subject()).isEqualTo("sub.1");
            assertThat(publisher.getPublishedMessages().get(2).subject()).isEqualTo("sub.3");
        }

        @Test
        @DisplayName("Filter messages by subject")
        void filterBySubject() {
            publisher.publish(testMessage("audit.business"));
            publisher.publish(testMessage("audit.security"));
            publisher.publish(testMessage("audit.business"));

            assertThat(publisher.getMessagesForSubject("audit.business")).hasSize(2);
            assertThat(publisher.getMessagesForSubject("audit.security")).hasSize(1);
        }

        @Test
        @DisplayName("Filter messages by type")
        void filterByType() {
            publisher.publish(MessageEnvelope.<String>builder()
                .subject("s").type("type-a").payload("d").build());
            publisher.publish(MessageEnvelope.<String>builder()
                .subject("s").type("type-b").payload("d").build());

            assertThat(publisher.getMessagesByType("type-a")).hasSize(1);
        }
    }

    @Nested
    @DisplayName("Subscription and delivery")
    class Subscription {

        @Test
        @DisplayName("Handler receives published message")
        void handlerCalled() {
            AtomicReference<String> received = new AtomicReference<>();
            publisher.subscribe("test.subject", msg ->
                received.set((String) msg.payload()));

            publisher.publish(testMessage("test.subject"));
            assertThat(received.get()).isEqualTo("data");
        }

        @Test
        @DisplayName("Wildcard * matches single token")
        void singleWildcard() {
            AtomicReference<String> received = new AtomicReference<>();
            publisher.subscribe("audit.*.events", msg ->
                received.set(msg.subject()));

            publisher.publish(testMessage("audit.security.events"));
            assertThat(received.get()).isEqualTo("audit.security.events");

            received.set(null);
            publisher.publish(testMessage("audit.security.events.extra"));
            assertThat(received.get()).isNull(); // should NOT match
        }

        @Test
        @DisplayName("Wildcard > matches rest of subject")
        void trailingWildcard() {
            AtomicReference<Integer> count = new AtomicReference<>(0);
            publisher.subscribe("audit.>", msg ->
                count.updateAndGet(c -> c + 1));

            publisher.publish(testMessage("audit.a"));
            publisher.publish(testMessage("audit.a.b"));
            publisher.publish(testMessage("audit.a.b.c"));
            assertThat(count.get()).isEqualTo(3);
        }

        @Test
        @DisplayName("Non-matching subject does not trigger handler")
        void noMatch() {
            AtomicReference<Boolean> called = new AtomicReference<>(false);
            publisher.subscribe("other.subject", msg -> called.set(true));

            publisher.publish(testMessage("different.subject"));
            assertThat(called.get()).isFalse();
        }
    }

    @Nested
    @DisplayName("Subject matching")
    class SubjectMatching {

        @Test
        void exactMatch() {
            assertThat(InMemoryMessagePublisher.subjectMatches("a.b.c", "a.b.c")).isTrue();
            assertThat(InMemoryMessagePublisher.subjectMatches("a.b.c", "a.b.d")).isFalse();
        }

        @Test
        void singleWildcard() {
            assertThat(InMemoryMessagePublisher.subjectMatches("a.*.c", "a.b.c")).isTrue();
            assertThat(InMemoryMessagePublisher.subjectMatches("a.*.c", "a.x.c")).isTrue();
            assertThat(InMemoryMessagePublisher.subjectMatches("a.*.c", "a.b.d")).isFalse();
        }

        @Test
        void trailingWildcard() {
            assertThat(InMemoryMessagePublisher.subjectMatches("a.>", "a.b")).isTrue();
            assertThat(InMemoryMessagePublisher.subjectMatches("a.>", "a.b.c.d")).isTrue();
            assertThat(InMemoryMessagePublisher.subjectMatches("a.>", "b.c")).isFalse();
        }

        @Test
        void globalWildcard() {
            assertThat(InMemoryMessagePublisher.subjectMatches(">", "any.subject")).isTrue();
        }
    }

    @Nested
    @DisplayName("Reset")
    class ResetTests {
        @Test
        void resetClearsEverything() {
            publisher.subscribe("s", msg -> {});
            publisher.publish(testMessage("s"));
            assertThat(publisher.publishedCount()).isEqualTo(1);

            publisher.reset();
            assertThat(publisher.publishedCount()).isZero();
        }
    }

    @Test
    @DisplayName("Transport type is in_memory")
    void transportType() {
        assertThat(publisher.transportType()).isEqualTo("in_memory");
    }

    @Test
    @DisplayName("Always healthy")
    void healthy() {
        assertThat(publisher.isHealthy()).isTrue();
    }
}
