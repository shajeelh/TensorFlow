package com.paymenthub.messaging.routing;

import com.paymenthub.common.enums.EventCategory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

class SubjectRouterTest {

    @Test
    @DisplayName("allAuditEvents returns wildcard")
    void allEvents() {
        assertThat(SubjectRouter.allAuditEvents()).isEqualTo("hub.audit.>");
    }

    @Test
    @DisplayName("allEventsForTenant includes tenant and wildcard")
    void forTenant() {
        assertThat(SubjectRouter.allEventsForTenant("MB-001"))
            .isEqualTo("hub.audit.MB-001.>");
    }

    @Test
    @DisplayName("allEventsForCategory uses token wildcard for tenant")
    void forCategory() {
        assertThat(SubjectRouter.allEventsForCategory(EventCategory.SECURITY))
            .isEqualTo("hub.audit.*.security.>");
    }

    @Test
    @DisplayName("receiptSubject includes tenant and event ID")
    void receiptSubject() {
        assertThat(SubjectRouter.receiptSubject("MB-001", "evt-123"))
            .isEqualTo("hub.audit.receipt.MB-001.evt-123");
    }

    @Test
    @DisplayName("extractTenantId from subject")
    void extractTenant() {
        assertThat(SubjectRouter.extractTenantId("hub.audit.MB-001.business.payment"))
            .isEqualTo("MB-001");
        assertThat(SubjectRouter.extractTenantId("other.subject")).isNull();
        assertThat(SubjectRouter.extractTenantId(null)).isNull();
    }
}
