package com.paymenthub.messaging.envelope;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.Map;

import static org.assertj.core.api.Assertions.*;

class MessageEnvelopeTest {

    @Test
    @DisplayName("Builder creates complete envelope with auto-generated fields")
    void builder() {
        var env = MessageEnvelope.<String>builder()
            .subject("hub.audit.MB-001.business.payment")
            .type("payment.transfer_completed")
            .source("payment-orch")
            .correlationId("corr-123")
            .tenantId("MB-001")
            .header("priority", "high")
            .payload("data")
            .build();

        assertThat(env.messageId()).isNotBlank();
        assertThat(env.timestamp()).isNotNull();
        assertThat(env.subject()).isEqualTo("hub.audit.MB-001.business.payment");
        assertThat(env.header("priority")).isEqualTo("high");
        assertThat(env.header("missing", "default")).isEqualTo("default");
    }

    @Test
    @DisplayName("Headers are immutable")
    void headersImmutable() {
        var env = MessageEnvelope.<String>builder()
            .subject("test").header("k", "v").payload("d").build();
        assertThatThrownBy(() -> env.headers().put("new", "val"))
            .isInstanceOf(UnsupportedOperationException.class);
    }

    @Test
    @DisplayName("Reply creates linked envelope")
    void reply() {
        var original = MessageEnvelope.<String>builder()
            .subject("request.subject")
            .correlationId("corr-1")
            .tenantId("MB-001")
            .payload("question")
            .build();

        var reply = original.reply("answer", "reply.type");
        assertThat(reply.correlationId()).isEqualTo("corr-1");
        assertThat(reply.tenantId()).isEqualTo("MB-001");
        assertThat(reply.isReply()).isTrue();
        assertThat(reply.replyTo()).isEqualTo(original.messageId());
        assertThat(reply.payload()).isEqualTo("answer");
    }

    @Test
    @DisplayName("Non-reply envelope isReply returns false")
    void notReply() {
        var env = MessageEnvelope.<String>builder().subject("test").payload("d").build();
        assertThat(env.isReply()).isFalse();
        assertThat(env.replyTo()).isNull();
    }
}
