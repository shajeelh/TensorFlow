package com.paymenthub.messaging.config;

import com.paymenthub.messaging.publisher.ContextEnrichingPublisher;
import com.paymenthub.messaging.publisher.InMemoryMessagePublisher;
import com.paymenthub.messaging.publisher.MessagePublisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;

/**
 * Auto-configuration for the messaging starter.
 *
 * <h3>Configuration</h3>
 * <pre>
 * hub.messaging:
 *   transport: in_memory              # in_memory, nats_jetstream, kafka
 * hub.observability:
 *   module-name: payment-orchestration
 * </pre>
 */
@AutoConfiguration
public class MessagingAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(MessagingAutoConfiguration.class);

    @Bean
    @ConditionalOnMissingBean(name = "rawMessagePublisher")
    @ConditionalOnProperty(name = "hub.messaging.transport", havingValue = "in_memory", matchIfMissing = true)
    public InMemoryMessagePublisher rawMessagePublisher() {
        log.warn("Using InMemoryMessagePublisher — not suitable for multi-node clusters");
        return new InMemoryMessagePublisher();
    }

    @Bean
    @ConditionalOnMissingBean(MessagePublisher.class)
    public MessagePublisher messagePublisher(
            InMemoryMessagePublisher rawPublisher,
            @Value("${hub.observability.module-name:unknown}") String moduleName) {

        log.info("Configuring ContextEnrichingPublisher: transport={}, module={}",
            rawPublisher.transportType(), moduleName);
        return new ContextEnrichingPublisher(rawPublisher, moduleName);
    }
}
