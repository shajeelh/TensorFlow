package com.paymenthub.messaging.subscriber;

import com.paymenthub.messaging.envelope.MessageEnvelope;

/**
 * Handler interface for processing messages received from subscriptions.
 *
 * <p>Implementations are registered with a {@link com.paymenthub.messaging.publisher.MessagePublisher}
 * or transport-specific subscriber. The handler receives the full
 * {@link MessageEnvelope} including metadata and headers.</p>
 *
 * <h3>Error Handling</h3>
 * <ul>
 *   <li>If the handler throws, the message is NACKed (not acknowledged)
 *       and will be redelivered by the transport after the retry delay.</li>
 *   <li>If the handler completes normally, the message is ACKed.</li>
 *   <li>For exactly-once processing, combine with the idempotency store
 *       to deduplicate redelivered messages.</li>
 * </ul>
 *
 * <h3>Context</h3>
 * <p>Before the handler is called, the messaging framework automatically sets:</p>
 * <ul>
 *   <li>{@code TenantContextHolder} — from envelope tenantId/entityId</li>
 *   <li>{@code CorrelationContextHolder} — from envelope correlationId</li>
 *   <li>SLF4J MDC — correlationId, tenantId for log correlation</li>
 * </ul>
 *
 * @param <T> the expected payload type
 */
@FunctionalInterface
public interface MessageHandler<T> {

    /**
     * Process a received message.
     *
     * @param message the message envelope with payload
     * @throws Exception if processing fails (triggers redelivery)
     */
    void handle(MessageEnvelope<T> message) throws Exception;
}
