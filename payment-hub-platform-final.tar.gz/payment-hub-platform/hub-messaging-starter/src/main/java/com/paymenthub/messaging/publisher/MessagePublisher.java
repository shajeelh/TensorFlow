package com.paymenthub.messaging.publisher;

import com.paymenthub.messaging.envelope.MessageEnvelope;

import java.time.Duration;
import java.util.concurrent.CompletableFuture;

/**
 * Transport-agnostic message publisher.
 *
 * <p>Implementations adapt to different transports:</p>
 * <ul>
 *   <li>{@link InMemoryMessagePublisher} — ConcurrentLinkedQueue (dev/test)</li>
 *   <li>{@code NatsJetStreamPublisher} — NATS JetStream (production SMALL/MEDIUM)</li>
 *   <li>{@code KafkaPublisher} — Apache Kafka (production LARGE)</li>
 *   <li>{@code RabbitMqPublisher} — RabbitMQ (legacy integration)</li>
 * </ul>
 *
 * <h3>Publishing Patterns</h3>
 * <ul>
 *   <li><strong>Fire-and-forget</strong> — {@link #publish(MessageEnvelope)}.
 *       Returns a CompletableFuture that completes when the message is
 *       durably persisted by the transport (JetStream ack, Kafka ack).</li>
 *   <li><strong>Request-reply</strong> — {@link #request(MessageEnvelope, Duration)}.
 *       Publishes a request and waits for a reply on the inbox subject.</li>
 * </ul>
 *
 * <h3>Context Propagation</h3>
 * <p>Before publishing, the implementation automatically enriches the
 * envelope with context from {@code CorrelationContextHolder} and
 * {@code TenantContextHolder} (correlation ID, tenant ID, source module).</p>
 *
 * <h3>Delivery Guarantees</h3>
 * <p>All implementations provide at-least-once delivery. Combined with
 * the idempotency store on the consumer side, this achieves effectively
 * exactly-once processing.</p>
 */
public interface MessagePublisher {

    /**
     * Publish a message (fire-and-forget with durable ack).
     *
     * <p>The returned future completes when the transport acknowledges
     * durable persistence of the message. On NATS JetStream, this means
     * the message is written to the stream. On Kafka, this means the
     * broker has committed the record.</p>
     *
     * @param envelope the message envelope to publish
     * @return future that completes on transport ack
     */
    <T> CompletableFuture<PublishResult> publish(MessageEnvelope<T> envelope);

    /**
     * Publish a message to a specific subject (overriding envelope subject).
     */
    <T> CompletableFuture<PublishResult> publish(String subject, MessageEnvelope<T> envelope);

    /**
     * Publish and wait for reply (request-reply pattern).
     *
     * @param envelope the request message
     * @param timeout  how long to wait for a reply
     * @return future that completes with the reply envelope
     */
    <T, R> CompletableFuture<MessageEnvelope<R>> request(MessageEnvelope<T> envelope, Duration timeout);

    /**
     * Get the transport type identifier.
     *
     * @return "nats_jetstream", "kafka", "rabbitmq", or "in_memory"
     */
    String transportType();

    /**
     * Check if the publisher is connected and healthy.
     */
    boolean isHealthy();

    /**
     * Result of a publish operation.
     *
     * @param messageId the published message ID
     * @param subject   the subject it was published to
     * @param sequence  transport-specific sequence number (e.g., JetStream sequence)
     * @param acked     whether the transport acknowledged durable persistence
     */
    record PublishResult(String messageId, String subject, long sequence, boolean acked) {
        public static PublishResult success(String messageId, String subject, long sequence) {
            return new PublishResult(messageId, subject, sequence, true);
        }
        public static PublishResult failure(String messageId, String subject) {
            return new PublishResult(messageId, subject, -1, false);
        }
    }
}
