package com.paymenthub.messaging.routing;

import com.paymenthub.common.enums.EventCategory;
import com.paymenthub.common.model.AuditEvent;

import java.util.Objects;

/**
 * Builds NATS-style subject strings for routing audit events.
 *
 * <h3>Subject Hierarchy</h3>
 * <pre>
 * hub.audit.{tenant_id}.{category}.{event_type}
 *
 * Examples:
 *   hub.audit.MB-001.business.payment.transfer_completed
 *   hub.audit.MB-001.security.authz.privilege_escalation
 *   hub.audit.MB-001.admin.admin.manual_override
 * </pre>
 *
 * <h3>Consumer Subject Patterns</h3>
 * <ul>
 *   <li>{@code hub.audit.>} — all audit events (audit-module-server)</li>
 *   <li>{@code hub.audit.MB-001.>} — all events for one tenant</li>
 *   <li>{@code hub.audit.*.security.>} — all security events across tenants</li>
 *   <li>{@code hub.audit.MB-001.business.payment.>} — payment events for one tenant</li>
 * </ul>
 *
 * <h3>JetStream Stream Subjects</h3>
 * <p>The audit module JetStream stream is configured with subject
 * {@code hub.audit.>} to capture all audit events. Consumer groups
 * use filtered subjects for partitioned processing.</p>
 */
public final class SubjectRouter {

    private SubjectRouter() {}

    /** Root prefix for all audit subjects. */
    public static final String AUDIT_PREFIX = "hub.audit";

    /** Subject for audit receipts (sync acknowledgments). */
    public static final String RECEIPT_PREFIX = "hub.audit.receipt";

    /** Subject for anomaly alerts. */
    public static final String ALERT_PREFIX = "hub.audit.alert";

    /**
     * Build the routing subject for an audit event.
     *
     * @param event the audit event
     * @return NATS subject string
     */
    public static String subjectFor(AuditEvent event) {
        Objects.requireNonNull(event, "Event required");
        Objects.requireNonNull(event.resource(), "Event resource required");
        Objects.requireNonNull(event.resource().tenantId(), "Tenant ID required");

        String tenantId = sanitize(event.resource().tenantId());
        String category = event.category().name().toLowerCase();
        String eventType = sanitize(event.eventType());

        return "%s.%s.%s.%s".formatted(AUDIT_PREFIX, tenantId, category, eventType);
    }

    /**
     * Build a subject for a specific tenant and category.
     */
    public static String subjectFor(String tenantId, EventCategory category) {
        return "%s.%s.%s.>".formatted(AUDIT_PREFIX, sanitize(tenantId), category.name().toLowerCase());
    }

    /**
     * Build the receipt subject for an event.
     */
    public static String receiptSubject(String tenantId, String eventId) {
        return "%s.%s.%s".formatted(RECEIPT_PREFIX, sanitize(tenantId), eventId);
    }

    /**
     * Build the alert subject for a tenant.
     */
    public static String alertSubject(String tenantId) {
        return "%s.%s".formatted(ALERT_PREFIX, sanitize(tenantId));
    }

    /**
     * Build a wildcard subject matching all events for a tenant.
     */
    public static String allEventsForTenant(String tenantId) {
        return "%s.%s.>".formatted(AUDIT_PREFIX, sanitize(tenantId));
    }

    /**
     * Build a wildcard subject matching all events of a category across tenants.
     */
    public static String allEventsForCategory(EventCategory category) {
        return "%s.*.%s.>".formatted(AUDIT_PREFIX, category.name().toLowerCase());
    }

    /**
     * Build the wildcard subject for ALL audit events.
     */
    public static String allAuditEvents() {
        return AUDIT_PREFIX + ".>";
    }

    /**
     * Extract tenant ID from a subject string.
     *
     * @param subject e.g., "hub.audit.MB-001.business.payment.transfer_completed"
     * @return tenant ID ("MB-001"), or null if subject doesn't match pattern
     */
    public static String extractTenantId(String subject) {
        if (subject == null || !subject.startsWith(AUDIT_PREFIX + ".")) return null;
        String[] parts = subject.split("\\.", 4);
        return parts.length >= 3 ? parts[2] : null;
    }

    /**
     * Sanitize a string for use in a NATS subject token.
     * Replaces dots and spaces with underscores.
     */
    private static String sanitize(String token) {
        if (token == null) return "unknown";
        return token.replace(' ', '_');
    }
}
