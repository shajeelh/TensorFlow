package com.paymenthub.messaging.publisher;

import com.paymenthub.messaging.envelope.MessageEnvelope;
import com.paymenthub.observability.context.CorrelationContextHolder;
import com.paymenthub.tenant.context.TenantContextHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

/**
 * Publisher decorator that enriches outbound messages with context
 * from {@code TenantContextHolder} and {@code CorrelationContextHolder}.
 *
 * <p>Wraps any {@link MessagePublisher} implementation and automatically adds:</p>
 * <ul>
 *   <li>{@code tenantId} — from TenantContextHolder</li>
 *   <li>{@code entityId} — from TenantContextHolder</li>
 *   <li>{@code correlationId} — from CorrelationContextHolder</li>
 *   <li>{@code source} — configured module name</li>
 * </ul>
 *
 * <p>Fields already present in the envelope are NOT overwritten.
 * This allows callers to explicitly set values when needed.</p>
 */
public class ContextEnrichingPublisher implements MessagePublisher {

    private static final Logger log = LoggerFactory.getLogger(ContextEnrichingPublisher.class);

    private final MessagePublisher delegate;
    private final String sourceModule;

    /**
     * @param delegate     the underlying publisher implementation
     * @param sourceModule the name of this module (added as source)
     */
    public ContextEnrichingPublisher(MessagePublisher delegate, String sourceModule) {
        this.delegate = Objects.requireNonNull(delegate, "Delegate publisher required");
        this.sourceModule = Objects.requireNonNull(sourceModule, "Source module required");
    }

    @Override
    public <T> CompletableFuture<PublishResult> publish(MessageEnvelope<T> envelope) {
        return delegate.publish(enrich(envelope));
    }

    @Override
    public <T> CompletableFuture<PublishResult> publish(String subject, MessageEnvelope<T> envelope) {
        return delegate.publish(subject, enrich(envelope));
    }

    @Override
    public <T, R> CompletableFuture<MessageEnvelope<R>> request(MessageEnvelope<T> envelope, Duration timeout) {
        return delegate.request(enrich(envelope), timeout);
    }

    @Override
    public String transportType() { return delegate.transportType(); }

    @Override
    public boolean isHealthy() { return delegate.isHealthy(); }

    /**
     * Get the underlying (unwrapped) publisher.
     */
    public MessagePublisher unwrap() { return delegate; }

    // ── Internal ─────────────────────────────────────────────

    private <T> MessageEnvelope<T> enrich(MessageEnvelope<T> envelope) {
        String tenantId = envelope.tenantId();
        String entityId = envelope.entityId();
        String correlationId = envelope.correlationId();
        String source = envelope.source();

        // Enrich from context only if not already set
        if (tenantId == null) {
            tenantId = TenantContextHolder.getTenantId();
        }
        if (entityId == null) {
            entityId = TenantContextHolder.getEntityId();
        }
        if (correlationId == null) {
            correlationId = CorrelationContextHolder.getCorrelationId();
        }
        if (source == null) {
            source = sourceModule;
        }

        // Only create a new envelope if something changed
        if (Objects.equals(tenantId, envelope.tenantId()) &&
            Objects.equals(entityId, envelope.entityId()) &&
            Objects.equals(correlationId, envelope.correlationId()) &&
            Objects.equals(source, envelope.source())) {
            return envelope;
        }

        return new MessageEnvelope<>(
            envelope.messageId(), envelope.subject(), envelope.type(), source,
            envelope.timestamp(), correlationId, tenantId, entityId,
            envelope.headers(), envelope.payload()
        );
    }
}
