package com.paymenthub.messaging.envelope;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.Instant;
import java.util.*;

/**
 * Universal wire envelope wrapping every inter-module message.
 *
 * <p>All messages published through the messaging abstraction are wrapped
 * in this envelope before being serialized to the transport (NATS, Kafka, etc.).
 * The envelope carries metadata that is transport-independent.</p>
 *
 * <h3>Structure</h3>
 * <pre>
 * ┌─────────────────────────────────────────┐
 * │ MessageEnvelope                         │
 * │  ├─ messageId     (UUID, unique per msg)│
 * │  ├─ subject       (routing subject)     │
 * │  ├─ type          (payload type name)   │
 * │  ├─ source        (publishing module)   │
 * │  ├─ timestamp     (publish time)        │
 * │  ├─ correlationId (tracing)             │
 * │  ├─ tenantId      (isolation)           │
 * │  ├─ entityId      (sub-tenant)          │
 * │  ├─ headers       (custom metadata)     │
 * │  └─ payload       (serialized body)     │
 * └─────────────────────────────────────────┘
 * </pre>
 *
 * <h3>Serialization</h3>
 * <p>The envelope itself is serialized to JSON. The {@code payload} field
 * contains the pre-serialized message body (also JSON). This allows
 * consumers to deserialize the envelope without knowing the payload type,
 * and then deserialize the payload based on the {@code type} field.</p>
 *
 * <h3>Deduplication</h3>
 * <p>The {@code messageId} enables exactly-once delivery semantics when
 * combined with the idempotency store. Consumers check the message ID
 * before processing.</p>
 *
 * @param <T> the payload type
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record MessageEnvelope<T>(
    String messageId,
    String subject,
    String type,
    String source,
    Instant timestamp,
    String correlationId,
    String tenantId,
    String entityId,
    Map<String, String> headers,
    T payload
) {
    /**
     * Canonical constructor with defaults.
     */
    public MessageEnvelope {
        messageId = messageId != null ? messageId : UUID.randomUUID().toString();
        timestamp = timestamp != null ? timestamp : Instant.now();
        headers = headers != null ? Map.copyOf(headers) : Map.of();
    }

    /**
     * Builder for constructing envelopes with fluent API.
     */
    public static <T> Builder<T> builder() {
        return new Builder<>();
    }

    /**
     * Create a reply envelope for request-reply patterns.
     */
    public <R> MessageEnvelope<R> reply(R replyPayload, String replyType) {
        return new MessageEnvelope<>(
            UUID.randomUUID().toString(),
            subject + ".reply",
            replyType,
            null, // source set by publisher
            Instant.now(),
            correlationId, // preserve correlation chain
            tenantId,
            entityId,
            Map.of("replyTo", messageId),
            replyPayload
        );
    }

    /**
     * Get a header value, or null.
     */
    public String header(String key) {
        return headers.get(key);
    }

    /**
     * Get a header value with a default.
     */
    public String header(String key, String defaultValue) {
        return headers.getOrDefault(key, defaultValue);
    }

    /**
     * Check if this is a reply to another message.
     */
    public boolean isReply() {
        return headers.containsKey("replyTo");
    }

    /**
     * Get the original message ID if this is a reply.
     */
    public String replyTo() {
        return headers.get("replyTo");
    }

    // ── Builder ──────────────────────────────────────────────

    public static class Builder<T> {
        private String messageId;
        private String subject;
        private String type;
        private String source;
        private Instant timestamp;
        private String correlationId;
        private String tenantId;
        private String entityId;
        private final Map<String, String> headers = new LinkedHashMap<>();
        private T payload;

        public Builder<T> messageId(String messageId) { this.messageId = messageId; return this; }
        public Builder<T> subject(String subject) { this.subject = subject; return this; }
        public Builder<T> type(String type) { this.type = type; return this; }
        public Builder<T> source(String source) { this.source = source; return this; }
        public Builder<T> timestamp(Instant timestamp) { this.timestamp = timestamp; return this; }
        public Builder<T> correlationId(String id) { this.correlationId = id; return this; }
        public Builder<T> tenantId(String tenantId) { this.tenantId = tenantId; return this; }
        public Builder<T> entityId(String entityId) { this.entityId = entityId; return this; }
        public Builder<T> header(String key, String value) { this.headers.put(key, value); return this; }
        public Builder<T> headers(Map<String, String> headers) { this.headers.putAll(headers); return this; }
        public Builder<T> payload(T payload) { this.payload = payload; return this; }

        public MessageEnvelope<T> build() {
            return new MessageEnvelope<>(messageId, subject, type, source,
                timestamp, correlationId, tenantId, entityId, headers, payload);
        }
    }
}
