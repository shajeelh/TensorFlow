package com.paymenthub.messaging.publisher;

import com.paymenthub.messaging.envelope.MessageEnvelope;
import com.paymenthub.messaging.subscriber.MessageHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * In-memory message publisher for development, testing, and single-node deployments.
 *
 * <p>Provides a complete messaging implementation without external dependencies.
 * Messages are stored in memory and delivered to registered handlers synchronously
 * (within the publish call) or asynchronously via an executor.</p>
 *
 * <h3>Features</h3>
 * <ul>
 *   <li>Subject-based routing with wildcard support ({@code *} single token,
 *       {@code >} trailing wildcard, matching NATS subject semantics)</li>
 *   <li>Request-reply via temporary inbox subjects</li>
 *   <li>Message history for testing assertions</li>
 *   <li>Configurable async delivery via executor</li>
 * </ul>
 *
 * <h3>Limitations</h3>
 * <ul>
 *   <li>Messages are not persisted — lost on JVM restart</li>
 *   <li>No consumer groups or load balancing</li>
 *   <li>Not suitable for multi-node clusters</li>
 * </ul>
 */
public class InMemoryMessagePublisher implements MessagePublisher {

    private static final Logger log = LoggerFactory.getLogger(InMemoryMessagePublisher.class);

    private final Map<String, List<MessageHandler<?>>> handlers = new ConcurrentHashMap<>();
    private final List<MessageEnvelope<?>> publishedMessages = new CopyOnWriteArrayList<>();
    private final Map<String, CompletableFuture<MessageEnvelope<?>>> pendingReplies = new ConcurrentHashMap<>();
    private final AtomicLong sequenceCounter = new AtomicLong(0);
    private final Executor deliveryExecutor;
    private final boolean synchronousDelivery;

    /**
     * Create with synchronous delivery (messages delivered within publish call).
     */
    public InMemoryMessagePublisher() {
        this(true);
    }

    /**
     * @param synchronousDelivery if true, handlers are called synchronously in publish
     */
    public InMemoryMessagePublisher(boolean synchronousDelivery) {
        this.synchronousDelivery = synchronousDelivery;
        this.deliveryExecutor = synchronousDelivery
            ? Runnable::run
            : Executors.newVirtualThreadPerTaskExecutor();
    }

    @Override
    public <T> CompletableFuture<PublishResult> publish(MessageEnvelope<T> envelope) {
        return publish(envelope.subject(), envelope);
    }

    @Override
    public <T> CompletableFuture<PublishResult> publish(String subject, MessageEnvelope<T> envelope) {
        Objects.requireNonNull(subject, "Subject required");
        Objects.requireNonNull(envelope, "Envelope required");

        long seq = sequenceCounter.incrementAndGet();

        // Re-create envelope with subject if different
        MessageEnvelope<T> published = subject.equals(envelope.subject())
            ? envelope
            : new MessageEnvelope<>(
                envelope.messageId(), subject, envelope.type(), envelope.source(),
                envelope.timestamp(), envelope.correlationId(), envelope.tenantId(),
                envelope.entityId(), envelope.headers(), envelope.payload());

        publishedMessages.add(published);
        log.debug("Published [{}/{}] to '{}': type={}, tenant={}",
            seq, published.messageId(), subject, published.type(), published.tenantId());

        // Check for pending request-reply
        CompletableFuture<MessageEnvelope<?>> pending = pendingReplies.remove(subject);
        if (pending != null) {
            pending.complete(published);
        }

        // Deliver to matching handlers
        deliverToHandlers(subject, published);

        return CompletableFuture.completedFuture(
            PublishResult.success(published.messageId(), subject, seq));
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T, R> CompletableFuture<MessageEnvelope<R>> request(MessageEnvelope<T> envelope, Duration timeout) {
        String replySubject = "_INBOX." + UUID.randomUUID();

        // Register pending reply before publishing
        CompletableFuture<MessageEnvelope<?>> replyFuture = new CompletableFuture<>();
        pendingReplies.put(replySubject, replyFuture);

        // Add reply-to header
        MessageEnvelope<T> requestEnvelope = MessageEnvelope.<T>builder()
            .messageId(envelope.messageId())
            .subject(envelope.subject())
            .type(envelope.type())
            .source(envelope.source())
            .correlationId(envelope.correlationId())
            .tenantId(envelope.tenantId())
            .entityId(envelope.entityId())
            .headers(envelope.headers())
            .header("replyTo", replySubject)
            .payload(envelope.payload())
            .build();

        // Publish the request
        publish(requestEnvelope);

        // Wait for reply with timeout
        return replyFuture
            .orTimeout(timeout.toMillis(), TimeUnit.MILLISECONDS)
            .thenApply(reply -> (MessageEnvelope<R>) reply)
            .whenComplete((result, error) -> pendingReplies.remove(replySubject));
    }

    // ── Subscription Management ──────────────────────────────

    /**
     * Subscribe a handler to a subject pattern.
     *
     * @param subject subject or pattern ({@code audit.events.>})
     * @param handler the message handler
     */
    public <T> void subscribe(String subject, MessageHandler<T> handler) {
        handlers.computeIfAbsent(subject, k -> new CopyOnWriteArrayList<>()).add(handler);
        log.debug("Subscribed handler to '{}'", subject);
    }

    /**
     * Unsubscribe all handlers for a subject.
     */
    public void unsubscribe(String subject) {
        handlers.remove(subject);
    }

    // ── Test Utilities ───────────────────────────────────────

    /**
     * Get all published messages (for test assertions).
     */
    public List<MessageEnvelope<?>> getPublishedMessages() {
        return Collections.unmodifiableList(publishedMessages);
    }

    /**
     * Get published messages for a specific subject.
     */
    public List<MessageEnvelope<?>> getMessagesForSubject(String subject) {
        return publishedMessages.stream()
            .filter(m -> subject.equals(m.subject()))
            .toList();
    }

    /**
     * Get published messages of a specific type.
     */
    public List<MessageEnvelope<?>> getMessagesByType(String type) {
        return publishedMessages.stream()
            .filter(m -> type.equals(m.type()))
            .toList();
    }

    /**
     * Get the total number of published messages.
     */
    public int publishedCount() { return publishedMessages.size(); }

    /**
     * Clear all published messages and subscriptions.
     */
    public void reset() {
        publishedMessages.clear();
        handlers.clear();
        pendingReplies.values().forEach(f ->
            f.completeExceptionally(new CancellationException("Reset")));
        pendingReplies.clear();
        sequenceCounter.set(0);
    }

    @Override
    public String transportType() { return "in_memory"; }

    @Override
    public boolean isHealthy() { return true; }

    // ── Internal ─────────────────────────────────────────────

    @SuppressWarnings({"unchecked", "rawtypes"})
    private void deliverToHandlers(String subject, MessageEnvelope<?> message) {
        for (Map.Entry<String, List<MessageHandler<?>>> entry : handlers.entrySet()) {
            if (subjectMatches(entry.getKey(), subject)) {
                for (MessageHandler handler : entry.getValue()) {
                    deliveryExecutor.execute(() -> {
                        try {
                            handler.handle(message);
                        } catch (Exception e) {
                            log.error("Handler failed for subject '{}': {}",
                                subject, e.getMessage(), e);
                        }
                    });
                }
            }
        }
    }

    /**
     * NATS-style subject matching.
     * {@code *} matches a single token. {@code >} matches the rest.
     */
    static boolean subjectMatches(String pattern, String subject) {
        if (pattern.equals(subject)) return true;
        if (">".equals(pattern)) return true;

        String[] patternParts = pattern.split("\\.");
        String[] subjectParts = subject.split("\\.");

        for (int i = 0; i < patternParts.length; i++) {
            if (">".equals(patternParts[i])) return true; // matches rest
            if (i >= subjectParts.length) return false;
            if (!"*".equals(patternParts[i]) && !patternParts[i].equals(subjectParts[i])) {
                return false;
            }
        }
        return patternParts.length == subjectParts.length;
    }

    @Override
    public String toString() {
        return "InMemoryMessagePublisher{published=%d, subscriptions=%d, sync=%s}"
            .formatted(publishedMessages.size(), handlers.size(), synchronousDelivery);
    }
}
