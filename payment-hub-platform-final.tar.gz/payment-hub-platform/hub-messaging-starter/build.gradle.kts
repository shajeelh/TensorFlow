plugins { `java-library` }
description = "Payment Hub — Transport-Agnostic Messaging (NATS JetStream, Kafka, RabbitMQ, In-Memory)"
dependencies {
    api(project(":hub-common-model"))
    implementation(project(":hub-observability-starter"))
    implementation(project(":hub-tenant-context-starter"))

    implementation("com.fasterxml.jackson.core:jackson-databind")
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("org.slf4j:slf4j-api")

    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
