import org.gradle.api.tasks.testing.logging.TestExceptionFormat

plugins {
    java
    id("org.springframework.boot") version "4.0.2" apply false
    id("io.spring.dependency-management") version "1.1.7" apply false
    id("com.google.protobuf") version "0.9.4" apply false
}

// ═══════════════════════════════════════════════════════════
// Centralized version catalog
// ═══════════════════════════════════════════════════════════
val springBootVersion       = "4.0.2"
val grpcVersion             = "1.70.0"
val protobufVersion         = "4.29.3"
val lmaxDisruptorVersion    = "4.0.0"
val resilience4jVersion     = "2.3.0"
val bouncyCastleVersion     = "1.80"
val natsClientVersion       = "2.21.0"
val opensearchClientVersion = "2.19.0"
val parquetVersion          = "1.15.0"
val testcontainersVersion   = "1.20.5"
val archunitVersion         = "1.3.0"

allprojects {
    group = "com.paymenthub"
    version = "1.0.0-SNAPSHOT"
    repositories {
        mavenCentral()
    }
}

subprojects {
    apply(plugin = "java-library")
    apply(plugin = "io.spring.dependency-management")

    java {
        toolchain {
            languageVersion.set(JavaLanguageVersion.of(25))
        }
    }

    dependencyManagement {
        imports {
            mavenBom("org.springframework.boot:spring-boot-dependencies:$springBootVersion")
            mavenBom("io.grpc:grpc-bom:$grpcVersion")
        }
        dependencies {
            dependency("com.lmax:disruptor:$lmaxDisruptorVersion")
            dependency("io.github.resilience4j:resilience4j-spring-boot3:$resilience4jVersion")
            dependency("io.github.resilience4j:resilience4j-circuitbreaker:$resilience4jVersion")
            dependency("io.github.resilience4j:resilience4j-retry:$resilience4jVersion")
            dependency("io.github.resilience4j:resilience4j-timelimiter:$resilience4jVersion")
            dependency("org.bouncycastle:bcprov-jdk18on:$bouncyCastleVersion")
            dependency("org.bouncycastle:bcpkix-jdk18on:$bouncyCastleVersion")
            dependency("io.nats:jnats:$natsClientVersion")
            dependency("org.opensearch.client:opensearch-java:$opensearchClientVersion")
            dependency("org.apache.parquet:parquet-avro:$parquetVersion")
            dependency("com.google.protobuf:protobuf-java:$protobufVersion")
            dependency("com.google.protobuf:protobuf-java-util:$protobufVersion")
            dependency("org.testcontainers:testcontainers:$testcontainersVersion")
            dependency("org.testcontainers:postgresql:$testcontainersVersion")
            dependency("org.testcontainers:kafka:$testcontainersVersion")
            dependency("com.tngtech.archunit:archunit-junit5:$archunitVersion")
        }
    }

    dependencies {
        annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
        testImplementation("org.springframework.boot:spring-boot-starter-test")
        testImplementation("org.assertj:assertj-core")
    }

    tasks.withType<JavaCompile> {
        options.encoding = "UTF-8"
        options.compilerArgs.addAll(listOf("-parameters"))
    }

    tasks.withType<Test> {
        useJUnitPlatform()
        testLogging {
            events("passed", "skipped", "failed")
            exceptionFormat = TestExceptionFormat.FULL
        }
    }
}
