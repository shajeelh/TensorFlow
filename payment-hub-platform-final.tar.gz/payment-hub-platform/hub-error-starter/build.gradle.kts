plugins { `java-library` }
description = "Payment Hub — Error Codes, Exception Hierarchy, Structured Error Responses"
dependencies {
    api(project(":hub-common-model"))
    implementation(project(":hub-observability-starter"))
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("com.fasterxml.jackson.core:jackson-databind")
    implementation("org.slf4j:slf4j-api")
    compileOnly("org.springframework:spring-webmvc")
    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
