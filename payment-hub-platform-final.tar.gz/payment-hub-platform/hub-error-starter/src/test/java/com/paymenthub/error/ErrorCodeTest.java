package com.paymenthub.error;

import com.paymenthub.common.exception.HubException;
import com.paymenthub.error.codes.ErrorCode;
import com.paymenthub.error.response.ErrorResponse;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.*;

class ErrorCodeTest {

    @Test
    @DisplayName("All error codes are unique")
    void uniqueCodes() {
        Set<String> codes = new HashSet<>();
        for (ErrorCode ec : ErrorCode.values()) {
            assertThat(codes.add(ec.code()))
                .as("Duplicate code: %s", ec.code())
                .isTrue();
        }
    }

    @Test
    @DisplayName("Security errors map to 4xx HTTP status")
    void securityStatusCodes() {
        assertThat(ErrorCode.AUTH_UNAUTHORIZED.httpStatus()).isEqualTo(401);
        assertThat(ErrorCode.AUTH_FORBIDDEN.httpStatus()).isEqualTo(403);
        assertThat(ErrorCode.TENANT_ISOLATION_VIOLATION.httpStatus()).isEqualTo(403);
    }

    @Test
    @DisplayName("Technical errors map to 5xx HTTP status")
    void technicalStatusCodes() {
        assertThat(ErrorCode.SYS_INTERNAL_ERROR.httpStatus()).isEqualTo(500);
        assertThat(ErrorCode.SYS_SERVICE_UNAVAILABLE.httpStatus()).isEqualTo(503);
        assertThat(ErrorCode.SYS_TIMEOUT.httpStatus()).isEqualTo(504);
    }

    @Test
    @DisplayName("fromCode lookup works")
    void fromCodeLookup() {
        assertThat(ErrorCode.fromCode("AUDIT-0001")).isEqualTo(ErrorCode.AUDIT_RECORDING_FAILED);
        assertThat(ErrorCode.fromCode("UNKNOWN")).isEqualTo(ErrorCode.SYS_INTERNAL_ERROR);
        assertThat(ErrorCode.fromCode(null)).isEqualTo(ErrorCode.SYS_INTERNAL_ERROR);
    }

    @Test
    @DisplayName("ErrorResponse from ErrorCode")
    void errorResponse() {
        ErrorResponse resp = ErrorResponse.fromErrorCode(ErrorCode.AUDIT_RECORDING_FAILED, "corr-123");
        assertThat(resp.errorCode()).isEqualTo("AUDIT-0001");
        assertThat(resp.severity()).isEqualTo("SECURITY");
        assertThat(resp.retrySafe()).isFalse();
        assertThat(resp.correlationId()).isEqualTo("corr-123");
        assertThat(resp.timestamp()).isNotNull();
    }

    @Test
    @DisplayName("Retry-safe flags are correct")
    void retrySafe() {
        assertThat(ErrorCode.AUDIT_STORE_UNAVAILABLE.retrySafe()).isTrue();
        assertThat(ErrorCode.MSG_PUBLISH_FAILED.retrySafe()).isTrue();
        assertThat(ErrorCode.TENANT_ISOLATION_VIOLATION.retrySafe()).isFalse();
        assertThat(ErrorCode.AUTH_UNAUTHORIZED.retrySafe()).isFalse();
    }
}
