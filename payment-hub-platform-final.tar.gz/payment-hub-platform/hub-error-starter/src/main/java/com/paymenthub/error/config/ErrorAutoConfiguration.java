package com.paymenthub.error.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;

@AutoConfiguration
public class ErrorAutoConfiguration {
    private static final Logger log = LoggerFactory.getLogger(ErrorAutoConfiguration.class);
    public ErrorAutoConfiguration() {
        log.info("Payment Hub error handling configured");
    }
}
