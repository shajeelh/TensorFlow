package com.paymenthub.error.codes;

import com.paymenthub.common.exception.HubException;

/**
 * Centralized error code registry for the payment hub platform.
 *
 * <p>Every error has a unique, machine-readable code following the format:
 * {@code MODULE-NNNN} (e.g., AUDIT-0001, CRYPTO-0002, TENANT-0003).</p>
 *
 * <p>Error codes are grouped by module prefix:</p>
 * <ul>
 *   <li>{@code AUDIT-xxxx} — Audit module errors</li>
 *   <li>{@code CRYPTO-xxxx} — Cryptographic operation errors</li>
 *   <li>{@code TENANT-xxxx} — Multi-tenancy errors</li>
 *   <li>{@code PII-xxxx} — PII handling errors</li>
 *   <li>{@code MSG-xxxx} — Messaging transport errors</li>
 *   <li>{@code AUTH-xxxx} — Authentication/authorization errors</li>
 *   <li>{@code SYS-xxxx} — System/infrastructure errors</li>
 * </ul>
 */
public enum ErrorCode {

    // ── Audit (AUDIT-xxxx) ───────────────────────────────────
    AUDIT_RECORDING_FAILED("AUDIT-0001", "Audit recording failed", HubException.Severity.SECURITY, false),
    AUDIT_HASH_CHAIN_BROKEN("AUDIT-0002", "Hash chain integrity violation", HubException.Severity.SECURITY, false),
    AUDIT_EVENT_INVALID("AUDIT-0003", "Audit event validation failed", HubException.Severity.BUSINESS, false),
    AUDIT_BATCH_SIGNING_FAILED("AUDIT-0004", "Batch signing failed", HubException.Severity.TECHNICAL, true),
    AUDIT_STORE_UNAVAILABLE("AUDIT-0005", "Audit store unavailable", HubException.Severity.TECHNICAL, true),

    // ── Crypto (CRYPTO-xxxx) ─────────────────────────────────
    CRYPTO_HASH_FAILED("CRYPTO-0001", "Hash computation failed", HubException.Severity.TECHNICAL, true),
    CRYPTO_SIGN_FAILED("CRYPTO-0002", "Signing failed", HubException.Severity.TECHNICAL, true),
    CRYPTO_VERIFY_FAILED("CRYPTO-0003", "Signature verification failed", HubException.Severity.SECURITY, false),
    CRYPTO_ENCRYPT_FAILED("CRYPTO-0004", "Encryption failed", HubException.Severity.TECHNICAL, true),
    CRYPTO_DECRYPT_FAILED("CRYPTO-0005", "Decryption failed", HubException.Severity.SECURITY, false),
    CRYPTO_KEY_UNAVAILABLE("CRYPTO-0006", "Signing key unavailable", HubException.Severity.TECHNICAL, true),

    // ── Tenant (TENANT-xxxx) ─────────────────────────────────
    TENANT_ISOLATION_VIOLATION("TENANT-0001", "Cross-tenant access attempt", HubException.Severity.SECURITY, false),
    TENANT_NOT_FOUND("TENANT-0002", "Tenant not found", HubException.Severity.BUSINESS, false),
    TENANT_CONTEXT_MISSING("TENANT-0003", "Tenant context not set", HubException.Severity.TECHNICAL, false),

    // ── PII (PII-xxxx) ──────────────────────────────────────
    PII_SCAN_FAILED("PII-0001", "PII scan failed", HubException.Severity.TECHNICAL, true),
    PII_TIER0_DETECTED("PII-0002", "PCI data detected in restricted field", HubException.Severity.SECURITY, false),
    PII_TOKENIZATION_FAILED("PII-0003", "PII tokenization failed", HubException.Severity.TECHNICAL, true),

    // ── Messaging (MSG-xxxx) ─────────────────────────────────
    MSG_PUBLISH_FAILED("MSG-0001", "Message publish failed", HubException.Severity.TECHNICAL, true),
    MSG_CONSUME_FAILED("MSG-0002", "Message consumption failed", HubException.Severity.TECHNICAL, true),
    MSG_TRANSPORT_UNAVAILABLE("MSG-0003", "Transport unavailable", HubException.Severity.TECHNICAL, true),

    // ── Auth (AUTH-xxxx) ─────────────────────────────────────
    AUTH_UNAUTHORIZED("AUTH-0001", "Unauthorized access", HubException.Severity.SECURITY, false),
    AUTH_FORBIDDEN("AUTH-0002", "Forbidden — insufficient permissions", HubException.Severity.SECURITY, false),
    AUTH_TOKEN_EXPIRED("AUTH-0003", "Authentication token expired", HubException.Severity.BUSINESS, false),

    // ── System (SYS-xxxx) ────────────────────────────────────
    SYS_INTERNAL_ERROR("SYS-0001", "Internal server error", HubException.Severity.TECHNICAL, true),
    SYS_SERVICE_UNAVAILABLE("SYS-0002", "Service temporarily unavailable", HubException.Severity.TECHNICAL, true),
    SYS_TIMEOUT("SYS-0003", "Operation timed out", HubException.Severity.TECHNICAL, true),
    SYS_IDEMPOTENCY_CONFLICT("SYS-0004", "Duplicate request (idempotency key)", HubException.Severity.BUSINESS, false),
    SYS_RATE_LIMITED("SYS-0005", "Rate limit exceeded", HubException.Severity.BUSINESS, false);

    private final String code;
    private final String defaultMessage;
    private final HubException.Severity severity;
    private final boolean retrySafe;

    ErrorCode(String code, String defaultMessage, HubException.Severity severity, boolean retrySafe) {
        this.code = code;
        this.defaultMessage = defaultMessage;
        this.severity = severity;
        this.retrySafe = retrySafe;
    }

    public String code() { return code; }
    public String defaultMessage() { return defaultMessage; }
    public HubException.Severity severity() { return severity; }
    public boolean retrySafe() { return retrySafe; }

    /** HTTP status code mapping. */
    public int httpStatus() {
        return switch (severity) {
            case BUSINESS -> switch (this) {
                case AUTH_TOKEN_EXPIRED -> 401;
                case SYS_IDEMPOTENCY_CONFLICT -> 409;
                case SYS_RATE_LIMITED -> 429;
                default -> 422;
            };
            case SECURITY -> switch (this) {
                case AUTH_UNAUTHORIZED -> 401;
                case AUTH_FORBIDDEN -> 403;
                default -> 403;
            };
            case TECHNICAL -> switch (this) {
                case SYS_SERVICE_UNAVAILABLE, AUDIT_STORE_UNAVAILABLE, MSG_TRANSPORT_UNAVAILABLE -> 503;
                case SYS_TIMEOUT -> 504;
                default -> 500;
            };
        };
    }

    /** Look up error code by string. */
    public static ErrorCode fromCode(String code) {
        if (code == null) return SYS_INTERNAL_ERROR;
        for (ErrorCode ec : values()) {
            if (ec.code.equals(code)) return ec;
        }
        return SYS_INTERNAL_ERROR;
    }
}
