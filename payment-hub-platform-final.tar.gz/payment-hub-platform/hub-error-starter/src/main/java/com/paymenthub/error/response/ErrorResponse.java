package com.paymenthub.error.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paymenthub.error.codes.ErrorCode;

import java.time.Instant;
import java.util.List;

/**
 * Structured error response for REST and gRPC APIs.
 *
 * <p>Follows RFC 7807 (Problem Details for HTTP APIs) conventions.</p>
 *
 * @param errorCode      machine-readable error code
 * @param message        human-readable error message
 * @param severity       BUSINESS / TECHNICAL / SECURITY
 * @param retrySafe      whether the client should retry
 * @param correlationId  for tracing the error across modules
 * @param timestamp      when the error occurred
 * @param details        optional additional detail messages
 * @param fieldErrors    optional field-level validation errors
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ErrorResponse(
    String errorCode,
    String message,
    String severity,
    boolean retrySafe,
    String correlationId,
    Instant timestamp,
    List<String> details,
    List<FieldError> fieldErrors
) {
    public static ErrorResponse fromErrorCode(ErrorCode code, String correlationId) {
        return new ErrorResponse(
            code.code(), code.defaultMessage(), code.severity().name(),
            code.retrySafe(), correlationId, Instant.now(), null, null
        );
    }

    public static ErrorResponse fromErrorCode(ErrorCode code, String message, String correlationId) {
        return new ErrorResponse(
            code.code(), message, code.severity().name(),
            code.retrySafe(), correlationId, Instant.now(), null, null
        );
    }

    public record FieldError(String field, String message, String rejectedValue) {}
}
