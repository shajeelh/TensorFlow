package com.paymenthub.crypto.encryption;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import static org.assertj.core.api.Assertions.*;

class EncryptionServiceTest {

    private EncryptionService encryptionService;
    private byte[] key;

    @BeforeEach
    void setUp() {
        encryptionService = new EncryptionService();
        key = encryptionService.generateKey();
    }

    @Nested
    @DisplayName("Encryption and Decryption")
    class EncryptDecrypt {

        @Test
        @DisplayName("Round-trip encrypt/decrypt preserves plaintext")
        void roundTrip() {
            byte[] plaintext = "Sensitive PII: jane.doe@megabank.com".getBytes(StandardCharsets.UTF_8);
            var encrypted = encryptionService.encrypt(plaintext, key);
            byte[] decrypted = encryptionService.decrypt(encrypted, key);

            assertThat(decrypted).isEqualTo(plaintext);
        }

        @Test
        @DisplayName("String round-trip preserves text")
        void stringRoundTrip() {
            String original = "GB82 WEST 1234 5698 7654 32";
            var encrypted = encryptionService.encryptString(original, key);
            String decrypted = encryptionService.decryptToString(encrypted, key);

            assertThat(decrypted).isEqualTo(original);
        }

        @Test
        @DisplayName("Ciphertext differs from plaintext")
        void ciphertextDiffers() {
            byte[] plaintext = "cleartext data".getBytes(StandardCharsets.UTF_8);
            var encrypted = encryptionService.encrypt(plaintext, key);

            assertThat(encrypted.ciphertext()).isNotEqualTo(plaintext);
        }

        @Test
        @DisplayName("Same plaintext produces different ciphertext (random IV)")
        void randomIv() {
            byte[] plaintext = "same input".getBytes(StandardCharsets.UTF_8);
            var enc1 = encryptionService.encrypt(plaintext, key);
            var enc2 = encryptionService.encrypt(plaintext, key);

            assertThat(enc1.iv()).isNotEqualTo(enc2.iv());
            assertThat(enc1.ciphertext()).isNotEqualTo(enc2.ciphertext());
        }

        @Test
        @DisplayName("Empty plaintext can be encrypted and decrypted")
        void emptyPlaintext() {
            var encrypted = encryptionService.encrypt(new byte[0], key);
            byte[] decrypted = encryptionService.decrypt(encrypted, key);
            assertThat(decrypted).isEmpty();
        }

        @Test
        @DisplayName("Large plaintext works correctly")
        void largePlaintext() {
            byte[] plaintext = new byte[1_000_000]; // 1MB
            Arrays.fill(plaintext, (byte) 0x42);

            var encrypted = encryptionService.encrypt(plaintext, key);
            byte[] decrypted = encryptionService.decrypt(encrypted, key);
            assertThat(decrypted).isEqualTo(plaintext);
        }
    }

    @Nested
    @DisplayName("Authentication (GCM tag)")
    class Authentication {

        @Test
        @DisplayName("Wrong key fails decryption")
        void wrongKey() {
            byte[] plaintext = "sensitive".getBytes(StandardCharsets.UTF_8);
            var encrypted = encryptionService.encrypt(plaintext, key);

            byte[] wrongKey = encryptionService.generateKey();
            assertThatThrownBy(() -> encryptionService.decrypt(encrypted, wrongKey))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("authentication tag");
        }

        @Test
        @DisplayName("Tampered ciphertext fails decryption")
        void tamperedCiphertext() {
            byte[] plaintext = "sensitive".getBytes(StandardCharsets.UTF_8);
            var encrypted = encryptionService.encrypt(plaintext, key);

            byte[] tampered = encrypted.ciphertext().clone();
            tampered[0] ^= 0xFF;
            var tamperedPayload = new EncryptionService.EncryptedPayload(encrypted.iv(), tampered);

            assertThatThrownBy(() -> encryptionService.decrypt(tamperedPayload, key))
                .isInstanceOf(IllegalStateException.class);
        }

        @Test
        @DisplayName("Tampered IV fails decryption")
        void tamperedIv() {
            byte[] plaintext = "sensitive".getBytes(StandardCharsets.UTF_8);
            var encrypted = encryptionService.encrypt(plaintext, key);

            byte[] tampered = encrypted.iv().clone();
            tampered[0] ^= 0xFF;
            var tamperedPayload = new EncryptionService.EncryptedPayload(tampered, encrypted.ciphertext());

            assertThatThrownBy(() -> encryptionService.decrypt(tamperedPayload, key))
                .isInstanceOf(IllegalStateException.class);
        }
    }

    @Nested
    @DisplayName("Base64 serialization")
    class Base64Serialization {

        @Test
        @DisplayName("Round-trip through Base64")
        void roundTrip() {
            byte[] plaintext = "IBAN: DE89 3704 0044 0532 0130 00".getBytes(StandardCharsets.UTF_8);
            var encrypted = encryptionService.encrypt(plaintext, key);

            String base64 = encrypted.toBase64();
            assertThat(base64).isNotBlank();

            var deserialized = EncryptionService.EncryptedPayload.fromBase64(base64);
            byte[] decrypted = encryptionService.decrypt(deserialized, key);
            assertThat(decrypted).isEqualTo(plaintext);
        }

        @Test
        @DisplayName("decryptFromBase64 convenience method")
        void decryptFromBase64() {
            String original = "test@example.com";
            var encrypted = encryptionService.encryptString(original, key);
            String base64 = encrypted.toBase64();

            byte[] decrypted = encryptionService.decryptFromBase64(base64, key);
            assertThat(new String(decrypted, StandardCharsets.UTF_8)).isEqualTo(original);
        }
    }

    @Nested
    @DisplayName("Key management")
    class KeyManagement {

        @Test
        @DisplayName("Generated key is 32 bytes")
        void keySize() {
            byte[] key = encryptionService.generateKey();
            assertThat(key).hasSize(32);
        }

        @Test
        @DisplayName("Generated keys are unique")
        void keyUniqueness() {
            byte[] key1 = encryptionService.generateKey();
            byte[] key2 = encryptionService.generateKey();
            assertThat(key1).isNotEqualTo(key2);
        }

        @Test
        @DisplayName("Wrong key size throws IllegalArgumentException")
        void wrongKeySize() {
            byte[] shortKey = new byte[16]; // AES-128, not AES-256
            assertThatThrownBy(() -> encryptionService.encrypt("test".getBytes(), shortKey))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("32 bytes");
        }

        @Test
        @DisplayName("Null key throws NullPointerException")
        void nullKey() {
            assertThatThrownBy(() -> encryptionService.encrypt("test".getBytes(), null))
                .isInstanceOf(NullPointerException.class);
        }
    }
}
