package com.paymenthub.crypto.signature;

import com.paymenthub.common.model.integrity.SignedBatch;
import com.paymenthub.crypto.hash.HashService;
import org.bouncycastle.jce.ECNamedCurveTable;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECParameterSpec;
import org.junit.jupiter.api.*;

import java.security.*;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.*;

class SoftwareAuditSignerTest {

    private SoftwareAuditSigner signer;
    private HashService hashService;

    @BeforeAll
    static void setupProvider() {
        if (Security.getProvider("BC") == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }

    @BeforeEach
    void setUp() throws Exception {
        hashService = new HashService("SHA-256");
        ECParameterSpec ecSpec = ECNamedCurveTable.getParameterSpec("P-384");
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC", "BC");
        kpg.initialize(ecSpec, new SecureRandom());
        KeyPair kp = kpg.generateKeyPair();
        signer = new SoftwareAuditSigner(kp.getPrivate(), kp.getPublic(), "test-key-1", hashService);
    }

    @Nested
    @DisplayName("Signing")
    class SigningTests {

        @Test
        @DisplayName("Sign a single-hash batch")
        void signSingle() {
            List<byte[]> hashes = List.of(hashService.hash("event-1".getBytes()));
            SignedBatch batch = signer.sign(hashes);

            assertThat(batch.batchId()).isEqualTo(1);
            assertThat(batch.signature()).isNotEmpty();
            assertThat(batch.batchDigest()).isNotEmpty();
            assertThat(batch.signingKeyId()).isEqualTo("test-key-1");
            assertThat(batch.signingMode()).isEqualTo("software");
            assertThat(batch.size()).isEqualTo(1);
        }

        @Test
        @DisplayName("Sign a multi-hash batch")
        void signMultiple() {
            List<byte[]> hashes = new ArrayList<>();
            for (int i = 0; i < 50; i++) {
                hashes.add(hashService.hash(("event-" + i).getBytes()));
            }
            SignedBatch batch = signer.sign(hashes);

            assertThat(batch.size()).isEqualTo(50);
            assertThat(batch.signature()).isNotEmpty();
        }

        @Test
        @DisplayName("Empty batch throws IllegalArgumentException")
        void emptyBatch() {
            assertThatThrownBy(() -> signer.sign(List.of()))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("empty");
        }

        @Test
        @DisplayName("Null hashes throws NullPointerException")
        void nullHashes() {
            assertThatThrownBy(() -> signer.sign(null))
                .isInstanceOf(NullPointerException.class);
        }
    }

    @Nested
    @DisplayName("Verification")
    class VerificationTests {

        @Test
        @DisplayName("Valid batch passes verification")
        void validBatch() {
            List<byte[]> hashes = List.of(
                hashService.hash("event-1".getBytes()),
                hashService.hash("event-2".getBytes()),
                hashService.hash("event-3".getBytes())
            );
            SignedBatch batch = signer.sign(hashes);
            assertThat(signer.verify(batch)).isTrue();
        }

        @Test
        @DisplayName("Tampered digest fails verification")
        void tamperedDigest() {
            List<byte[]> hashes = List.of(hashService.hash("event".getBytes()));
            SignedBatch batch = signer.sign(hashes);

            byte[] tamperedDigest = batch.batchDigest().clone();
            tamperedDigest[0] ^= 0xFF;
            SignedBatch tampered = new SignedBatch(
                batch.batchId(), batch.recordHashes(), tamperedDigest,
                batch.signature(), batch.signingKeyId(), batch.signingMode());

            assertThat(signer.verify(tampered)).isFalse();
        }

        @Test
        @DisplayName("Tampered signature fails verification")
        void tamperedSignature() {
            List<byte[]> hashes = List.of(hashService.hash("event".getBytes()));
            SignedBatch batch = signer.sign(hashes);

            byte[] tamperedSig = batch.signature().clone();
            tamperedSig[tamperedSig.length - 1] ^= 0xFF;
            SignedBatch tampered = new SignedBatch(
                batch.batchId(), batch.recordHashes(), batch.batchDigest(),
                tamperedSig, batch.signingKeyId(), batch.signingMode());

            assertThat(signer.verify(tampered)).isFalse();
        }

        @Test
        @DisplayName("Batch signed with different key fails verification")
        void differentKey() throws Exception {
            ECParameterSpec ecSpec = ECNamedCurveTable.getParameterSpec("P-384");
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC", "BC");
            kpg.initialize(ecSpec, new SecureRandom());
            KeyPair otherKeyPair = kpg.generateKeyPair();
            var otherSigner = new SoftwareAuditSigner(
                otherKeyPair.getPrivate(), otherKeyPair.getPublic(), "other-key", hashService);

            List<byte[]> hashes = List.of(hashService.hash("event".getBytes()));
            SignedBatch batch = otherSigner.sign(hashes);

            // Verify with original signer's key — should fail
            assertThat(signer.verify(batch)).isFalse();
        }
    }

    @Nested
    @DisplayName("Batch ID monotonicity")
    class BatchIdTests {

        @Test
        @DisplayName("Batch IDs are monotonically increasing")
        void monotonic() {
            List<byte[]> hashes = List.of(hashService.hash("event".getBytes()));
            long prevId = 0;
            for (int i = 0; i < 100; i++) {
                SignedBatch batch = signer.sign(hashes);
                assertThat(batch.batchId()).isGreaterThan(prevId);
                prevId = batch.batchId();
            }
        }

        @Test
        @DisplayName("Batch counter tracks total signed")
        void counter() {
            assertThat(signer.getTotalBatchesSigned()).isZero();

            List<byte[]> hashes = List.of(hashService.hash("event".getBytes()));
            signer.sign(hashes);
            signer.sign(hashes);
            signer.sign(hashes);

            assertThat(signer.getTotalBatchesSigned()).isEqualTo(3);
        }
    }

    @Nested
    @DisplayName("Metadata")
    class MetadataTests {

        @Test
        @DisplayName("Signing mode is 'software'")
        void signingMode() {
            assertThat(signer.signingMode()).isEqualTo("software");
        }

        @Test
        @DisplayName("Key ID matches construction parameter")
        void keyId() {
            assertThat(signer.currentKeyId()).isEqualTo("test-key-1");
        }

        @Test
        @DisplayName("isHealthy returns true when keys present")
        void healthy() {
            assertThat(signer.isHealthy()).isTrue();
        }

        @Test
        @DisplayName("Key creation timestamp is recorded")
        void keyCreatedAt() {
            assertThat(signer.getKeyCreatedAt()).isNotNull();
        }
    }
}
