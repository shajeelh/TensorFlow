package com.paymenthub.crypto.hash;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;

import static org.assertj.core.api.Assertions.*;

class HashServiceTest {

    private HashService hashService;

    @BeforeEach
    void setUp() {
        hashService = new HashService("SHA3-256");
    }

    @Nested
    @DisplayName("Raw hashing")
    class RawHashing {

        @Test
        @DisplayName("SHA3-256 produces 32-byte digest")
        void digestLength() {
            byte[] result = hashService.hash("hello".getBytes(StandardCharsets.UTF_8));
            assertThat(result).hasSize(32);
        }

        @Test
        @DisplayName("Same input produces same hash (deterministic)")
        void deterministic() {
            byte[] input = "audit event data".getBytes(StandardCharsets.UTF_8);
            byte[] hash1 = hashService.hash(input);
            byte[] hash2 = hashService.hash(input);
            assertThat(hash1).isEqualTo(hash2);
        }

        @Test
        @DisplayName("Different inputs produce different hashes")
        void uniqueness() {
            byte[] hash1 = hashService.hash("input1".getBytes());
            byte[] hash2 = hashService.hash("input2".getBytes());
            assertThat(hash1).isNotEqualTo(hash2);
        }

        @Test
        @DisplayName("Empty input produces valid hash")
        void emptyInput() {
            byte[] result = hashService.hash(new byte[0]);
            assertThat(result).hasSize(32);
        }

        @Test
        @DisplayName("Null input throws NullPointerException")
        void nullInput() {
            assertThatThrownBy(() -> hashService.hash((byte[]) null))
                .isInstanceOf(NullPointerException.class);
        }

        @Test
        @DisplayName("hashString convenience method works")
        void hashString() {
            byte[] fromBytes = hashService.hash("test".getBytes(StandardCharsets.UTF_8));
            byte[] fromString = hashService.hashString("test");
            assertThat(fromString).isEqualTo(fromBytes);
        }
    }

    @Nested
    @DisplayName("HMAC")
    class HmacTests {

        @Test
        @DisplayName("HMAC produces consistent output")
        void consistent() {
            byte[] key = new byte[32];
            java.util.Arrays.fill(key, (byte) 0x42);
            byte[] input = "data".getBytes();

            byte[] hmac1 = hashService.hmac(input, key);
            byte[] hmac2 = hashService.hmac(input, key);
            assertThat(hmac1).isEqualTo(hmac2);
        }

        @Test
        @DisplayName("Different keys produce different HMACs")
        void keyDependence() {
            byte[] input = "data".getBytes();
            byte[] key1 = new byte[32];
            byte[] key2 = new byte[32];
            key1[0] = 1;
            key2[0] = 2;

            assertThat(hashService.hmac(input, key1))
                .isNotEqualTo(hashService.hmac(input, key2));
        }
    }

    @Nested
    @DisplayName("Canonical hashing")
    class CanonicalHashing {

        @Test
        @DisplayName("Same object content produces same hash regardless of key order")
        void keyOrderIndependence() {
            var map1 = new LinkedHashMap<String, Object>();
            map1.put("alpha", 1);
            map1.put("beta", 2);

            var map2 = new LinkedHashMap<String, Object>();
            map2.put("beta", 2);
            map2.put("alpha", 1);

            byte[] hash1 = hashService.canonicalHash(map1);
            byte[] hash2 = hashService.canonicalHash(map2);
            assertThat(hash1).isEqualTo(hash2);
        }

        @Test
        @DisplayName("Different content produces different hash")
        void contentDependence() {
            byte[] hash1 = hashService.canonicalHash(java.util.Map.of("key", "value1"));
            byte[] hash2 = hashService.canonicalHash(java.util.Map.of("key", "value2"));
            assertThat(hash1).isNotEqualTo(hash2);
        }
    }

    @Nested
    @DisplayName("Chain hashing")
    class ChainHashing {

        @Test
        @DisplayName("Chain hash depends on both previous and record hash")
        void bothInputsMatter() {
            byte[] prev = hashService.hash("prev".getBytes());
            byte[] rec1 = hashService.hash("record1".getBytes());
            byte[] rec2 = hashService.hash("record2".getBytes());

            byte[] chain1 = hashService.chainHash(prev, rec1);
            byte[] chain2 = hashService.chainHash(prev, rec2);
            assertThat(chain1).isNotEqualTo(chain2);
        }

        @Test
        @DisplayName("Chain hash is deterministic")
        void deterministic() {
            byte[] prev = hashService.hash("prev".getBytes());
            byte[] rec = hashService.hash("record".getBytes());

            assertThat(hashService.chainHash(prev, rec))
                .isEqualTo(hashService.chainHash(prev, rec));
        }

        @Test
        @DisplayName("verifyChainLink works for valid link")
        void verifyValid() {
            byte[] prev = hashService.hash("prev".getBytes());
            byte[] rec = hashService.hash("record".getBytes());
            byte[] chain = hashService.chainHash(prev, rec);

            assertThat(hashService.verifyChainLink(prev, rec, chain)).isTrue();
        }

        @Test
        @DisplayName("verifyChainLink fails for tampered chain")
        void verifyTampered() {
            byte[] prev = hashService.hash("prev".getBytes());
            byte[] rec = hashService.hash("record".getBytes());
            byte[] chain = hashService.chainHash(prev, rec);
            chain[0] ^= 0xFF; // tamper

            assertThat(hashService.verifyChainLink(prev, rec, chain)).isFalse();
        }

        @Test
        @DisplayName("Genesis hash is all zeros")
        void genesis() {
            byte[] genesis = hashService.genesisHash();
            assertThat(genesis).hasSize(32);
            for (byte b : genesis) {
                assertThat(b).isZero();
            }
        }
    }

    @Nested
    @DisplayName("Configuration")
    class Configuration {

        @Test
        @DisplayName("Unsupported algorithm throws at construction")
        void unsupportedAlgorithm() {
            assertThatThrownBy(() -> new HashService("MD5"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Unsupported");
        }

        @Test
        @DisplayName("SHA-256 is supported")
        void sha256Support() {
            var sha256 = new HashService("SHA-256");
            byte[] hash = sha256.hash("test".getBytes());
            assertThat(hash).hasSize(32);
        }

        @Test
        @DisplayName("getDigestLength returns correct size")
        void digestLength() {
            assertThat(new HashService("SHA3-256").getDigestLength()).isEqualTo(32);
            assertThat(new HashService("SHA-256").getDigestLength()).isEqualTo(32);
        }
    }
}
