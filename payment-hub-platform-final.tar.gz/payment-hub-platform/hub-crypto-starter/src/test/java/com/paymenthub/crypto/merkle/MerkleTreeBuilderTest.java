package com.paymenthub.crypto.merkle;

import com.paymenthub.common.model.integrity.MerkleProof;
import com.paymenthub.crypto.hash.HashService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.*;

class MerkleTreeBuilderTest {

    private MerkleTreeBuilder treeBuilder;
    private HashService hashService;

    @BeforeEach
    void setUp() {
        hashService = new HashService("SHA-256");
        treeBuilder = new MerkleTreeBuilder(hashService);
    }

    private byte[] leaf(String data) {
        return hashService.hash(data.getBytes());
    }

    @Nested
    @DisplayName("Root computation")
    class RootComputation {

        @Test
        @DisplayName("Single leaf — root is the leaf itself")
        void singleLeaf() {
            byte[] leafHash = leaf("event-1");
            byte[] root = treeBuilder.computeRoot(List.of(leafHash));
            assertThat(root).isEqualTo(leafHash);
        }

        @Test
        @DisplayName("Two leaves — root is hash of their concatenation")
        void twoLeaves() {
            byte[] l1 = leaf("event-1");
            byte[] l2 = leaf("event-2");
            byte[] root = treeBuilder.computeRoot(List.of(l1, l2));

            // Manual computation
            byte[] combined = new byte[l1.length + l2.length];
            System.arraycopy(l1, 0, combined, 0, l1.length);
            System.arraycopy(l2, 0, combined, l1.length, l2.length);
            byte[] expectedRoot = hashService.hash(combined);

            assertThat(root).isEqualTo(expectedRoot);
        }

        @Test
        @DisplayName("Power-of-2 leaves produce valid root")
        void powerOfTwo() {
            List<byte[]> leaves = new ArrayList<>();
            for (int i = 0; i < 8; i++) {
                leaves.add(leaf("event-" + i));
            }
            byte[] root = treeBuilder.computeRoot(leaves);
            assertThat(root).hasSize(32);
        }

        @Test
        @DisplayName("Non-power-of-2 leaves are padded")
        void nonPowerOfTwo() {
            List<byte[]> leaves = new ArrayList<>();
            for (int i = 0; i < 5; i++) {
                leaves.add(leaf("event-" + i));
            }
            byte[] root = treeBuilder.computeRoot(leaves);
            assertThat(root).hasSize(32);
        }

        @Test
        @DisplayName("Root is deterministic")
        void deterministic() {
            List<byte[]> leaves = List.of(leaf("a"), leaf("b"), leaf("c"));
            byte[] root1 = treeBuilder.computeRoot(leaves);
            byte[] root2 = treeBuilder.computeRoot(leaves);
            assertThat(root1).isEqualTo(root2);
        }

        @Test
        @DisplayName("Different leaves produce different root")
        void differentLeaves() {
            byte[] root1 = treeBuilder.computeRoot(List.of(leaf("a"), leaf("b")));
            byte[] root2 = treeBuilder.computeRoot(List.of(leaf("a"), leaf("c")));
            assertThat(root1).isNotEqualTo(root2);
        }

        @Test
        @DisplayName("Empty list produces sentinel hash")
        void emptyList() {
            byte[] root = treeBuilder.computeRoot(List.of());
            assertThat(root).isNotNull();
            assertThat(root).hasSize(32);
        }

        @Test
        @DisplayName("Large tree (1000 leaves)")
        void largeTree() {
            List<byte[]> leaves = new ArrayList<>();
            for (int i = 0; i < 1000; i++) {
                leaves.add(leaf("event-" + i));
            }
            byte[] root = treeBuilder.computeRoot(leaves);
            assertThat(root).hasSize(32);
        }
    }

    @Nested
    @DisplayName("Proof generation and verification")
    class ProofTests {

        @Test
        @DisplayName("Proof for single leaf")
        void singleLeafProof() {
            byte[] l = leaf("only-event");
            MerkleProof proof = treeBuilder.generateProof(List.of(l), 0);

            assertThat(proof.leafHash()).isEqualTo(l);
            assertThat(proof.rootHash()).isEqualTo(l);
            assertThat(proof.path()).isEmpty();
            assertThat(treeBuilder.verifyProof(proof)).isTrue();
        }

        @Test
        @DisplayName("Proof for each leaf in 2-leaf tree")
        void twoLeafProofs() {
            List<byte[]> leaves = List.of(leaf("a"), leaf("b"));
            byte[] root = treeBuilder.computeRoot(leaves);

            for (int i = 0; i < leaves.size(); i++) {
                MerkleProof proof = treeBuilder.generateProof(leaves, i);
                assertThat(proof.rootHash()).isEqualTo(root);
                assertThat(treeBuilder.verifyProof(proof)).isTrue();
            }
        }

        @Test
        @DisplayName("Proof for each leaf in 4-leaf tree")
        void fourLeafProofs() {
            List<byte[]> leaves = List.of(leaf("a"), leaf("b"), leaf("c"), leaf("d"));
            byte[] root = treeBuilder.computeRoot(leaves);

            for (int i = 0; i < leaves.size(); i++) {
                MerkleProof proof = treeBuilder.generateProof(leaves, i);
                assertThat(proof.rootHash()).isEqualTo(root);
                assertThat(proof.path()).hasSize(2); // depth = log2(4) = 2
                assertThat(treeBuilder.verifyProof(proof)).isTrue();
            }
        }

        @Test
        @DisplayName("Proof for each leaf in 7-leaf tree (non-power-of-2)")
        void sevenLeafProofs() {
            List<byte[]> leaves = new ArrayList<>();
            for (int i = 0; i < 7; i++) {
                leaves.add(leaf("event-" + i));
            }
            byte[] root = treeBuilder.computeRoot(leaves);

            for (int i = 0; i < leaves.size(); i++) {
                MerkleProof proof = treeBuilder.generateProof(leaves, i);
                assertThat(proof.rootHash()).isEqualTo(root);
                assertThat(treeBuilder.verifyProof(proof)).isTrue();
            }
        }

        @Test
        @DisplayName("Proof for 100-leaf tree (all leaves)")
        void hundredLeafProofs() {
            List<byte[]> leaves = new ArrayList<>();
            for (int i = 0; i < 100; i++) {
                leaves.add(leaf("event-" + i));
            }
            byte[] root = treeBuilder.computeRoot(leaves);

            for (int i = 0; i < leaves.size(); i++) {
                MerkleProof proof = treeBuilder.generateProof(leaves, i);
                assertThat(proof.rootHash()).isEqualTo(root);
                assertThat(treeBuilder.verifyProof(proof))
                    .as("Proof for leaf %d should verify", i)
                    .isTrue();
            }
        }

        @Test
        @DisplayName("Tampered leaf hash fails verification")
        void tamperedLeafFails() {
            List<byte[]> leaves = List.of(leaf("a"), leaf("b"), leaf("c"), leaf("d"));
            MerkleProof proof = treeBuilder.generateProof(leaves, 0);

            // Tamper with the leaf hash
            byte[] tampered = proof.leafHash().clone();
            tampered[0] ^= 0xFF;
            MerkleProof tamperedProof = new MerkleProof(
                tampered, proof.rootHash(), proof.path(), proof.leafIndex());

            assertThat(treeBuilder.verifyProof(tamperedProof)).isFalse();
        }

        @Test
        @DisplayName("Out-of-bounds leaf index throws")
        void outOfBounds() {
            List<byte[]> leaves = List.of(leaf("a"), leaf("b"));

            assertThatThrownBy(() -> treeBuilder.generateProof(leaves, 2))
                .isInstanceOf(IndexOutOfBoundsException.class);
            assertThatThrownBy(() -> treeBuilder.generateProof(leaves, -1))
                .isInstanceOf(IndexOutOfBoundsException.class);
        }
    }
}
