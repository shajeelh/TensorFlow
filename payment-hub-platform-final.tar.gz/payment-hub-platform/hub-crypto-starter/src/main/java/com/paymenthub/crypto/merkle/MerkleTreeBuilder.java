package com.paymenthub.crypto.merkle;

import com.paymenthub.common.model.integrity.MerkleProof;
import com.paymenthub.common.model.integrity.MerkleProofNode;
import com.paymenthub.common.util.HexUtils;
import com.paymenthub.crypto.hash.HashService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * Merkle tree builder for audit event integrity anchoring.
 *
 * <p>Every 10 minutes (configurable), the audit module collects all
 * record hashes from that window and builds a Merkle tree. The root
 * is signed and persisted as a {@link com.paymenthub.common.model.integrity.MerkleRoot}.</p>
 *
 * <h3>Tree Construction</h3>
 * <ol>
 *   <li>Collect leaf hashes (event record hashes) for the window</li>
 *   <li>Pad to next power of 2 by duplicating the last leaf</li>
 *   <li>Build tree bottom-up: each parent = HASH(left_child || right_child)</li>
 *   <li>Root hash = the single remaining node</li>
 * </ol>
 *
 * <h3>Proof Generation</h3>
 * <p>Given a leaf hash, generate a list of sibling hashes from leaf to root.
 * A verifier can reconstruct the root from the leaf + proof without seeing
 * any other leaf data (privacy-preserving evidence).</p>
 *
 * <h3>Proof Verification</h3>
 * <p>Start from the leaf hash, combine with each sibling in the proof path
 * (respecting LEFT/RIGHT position), hash upward. If the result matches
 * the root hash, the leaf is proved to be part of the tree.</p>
 *
 * @see com.paymenthub.common.model.integrity.MerkleProof
 */
public class MerkleTreeBuilder {

    private static final Logger log = LoggerFactory.getLogger(MerkleTreeBuilder.class);

    private final HashService hashService;

    public MerkleTreeBuilder(HashService hashService) {
        this.hashService = Objects.requireNonNull(hashService, "HashService required");
    }

    // ── Tree Construction ────────────────────────────────────

    /**
     * Compute the Merkle root hash from a list of leaf hashes.
     *
     * @param leaves list of leaf hashes (event record hashes)
     * @return the root hash
     * @throws IllegalArgumentException if leaves is null
     */
    public byte[] computeRoot(List<byte[]> leaves) {
        Objects.requireNonNull(leaves, "Leaves must not be null");

        if (leaves.isEmpty()) {
            return hashService.hash(new byte[0]); // empty tree sentinel
        }
        if (leaves.size() == 1) {
            return leaves.getFirst();
        }

        // Pad to next power of 2
        List<byte[]> level = new ArrayList<>(leaves);
        padToPowerOfTwo(level);

        // Build tree bottom-up
        while (level.size() > 1) {
            List<byte[]> nextLevel = new ArrayList<>(level.size() / 2);
            for (int i = 0; i < level.size(); i += 2) {
                byte[] combined = concatenate(level.get(i), level.get(i + 1));
                nextLevel.add(hashService.hash(combined));
            }
            level = nextLevel;
        }

        byte[] root = level.getFirst();
        log.debug("Merkle root computed: {} leaves → root={}",
            leaves.size(), HexUtils.toShortHex(root));
        return root;
    }

    // ── Proof Generation ─────────────────────────────────────

    /**
     * Generate an inclusion proof for a specific leaf.
     *
     * @param leaves    all leaf hashes in the tree
     * @param leafIndex index of the leaf to prove
     * @return Merkle proof containing sibling path from leaf to root
     * @throws IndexOutOfBoundsException if leafIndex is out of range
     */
    public MerkleProof generateProof(List<byte[]> leaves, int leafIndex) {
        Objects.requireNonNull(leaves, "Leaves must not be null");
        if (leafIndex < 0 || leafIndex >= leaves.size()) {
            throw new IndexOutOfBoundsException(
                "Leaf index %d out of range [0, %d)".formatted(leafIndex, leaves.size()));
        }

        if (leaves.size() == 1) {
            return new MerkleProof(leaves.getFirst(), leaves.getFirst(), List.of(), 0);
        }

        // Pad to power of 2
        List<byte[]> paddedLeaves = new ArrayList<>(leaves);
        padToPowerOfTwo(paddedLeaves);

        // Build all levels bottom-up, collecting sibling at each level
        List<MerkleProofNode> path = new ArrayList<>();
        List<byte[]> currentLevel = new ArrayList<>(paddedLeaves);
        int currentIndex = leafIndex;

        while (currentLevel.size() > 1) {
            List<byte[]> nextLevel = new ArrayList<>(currentLevel.size() / 2);

            for (int i = 0; i < currentLevel.size(); i += 2) {
                byte[] combined = concatenate(currentLevel.get(i), currentLevel.get(i + 1));
                nextLevel.add(hashService.hash(combined));
            }

            // Collect sibling
            int siblingIndex = (currentIndex % 2 == 0) ? currentIndex + 1 : currentIndex - 1;
            MerkleProofNode.Position position = (currentIndex % 2 == 0)
                ? MerkleProofNode.Position.RIGHT
                : MerkleProofNode.Position.LEFT;

            if (siblingIndex < currentLevel.size()) {
                path.add(new MerkleProofNode(
                    Arrays.copyOf(currentLevel.get(siblingIndex),
                        currentLevel.get(siblingIndex).length),
                    position));
            }

            currentLevel = nextLevel;
            currentIndex = currentIndex / 2;
        }

        byte[] rootHash = currentLevel.getFirst();
        byte[] leafHash = paddedLeaves.get(leafIndex);

        log.trace("Proof generated: leaf[{}]={} → root={}, depth={}",
            leafIndex, HexUtils.toShortHex(leafHash),
            HexUtils.toShortHex(rootHash), path.size());

        return new MerkleProof(leafHash, rootHash, List.copyOf(path), leafIndex);
    }

    // ── Proof Verification ───────────────────────────────────

    /**
     * Verify a Merkle inclusion proof.
     *
     * <p>Reconstructs the root hash from the leaf hash and proof path,
     * then compares with the expected root hash.</p>
     *
     * @param proof the Merkle proof to verify
     * @return true if the proof is valid (leaf is included in the tree)
     */
    public boolean verifyProof(MerkleProof proof) {
        Objects.requireNonNull(proof, "Proof must not be null");
        if (proof.leafHash() == null || proof.rootHash() == null) {
            return false;
        }

        byte[] current = proof.leafHash();

        for (MerkleProofNode node : proof.path()) {
            byte[] combined;
            if (node.position() == MerkleProofNode.Position.LEFT) {
                // Sibling is on the LEFT, so: combined = sibling || current
                combined = concatenate(node.hash(), current);
            } else {
                // Sibling is on the RIGHT, so: combined = current || sibling
                combined = concatenate(current, node.hash());
            }
            current = hashService.hash(combined);
        }

        boolean valid = MessageDigest.isEqual(current, proof.rootHash());

        if (!valid) {
            log.warn("Merkle proof verification FAILED: computed root={}, expected={}",
                HexUtils.toShortHex(current), HexUtils.toShortHex(proof.rootHash()));
        }

        return valid;
    }

    // ── Utilities ────────────────────────────────────────────

    /**
     * Pad a list to the next power of 2 by duplicating the last element.
     * This is the standard approach for Merkle trees with non-power-of-2 leaves.
     */
    private void padToPowerOfTwo(List<byte[]> list) {
        int size = list.size();
        int nextPow2 = Integer.highestOneBit(size - 1) << 1;
        if (nextPow2 < size) nextPow2 = size; // already a power of 2
        if (Integer.bitCount(size) == 1) return; // already power of 2

        byte[] lastLeaf = list.getLast();
        while (list.size() < nextPow2) {
            list.add(lastLeaf);
        }
    }

    /**
     * Concatenate two byte arrays.
     */
    private byte[] concatenate(byte[] a, byte[] b) {
        byte[] result = new byte[a.length + b.length];
        System.arraycopy(a, 0, result, 0, a.length);
        System.arraycopy(b, 0, result, a.length, b.length);
        return result;
    }

    @Override
    public String toString() {
        return "MerkleTreeBuilder{hashAlgorithm='%s'}".formatted(hashService.getDefaultAlgorithm());
    }
}
