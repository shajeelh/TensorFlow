package com.paymenthub.crypto.signature;

import com.paymenthub.common.model.integrity.SignedBatch;
import com.paymenthub.crypto.hash.HashService;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.*;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Software-based audit signer using ECDSA-P384 via BouncyCastle.
 *
 * <p>Used by the SMALL deployment profile where an HSM is not available.
 * Per ADR-004, this is acceptable with the following mitigations:</p>
 * <ul>
 *   <li>Key rotation every 90 days</li>
 *   <li>Signing key stored in HashiCorp Vault (never in config files)</li>
 *   <li>Key material never leaves the JVM (no export API)</li>
 *   <li>JVM hardened with {@code -XX:+DisableAttachMechanism}</li>
 *   <li>All signing operations are logged and audited</li>
 * </ul>
 *
 * <h3>Algorithm Details</h3>
 * <ul>
 *   <li>Curve: NIST P-384 (secp384r1)</li>
 *   <li>Signature algorithm: SHA384withECDSA</li>
 *   <li>Batch digest: SHA3-256 of concatenated record hashes</li>
 *   <li>Signature output: ~96-104 bytes (DER encoded)</li>
 * </ul>
 *
 * <h3>Thread Safety</h3>
 * <p>Thread-safe. The {@link AtomicLong} batch counter ensures
 * monotonically increasing batch IDs across threads. The
 * {@link Signature} instances are created per-invocation.</p>
 *
 * @see AuditSigner
 */
public class SoftwareAuditSigner implements AuditSigner {

    private static final Logger log = LoggerFactory.getLogger(SoftwareAuditSigner.class);
    private static final String SIGNATURE_ALGORITHM = "SHA384withECDSA";

    private final PrivateKey signingKey;
    private final PublicKey verificationKey;
    private final String keyId;
    private final HashService hashService;
    private final AtomicLong batchCounter;
    private final Instant keyCreatedAt;

    /**
     * Create a software signer with the given key pair.
     *
     * @param signingKey      ECDSA-P384 private key
     * @param verificationKey ECDSA-P384 public key
     * @param keyId           unique identifier for this key (e.g., "sw-2025-001")
     * @param hashService     hash service for batch digest computation
     */
    public SoftwareAuditSigner(PrivateKey signingKey, PublicKey verificationKey,
                                 String keyId, HashService hashService) {
        this.signingKey = Objects.requireNonNull(signingKey, "Signing key required");
        this.verificationKey = Objects.requireNonNull(verificationKey, "Verification key required");
        this.keyId = Objects.requireNonNull(keyId, "Key ID required");
        this.hashService = Objects.requireNonNull(hashService, "Hash service required");
        this.batchCounter = new AtomicLong(0);
        this.keyCreatedAt = Instant.now();

        log.info("SoftwareAuditSigner initialized: keyId={}, algorithm=ECDSA-P384", keyId);
    }

    @Override
    public SignedBatch sign(List<byte[]> recordHashes) {
        Objects.requireNonNull(recordHashes, "Record hashes must not be null");
        if (recordHashes.isEmpty()) {
            throw new IllegalArgumentException("Cannot sign empty batch");
        }

        try {
            // 1. Compute batch digest = HASH(hash1 || hash2 || ... || hashN)
            byte[] concatenated = concatenateHashes(recordHashes);
            byte[] batchDigest = hashService.hash(concatenated);

            // 2. Sign the digest
            Signature sig = Signature.getInstance(SIGNATURE_ALGORITHM, BouncyCastleProvider.PROVIDER_NAME);
            sig.initSign(signingKey);
            sig.update(batchDigest);
            byte[] signature = sig.sign();

            // 3. Create the signed batch
            long batchId = batchCounter.incrementAndGet();

            log.debug("Batch {} signed: {} records, digest={}, keyId={}",
                batchId, recordHashes.size(),
                com.paymenthub.common.util.HexUtils.toShortHex(batchDigest), keyId);

            return new SignedBatch(batchId, List.copyOf(recordHashes),
                batchDigest, signature, keyId, signingMode());

        } catch (GeneralSecurityException e) {
            log.error("Signing failed for batch with {} records", recordHashes.size(), e);
            throw new IllegalStateException("Batch signing failed", e);
        }
    }

    @Override
    public boolean verify(SignedBatch batch) {
        Objects.requireNonNull(batch, "Batch must not be null");

        try {
            Signature sig = Signature.getInstance(SIGNATURE_ALGORITHM, BouncyCastleProvider.PROVIDER_NAME);
            sig.initVerify(verificationKey);
            sig.update(batch.batchDigest());
            boolean valid = sig.verify(batch.signature());

            if (!valid) {
                log.warn("Signature verification FAILED for batch {}, keyId={}",
                    batch.batchId(), batch.signingKeyId());
            }
            return valid;

        } catch (GeneralSecurityException e) {
            log.error("Signature verification error for batch {}", batch.batchId(), e);
            return false;
        }
    }

    @Override
    public String signingMode() { return "software"; }

    @Override
    public String currentKeyId() { return keyId; }

    @Override
    public boolean isHealthy() {
        return signingKey != null && verificationKey != null;
    }

    /**
     * Get the age of the current signing key.
     * Used by the key rotation scheduler to determine when rotation is needed.
     */
    public Instant getKeyCreatedAt() { return keyCreatedAt; }

    /**
     * Get the total number of batches signed with this key.
     */
    public long getTotalBatchesSigned() { return batchCounter.get(); }

    /**
     * Get the verification (public) key for external verification use cases.
     * This is intentionally exposed — public keys are not secret.
     */
    public PublicKey getVerificationKey() { return verificationKey; }

    // ── Internal ─────────────────────────────────────────────

    /**
     * Concatenate all record hashes into a single byte array.
     * This is the input to the batch digest computation.
     */
    private byte[] concatenateHashes(List<byte[]> hashes) {
        int totalLength = 0;
        for (byte[] hash : hashes) {
            totalLength += hash.length;
        }

        byte[] result = new byte[totalLength];
        int offset = 0;
        for (byte[] hash : hashes) {
            System.arraycopy(hash, 0, result, offset, hash.length);
            offset += hash.length;
        }
        return result;
    }

    @Override
    public String toString() {
        return "SoftwareAuditSigner{keyId='%s', batchesSigned=%d, keyAge=%s}"
            .formatted(keyId, batchCounter.get(), keyCreatedAt);
    }
}
