package com.paymenthub.crypto.config;

import com.paymenthub.crypto.encryption.EncryptionService;
import com.paymenthub.crypto.hash.HashService;
import com.paymenthub.crypto.hash.ThreadLocalHashService;
import com.paymenthub.crypto.merkle.MerkleTreeBuilder;
import com.paymenthub.crypto.signature.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * Spring Boot auto-configuration for the crypto starter.
 *
 * <p>Registers all cryptographic beans with sensible defaults.
 * Each bean is {@code @ConditionalOnMissingBean} so modules can
 * override with custom implementations (e.g., HSM-backed signer).</p>
 *
 * <h3>Configuration Properties</h3>
 * <pre>
 * hub.crypto:
 *   hash-algorithm: SHA3-256           # SHA3-256, SHA-256, SHA3-512, SHA-512
 *   signing:
 *     mode: software                   # software, hsm, cloud_hsm
 *     key-rotation-days: 90            # auto-rotation interval
 *   encryption:
 *     enabled: true
 * </pre>
 */
@AutoConfiguration
@EnableConfigurationProperties(CryptoAutoConfiguration.CryptoProperties.class)
public class CryptoAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(CryptoAutoConfiguration.class);

    @Bean
    @ConditionalOnMissingBean
    public HashService hashService(CryptoProperties properties) {
        log.info("Configuring HashService: algorithm={}", properties.getHashAlgorithm());
        return new HashService(properties.getHashAlgorithm());
    }

    @Bean
    @ConditionalOnMissingBean
    public ThreadLocalHashService threadLocalHashService(CryptoProperties properties) {
        return new ThreadLocalHashService(properties.getHashAlgorithm());
    }

    @Bean
    @ConditionalOnMissingBean
    public EncryptionService encryptionService() {
        return new EncryptionService();
    }

    @Bean
    @ConditionalOnMissingBean
    public MerkleTreeBuilder merkleTreeBuilder(HashService hashService) {
        return new MerkleTreeBuilder(hashService);
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(name = "hub.crypto.signing.mode", havingValue = "software", matchIfMissing = true)
    public SigningKeyProvider ephemeralSigningKeyProvider() {
        log.warn("Using EphemeralSigningKeyProvider — keys are in-memory only");
        return new EphemeralSigningKeyProvider();
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(name = "hub.crypto.signing.mode", havingValue = "software", matchIfMissing = true)
    public AuditSigner softwareAuditSigner(SigningKeyProvider keyProvider, HashService hashService) {
        var keyPair = keyProvider.getActiveKeyPair();
        var keyId = keyProvider.getCurrentKeyId();
        log.info("Configuring SoftwareAuditSigner: keyId={}", keyId);
        return new SoftwareAuditSigner(keyPair.getPrivate(), keyPair.getPublic(), keyId, hashService);
    }

    // ── Configuration Properties ─────────────────────────────

    @ConfigurationProperties(prefix = "hub.crypto")
    public static class CryptoProperties {

        /** Hash algorithm. Default: SHA3-256. */
        private String hashAlgorithm = "SHA3-256";

        /** Signing configuration. */
        private SigningProperties signing = new SigningProperties();

        /** Encryption configuration. */
        private EncryptionProperties encryption = new EncryptionProperties();

        public String getHashAlgorithm() { return hashAlgorithm; }
        public void setHashAlgorithm(String hashAlgorithm) { this.hashAlgorithm = hashAlgorithm; }
        public SigningProperties getSigning() { return signing; }
        public void setSigning(SigningProperties signing) { this.signing = signing; }
        public EncryptionProperties getEncryption() { return encryption; }
        public void setEncryption(EncryptionProperties encryption) { this.encryption = encryption; }

        public static class SigningProperties {
            private String mode = "software";
            private int keyRotationDays = 90;
            public String getMode() { return mode; }
            public void setMode(String mode) { this.mode = mode; }
            public int getKeyRotationDays() { return keyRotationDays; }
            public void setKeyRotationDays(int days) { this.keyRotationDays = days; }
        }

        public static class EncryptionProperties {
            private boolean enabled = true;
            public boolean isEnabled() { return enabled; }
            public void setEnabled(boolean enabled) { this.enabled = enabled; }
        }
    }
}
