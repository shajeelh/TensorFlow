package com.paymenthub.crypto.hash;

import com.paymenthub.common.util.HexUtils;
import com.paymenthub.common.util.JsonCanonicalizer;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.util.Arrays;
import java.util.Objects;
import java.util.Set;

/**
 * Core hashing service for the payment hub platform.
 *
 * <p>Provides four categories of hash operations:</p>
 * <ol>
 *   <li><strong>Raw hashing</strong> — {@link #hash(byte[])} for arbitrary data</li>
 *   <li><strong>HMAC</strong> — {@link #hmac(byte[], byte[])} for keyed message authentication</li>
 *   <li><strong>Canonical hashing</strong> — {@link #canonicalHash(Object)} for deterministic
 *       object hashing via RFC 8785 JSON Canonicalization</li>
 *   <li><strong>Chain hashing</strong> — {@link #chainHash(byte[], byte[])} for hash chain
 *       construction: {@code SHA3-256(previousHash || recordHash)}</li>
 * </ol>
 *
 * <h3>Algorithm Support</h3>
 * <p>Default: SHA3-256 (via BouncyCastle provider). Also supports SHA-256,
 * SHA-512, SHA3-512 for backward compatibility and specific use cases.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>All methods are thread-safe. {@link MessageDigest} instances are created
 * per-invocation (they are not thread-safe themselves). For high-throughput
 * paths, consider using the {@link ThreadLocalHashService} wrapper.</p>
 *
 * <h3>Performance</h3>
 * <p>SHA3-256 on modern hardware: ~400 MB/s. For a typical audit event
 * (~2KB canonical JSON), hashing takes ~5μs. Chain hashing adds ~2μs
 * for the concatenation + second hash.</p>
 *
 * @see com.paymenthub.common.util.JsonCanonicalizer
 */
public class HashService {

    private static final Logger log = LoggerFactory.getLogger(HashService.class);

    /** Supported hash algorithms. */
    private static final Set<String> SUPPORTED_ALGORITHMS = Set.of(
        "SHA3-256", "SHA3-512", "SHA-256", "SHA-512"
    );

    private final String defaultAlgorithm;
    private final String provider;

    static {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
            log.debug("BouncyCastle security provider registered");
        }
    }

    /**
     * Create a HashService with the specified default algorithm.
     *
     * @param defaultAlgorithm hash algorithm name (e.g., "SHA3-256")
     * @throws IllegalArgumentException if algorithm is not supported
     */
    public HashService(String defaultAlgorithm) {
        this(defaultAlgorithm, BouncyCastleProvider.PROVIDER_NAME);
    }

    /**
     * Create a HashService with the specified algorithm and JCA provider.
     *
     * @param defaultAlgorithm hash algorithm name
     * @param provider         JCA provider name (e.g., "BC" for BouncyCastle)
     */
    public HashService(String defaultAlgorithm, String provider) {
        Objects.requireNonNull(defaultAlgorithm, "Algorithm must not be null");
        if (!SUPPORTED_ALGORITHMS.contains(defaultAlgorithm)) {
            throw new IllegalArgumentException(
                "Unsupported algorithm: %s. Supported: %s".formatted(defaultAlgorithm, SUPPORTED_ALGORITHMS));
        }
        this.defaultAlgorithm = defaultAlgorithm;
        this.provider = provider;

        // Verify the algorithm is available at construction time
        try {
            getDigest(defaultAlgorithm);
            log.info("HashService initialized: algorithm={}, provider={}", defaultAlgorithm, provider);
        } catch (Exception e) {
            throw new IllegalStateException("Hash algorithm unavailable: " + defaultAlgorithm, e);
        }
    }

    // ── Raw Hashing ──────────────────────────────────────────

    /**
     * Hash arbitrary data using the default algorithm.
     *
     * @param input data to hash (must not be null)
     * @return hash digest bytes
     * @throws IllegalArgumentException if input is null
     */
    public byte[] hash(byte[] input) {
        return hash(input, defaultAlgorithm);
    }

    /**
     * Hash arbitrary data using a specific algorithm.
     *
     * @param input     data to hash
     * @param algorithm hash algorithm name
     * @return hash digest bytes
     */
    public byte[] hash(byte[] input, String algorithm) {
        Objects.requireNonNull(input, "Input must not be null");
        try {
            MessageDigest digest = getDigest(algorithm);
            return digest.digest(input);
        } catch (NoSuchAlgorithmException | NoSuchProviderException e) {
            throw new IllegalStateException("Hash computation failed: " + algorithm, e);
        }
    }

    /**
     * Hash a UTF-8 string using the default algorithm.
     */
    public byte[] hashString(String input) {
        Objects.requireNonNull(input, "Input must not be null");
        return hash(input.getBytes(StandardCharsets.UTF_8));
    }

    // ── HMAC ─────────────────────────────────────────────────

    /**
     * Compute HMAC-SHA256 for keyed message authentication.
     *
     * @param input data to authenticate
     * @param key   HMAC key (minimum 32 bytes recommended)
     * @return HMAC digest bytes
     */
    public byte[] hmac(byte[] input, byte[] key) {
        Objects.requireNonNull(input, "Input must not be null");
        Objects.requireNonNull(key, "Key must not be null");
        if (key.length < 16) {
            log.warn("HMAC key length {} is below recommended minimum of 32 bytes", key.length);
        }
        try {
            Mac mac = Mac.getInstance("HmacSHA256", provider);
            mac.init(new SecretKeySpec(key, "HmacSHA256"));
            return mac.doFinal(input);
        } catch (Exception e) {
            throw new IllegalStateException("HMAC computation failed", e);
        }
    }

    // ── Canonical Hashing ────────────────────────────────────

    /**
     * Hash an object using RFC 8785 canonical JSON serialization.
     *
     * <p>This is the primary method used for audit event hashing.
     * The object is first serialized to canonical JSON (sorted keys,
     * no whitespace, deterministic number format), then the resulting
     * UTF-8 bytes are hashed.</p>
     *
     * @param obj any Jackson-serializable object
     * @return hash digest bytes
     */
    public byte[] canonicalHash(Object obj) {
        Objects.requireNonNull(obj, "Object must not be null");
        byte[] canonical = JsonCanonicalizer.canonicalizeToBytes(obj);
        return hash(canonical);
    }

    // ── Chain Hashing ────────────────────────────────────────

    /**
     * Compute the chain hash linking two events.
     *
     * <p>Formula: {@code chainHash = HASH(previousHash || recordHash)}</p>
     *
     * <p>This creates a backward-linked chain where modifying any
     * prior event invalidates all subsequent chain hashes.</p>
     *
     * @param previousHash hash of the preceding event (all-zeros for genesis)
     * @param recordHash   hash of the current event
     * @return the chain link hash
     */
    public byte[] chainHash(byte[] previousHash, byte[] recordHash) {
        Objects.requireNonNull(previousHash, "Previous hash must not be null");
        Objects.requireNonNull(recordHash, "Record hash must not be null");

        byte[] combined = new byte[previousHash.length + recordHash.length];
        System.arraycopy(previousHash, 0, combined, 0, previousHash.length);
        System.arraycopy(recordHash, 0, combined, previousHash.length, recordHash.length);
        return hash(combined);
    }

    // ── Verification ─────────────────────────────────────────

    /**
     * Verify that a chain link is valid.
     *
     * @param previousHash    hash of the preceding event
     * @param recordHash      hash of the current event
     * @param expectedResult  the expected chain hash to verify against
     * @return true if the chain link is valid
     */
    public boolean verifyChainLink(byte[] previousHash, byte[] recordHash, byte[] expectedResult) {
        byte[] computed = chainHash(previousHash, recordHash);
        return MessageDigest.isEqual(computed, expectedResult);
    }

    /**
     * Constant-time hash comparison (prevents timing attacks).
     */
    public boolean constantTimeEquals(byte[] a, byte[] b) {
        return MessageDigest.isEqual(a, b);
    }

    // ── Accessors ────────────────────────────────────────────

    public String getDefaultAlgorithm() { return defaultAlgorithm; }
    public String getProvider() { return provider; }

    /**
     * Get the output size in bytes for the default algorithm.
     */
    public int getDigestLength() {
        return switch (defaultAlgorithm) {
            case "SHA3-256", "SHA-256" -> 32;
            case "SHA3-512", "SHA-512" -> 64;
            default -> 32;
        };
    }

    /**
     * Create a fresh genesis hash (all zeros) for starting a new chain.
     */
    public byte[] genesisHash() {
        return new byte[getDigestLength()];
    }

    // ── Internal ─────────────────────────────────────────────

    private MessageDigest getDigest(String algorithm)
            throws NoSuchAlgorithmException, NoSuchProviderException {
        return MessageDigest.getInstance(algorithm, provider);
    }

    @Override
    public String toString() {
        return "HashService{algorithm='%s', provider='%s', digestLength=%d}"
            .formatted(defaultAlgorithm, provider, getDigestLength());
    }
}
