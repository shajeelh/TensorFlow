package com.paymenthub.crypto.signature;

import java.security.KeyPair;
import java.security.PublicKey;

/**
 * Abstraction for signing key provisioning and rotation.
 *
 * <p>Implementations handle key generation, storage, and retrieval
 * for different backends:</p>
 * <ul>
 *   <li>{@link EphemeralSigningKeyProvider} — in-memory keys for development/testing</li>
 *   <li>{@code VaultSigningKeyProvider} — HashiCorp Vault transit engine (production SMALL)</li>
 *   <li>{@code HsmSigningKeyProvider} — PKCS#11 HSM (production LARGE/MEDIUM)</li>
 * </ul>
 */
public interface SigningKeyProvider {

    /**
     * Generate a new signing key pair.
     *
     * @return the generated key pair
     */
    KeyPair generateKeyPair();

    /**
     * Get the currently active key pair.
     *
     * @return the active key pair
     */
    KeyPair getActiveKeyPair();

    /**
     * Get the current key identifier.
     */
    String getCurrentKeyId();

    /**
     * Retrieve a public key by its identifier (for verification of old signatures).
     *
     * @param keyId the key identifier
     * @return the public key, or null if not found
     */
    PublicKey getPublicKey(String keyId);

    /**
     * Rotate the signing key. The old key is retained for verification
     * but no longer used for new signatures.
     *
     * @return the new key identifier
     */
    String rotateKey();
}
