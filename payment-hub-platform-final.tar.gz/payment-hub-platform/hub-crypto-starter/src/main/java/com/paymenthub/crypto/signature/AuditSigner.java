package com.paymenthub.crypto.signature;

import com.paymenthub.common.model.integrity.SignedBatch;

import java.util.List;

/**
 * Pluggable interface for audit batch signing.
 *
 * <p>Three implementations are provided, selected by deployment profile:</p>
 * <ul>
 *   <li>{@link SoftwareAuditSigner} — ECDSA-P384 via BouncyCastle. Used by SMALL profile.
 *       Key stored in Vault, rotated every 90 days. Key never leaves the JVM.</li>
 *   <li>{@code HsmAuditSigner} — PKCS#11 HSM. Used by LARGE and MEDIUM profiles.
 *       Keys generated and stored inside the HSM, never exported.</li>
 *   <li>{@code CloudHsmAuditSigner} — AWS CloudHSM / Azure Managed HSM.
 *       Cloud-native alternative for cloud deployments.</li>
 * </ul>
 *
 * <p>The signing contract is batch-oriented: the audit module accumulates
 * record hashes and signs them in configurable batches (Large=500,
 * Medium=200, Small=50) to amortize the cost of HSM round-trips.</p>
 *
 * <h3>Security Properties</h3>
 * <ul>
 *   <li>Non-repudiation: signed batches prove the audit module produced them</li>
 *   <li>Forward integrity: batch IDs are monotonically increasing</li>
 *   <li>Key rotation: {@link #currentKeyId()} tracks which key was used</li>
 * </ul>
 *
 * @see SoftwareAuditSigner
 */
public interface AuditSigner {

    /**
     * Sign a batch of record hashes.
     *
     * <p>The implementation computes a batch digest from the concatenated
     * hashes and signs that digest. The returned {@link SignedBatch} includes
     * the signature, key ID, and signing mode for verification.</p>
     *
     * @param recordHashes list of individual event record hashes
     * @return signed batch containing the signature and metadata
     * @throws IllegalStateException if signing fails (e.g., HSM unavailable)
     */
    SignedBatch sign(List<byte[]> recordHashes);

    /**
     * Verify a previously signed batch.
     *
     * @param batch the signed batch to verify
     * @return true if the signature is valid
     */
    boolean verify(SignedBatch batch);

    /**
     * Get the signing mode identifier.
     *
     * @return "software", "hsm", or "cloud_hsm"
     */
    String signingMode();

    /**
     * Get the current signing key identifier.
     * Changes on key rotation.
     *
     * @return key identifier string
     */
    String currentKeyId();

    /**
     * Check if the signer is healthy and ready.
     *
     * @return true if signing operations can proceed
     */
    default boolean isHealthy() {
        return currentKeyId() != null;
    }
}
