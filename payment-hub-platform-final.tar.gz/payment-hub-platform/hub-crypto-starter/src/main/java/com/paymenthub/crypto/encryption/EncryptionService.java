package com.paymenthub.crypto.encryption;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Objects;

/**
 * AES-256-GCM encryption service for Tier 2 PII field protection.
 *
 * <p>Used by the audit pipeline to encrypt PII-classified fields
 * (full names, email addresses, phone numbers, dates of birth,
 * addresses, IBANs) before storage in the audit trail.</p>
 *
 * <h3>Algorithm Details</h3>
 * <ul>
 *   <li>Cipher: AES-256-GCM (authenticated encryption)</li>
 *   <li>IV: 12 bytes, randomly generated per encryption</li>
 *   <li>Authentication tag: 128 bits</li>
 *   <li>Output format: IV (12 bytes) || Ciphertext || Tag (16 bytes)</li>
 * </ul>
 *
 * <h3>Key Management</h3>
 * <p>Encryption keys are NOT managed by this class. They are provided
 * by the {@code SecretProvider} (Vault/KMS/Secrets Manager) and passed
 * in as raw byte arrays. Key rotation is handled externally.</p>
 *
 * <h3>Thread Safety</h3>
 * <p>Thread-safe. Each operation creates its own {@link Cipher} instance.</p>
 *
 * <h3>Serialization Format</h3>
 * <p>The {@link EncryptedPayload} record provides Base64 serialization
 * suitable for JSON storage in the audit event payload.</p>
 */
public class EncryptionService {

    private static final Logger log = LoggerFactory.getLogger(EncryptionService.class);

    private static final String ALGORITHM = "AES/GCM/NoPadding";
    private static final int GCM_TAG_LENGTH_BITS = 128;
    private static final int IV_LENGTH_BYTES = 12;
    private static final int KEY_SIZE_BITS = 256;

    private final SecureRandom secureRandom;

    public EncryptionService() {
        this.secureRandom = new SecureRandom();
    }

    /**
     * Encrypted data container with serialization support.
     *
     * @param iv         initialization vector (12 bytes)
     * @param ciphertext encrypted data including GCM authentication tag
     */
    public record EncryptedPayload(byte[] iv, byte[] ciphertext) {

        /**
         * Serialize to Base64 string for JSON storage.
         * Format: Base64(IV || Ciphertext)
         */
        public String toBase64() {
            ByteBuffer buffer = ByteBuffer.allocate(iv.length + ciphertext.length);
            buffer.put(iv);
            buffer.put(ciphertext);
            return Base64.getEncoder().encodeToString(buffer.array());
        }

        /**
         * Deserialize from Base64 string.
         */
        public static EncryptedPayload fromBase64(String encoded) {
            Objects.requireNonNull(encoded, "Encoded string must not be null");
            byte[] combined = Base64.getDecoder().decode(encoded);
            if (combined.length < IV_LENGTH_BYTES) {
                throw new IllegalArgumentException("Invalid payload: too short");
            }

            byte[] iv = new byte[IV_LENGTH_BYTES];
            byte[] ciphertext = new byte[combined.length - IV_LENGTH_BYTES];
            System.arraycopy(combined, 0, iv, 0, IV_LENGTH_BYTES);
            System.arraycopy(combined, IV_LENGTH_BYTES, ciphertext, 0, ciphertext.length);
            return new EncryptedPayload(iv, ciphertext);
        }

        /**
         * Total size in bytes (IV + ciphertext + GCM tag).
         */
        public int totalSize() { return iv.length + ciphertext.length; }
    }

    // ── Encryption ───────────────────────────────────────────

    /**
     * Encrypt plaintext data with AES-256-GCM.
     *
     * @param plaintext data to encrypt
     * @param key       AES-256 key (exactly 32 bytes)
     * @return encrypted payload containing IV and ciphertext
     * @throws IllegalArgumentException if key is not 32 bytes
     * @throws IllegalStateException    if encryption fails
     */
    public EncryptedPayload encrypt(byte[] plaintext, byte[] key) {
        Objects.requireNonNull(plaintext, "Plaintext must not be null");
        validateKey(key);

        try {
            // Generate random IV
            byte[] iv = new byte[IV_LENGTH_BYTES];
            secureRandom.nextBytes(iv);

            Cipher cipher = Cipher.getInstance(ALGORITHM);
            GCMParameterSpec gcmSpec = new GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv);
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), gcmSpec);

            byte[] ciphertext = cipher.doFinal(plaintext);
            return new EncryptedPayload(iv, ciphertext);

        } catch (Exception e) {
            throw new IllegalStateException("AES-256-GCM encryption failed", e);
        }
    }

    /**
     * Encrypt a UTF-8 string.
     */
    public EncryptedPayload encryptString(String plaintext, byte[] key) {
        Objects.requireNonNull(plaintext, "Plaintext must not be null");
        return encrypt(plaintext.getBytes(java.nio.charset.StandardCharsets.UTF_8), key);
    }

    // ── Decryption ───────────────────────────────────────────

    /**
     * Decrypt an encrypted payload with AES-256-GCM.
     *
     * @param payload encrypted payload (IV + ciphertext)
     * @param key     AES-256 key (exactly 32 bytes)
     * @return decrypted plaintext
     * @throws IllegalArgumentException if key is invalid
     * @throws IllegalStateException    if decryption fails (wrong key or tampered data)
     */
    public byte[] decrypt(EncryptedPayload payload, byte[] key) {
        Objects.requireNonNull(payload, "Payload must not be null");
        validateKey(key);

        try {
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            GCMParameterSpec gcmSpec = new GCMParameterSpec(GCM_TAG_LENGTH_BITS, payload.iv());
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), gcmSpec);
            return cipher.doFinal(payload.ciphertext());

        } catch (javax.crypto.AEADBadTagException e) {
            throw new IllegalStateException("Decryption failed: authentication tag mismatch " +
                "(wrong key or tampered data)", e);
        } catch (Exception e) {
            throw new IllegalStateException("AES-256-GCM decryption failed", e);
        }
    }

    /**
     * Decrypt to UTF-8 string.
     */
    public String decryptToString(EncryptedPayload payload, byte[] key) {
        byte[] plaintext = decrypt(payload, key);
        return new String(plaintext, java.nio.charset.StandardCharsets.UTF_8);
    }

    /**
     * Decrypt from a Base64-encoded string.
     */
    public byte[] decryptFromBase64(String encoded, byte[] key) {
        return decrypt(EncryptedPayload.fromBase64(encoded), key);
    }

    // ── Key Generation ───────────────────────────────────────

    /**
     * Generate a new random AES-256 key.
     *
     * @return 32 bytes of cryptographically random key material
     */
    public byte[] generateKey() {
        try {
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(KEY_SIZE_BITS, secureRandom);
            SecretKey secretKey = keyGen.generateKey();
            return secretKey.getEncoded();
        } catch (Exception e) {
            throw new IllegalStateException("AES key generation failed", e);
        }
    }

    // ── Validation ───────────────────────────────────────────

    private void validateKey(byte[] key) {
        Objects.requireNonNull(key, "Key must not be null");
        if (key.length != 32) {
            throw new IllegalArgumentException(
                "AES-256 key must be exactly 32 bytes, got " + key.length);
        }
    }

    @Override
    public String toString() {
        return "EncryptionService{algorithm=AES-256-GCM, ivLength=12, tagLength=128}";
    }
}
