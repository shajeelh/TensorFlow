package com.paymenthub.crypto.signature;

import org.bouncycastle.jce.ECNamedCurveTable;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECParameterSpec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.*;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

/**
 * In-memory ECDSA-P384 key provider for development, testing, and
 * initial bootstrap of the SMALL profile.
 *
 * <p><strong>WARNING:</strong> Keys exist only in memory and are lost
 * on JVM restart. In production SMALL profile, this should be replaced
 * with {@code VaultSigningKeyProvider} which persists keys in Vault.</p>
 *
 * <p>Key rotation creates a new key pair and retains the old public key
 * for verification of previously signed batches.</p>
 */
public class EphemeralSigningKeyProvider implements SigningKeyProvider {

    private static final Logger log = LoggerFactory.getLogger(EphemeralSigningKeyProvider.class);
    private static final String CURVE = "P-384";
    private static final String KEY_ALGORITHM = "EC";

    private final AtomicReference<ActiveKey> activeKey = new AtomicReference<>();
    private final Map<String, PublicKey> keyArchive = new ConcurrentHashMap<>();
    private int keySequence = 0;

    static {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }

    public EphemeralSigningKeyProvider() {
        // Generate initial key on construction
        generateAndActivate();
        log.warn("EphemeralSigningKeyProvider active — keys are IN-MEMORY ONLY. " +
            "Use VaultSigningKeyProvider in production.");
    }

    @Override
    public KeyPair generateKeyPair() {
        try {
            ECParameterSpec ecSpec = ECNamedCurveTable.getParameterSpec(CURVE);
            KeyPairGenerator kpg = KeyPairGenerator.getInstance(KEY_ALGORITHM, BouncyCastleProvider.PROVIDER_NAME);
            kpg.initialize(ecSpec, new SecureRandom());
            return kpg.generateKeyPair();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Failed to generate ECDSA-P384 key pair", e);
        }
    }

    @Override
    public KeyPair getActiveKeyPair() {
        ActiveKey current = activeKey.get();
        if (current == null) {
            throw new IllegalStateException("No active signing key");
        }
        return current.keyPair;
    }

    @Override
    public String getCurrentKeyId() {
        ActiveKey current = activeKey.get();
        return current != null ? current.keyId : null;
    }

    @Override
    public PublicKey getPublicKey(String keyId) {
        return keyArchive.get(keyId);
    }

    @Override
    public String rotateKey() {
        String newKeyId = generateAndActivate();
        log.info("Key rotated: new keyId={}, total archived keys={}", newKeyId, keyArchive.size());
        return newKeyId;
    }

    private String generateAndActivate() {
        keySequence++;
        String keyId = "ephemeral-" + keySequence + "-" + System.currentTimeMillis();
        KeyPair keyPair = generateKeyPair();

        ActiveKey newKey = new ActiveKey(keyId, keyPair);
        activeKey.set(newKey);
        keyArchive.put(keyId, keyPair.getPublic());

        log.debug("Activated key: {}", keyId);
        return keyId;
    }

    private record ActiveKey(String keyId, KeyPair keyPair) {}
}
