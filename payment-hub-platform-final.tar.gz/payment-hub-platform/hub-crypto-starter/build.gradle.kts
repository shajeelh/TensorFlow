plugins {
    `java-library`
}

description = "Payment Hub — Cryptographic Services (SHA3-256 hashing, ECDSA-P384 signing, AES-256-GCM encryption, Merkle trees)"

dependencies {
    api(project(":hub-common-model"))

    api("org.bouncycastle:bcprov-jdk18on")
    api("org.bouncycastle:bcpkix-jdk18on")

    implementation("com.fasterxml.jackson.core:jackson-databind")
    implementation("org.springframework.boot:spring-boot-autoconfigure")
    implementation("org.slf4j:slf4j-api")

    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.assertj:assertj-core")
}
